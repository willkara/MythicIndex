# Corporal Darric – Profile

## Basic Information
- Full Name: Darric (surname not mentioned)
- Aliases/Nicknames: None
- Race: Dwarf (Shield Dwarf)
- Race: Dwarf (Shield Dwarf)
- Age: Not specified
- Gender: Female
- Role in Story: City Guard patrol member, proto-Company member
- First Appearance: Chapter 1, Scene 6 (The Vigil)
- Status: Active

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: A perpetually unimpressed expression and a proudly dented shin-guard.
- Typical Clothing: City Guard armor
- Body Language: Steady, reliable presence
- Physical Condition: Combat-ready

## Significance
Corporal Darric is part of Thorne's loyal patrol that rescued Veyra. Her steady, reliable nature makes her a valuable support member of what will become the Last Light Company. She represents the rank-and-file soldiers who form the backbone of any military organization.

## Key Actions
- Helped arrange the bodies of Elara and Borin with respect
- Brought a blue-and-silver pennon to Veyra during recovery
- Participated in the patrol's vigil
- Made jest about Veyra being "steady, stubborn" like dwarven oil
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).

## Personality Traits
- Steady and reliable
- Respectful
- Dry sense of humor
- Team player

## Future Role
Expected to become a support-role infantry specialist in the Last Light Company.


---

# Corporal Darric – Background

## Origin
- **Birthplace**: Waterdeep (Dwarven District)
- **Social Class**: Middle class
- **Cultural Background**: Shield Dwarf; deeply ingrained in clan and community traditions.

## Family
- **Clan**: Darric Clan
- **Family Dynamics**: Darric has a large, boisterous family and is the exasperated but beloved aunt to numerous nieces and nephews. Her off-duty time is often spent at sprawling family dinners, mediating squabbles over brewing techniques and sharing stories of city life.

## History
- **Childhood**: Raised with a strong sense of tradition and duty. She is one of the first women in her direct family line to join the City Watch, a choice she made to both honor her family's history of service and forge her own path within it.
- **Education/Training**: Waterdeep City Guard Academy, with a focus on defensive formations and urban pacification.
- **Hobbies**: She has a secret hobby that contrasts with her gruff exterior: competitive stone-skipping at the city's canals, a pastime requiring a surprising amount of grace and precision.
- **Motivation for Joining the Watch**: It was a matter of family tradition and personal pride. The Darric clan has a long history of serving in the city's garrisons, and she joined to uphold that legacy while proving she was as capable as any of her male relatives.

---

# Corporal Darric – Character Development

## Personality Core
- **Defining Traits**: Reliable, steady, unimpressed, dry sense of humor, deeply loyal to her unit.
- **Core Values**: Clan honor, tradition, duty, the importance of holding your ground.
- **Motivations**: To live up to her family name and to protect the comrades who have become her second family.
- **Fears**: Bringing dishonor to her clan, letting her team down in a critical moment.
- **Internal Conflicts**: The dwarven love of tradition versus the unprecedented, unconventional nature of the Last Light Company's mission.

## Character Arc
- **Starting Point**: A dependable, if somewhat cynical, Corporal in the City Watch, content with her role.
- **Catalyst Events**: Witnessing Veyra's dwarven-like grit and resilience in the face of unimaginable trauma.
- **Current State**: A steadfast member of the Company, providing a grounding, no-nonsense presence that balances the more eccentric specialists.
- **Intended Destination**: To become a respected veteran within the Company, a touchstone of common sense and reliability for the entire team.

## Key Relationships
- **Relationship to Thorne**: Thorne is "The Captain." She respects the rank and the man holding it. She trusts his judgment implicitly because he has never led them astray. She wouldn't call him a friend, but she'd die for him without hesitation.
- **Reaction to Veyra**:
    - **First Thought**: "Gods, look at her. She's got the grit of a quarry-master. Most would be screaming or catatonic. She's... working." Her initial thought is one of professional, almost grudging, respect for Veyra's sheer fortitude, recognizing a shared dwarven value of endurance over emotional display.
    - **Why She Followed**: Loyalty to her unit was the start. The turning point for her was Veyra's quiet, fierce dignity during her recovery. She wasn't broken, she was reforged. Her jest about "dwarven oil" was her way of acknowledging her incredible resilience, a quality highly prized in dwarven culture. She saw that this new path, while uncertain, had more substance and meaning than endless city patrols.


---

# Corporal Darric - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Corporal Darric - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Corporal Darric - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

