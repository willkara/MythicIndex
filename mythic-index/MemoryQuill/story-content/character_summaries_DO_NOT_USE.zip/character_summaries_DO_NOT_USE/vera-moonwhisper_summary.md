# Vera "The Tracker" Moonwhisper - Profile

## Basic Information
- **Full Name**: Vera Moonwhisper
- **Aliases/Nicknames**: "The Tracker"
- **Race**: Half-Elf
- **Class**: Ranger
- **Role in Story**: Scout for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Lean, rangy build developed from years moving through wilderness - efficient muscle for constant travel
- **Hair**: Dark brown hair kept in a practical braid threaded with small feathers, bone beads, and thin leather cords (tokens from different animal allies)
- **Eyes**: TBD
- **Distinguishing Features**: Slightly pointed ears and angular features from half-elven heritage
- **Typical Clothing**: Earth-toned leather and canvas designed for silent movement and weather resistance
- **Body Language**: Alert, observant, tends to scan environments constantly
- **Physical Condition**: Excellent endurance from human side of heritage, built for long pursuits and tracking

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Vera Moonwhisper.

## Personality
- **Archetype**: The Tracker/Seeker
- **Temperament**: Methodical, patient, wary with strangers
- **Positive Traits**: Observant, resourceful, determined, loyal to those who earn trust
- **Negative Traits**: Initial distrust of people, tendency to slip into obsessive patterns
- **Moral Alignment**: Neutral Good (focused on specific goals rather than larger causes)

## Skills & Abilities
- **Expertise**: Tracking, animal communication, wilderness survival, archery
- **Languages**: TBD
- **Education Level**: Self-taught/wilderness training
- **Special Abilities**: Exceptional tracking skills, ability to form partnerships with animals

## Personal Details
- **Habits**: Checking with her raven Echo before trusting human judgment
- **Hobbies**: Collecting tokens from animal allies
- **Personal Quarters**: A round, airy room at the top of one of the Bastion's smaller towers, with a large, covered balcony. The room is sparse, with a simple cot and a chest for her belongings. The floor is covered in a layer of clean sand and dried leaves, bringing the feeling of the forest indoors. This room is a nest, a place of observation. The true heart of the room is a massive, circular table in the center, upon which is a constantly evolving topographical map of the region, crafted from moss, twigs, carved wooden blocks, and polished stones. She uses it to visualize the hunt in three dimensions. The walls are covered in dozens of charcoal sketches of faces, but the most prominent is a series of portraits that attempt to age her lost brother—from a smiling child to a haunted-looking young man. She spends her nights on the balcony with her raven, Echo, listening to the sounds of the world and adding new details to her maps.
- **Likes**: Animals, open wilderness, practical solutions
- **Dislikes**: Enclosed spaces, betrayal, false promises
- **Fears**: Failing to find her brother, returning to desperate obsession

## Combat & Tactics
- **Primary Weapon**: "Whisperwind" - transforming bow-staff passed down through the Moonwhisper family, elegant quarterstaff that converts into a recurve bow with practiced motion
- **Secondary Weapon**: Skinning knife that doubles as close-combat blade - practical tool turned weapon
- **Companion Weapons**: Echo (raven) provides aerial reconnaissance and distraction, forms hunting partnerships with wolves when needed
- **Armor**: Layered leather and canvas designed for silent movement, weather resistance, and blending with natural environments
- **Fighting Style**: Versatile hunter - staff for close quarters defense, bow for ranged precision, seamless transitions between modes
- **Signature Move**: "Hunter's Dance" - fluid transition from staff strikes to bow shots in continuous motion
- **Combat Philosophy**: "Adapt to the terrain, adapt to the prey" - flexibility over rigid tactics
- **Tactical Role**: Forward scout who identifies threats, provides overwatch, and can hold defensive lines when needed

## Psychological Response Matrix
- **In Crisis**: Hyperfocuses on the immediate objective with trained precision, compartmentalizes personal concerns
- **During Negotiation**: Watches exits and reads micro-expressions, but now trusts team to handle social dynamics
- **Moral Dilemma**: Weighs decisions practically - brother's trail has been cold for years, current lives take precedence
- **Team Conflict**: Observes from distance but now offers quiet wisdom when asked rather than completely withdrawing
- **Under Personal Attack**: Notes it for later consideration but doesn't let it derail current mission
- **In Victory**: Takes moment to appreciate success before planning next steps - learned to value small victories

## Voice & Dialogue Patterns
- **Speech Style**: Soft-spoken but more confident than before, still prefers listening to speaking
- **Signature Phrases**: 
  - "Trail's three days old... still worth following" (balanced hope)
  - "Echo agrees" (trusts but verifies animal intelligence)
  - "Every hunt teaches something new"
  - "Whisperwind remembers" (when the weapon helps her track)
- **Mature Perspective**: No longer speaks of brother constantly, mentions him only when relevant
- **Example Dialogue**: "Target went to ground two hours ago. Guards are nervous - Echo counted three on patrol, two more hidden. We can wait them out or find another way."
- **Emotional Tells**: Touches locket when thinking of brother but doesn't let it consume her, runs hand along Whisperwind when planning
- **Growth Indicators**: Now offers suggestions rather than just observations, engages in team planning

## Companions
- **Echo**: A raven companion that serves as both messenger and emotional anchor, helping Vera maintain methodical thinking

## Notes
- Rescued by Veyra during a blizzard while still searching for her long-missing brother
- Changed her approach from desperate obsession to methodical skill after Veyra's influence
- Still maintains hope of finding her brother but it's no longer consuming
- Forms practical partnerships with animals rather than spiritual connections

### Public Perception
- Known as "The Tracker" who can find anyone, even when the City Watch gives up, often with the help of her raven companion, Echo.
- Rumored to communicate with animals, with stories circulating about her getting directions from squirrels and other creatures.
- Her methodical approach to tracking, learned after a period of desperate obsession, is highly respected by those who have witnessed her work.


---

# Vera "The Tracker" Moonwhisper - Background

## Origin
- **Birthplace**: A small, unnamed village on the edge of the High Forest.
- **Birth Date**: TBD
- **Social Class**: Commoner.
- **Cultural Background**: Half-Elven heritage, raised in a small, close-knit human community.

## Family
- **Parents**: TBD
- **Siblings**: Younger brother, Liam (kidnapped as a child, fate unknown).
- **Extended Family**: TBD
- **Family Dynamics**: Her family life was shattered by the loss of her brother, a tragedy that has defined her entire existence.

## History
- **Childhood**: 
  - *Key Events*: The kidnapping of her younger brother, Liam, by a shadowy slaver ring known as the "Silent Hand."
  - *Formative Experiences*: As the older sibling, Vera was supposed to be watching Liam while they were playing in the woods just outside their village. She was distracted for a single, crucial moment by a rare bird, and when she looked back, he was gone. There was no sound, no struggle, just an eerie silence. This personal, momentary lapse is the source of her deep, gnawing guilt.
  
- **Education/Training**: 
  - *Institutions*: Self-taught in the harsh classroom of the wilderness.
  - *Mentors*: The animals of the forest became her teachers when the people of her village failed her.
  - *Areas of Study*: Tracking, wilderness survival, animal communication, and the art of becoming unseen.
  
- **Adolescence/Young Adulthood**:
  - *Key Events*: After the local authorities gave up their search for Liam, Vera began her own. She spent years in a desperate, obsessive search, honing her skills but losing her connection to humanity.
  - *Relationships*: She formed practical, non-magical partnerships with animals, finding them more reliable than people.
  - *Choices & Consequences*: She chose a life of isolation and single-minded pursuit, sacrificing a normal existence for her all-consuming mission.
  
- **Major Life Events**:
  - *Event 1*: The Kidnapping of Liam - The traumatic event that set her life's course.
  - *Event 2*: The Meeting with Echo - Years into her search, at her absolute lowest point, she collapsed in the snow, ready to give up. A lone, scrappy raven, also a survivor, landed nearby and simply... stayed. Its persistent, silent presence became her anchor, a reflection of her own stubborn will to live. She named him "Echo," and in emulating his methodical survival, she began to transform her raw obsession into a true skill.
  - *Event 3*: The Rescue by Veyra - While tracking a false lead, she was caught in a blizzard and found, near death, by Veyra and the nascent Last Light Company.
  - *Event 4*: The Turning Point - Veyra's words, "Hope is a tool. Learn to use it better," gave Vera the final piece of the puzzle she needed to channel her grief and guilt into a focused, professional purpose.
  - *Event 5*: The "Silent Hand" Mission - Vera's relentless research uncovered a credible lead on the "Silent Hand," the very slaver ring that took her brother. The mission to rescue a group of children from a fortified compound became deeply personal, the first real hope she'd had in years. Her personal stake in the mission was the direct catalyst for the Company hiring Korrath Threnx and Cidrella Vexweld.

## Backstory Elements
- **Defining Moments**: 
  - The moment of distraction that led to her brother's kidnapping.
  - The quiet, persistent companionship of Echo at her lowest point.
  - Hearing Veyra's philosophy, which offered her a new way to live with her mission.
  
- **Past Trauma**: 
  - The loss of her brother and the deep guilt she carries for it.
  - The years of isolation and futile searching.
  - The feeling of being abandoned by her community and the authorities.
  
- **Greatest Achievements**: 
  - Surviving alone in the wilderness for years.
  - Developing her extraordinary tracking skills from scratch.
  - Forging a unique, symbiotic relationship with her animal network.
  
- **Biggest Failures**: 
  - Her inability to find her brother, despite dedicating her life to the search.
  - The single, unforgivable moment of inattention that she believes cost her brother his freedom.
  
- **Secrets**: 
  - She carries the full weight of her perceived responsibility for her brother's disappearance, a secret she has never shared with anyone.

## How They Got Here
- **Reason for Current Situation**: Rescued by Veyra and given a new perspective, Vera found in the Last Light Company a way to use her hard-won skills for a greater purpose. It offered her a community that understood loss and a structured, methodical way to continue her search without being consumed by it.
- **Path to Current Location**: 
  - Years of wilderness tracking -> The meeting with Echo -> Near-death in a blizzard -> Rescue by Veyra -> Joining the Last Light Company.
  
- **Goals Prior to Story Start**: 
  - To find her kidnapped brother.
  - To transform her desperate obsession into a focused, professional skill.

## Historical Connections
- **Connection to Main Plot**: Member of the Last Light Company as Scout. The "Silent Hand" slaver ring is a potential recurring antagonist.
- **Connection to Other Characters**: 
  - Rescued by Veyra and deeply influenced by her philosophy.
  - Her personal quest for her brother was the direct catalyst for the mission that brought Korrath Threnx and Cidrella Vexweld into the Last Light Company.
  
- **Connection to Story World**: 
  - Extensive knowledge of the wilderness areas of the Sword Coast.
  - A unique, non-magical connection to the animal life of the region.

## Timeline
- Childhood in a small village on the edge of the High Forest.
- Younger brother, Liam, is kidnapped by the "Silent Hand" slaver ring.
- Spends years in an increasingly desperate and isolated search.
- At her lowest point, she meets Echo, a raven who becomes her anchor and companion.
- Her tracking skills sharpen from raw obsession into methodical expertise.
- Is caught in a blizzard and rescued by Veyra Thornwake.
- Inspired by Veyra's philosophy, she joins the Last Light Company as its Scout.
- Currently serves as the Company's tracker while maintaining her personal mission to find her brother.

## Personal Details
- **How She Relaxes**: She finds calm in the quiet observation of her animal allies, particularly Echo. She will spend hours on the balcony of her Aerie, simply watching him preen his feathers or observing the subtle interactions of the birds in the courtyard below. It's a silent, comfortable form of communication that requires no words and carries no risk of misunderstanding.
- **Favorite Meal**: Smoked river trout with wild berries and nuts. It's the ultimate survivalist's meal—food she can easily forage and prepare herself in the wild. It's not just a preference; it's a taste of self-reliance and competence, a reminder of the skills that have kept her alive for years.
- **A Prized Possession**: She carries a small, smooth river stone in her pocket. It was the last thing her brother, Liam, gave her, found on the bank of the stream where they were playing just before he was taken. She will often turn it over and over in her hand, the cool, smooth surface a tangible link to her past and the driving force of her mission.
- **Hobby**: **Scrimshaw and Bone Carving.** During her long, solitary years in the wilderness, Vera learned to pass the quiet hours by carving intricate designs into animal bones and teeth she found naturally. Her carvings are not morbid, but beautiful and detailed depictions of the animals and landscapes she has seen. It's a quiet, patient art form that requires the same focus and steady hand as tracking, and it's a way for her to honor the natural world she is so deeply connected to.


---

# Vera "The Tracker" Moonwhisper - Character Development

## Personality Core
- **Defining Traits**: Observant, methodical, resourceful, wary
- **Core Values**: Loyalty, perseverance, practical solutions, animal partnerships
- **Motivations**: Finding her missing brother, honoring Veyra's influence by becoming more methodical
- **Fears**: Returning to desperate obsession, failing to find her brother
- **Internal Conflicts**: Need for human connection vs. trust issues, hope vs. pragmatism
- **Contradictions**: Independent yet relies on Echo for emotional stability, wary of people but part of a team

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Desperate searcher consumed by loss
  - *World View*: People fail, animals don't
  - *Key Relationships*: Absent (humans), utilitarian (animals)
  
- **Catalyst Events**:
  - *Event 1*: Brother's kidnapping - start of her obsessive search
  - *Event 2*: Being rescued by Veyra during blizzard
  - *Event 3*: Veyra's words: "Hope is a tool. Learn to use it better"
  
- **Current State**:
  - *Self-Perception*: Skilled tracker with purpose beyond personal quest
  - *World View*: Still cautious about people but recognizes value in select human connections
  - *Key Relationships*: Echo (raven), Veyra (mentor), animal network, Last Light Company
  
- **Intended Destination**:
  - *Self-Perception*: TBD - perhaps finding peace whether brother is found or not
  - *World View*: TBD - potentially developing greater trust in humans
  - *Key Relationships*: TBD - possibly resolving brother storyline, deeper integration with Last Light Company

## Growth Milestones
- **From Desperate Searcher to Methodical Tracker**: 
  - *Development Noted*: Changed approach after Veyra's influence
  - *Catalyst*: Near-death experience in blizzard, Veyra's philosophy
  - *Impact*: More effective tracking, less consumed by obsession
  
- **From Isolated to Team Member**: 
  - *Development Noted*: Joining Last Light Company
  - *Catalyst*: Trust built with Veyra
  - *Impact*: Applying skills to help others while continuing personal quest

## Character Flaws
- **Trust Issues**: 
  - *Effects on Character*: Initial wariness with new people, emotional distance
  - *Effects on Others*: May seem aloof or difficult to connect with
  - *Development Plan*: Gradual building of trust through shared experiences with Last Light Company
  
- **Tendency toward Obsession**: 
  - *Effects on Character*: Risk of slipping back into unhealthy patterns
  - *Effects on Others*: Might prioritize brother search over team needs at critical moments
  - *Development Plan*: Echo serves as anchor to methodical thinking, preventing backslide

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Possible feelings of responsibility for brother's kidnapping
  - *Secret 2*: May have information about brother she hasn't shared
  
- **Unknown to Character (Potential Story Hook):**
  - *Truth 1*: Echo is not just a raven. He is the reincarnated spirit of her lost brother, Liam. After dying in the hands of the "Silent Hand," his spirit was drawn to a raven's form and found its way back to his sister, becoming her silent protector and guide. The full truth of this is a major potential plot revelation, likely to be discovered through the intervention of Nireya Voss.
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD - brother's fate
  - *Planned Reveal*: TBD
  - *Expected Impact*: Would fundamentally change her core motivation

## Key Decisions & Turning Points
- **Decision to Search for Brother**:
  - *Context*: Childhood trauma of kidnapping
  - *Options Considered*: Unknown
  - *Choice Made*: Dedicated life to finding him
  - *Consequences*: Years of isolation, development of tracking skills, animal partnerships
  
- **Accepting Veyra's Help/Philosophy**:
  - *Context*: Near-death in blizzard
  - *Options Considered*: Continue alone or accept new perspective
  - *Choice Made*: Embraced Veyra's "hope as a tool" philosophy
  - *Consequences*: More methodical approach, joining Last Light Company

## Development Notes
- Character represents transformation from obsession to methodology
- Echo serves as both practical companion and emotional/psychological anchor
- Development path likely involves resolution of brother storyline
- Trust issues provide opportunities for growth through team dynamics
- Connection to animals is practical rather than spiritual - pragmatic partnerships formed from necessity
- The small locket with brother's picture represents both motivation and potential character growth if/when resolved

## Psychological Profile
*   **Vera Moonwhisper (The Seeker):** Vera's psychology is a pendulum swinging between obsessive focus and methodical patience. The search for her brother has defined her entire life, making her wary of people and more comfortable with the honesty of animals. Veyra's influence has tempered her desperation into a professional skill, but the obsessive fire is still there. She fears returning to that desperate state, and her trust, once given, is absolute and fierce.


---

# Vera "The Tracker" Moonwhisper - Relationships

## Family Bonds
- **Missing Brother**: 
  - *Relationship Type*: Sibling, primary motivation
  - *History*: Kidnapped as a child, spent years searching for him
  - *Current Status*: Missing, would now be a grown man
  - *Feelings Toward*: Deep guilt, responsibility, unwavering determination to find him
  - *Tensions/Issues*: The passing of time makes recognition increasingly difficult
  - *Shared Experiences*: Childhood memories before the kidnapping

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Rescuer, commander, mentor
  - *Hierarchy*: Veyra as Commander of Last Light Company
  - *Dynamics*: Deep respect from Vera, influenced by Veyra's philosophy
  - *History*: Veyra found her half-dead in a blizzard, still hunting for traces of her brother
  - *Current Status*: Commander and subordinate, possibly friendship
  - *Professional Opinion of*: High regard for Veyra's wisdom and leadership
  - *Memorable Interactions*: Veyra's words "Hope is a tool. Learn to use it better" changed her approach to searching

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Thorne as Deputy Commander
  - *Dynamics*: Likely works with him on tactical operations utilizing her tracking skills
  - *History*: TBD when they first met
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely respects his tactical mind but may be reserved in personal interactions

- **Brother Aldwin Gentleheart**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties (tracking vs. medical)
  - *Dynamics*: His healing abilities support her tracking work; may find common ground in their observant natures
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely respects his calm presence and healing skills

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Mentor and mentee; "The Old Rock and the Young Sapling."
  - *Hierarchy*: Equals, but with a clear mentor-mentee dynamic.
  - *Dynamics*: Grimjaw has taken on a paternal, protective role with Vera. He sees her fierce spirit and the fragility beneath it. He doesn't offer advice on her tracking—that's her domain—but on endurance and self-preservation. He is the one who ensures she eats and rests, often sharing a quiet meal with her by the fire pits. His steady, grounding presence is a silent source of comfort and stability for her.
  - *History*: TBD
  - *Current Status*: Close mentor-mentee bond.
  - *Feelings Toward*: She sees him as a steadfast, protective figure, a source of quiet strength.

- **Lyralei Stormcaller**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: Her weather magic might assist with tracking conditions or provide cover
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her magical capabilities

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: His diplomatic skills complement her tracking information gathering
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values his negotiation abilities

- **Nireya Voss**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: Her spiritual abilities might provide different kinds of tracking information
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Finds her spiritual approach mysterious but respects results

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: Her technical innovations might enhance tracking capabilities
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her problem-solving abilities

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: His structural knowledge could help locate targets within buildings
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his engineering expertise

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: "The Outsiders' Alliance"; quiet friendship.
  - *Hierarchy*: Equals.
  - *Dynamics*: Both Vera and Kaida are deeply wary of people due to past betrayals. They have a quiet, minimalist friendship built on shared observation rather than conversation. They might spend hours together in the courtyard, one practicing with her tools, the other observing the patterns of birds, finding a strange comfort in each other's silent, professional competence. They understand each other's need for space and self-reliance.
  - *History*: TBD
  - *Current Status*: A quiet, unspoken alliance.
  - *Feelings Toward*: A sense of kinship with a fellow outsider. She trusts Kaida's professionalism, if not her history.

## Adversaries
- **Silent Hand (slaver ring)**: The network responsible for her brother's disappearance. They operate in cells with a winter "harvest season" and represent Vera's primary long-term antagonist and the driving force of her personal quest (evidence: chapters/ch10).

## Animal Connections
- **Echo (Raven Companion)**:
  - *Relationship Type*: Primary animal companion, emotional anchor
  - *History*: Unknown when they first bonded
  - *Current Status*: Constant companion
  - *Feelings Toward*: Deep trust, partnership
  - *Tensions/Issues*: None apparent
  - *Shared Experiences*: Serves as both messenger and reminder to stay methodical
  - *Communication*: Seems to have a special understanding with this animal

- **Animal Network**:
  - *Relationship Type*: Practical partnerships
  - *History*: Formed when humans failed her during desperate searching years
  - *Current Status*: Ongoing information network
  - *Dynamics*: Not spiritual reverence but practical alliance
  - *Notes*: Occasionally asks her animal network about "a boy who would be a man now"

## Interpersonal Patterns
- **Trust Issues**:
  - *Origin*: When people failed her during desperate searching years
  - *Manifestation*: Wariness with new people, tendency to check with Echo before trusting human judgment
  - *Exceptions*: Veyra earned her trust through actions rather than words
  - *Development*: Slowly learning to trust select humans again through Last Light Company

## Relationship Evolution Tracker
- **Pre-Brother's Kidnapping**: Normal familial relationships, limited information
- **Post-Kidnapping to Rescue**: Animals became primary allies when humans failed her
- **Rescue by Veyra**: Beginning of trust in humans again, specifically Veyra
- **Current**: Member of Last Light Company, maintains animal partnerships while developing human connections


---

# Vera "The Tracker" Moonwhisper — Dialogue & Psyche

## Core temperament
Focused, quietly intense, and perceptive. Tracker instincts make her observant and economical with words; she speaks to patterns and instincts rather than abstractions.

## Dialogue instincts
- Public: concise, observational—notes details others miss; often speaks in practical metaphors from nature.
- Tracking/skill use: speaks in short declaratives, pointing out evidence and inference.
- Under pressure: calm, quietly urgent; instructive to teammates in minimal phrases.
- Humor: dry, occasional wryness—rarely the source of levity.

## Emotional anchors & physical tells
- Fingers tracing surfaces or adjusting cloak: thinking/reading environment.
- Eyes narrow to focus; a softening gaze is rare and indicates trust.
- Brief, clipped phrases denote urgency or alert.

## Conflict & humor rules
- Avoids obvious bravado; will not mock lost causes lightly.
- Uses humor as a salve for awkward social moments, not for deep grief.
- Breaks pattern with rare personal confessions, usually short and earthy.

## Writer cues (practical)
- Use Vera to provide scene detail and to point out small physical clues that advance dialogue.
- When adding lines, let her provide precise observations that other characters then act on.
- Keep her metaphors tied to fauna, tracking, and landscape—avoid romantic abstractions.

## Drop-in sample lines
- Observation: "Boot treads here—two sets, left foot deeper. They moved downhill."
- Command/alert: "Move low. Wind's changing; scent will carry."
- Soft moment: "You read stone like a story. I read trees. We both listen."

## Voice evolution note (chapters 1–9)
- Began as a taciturn specialist; becomes more socially integrated, offering practical counsel and rare warmth as she trusts the Company.

## Usage examples (scenes)
- Recon: short, factual lines that reveal hidden paths or signs.
- Interactions with Kaida: sharing of craft-respecting banter.
- Quiet camp moments: terse, comfortable remarks that show slow thawing of trust.

## Notes for editors
- Keep Vera's lines precise and sensory. Avoid overly lyrical lines outside private scenes.


---

# Vera "The Tracker" Moonwhisper - Scene Tracker

## Major Scenes

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 4**: Found half-dead in winter forest by the Company, protected by animals
- **Scene 5**: Rescued and warmed, animals' protective behavior noted
- **Scene 6**: Recovery at Westwall Watchpost, initial conversation with Veyra about lost brother
- **Scene 8**: Demonstrates tracking abilities and beast sense to find kidnapped children
- **Scene 9**: Confronts Silent Hand trafficker, kills him with frost-covered thorny vines
- **Scene 9**: Officially recruited into the Last Light Company
- **Epilogue**: Settles into "The Aerie" quarters, bonds with Company at dinner

## Character Moments

### Best Moments
- Animals protecting her with leaves and offerings in the winter cold
- Using beast sense through Echo to locate the kidnapped children
- Taking vengeance on the Silent Hand trafficker
- Finding acceptance with the Last Light Company

### Worst Moments  
- Nearly freezing to death while searching for her brother
- Being told by the trafficker that her brother was "sold three times over"

### Turning Points
- Veyra's words: "Hope is a tool. Learn to use it better"
- Killing the trafficker - first confirmed Silent Hand member eliminated
- Accepting Veyra's offer to join the Company

## Interaction Log

### With Veyra Thornwake
- Chapter 10: Rescued, mentored, recruited - shared understanding of loss

### With Echo (Raven Companion)
- Chapter 10: Constant companion throughout, possible deeper connection hinted

### With Grimjaw Ironbeard
- Chapter 10: Pragmatic discussion about interrogation vs execution

### With Aldwin Gentleheart
- Chapter 10: Medical care during recovery, discussion of herbs for beast sense

### With Animals
- Chapter 10: Protected by forest creatures, demonstrates deep druidic connection

## Upcoming Scenes

### Planned Appearances
- Continued tracking missions with the Company
- Investigation into the Silent Hand operations
- Potential revelation about Echo's true nature

### Required Interactions
- Further bonding with Company members
- Exploration of her druidic abilities
- Pursuit of brother's trail through Silent Hand connections


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

