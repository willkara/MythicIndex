# Lyralei Stormcaller - Profile

## Basic Information
- **Full Name**: Lyralei Stormcaller
- **Aliases/Nicknames**: Weather Mage
- **Race**: Elf
- **Class**: Wizard
- **Role in Story**: Magical Support for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Typical elven height and slender build
- **Hair**: Most striking feature - a living representation of a storm that shifts from dark, loamy brown at the roots to stormy gray in the middle, ending in pure white at the tips like a storm cloud giving way to snow. When emotional or casting, a faint breeze seems to rustle through it even indoors.
- **Eyes**: Change with mood and weather - bright cloudless blue on clear days, darkening to stormy gray when concentrating, with tiny sparks of lightning visible in their depths
- **Distinguishing Features**: 
  - A delicate, silvery scar traces a branching path from her temple down her cheek - not disfiguring but beautiful, like fossilized lightning that sometimes glows with soft blue light during spellcasting
  - A single shimmering phoenix feather woven into one of her braids, catching light like a tiny flickering flame
- **Typical Clothing**: Practical mage attire suited for field work, with earth and sky adornments - an amber necklace with a prehistoric insect trapped within, silver raindrop earrings, and rings with polished river stones and swirling wind designs
- **Body Language**: Precise, calculated movements with occasional unpredictable gestures (like weather patterns)
- **Physical Condition**: Healthy, with an otherworldly quality from her brief experience trapped between dimensions

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Lyralei Stormcaller.

## Personality
- **Archetype**: The Academic/Researcher
- **Temperament**: Structured, analytical, intellectually curious
- **Positive Traits**: Brilliant, detail-oriented, methodical, knowledge-seeking
- **Negative Traits**: Possibly overly focused on research goals, may take calculated risks
- **Moral Alignment**: Neutral Good (primarily concerned with advancing knowledge while helping others)

## Skills & Abilities
- **Expertise**: Weather magic, planar convergence theory, elemental manipulation
- **Languages**: Common, Elvish, likely Primordial and other languages related to elemental planes
- **Education Level**: Highly educated in arcane theory and planar studies
- **Special Abilities**: 
  - Weather manipulation (can influence local atmospheric conditions)
  - Limited ability to detect planar anomalies from her experience trapped between dimensions
  - Theoretical understanding of planar convergence points
  - Connection with phoenix familiar

## Personal Details
- **Habits**: Taking meticulous notes on magical phenomena
- **Hobbies**: Studying ancient magical texts, experimenting with weather spells
- **Personal Quarters**: A circular room directly beneath the Aerie in the Tower of Innovation. The most prominent feature is a massive, domed skylight of reinforced, enchanted glass that serves as the floor of the observatory above. The room is a comfortable chaos of books and scrolls, stacked in precarious towers on every available surface. This is her personal library and think-tank. The light in the room is never constant, shifting in color and intensity as the magical energies from the Aerie's instruments filter down through the skylight. She often falls asleep in a large, overstuffed armchair, a heavy tome resting on her chest. One entire wall is a massive chalkboard, covered from top to bottom in a chaotic but brilliant scrawl of arcane equations, weather predictions, and complex planar charts. Her phoenix familiar has a grand, magically-warmed perch of driftwood near the ceiling, from which it occasionally drops shimmering, harmless ash that she collects in a small crystal bowl on her desk.
- **Likes**: Academic discussion, discovering new magical theories, proving hypotheses
- **Dislikes**: Dismissal of theoretical magic, rigid thinking, limitations on research
- **Fears**: Possibly being permanently trapped between planes

## Combat & Tactics
- **Primary Weapon**: "Axiom" - crystal-tipped staff that serves as both weather focus and lightning rod, named for fundamental truths of magic
- **Phoenix Familiar**: "Quill" - mystical firebird who guided her back from between dimensions, serves as aerial scout and living reminder of rebirth
- **Spell Focus**: Earth and sky adornments that resonate with elemental forces - amber for earth, silver for air
- **Armor**: Flowing robes that shift color with weather patterns - practical protection through magical deflection
- **Fighting Style**: Environmental controller - changes battlefield conditions through atmospheric manipulation
- **Signature Move**: "Eye of the Storm" - creates localized weather phenomena from fog to lightning strikes
- **Combat Philosophy**: "Nature is neither cruel nor kind, merely inevitable - I simply adjust the timetable"
- **Tactical Role**: Battlefield manipulation through weather control, aerial superiority via Quill's reconnaissance

## Psychological Response Matrix
- **In Crisis**: Calculates probabilities like solving equations - "Given these variables, the optimal solution is..."
- **During Negotiation**: Provides literal environmental pressure - storm clouds as visual representation of tension
- **Moral Dilemma**: Seeks precedent in magical theory and documented cases before deciding
- **Team Conflict**: Offers perspective from "30,000 feet" - both literally (via Quill) and metaphorically
- **Under Personal Attack**: Treats it as peer review - takes notes on criticism for later analysis
- **In Victory**: Documents everything - magical expenditure, weather patterns, unexpected interactions
- **Research Mode**: Complete tunnel vision - Cid builds while thinking, Lyralei theorizes while forgetting to eat

## Voice & Dialogue Patterns
- **Speech Style**: Academic precision with weather metaphors, often explaining theory during action
- **Signature Phrases**: 
  - "According to Axiom's readings..." (treating her staff like a measurement device)
  - "Statistically speaking..." (before doing something risky)
  - "Fascinating! Quill, are you recording this?"
  - "The probability matrix suggests..."
- **Academic Counterpoint to Cid**: Where Cid says "Let's try it!", Lyralei says "My calculations indicate a 73% success rate"
- **Example Dialogue**: "The barometric pressure via Axiom indicates precipitation in—oh, Quill's feathers are already smoking. Make that immediate precipitation."
- **Emotional Tells**: Hair moves faster when excited, consults Axiom like checking notes, Quill mimics her hand gestures
- **Teaching Mode**: Can't help but lecture even in combat - "Notice how the thermal updraft creates a perfect—duck!"

## Notes
- Views her dimensional accident as "an occupational hazard of the job" rather than trauma
- Joined the Last Light Company to study planar anomalies and magical sites they encounter during rescue operations
- Has excellent relationships with Cid (kindred spirit in pursuit of knowledge) and Nireya (shared respect for magic despite philosophical differences)
- More structured and academic in her approach to magic compared to other practitioners
- Sometimes engages in respectful philosophical arguments about "pushing boundaries to learn more" versus "accepting magic as simply part of life's natural order"

### Public Perception
- Known as the "Weather Mage," with rumors of her magic being unpredictable and having a mind of its own, sometimes with unintended consequences.
- Her phoenix familiar is a source of both awe and unease, seen by some as a sign of good luck and by others as a sign of meddling with dangerous forces.
- Respected for her brilliant mind and academic approach to magic, often working with Vera to track and locate missing persons.


---

# Lyralei Stormcaller - Background

## Origin
- **Birthplace**: TBD (likely an elven community with strong connections to arcane studies)
- **Birth Date**: TBD
- **Social Class**: Likely scholarly or academic class
- **Cultural Background**: Elven with focus on magical scholarship

## Family
- **Parents**: TBD
- **Siblings**: TBD
- **Extended Family**: TBD
- **Family Dynamics**: TBD

## History
- **Childhood**: 
  - *Key Events*: Likely showed early aptitude for elemental magic, particularly weather-related phenomena
  - *Formative Experiences*: Early education in magical theory
  
- **Education/Training**: 
  - *Institutions*: Formal magical academy or university focusing on elemental and theoretical magic
  - *Mentors*: Various magical scholars and researchers (specific names TBD)
  - *Areas of Study*: Weather magic, planar theory, elemental manipulation
  
- **Professional Career**:
  - *Early Research*: Initial studies in conventional weather magic
  - *Specialization*: Development of interest in planar convergence theory
  - *Breakthrough*: Discovery of theoretical connections between weather magic and planar convergence points
  - *Expedition Work*: Field research at various planar convergence sites
  
- **Major Life Events**:
  - *The Dimensional Accident*: During an expedition to a volatile convergence site, attempted to channel the intersection of the Elemental Planes of Air, Water, and Fire simultaneously
  - *Interdimensional Trapping*: The experiment created unexpected planar instabilities that temporarily trapped her between dimensions
  - *Phoenix Encounter*: While trapped between planes, discovered her phoenix familiar who guided her back to the material plane
  - *Recovery and Research*: Continued studies with new insights from interdimensional experience
  - *Joining the Last Light Company*: Sought out the company believing their rescue operations brought them into contact with planar anomalies and ancient magical sites needed for her research

## Backstory Elements
- **Defining Moments**: 
  - The dimensional accident and subsequent survival
  - Discovery of her phoenix familiar
  - First successful application of planar convergence theory to weather magic
  
- **Past Trauma**: 
  # Lyralei Stormcaller - Background

## Origin
- **Birthplace**: TBD (likely an elven community with strong connections to arcane studies)
- **Birth Date**: TBD
- **Social Class**: Scholarly / Academic
- **Cultural Background**: Elven with focus on magical scholarship

## History
- **The Radical Theory**: As one of the academy's most promising weather wizards, Lyralei grew frustrated with the limitations of her field. She developed a radical theory: to truly master weather, one must understand its ultimate source—the "harmonic echoes" of events from other planes vibrating through the Weave. She began to dabble in broader elemental and planar magic, not as a new focus, but as a necessary means to deepen her understanding of meteorology. Her mentor, Master Valerius, respected her ambition but feared her methods.

- **The Experiment & The Phoenix**: To prove her theory, she used an abandoned observatory on a convergence point tied to the Plane of Fire—the nascent territory of a young phoenix, Quill. Her attempt to "strum the Weave" succeeded catastrophically, proving her theory while tearing a hole in reality. The resulting magical chaos threatened both her and the phoenix. In an act of mutual self-preservation, Quill bonded with her, its cyclical energy of rebirth stabilizing the event and pulling her back from the void. This was Quill's first, premature rebirth, and it tied them together permanently, leaving the lightning-like scar on Lyralei's face.

- **The Aftermath**: Lyralei returned scarred but with invaluable data. Her reaction was not one of horror, but of academic fascination. The academy, led by a somber Master Valerius, acknowledged the brilliance of her discovery but could not condone the danger of her methods. With a heavy heart on both sides, it was mutually agreed that she must leave. "The truth you seek is valid, Lyralei," Valerius told her, "but the path to it is too dangerous for these walls to contain." She departed not as a failure, but as a pioneer who had outgrown the confines of traditional academia.

## Backstory Elements
- **Defining Moments**: 
  - The dimensional accident that proved her theory but forced her from the academy.
  - The symbiotic bonding with her phoenix familiar, Quill.
  
- **Past Trauma**: She views the accident as a successful, if costly, experiment rather than a trauma. Her primary regret is the loss of the observatory, a valuable historical site.

- **Greatest Achievements**: 
  - Advancing magical theory in a significant way.
  - Forming a bond with a phoenix.

## How They Got Here
- **Reason for Current Situation**: After leaving the academy, Lyralei sought a way to continue her field research. The Last Light Company, with its focus on missions to dangerous and ancient locations, represents the perfect opportunity to gather more data on planar convergence and weather phenomena.

## Historical Connections
- **Connection to Main Plot**: Magical Support for the Last Light Company.
- **Connection to Other Characters**: 
  - **Aldwin Gentleheart**: She knew him from the academy. He found her detached then, but now sees the profound change in her, viewing her with a healer's compassion.
  - **Cid Vexweld**: Views Cid as a kindred spirit in the relentless pursuit of knowledge, though their methods differ wildly.
  - **Nireya Voss**: Shares a respectful admiration for magic, though they sometimes have philosophical disagreements.

## Timeline
- Early career as a promising weather wizard at a prestigious academy.
- Develops her radical theory on planar harmonics.
- Conducts the fateful experiment at the abandoned observatory.
- Bonds with Quill and is forced to leave the academy.
- Joins the Last Light Company to continue her field research.

## Personal Details
- **How She Relaxes**: She finds calm in creating intricate, temporary weather systems in a bottle.
- **Favorite Meal**: Spiced Air-Popped Sorghum with a side of lightning-seared fish.
- **A Unique Habit**: She can accurately "smell" the weather, a sensory side-effect of her deep attunement to atmospheric magic.

  - Possibly academic rejection of her theories before proving them
  
- **Greatest Achievements**: 
  - Surviving interdimensional trapping
  - Advancing planar convergence theory
  - Creating new weather magic techniques based on ancient texts
  
- **Biggest Failures**: 
  - The experiment that went wrong, though she views it as a learning experience rather than failure
  - Potentially other magical experiments with unexpected results
  
- **Secrets**: 
  - May have deeper knowledge of the planes than she reveals
  - Possibly a special connection to her phoenix familiar beyond what others understand

## How They Got Here
- **Reason for Current Situation**: 
  - Academic interest in planar anomalies encountered during Last Light Company missions
  - Belief that the Company's rescue work will give her access to magical sites and phenomena needed for her research
  
- **Path to Current Location**: 
  - Academic study in weather magic
  - Development of planar convergence theories
  - The dimensional accident and phoenix encounter
  - Seeking out the Last Light Company for their access to unique magical sites
  
- **Goals Prior to Story Start**: 
  - Advancing understanding of planar convergence theory
  - Documenting ancient magical techniques
  - Developing new applications for weather magic

## Historical Connections
- **Connection to Main Plot**: Magical Support for the Last Light Company
- **Connection to Other Characters**: 
  - Views Cid as kindred spirit in the pursuit of knowledge
  - Shares respectful admiration for magic with Nireya, though they sometimes have philosophical disagreements
  
- **Connection to Story World**: 
  - Knowledge of planar anomalies
  - Understanding of ancient magical techniques
  - Experience with interdimensional spaces

## Timeline
- Early magical education and training
- Specialization in weather magic
- Development of interest in planar convergence theory
- Research into ancient magical texts describing forgotten techniques
- Expedition to volatile convergence site
- The dimensional accident and trapping between planes
- Discovery of phoenix familiar and return to material plane
- Continued research with new insights
- Learning of the Last Light Company's activities
- Joining the Company to further research while providing magical support

## Philosophical Development
- Initially focused on pure academic knowledge
- Experience between dimensions gave her unique perspective on magical theory
- Developed pragmatic view of magical experimentation risks
- Believes in pushing magical boundaries for greater understanding
- Sometimes engages in philosophical debates about the balance between "pushing boundaries to learn more" versus "accepting magic as simply part of life's natural order"
- Values hands-on experimentation over pure theory

## Personal Details
- **How She Relaxes**: She finds calm in creating intricate, temporary weather systems in a bottle. Using a large, sealed glass carboy, she will spend hours meticulously layering enchanted vapors and elemental motes to create miniature thunderstorms, swirling blizzards, or tiny, self-contained rainbows. It's a form of magical art that is both a complex academic exercise and a source of quiet, aesthetic pleasure.
- **Favorite Meal**: Spiced Air-Popped Sorghum with a side of lightning-seared fish. The sorghum is a light, almost flavorless grain that she pops using a precise application of superheated air. The fish is cooked in an instant with a contained bolt of lightning. It's less about the taste and more about the process—a meal prepared with the very elements she studies.
- **A Unique Habit**: She can accurately "smell" the weather. Before a rainstorm, she'll often comment on the scent of ozone and petrichor long before anyone else notices a cloud. Before a snowfall, she'll mention a crisp, metallic tang in the air. It's a sensory side-effect of her deep attunement to atmospheric magic.


---

# Lyralei Stormcaller - Character Development

## Personality Core
- **Defining Traits**: Analytical, curious, structured, knowledge-seeking
- **Core Values**: Academic discovery, advancing magical understanding, practical application of theory
- **Motivations**: Uncovering lost magical knowledge, proving planar convergence theories, documenting magical phenomena
- **Fears**: Being permanently trapped between planes, having theories dismissed without evidence
- **Internal Conflicts**: Academic pursuit vs. practical application, pushing boundaries vs. safety
- **Contradictions**: Structured academic approach with willingness to take calculated magical risks

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Academic researcher with innovative theories
  - *World View*: Knowledge must be pursued even with risks
  - *Key Relationships*: Primarily academic connections
  
- **Catalyst Events**:
  - *Event 1*: Discovery of planar convergence theory applications to weather magic
  - *Event 2*: Interdimensional accident and trapping between planes
  - *Event 3*: Rescue by phoenix familiar
  - *Event 4*: Joining the Last Light Company
  
- **Current State**:
  - *Self-Perception*: Magical theorist with unique interdimensional experience
  - *World View*: Balanced perspective on risk and reward in magical research
  - *Key Relationships*: Developing connections within Last Light Company, especially with Cid and Nireya
  
- **Intended Destination**:
  - *Self-Perception*: TBD - possibly recognized authority on planar magic
  - *World View*: TBD - potentially more integrated view of academic and practical magic
  - *Key Relationships*: TBD - deeper integration with Last Light Company

## Growth Milestones
- **From Academic to Field Researcher**: 
  - *Development Noted*: Shift from pure theory to practical application
  - *Catalyst*: Early field expeditions to convergence sites
  - *Impact*: More balanced approach to magical research
  
- **Interdimensional Experience**: 
  - *Development Noted*: Gaining unique perspective on planar magic
  - *Catalyst*: Being trapped between dimensions
  - *Impact*: First-hand knowledge of interdimensional space, bond with phoenix familiar
  
- **Joining Last Light Company**: 
  - *Development Noted*: Application of magical knowledge to rescue operations
  - *Catalyst*: Recognition that the Company encounters unique magical phenomena
  - *Impact*: Expanding research while contributing to meaningful work

## Character Flaws
- **Academic Tunnel Vision**: 
  - *Effects on Character*: May prioritize research goals over other considerations
  - *Effects on Others*: Could create friction with more pragmatic team members
  - *Development Plan*: Learning to balance research with team priorities
  
- **Calculated Risk-Taking**: 
  - *Effects on Character*: Willingness to face magical dangers for knowledge
  - *Effects on Others*: Might put team in uncertain magical situations
  - *Development Plan*: Developing better risk assessment that includes team safety

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Possibly deeper understanding of planes than she reveals
  - *Secret 2*: Specific nature of bond with phoenix familiar
  
- **Unknown to Character**:
  - *Truth 1*: Full implications of her interdimensional experience
  - *Truth 2*: Potential unintended consequences of her magical experiments
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Pursuing Planar Convergence Theory**:
  - *Context*: Early academic career
  - *Options Considered*: Conventional magical research vs. unconventional theory
  - *Choice Made*: Focused on controversial planar theory
  - *Consequences*: Led to new magical discoveries but also to the dimensional accident

- **The Triple-Planar Channeling Experiment**:
  - *Context*: Field research at convergence site
  - *Options Considered*: Safer approach vs. ambitious experiment
  - *Choice Made*: Attempted to channel three elemental planes simultaneously
  - *Consequences*: Trapped between dimensions but also discovered phoenix familiar

- **Joining Last Light Company**:
  - *Context*: Post-interdimensional experience
  - *Options Considered*: Return to academia vs. field work with Company
  - *Choice Made*: Joined Company for access to magical phenomena during rescues
  - *Consequences*: Applied knowledge in practical settings, developing new relationships

## Development Notes
- Character represents the balance between academic knowledge and practical application
- The phoenix familiar symbolizes rebirth from her interdimensional experience
- Her changing hair and eyes reflect her connection to weather magic and emotional states
- The lightning scar is a physical reminder of her experience between planes
- The philosophical debates with Nireya highlight different approaches to magic
- Her relationship with Cid demonstrates intellectual kinship
- Her pragmatic view of the dimensional accident ("occupational hazard") shows her dedication to knowledge
- Future development could explore consequences of pushing magical boundaries

## Psychological Profile
*   **Lyralei Stormcaller (The Academic):** Lyralei is driven by an insatiable intellectual curiosity. To her, magic is not a mystical force, but a complex, fascinating system to be studied, catalogued, and understood. Her dimensional accident was not a trauma, but an "unexpected field experiment." She is logical and analytical, sometimes to a fault, and may view emotional responses as inefficient variables. She seeks knowledge for its own sake, and the Company provides her with an endless supply of unique magical phenomena to study.


---

# Lyralei Stormcaller - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Magical Support specialist
  - *Hierarchy*: Respects Veyra's leadership while contributing specialized magical knowledge
  - *Dynamics*: Likely values Veyra's mission to leave no one behind, while Veyra appreciates Lyralei's unique magical capabilities
  - *History*: TBD when they first met
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her leadership and dedication

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Magical Support specialist
  - *Hierarchy*: Respects chain of command while offering magical expertise
  - *Dynamics*: Potentially appreciates his tactical approach but may occasionally have different perspectives on magical matters
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely respects his military discipline but might sometimes find it at odds with magical research needs

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist in Last Light Company
  - *Hierarchy*: Equals with different areas of expertise
  - *Dynamics*: Lyralei's weather magic might complement Vera's tracking abilities
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her tracking skills, may be interested in how they could be enhanced with weather magic

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (magical support and medical)
  - *Dynamics*: Might collaborate on treatments that combine magic and medicine
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely appreciates his healing skills and calm demeanor

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (magical support and heavy rescue)
  - *Dynamics*: Her weather magic could help in creating safe conditions for his rescue operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his experience and practical expertise

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (magical support vs. negotiation)
  - *Dynamics*: Her weather magic might support his diplomatic efforts by creating appropriate atmospheric conditions
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates his diplomatic skills and strategic thinking

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Intellectual synergy; "The Theorist and the Practitioner."
  - *Hierarchy*: Equals and intellectual partners.
  - *Dynamics*: Lyralei understands the deep, theoretical principles of magic, while Cid is a genius at applying those principles in unconventional ways. Lyralei might spend a week researching a complex planar convergence theory, and Cid will listen for five minutes and say, "So, what you're saying is, if I build a harmonic resonator attuned to that frequency, I can make a portable hole-puncher?" They spend hours in Cid's workshop, surrounded by arcane diagrams and half-finished inventions, pushing the boundaries of what's possible.
  - *History*: TBD
  - *Current Status*: Close friends and research partners.
  - *Feelings Toward*: Deep admiration for Cid's practical genius and innovative spirit.

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Intellectual sparring partner; The Architect to her Storm.
  - *Hierarchy*: Peers and masters of opposing, yet complementary, domains.
  - *Dynamics*: Lyralei is deeply fascinated by Korrath's mastery of the physical world. She genuinely admires his ability to impose such elegant order and enduring structure upon it. However, she fundamentally believes all such structures are temporary—beautiful, defiant gestures against the inevitable entropy she communes with daily. Their interactions are a constant, good-natured philosophical debate.
  - *History*: Their bond likely formed during the construction of the Bastion, particularly the Aerie, where his precise engineering had to meet her arcane requirements.
  - *Current Status*: A strong, intellectual friendship built on mutual respect and playful antagonism.
  - *Feelings Toward*: She has immense respect for his intellect and craft. She sees his work as a noble and beautiful struggle against the chaos she represents, a struggle he is destined to lose.
  - *Signature Quip*: (After admiring one of his constructions) "It's a beautiful thought. But eventually, the elements always win."

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (magical support vs. infiltration)
  - *Dynamics*: Her weather magic might provide cover for Kaida's infiltration activities
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her professional competence and precise methods

- **Nireya Voss**:
  - *Nature of Relationship*: Philosophical divide.
  - *Hierarchy*: Equals.
  - *Dynamics*: Lyralei sees magic as a science to be dissected and understood. Nireya experiences it as an intuitive, spiritual reality. They have fascinating, respectful debates. Lyralei might try to quantify Nireya's abilities with arcane instruments, while Nireya might gently suggest that some things are meant to be felt, not measured. They are two sides of the same mystical coin, and their conversations push both of them to consider their own beliefs more deeply.
  - *History*: TBD
  - *Current Status*: A strong intellectual friendship built on mutual respect for their different paths to understanding.
  - *Feelings Toward*: Deep respect for Nireya's unique connection to the unseen world, even if she doesn't fully understand it.

## Academic/Research Connections

## Planar Connections
- **Phoenix Familiar**:
  - *Relationship Type*: Magical familiar, guide, possibly savior
  - *History*: Met when Lyralei was trapped between dimensions, guided her back to the material plane
  - *Current Status*: Constant companion
  - *Dynamics*: Deep magical bond forged in interdimensional space
  - *Tensions/Issues*: Possibly knows more about the multiverse than Lyralei fully understands
  - *Shared Experiences*: The interdimensional journey back to the material plane

## Academic Community
- **Former Mentors/Colleagues**:
  - *Relationship Type*: Academic connections
  - *History*: Education and early research
  - *Current Status*: Likely maintains some connections through correspondence
  - *Dynamics*: May have mixed responses to her current theories and experiences
  - *Tensions/Issues*: Possible skepticism from some regarding her planar theories

## Interpersonal Patterns
- **Approach to Authority**:
  - Respects proven expertise and leadership
  - Values authority based on knowledge and capability
  - May occasionally prioritize research goals over strict hierarchical commands

- **Collaborative Style**:
  - Brings specialized magical knowledge to team efforts
  - Likely offers weather-based solutions to tactical problems
  - Academic approach may sometimes need translation to practical application

- **Conflict Resolution**:
  - Probably addresses disagreements through intellectual debate
  - Uses evidence and theory to support positions
  - May need to work on understanding emotional aspects of conflicts

## Relationship Evolution Tracker
- **Pre-Company**: Academic relationships, research community
- **Early Company Days**: Initial professional relationships with team members
- **Current**: Developing working relationships, especially with Cid and Nireya
- **Future Development Potential**: TBD

## Notes on Potential Relationships
- Her weather magic could complement many team members' abilities
- Academic approach may create both respect and occasional friction
- Phoenix familiar could be point of interest/mystery for other team members
- Interdimensional experience gives her unique perspective that may affect relationships


---

# Lyralei Stormcaller — Dialogue & Psyche

## Core temperament
Measured, curious, and precise. A scholar of patterns and weather; speaks with an elven clarity that treats magic as craft and inquiry.

## Dialogue instincts
- Public: calm, slightly formal; explains arcane phenomena with analogies to weather and currents.
- Teaching/analysis: patient, methodical—lays out observation, inference, conclusion in ordered turns.
- Under pressure: voice remains calm; chooses exact language to avoid panic-driven mistakes.
- Humor: wry, often metaphoric; enjoys clever turns of phrase tied to wind and sky.

## Emotional anchors & physical tells
- Hands weave small gestures as if tracing currents in the air; fingers twitch when invoking minor wards.
- Eyes track small changes (light, humidity); a lifted brow signals new insight.
- A soft exhale accompanies successful calculations; abrupt inhalation indicates something unsettled.

## Conflict & humor rules
- Avoids flippancy about planar or mystical dangers; treats such topics with respectful curiosity.
- Will deflate grandstanding with a precise correction or a weather simile.
- Uses light, intellectual irony to defuse tense conversations, not coarse joking.

## Writer cues (practical)
- Use Lyralei to explain magical or environmental causes succinctly; keep explanations anchored in sensory metaphors (wind, pressure, needle of rain).
- When inserting lines, maintain an ordered logic in her speech: observation → analogy → recommendation.
- Pair technical lines with a small physical gesture of measurement (sweeps, pinches of air, examining a gauge).

## Drop-in sample lines
- Observation/explain: "The ley-thread here hums like a taut wire—tension increasing toward the east."
- Tactical advise: "Winds will favor a southern egress in three breaths. Time the lift with my signal."
- Comforting/curious: "There are patterns to grief as there are to storms. We read them the same: patiently."

## Voice evolution note (chapters 1–9)
- Starts as an aloof specialist with academic distance; increasingly bonds with the Company as she sees practical application for her study.
- Moves from theoretic aside to pragmatic partner—keeps curiosity but learns to value steady companionship.

## Usage examples (scenes)
- In briefings: offers short, clarifying metaphors and precise timing recommendations.
- During magic use: speaks calmly, using ordered clauses that keep teammates synchronized.
- In quiet moments: reflective lines that tie natural cycles to human resilience.

## Notes for editors
- Keep Lyralei's language precise and image-driven (wind/pressure/current). Avoid making her exposition long-winded—break into small turns.


---

# Lyralei Stormcaller - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD

## Potential Flashback Scenes
- **The Interdimensional Accident**: 
  - *Brief Description*: The experiment at the convergence site that went wrong
  - *Significance*: Shows her willingness to take risks for knowledge and the origin of her phoenix familiar
  - *Character's Goal*: Channel multiple elemental planes simultaneously
  - *Outcome*: Trapped between dimensions but discovered phoenix familiar
  - *Emotional State*: Initial panic giving way to scientific curiosity and eventual acceptance
  
- **Academic Discovery**: 
  - *Brief Description*: First discovering the potential applications of planar convergence theory
  - *Significance*: Catalyst for her specialized research path
  - *Character's Goal*: Find new applications for weather magic
  - *Outcome*: Development of groundbreaking magical theory
  - *Emotional State*: Intellectual excitement and vindication

## Character Moments
- **Best Moments**:
  - *Scene Reference*: TBD
  - *Description*: Successfully applying planar convergence theory to a practical problem
  - *Impact*: Validation of her research and approach
  
- **Worst Moments**:
  - *Scene Reference*: TBD
  - *Description*: Potentially facing a situation similar to her interdimensional accident
  - *Impact*: Confronting past trauma and fear
  
- **Turning Points**:
  - *Scene Reference*: TBD
  - *Description*: Decision to join Last Light Company
  - *Before/After Effect*: Shift from pure research to practical application
  
- **Revelations**:
  - *Scene Reference*: TBD
  - *What Was Revealed*: Perhaps deeper truth about interdimensional experiences
  - *Impact*: New understanding of her abilities or condition

## Interaction Log
- **With Veyra Thornwake**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Offering magical support during mission
  - *Outcome*: TBD
  - *Relationship Effect*: TBD
  
- **With Cid**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Discussion of magical theory or research
  - *Outcome*: TBD
  - *Relationship Effect*: TBD
  
- **With Nireya**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Philosophical debate about magical boundaries
  - *Outcome*: TBD
  - *Relationship Effect*: TBD

## Magic/Weather Scenes
- **Weather Manipulation**:
  - *Environmental Conditions*: TBD
  - *Magic Applied*: Weather magic to create advantageous conditions
  - *Challenges*: TBD
  - *Outcome*: TBD
  - *Character Growth*: TBD
  
- **Planar Detection**:
  - *Setting*: Area with planar anomalies
  - *Knowledge Applied*: Interdimensional experience allowing her to sense planar disturbances
  - *Critical Decision*: TBD
  - *Outcome*: TBD

## Phoenix Familiar Interactions
- **Communication Scene**:
  - *Context*: TBD
  - *Familiar's Role*: Providing insight or warning
  - *Information Revealed*: TBD
  - *Outcome*: TBD
  
- **Magical Assistance**:
  - *Context*: Challenging magical situation
  - *Familiar's Action*: Amplifying or guiding Lyralei's magic
  - *Result*: TBD
  - *Impact on Relationship*: TBD

## Research Scenes
- **Ancient Text Study**:
  - *Discovery*: Information about forgotten weather magic techniques
  - *Application*: TBD
  - *Challenges*: TBD
  - *Outcome*: TBD
  
- **Planar Convergence Investigation**:
  - *Location*: Site with unusual magical properties
  - *Observations*: Signs of multiple elemental planes touching
  - *Discoveries*: TBD
  - *Implications*: TBD

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*: TBD
  - *Key Quotes*: TBD
  - *Subtext*: TBD
  - *Impact*: TBD

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*: TBD
  - *Ending Emotion*: TBD
  - *Catalyst for Change*: TBD
  - *Visible Signs*: Hair and eye color shifts reflecting emotional state

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
*Potential scenes could include:*
- *Weather manipulation during a rescue operation*
- *Detection of a planar anomaly during a mission*
- *Academic debate with another magical practitioner*
- *Phoenix familiar revealing new information about the planes*
- *Application of theoretical knowledge to solve practical problem*
- *Moment where her hair/eyes dramatically reflect emotional state*
- *Discovery of ancient weather magic site or text*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

