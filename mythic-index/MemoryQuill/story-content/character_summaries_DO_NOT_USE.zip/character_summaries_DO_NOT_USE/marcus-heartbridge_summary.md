# Marcus "The Voice" Heartbridge - Profile

## Basic Information

- **Full Name**: Marcus Heartbridge
- **Aliases/Nicknames**: "The Voice", "The Fixer"
- **Race**: Human
- **Class**: Bard
- **Role in Story**: Negotiator & Morale Officer for the Last Light Company
- **First Appearance**: Chapter 12
- **Status**: Active

## Physical Description

- **Height/Build**: Average height with poised, confident posture
- **Hair**: Well-styled for court appearances while remaining practical for field work
- **Eyes**: TBD
- **Distinguishing Features**: Immaculate appearance regardless of circumstances
- **Typical Clothing**:
  - Well-tailored doublets in rich fabrics
  - Polished boots
  - Formal yet practical cloak
  - Hidden features in clothing:
    - Cufflinks that double as lockpicks
    - Signet ring with hidden compartment
    - Belt buckle that functions as a listening device
    - Reinforced fabrics for protection
    - Multiple hidden pockets
- **Body Language**: Smooth confidence, equally at ease in noble courts or shadowy back alleys
- **Physical Condition**: Well-maintained, likely agile and dexterous

## Visual References

- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Marcus Heartbridge.

## Personality

- **Archetype**: The Diplomat/Fixer
- **Temperament**: Pragmatic, adaptable, resourceful
- **Positive Traits**: Persuasive, detail-oriented, solution-focused
- **Negative Traits**: Potentially willing to compromise ethics for results
- **Moral Alignment**: Chaotic Good (focuses on results that help people, flexible on methods)

## Skills & Abilities

- **Expertise**:
  - Negotiation and diplomacy
  - Information gathering
  - Political maneuvering
  - Bribery and persuasion
  - Lockpicking and infiltration (non-combat)
  - Knowledge of noble houses and trade laws
  - Record keeping
- **Languages**: Multiple, likely including trade languages and noble court dialects
- **Education Level**: Highly educated in diplomatic protocols, trade laws, and political systems
- **Special Abilities**:
  - Bardic magic focused on persuasion and influence
  - Extensive network of contacts and informants
  - Ability to analyze complex social situations for leverage points

## Personal Details

- **Habits**: Maintaining meticulous records in his enchanted journal
- **Hobbies**: TBD
- **Personal Quarters**: A luxurious, two-room suite in a quiet wing of the Establishment building, soundproofed with heavy tapestries. The antechamber is a comfortable salon with several plush armchairs, a low table, and a well-stocked bar cart featuring rare wines and spirits. The inner room contains a large, canopied bed and a handsome mahogany writing desk. The walls are hung with rich, sound-dampening tapestries depicting historical negotiations and trade agreements. This suite is a tool of his trade. The salon is his "soft" office, where he builds rapport with contacts over a glass of fine brandy, extracting information through casual conversation. The inner room is his private sanctum. The desk is for his official correspondence, but a cleverly hidden panel in the desk reveals a smaller, more discreet set of tools: invisible inks, coded ledgers, and a collection of wax seals from various noble houses and guilds. He uses this space to be the man the Company needs him to be, balancing the public face with the private machinations.
- **Likes**: Successful negotiations, elegant solutions to complex problems
- **Dislikes**: Brute force approaches when subtlety would work, rigid thinking
- **Fears**: TBD
- **Motivations**: Solving complex diplomatic problems, applying his skills for meaningful outcomes

## Combat & Tactics
- **Primary Weapon**: Enchanted rapier with ornate handguard containing hidden compartments for poisons, lockpicks, and message scrolls
- **Secondary Weapon**: Words - considers verbal manipulation his most lethal tool
- **Hidden Arsenal**: Sleeve-mounted hand crossbow, cufflink lockpicks, signet ring with hidden compartment, belt buckle listening device
- **Armor**: Formal attire with subtle reinforcements woven into rich fabrics - protection that looks like fashion
- **Fighting Style**: Misdirection duelist - uses flourishes, conversation, and psychology to confuse opponents while striking
- **Signature Move**: "Diplomatic Immunity" - talks his way out of combat entirely, making opponents question why they wanted to fight
- **Combat Philosophy**: "A fight avoided is a victory achieved, but if combat is unavoidable, make it brief and profitable"
- **Tactical Role**: Social infiltrator and negotiator who opens doors with words that others would need crowbars for

## Psychological Response Matrix
- **In Crisis**: Immediately identifies all stakeholders, their motivations, and potential leverage points - treats every crisis like a negotiation
- **During Negotiation**: Already knows what everyone wants before they speak, three moves ahead in the conversation
- **Moral Dilemma**: Reframes ethical problems as negotiation puzzles with win-win solutions
- **Team Conflict**: Mediates by making each side believe they've won while serving the mission
- **Under Personal Attack**: Deflects with charm and humor while mentally filing information for future leverage
- **In Victory**: Networks with defeated opponents, turning enemies into future assets

## Voice & Dialogue Patterns
- **Speech Style**: Adjusts vocabulary, accent, and mannerisms to perfectly match his audience - chameleon-like adaptation
- **Signature Phrases**: 
  - "Let's find our mutual advantage"
  - "Hypothetically speaking..." (maintains plausible deniability)
  - "I'm sure we can reach an understanding"
- **Diplomatic Edge**: Speaks in hypotheticals, implies without stating, makes everything sound reasonable
- **Example Dialogue**: "Hypothetically, if one were to need passage through the Duke's checkpoint, one might mention the Duchess's birthday gala... purely as conversation, of course."
- **Perfect Partnership**: Completes Kaida's sentences, communicates through meaningful glances - "The Lock and The Key"
- **Emotional Tells**: Smile becomes more genuine when truly pleased, fingers drum when calculating

## Notes

- Approaches rescues like complex trade negotiations, analyzing all parties involved and finding leverage points
- Creates tension with Thorne due to their different approaches (by-the-book military vs. "whatever works")
- Partners effectively with Kaida on intelligence-gathering missions
- Sees bribes and unorthodox methods as practical tools to prevent bloodshed
- Maintains his regular diplomatic duties alongside his work with the Company
- Views hostage negotiations and trade agreements as fundamentally similar, just with different stakes
- First encountered the Company at the Wayward Compass inn while on an independent operation.

### Public Perception

- Known as "The Voice" or "The Fixer" who can talk his way out of any situation, even convincing a dragon to give up its hoard.
- Has an extensive network of contacts across all levels of society, from nobles to crime bosses.
- Works in a highly effective, almost silent partnership with Kaida Shadowstep for intelligence gathering and infiltration.


---

# Marcus "The Voice" Heartbridge - Background

## Origin
- **Birthplace**: Baldur's Gate, a city where coin and connections are the true rulers.
- **Social Class**: Minor nobility with significant influence in the merchant guilds.
- **Cultural Background**: A culture of pragmatic deal-making, where reputation is everything and information is a currency.

## Family
- **Parents**: Lord and Lady Heartbridge, respected figures in the Baldur's Gate Merchant Guild.
- **Siblings**: A younger sister, Seraphina, a talented but naive artist who is his one true blind spot.
- **Family Dynamics**: His family valued results over methods, teaching him early on that a well-placed word is often more effective than a show of force.

## History
- **Education & Mentorship**: Marcus was shaped by two opposing mentors. From **Master Aldric Fontaine**, a venerable diplomat, he learned protocol and the public face of power. From **"Whisper" Kess Nightmarket**, a notorious info-broker, he learned that information is the only real currency. This duality defines his career.
- **The Catalyst for his "Fixer" Career**: The turning point from pure diplomat to pragmatic fixer was the **Lian Extraction Case**. Hired by Lady Aris of Waterdeep to find her younger brother, Lian, who had fallen in with the **Silent Hand** slaver ring, Marcus found all official channels useless. The authorities lacked proof, and the political will to act was absent.
- **The Wayward Compass Incident**: His investigation led him to the Wayward Compass inn, where he was gathering intelligence on the Silent Hand's logistics, which he knew involved Zhentarim-supplied weapons. His goal was to find a route or timeline for the slavers' "spring shipment" to intercept it and rescue Lian. The arrival of the Last Light Company was an unforeseen opportunity. He de-escalated a conflict with local mercenaries by using information as a weapon, then decided to audition the Company by giving them a tip about a corrupt merchant in Stonebridge to test their competence for his real mission.

## Backstory Elements
- **Defining Moments**: 
  - Realizing official channels would fail to save his client, Lian, forcing him to seek unorthodox methods.
  - Deciding to test the Last Light Company as potential assets for his rescue operation.
- **Past Achievements**: 
  - A successful career as a public-facing diplomat for trade disputes.
  - Building a vast, covert network of contacts and informants.
- **Mentors/Influences**: 
  - **Master Aldric Fontaine**: A venerable diplomat who taught Marcus that "protocol prevents wars, and a diplomat's word is his bond."
  - **"Whisper" Kess Nightmarket**: A notorious information broker who taught Marcus that "information is the only real currency, and everyone has a price."

## How They Got Here
- **Reason for Current Situation**: He requires a team capable of direct, physical action to succeed where his own methods of subterfuge and negotiation are not enough.
- **Path to Current Location**: Diplomat -> Fixer -> Investigator of the Silent Hand -> Strategic alliance with the Last Light Company.
- **Goals Prior to Story Start**: 
  - Building his reputation as the go-to resource for delicate situations.
  - Perfecting his methods of non-violent conflict resolution.

## Historical Connections
- **Connection to Main Plot**: 
  - Serves as the Company's political and social interface.
- **Connection to Other Characters**: 
  - **Thorne**: Potential for tension between Thorne's by-the-book approach and Marcus's flexible methods.
  - **Kaida**: Potential to form an effective intelligence duo.

## Timeline
- Career as trade diplomat and noble house dispute negotiator.
- The Lian Extraction Case proves the limitations of traditional diplomacy.
- Establishes a dual career as a public diplomat and a discreet "fixer."
- Begins investigating the Silent Hand.
- First encounter with the Last Light Company at the Wayward Compass inn, where he offers the Stonebridge tip as an audition.

## Philosophical Development
- **Early Philosophy**: Believed in proper channels and protocols.
- **Catalyst for Change**: The Lian case showed the limitations of official methods.
- **Current Outlook**: Pragmatic approach where results matter more than methods.
- **Moral Framework**: Sometimes a well-placed bribe prevents bloodshed better than direct conflict.
- **Professional Ethics**: Believes in achieving the best outcomes through whatever means necessary, while minimizing harm.

## Personal Details
- **How He Relaxes**: He plays "The Great Game"—a city-wide, non-violent contest of influence and information played by a select few of Waterdeep's elite.
- **Favorite Meal**: Oysters on the half shell with a chilled glass of Tashlutan wine.
- **A Secret Vulnerability**: His younger sister, Seraphina. He secretly uses his network to protect her and advance her career.
- **A Private Pastime**: Calligraphy and Forgery. In private, he practices the art of calligraphy to perfectly replicate the handwriting of influential figures.
- **A Disarming Quirk**: For all his refined tastes, he is an absolute sucker for a simple, well-made sugar cookie.

---

# Marcus "The Voice" Heartbridge - Character Development

## Personality Core
- **Defining Traits**: Adaptable, pragmatic, diplomatic, resourceful
- **Core Values**: Results over process, discretion, effectiveness, preventing unnecessary conflict
- **Motivations**: Solving complex problems, maintaining dual professional identity, proving flexibility works better than rigidity
- **Fears**: Potential damage to diplomatic reputation, failure when lives are at stake
- **Internal Conflicts**: Traditional diplomatic protocols vs. unorthodox methods, personal ethics vs. practical necessities
- **Contradictions**: Polished courtier appearance with shadow operative capabilities, ethical principles with pragmatic methods

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Skilled diplomat limited by official channels
  - *World View*: Believed in traditional diplomatic processes with occasional flexibility
  - *Key Relationships*: Professional connections within noble houses and trade guilds
  
- **Catalyst Events**:
  - *Event 1*: Client kidnapping situation where traditional diplomacy failed
  - *Event 2*: First collaboration with the Last Light Company
  - *Event 3*: Decision to join Company while maintaining diplomatic career
  - *Event 4*: First major success using unorthodox methods to achieve rescue
  
- **Current State**:
  - *Self-Perception*: "Fixer" who can operate effectively in multiple worlds
  - *World View*: Results-oriented pragmatism, "the ends justify the means" when lives are at stake
  - *Key Relationships*: Dual network of official contacts and shadow connections, plus Company team
  
- **Intended Destination**:
  - *Self-Perception*: TBD - possibly full integration of dual identities
  - *World View*: TBD - refinement of moral framework around pragmatic methods
  - *Key Relationships*: TBD - deeper integration with Company members, especially resolving tension with Thorne

## Growth Milestones
- **From Traditional Diplomat to Flexible Negotiator**: 
  - *Development Noted*: Incorporating unorthodox methods into diplomatic toolkit
  - *Catalyst*: Early experiences where rule-following failed to achieve goals
  - *Impact*: More effective negotiations, but potential ethical compromises
  
- **From Client to Company Member**: 
  - *Development Noted*: Transition from hiring the Company to joining their operations
  - *Catalyst*: Witnessing the effectiveness of their direct approach
  - *Impact*: Expanded skill application beyond traditional diplomacy
  
- **From Independent Operator to Team Member**:
  - *Development Noted*: Learning to integrate his methods with the Company's approach
  - *Catalyst*: Successful collaborations, especially with Kaida
  - *Impact*: Enhanced effectiveness through combined capabilities

## Character Flaws
- **Moral Flexibility**: 
  - *Effects on Character*: Willingness to use bribes, deception, and manipulation
  - *Effects on Others*: Creates tension with more ethically rigid characters like Thorne
  - *Development Plan*: Finding balance between pragmatism and personal ethics
  
- **Potential Overconfidence**: 
  - *Effects on Character*: May take unnecessary risks based on belief in diplomatic skills
  - *Effects on Others*: Could endanger team members if negotiations fail
  - *Development Plan*: Learning humility and when to defer to others' expertise

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Extent of his underworld contacts and less savory methods
  - *Secret 2*: Details recorded in his enchanted journal that could compromise many
  
- **Unknown to Character**:
  - *Truth 1*: TBD - possible unintended consequences of his diplomatic compromises
  - *Truth 2*: TBD - perhaps someone from his past who knows too much about his methods
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **The Decision to Hire the Company**:
  - *Context*: Client kidnapping
  - *Options Considered*: Continue diplomatic channels vs. direct intervention
  - *Choice Made*: Hired the Last Light Company
  - *Consequences*: Changed career trajectory and worldview

- **Joining the Company Part-Time**:
  - *Context*: After successful rescue operation
  - *Options Considered*: Return to pure diplomacy vs. expand skills
  - *Choice Made*: Maintained diplomatic career while joining Company
  - *Consequences*: Dual professional identity, enhanced capabilities, moral complications

- **First Major Ethical Compromise**:
  - *Context*: TBD - perhaps a situation where a bribe or deception was necessary
  - *Options Considered*: Moral principles vs. practical necessity
  - *Choice Made*: Pragmatic approach over ethical idealism
  - *Consequences*: Successful outcome but personal ethical boundary crossed

## Development Notes
- Character represents the pragmatic, flexible approach to problem-solving
- The enchanted journal symbolizes both record-keeping precision and potential secrets
- Diplomatic attire with hidden tools reflects dual nature (open diplomat/shadow fixer)
- Tension with Thorne highlights philosophical differences in approach
- Partnership with Kaida shows complementary skills and methods
- "The Voice" nickname reflects both his diplomatic skills and bardic abilities
- Future development could explore consequences of moral compromises made

## Psychological Profile
*   **Marcus Heartbridge (The Fixer):** Marcus is a pragmatist who views the world as a complex web of leverage points and relationships. He is not immoral, but he is amoral in his methods; the ends (a successful rescue, a peaceful resolution) absolutely justify the means (bribery, manipulation, blackmail). He is a master of masks, equally comfortable in a noble's court and a criminal's den. His core belief is that the most elegant solution is the one that avoids bloodshed, and he sees his work as a form of high-stakes art.


---

# Marcus "The Voice" Heartbridge - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: First contact.
  - *Hierarchy*: N/A
  - *Dynamics*: Marcus likely sees Veyra as the clear leader of the group—pragmatic, dangerous, and driven. He would recognize her as the ultimate decision-maker and the one whose trust he needs to earn. His initial approach would be one of professional respect, demonstrating his value rather than asking for trust.
  - *History*: First met at the Wayward Compass inn in Chapter 12.
  - *Current Status*: Potential ally or contractor.
  - *Feelings Toward*: Intrigue and professional assessment. He sees a powerful, effective tool that he could potentially work with for mutual benefit.

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: First contact.
  - *Hierarchy*: N/A
  - *Dynamics*: Marcus would immediately identify Thorne as a professional soldier, likely former city guard or military. He would anticipate suspicion and a rigid, by-the-book mindset. This is the person he needs to win over with logic and results, not just charm. The potential for future friction is high, but so is the potential for professional respect if Marcus can prove his methods are effective.
  - *History*: First met at the Wayward Compass inn in Chapter 12.
  - *Current Status*: Wary observer.
  - *Feelings Toward*: Acknowledges his professional competence but sees him as a potential obstacle to more... flexible solutions.

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist with complementary skills
  - *Hierarchy*: Equals with different areas of expertise
  - *Dynamics*: Her tracking abilities pair well with his social intelligence gathering
  - *Professional Opinion of*: Appreciation for her skills that operate in different domains than his own

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Confidants; "The Cynic and the Believer."
  - *Hierarchy*: Equals.
  - *Dynamics*: Marcus, a pragmatist who often has to do morally gray things for the greater good, seeks out Aldwin after particularly difficult missions, not to confess, but to recalibrate. He sits for a tea ceremony, and Aldwin's quiet, non-judgmental presence allows Marcus to reconnect with the "why" of their mission, cleansing his palate from the dirty work he has to do.
  - *History*: TBD
  - *Current Status*: A quiet, deeply important confidential relationship.
  - *Feelings Toward*: He deeply respects Aldwin as the Company's moral compass and finds his presence centering.

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (negotiation and heavy rescue)
  - *Dynamics*: TBD
  - *Professional Opinion of*: TBD
  
- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (negotiation and magical support)
  - *Dynamics*: TBD
  - *Professional Opinion of*: TBD

- **Cidrella "Cid" Vexweld**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (negotiation vs. technical)
  - *Dynamics*: His diplomatic skills might help resolve technical complications while her innovations support his operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her technical problem-solving and innovative approach

- **Korrath "Wallbreaker" Threnx**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (negotiation vs. engineering)
  - *Dynamics*: His diplomatic skills complement Korrath's systematic engineering approach
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his methodical approach and engineering expertise

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Intelligence gathering partner; "The Lock and The Key."
  - *Hierarchy*: Equals and partners.
  - *Dynamics*: Theirs is a partnership of pure, silent professionalism. They communicate in half-sentences and shared glances. Marcus gathers the social intelligence, learning the secrets and schedules of a target. He is "The Key" who finds the right moment to turn. Kaida then uses that information for the physical infiltration. She is "The Lock" that can be opened. There is a deep, unspoken understanding between them, as they are the two members who most comfortably operate in the world's gray areas.
  - *History*: TBD
  - *Current Status*: The Company's primary intelligence and infiltration team.
  - *Feelings Toward*: Immense professional respect. He sees her as a master artist in a different medium and trusts her competence implicitly.

## Diplomatic Network
- **Noble Houses**:
  - *Relationship Type*: Professional negotiator and mediator
  - *History*: Long history of settling disputes between houses
  - *Current Status*: Maintains professional relationships with multiple noble families
  - *Dynamics*: Respected for discretion and results, though some may be wary of his methods
  - *Tensions/Issues*: Likely has both allies and enemies among the nobility

- **Merchants and Trade Guilds**:
  - *Relationship Type*: Negotiator for commercial agreements
  - *History*: Established reputation for fair and effective trade negotiations
  - *Current Status*: Active consultant on trade disputes
  - *Dynamics*: Valued for ability to create mutually beneficial arrangements
  - *Tensions/Issues*: TBD

- **City Officials and Guards**:
  - *Relationship Type*: Professional contact with occasional under-the-table arrangements
  - *History*: Built connections for permits and overlooking minor infractions
  - *Current Status*: Maintains network of officials who can be called upon when needed
  - *Dynamics*: Knowledge of who can be bribed and who must be handled through official channels
  - *Tensions/Issues*: Walks fine line between legitimate diplomacy and corruption

- **Underworld Contacts**:
  - *Relationship Type*: Information sources and occasional collaborators
  - *History*: Gradually built network of less reputable but highly useful contacts
  - *Current Status*: Maintains arms-length relationships with various underworld figures
  - *Dynamics*: Mutual benefit arrangement - information exchange, occasional services
  - *Tensions/Issues*: Risk to reputation if these connections became widely known

## Personal Relationships
- **Former Client (Kidnapping Victim)**:
  - *Relationship Type*: Client turned personal connection
  - *History*: The rescue that led to Marcus joining the Company
  - *Current Status*: TBD
  - *Dynamics*: Likely grateful for rescue and potentially now a valuable ally
  - *Tensions/Issues*: TBD

- **Diplomatic Mentors**:
  - *Relationship Type*: Former teachers or supervisors
  - *History*: Early career guidance and training
  - *Current Status*: Possibly still in contact
  - *Dynamics*: May or may not approve of his current methods
  - *Tensions/Issues*: Potential disappointment in his departure from traditional diplomatic approaches

- **Romantic Interests**:
  - *Current Status*: TBD
  - *History*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

## Interpersonal Patterns
- **Approach to Authority**:
  - Respects but not overly constrained by hierarchies
  - Views authority as a practical reality to be worked with or around as needed
  - Comfortable operating within official channels when effective, equally comfortable circumventing them when necessary

- **Collaborative Style**:
  - Adapts approach based on partners' strengths and weaknesses
  - Particularly effective with Kaida in intelligence operations
  - Creates tension with more rigid team members like Thorne

- **Conflict Resolution**:
  - Seeks diplomatic solutions first
  - Not afraid to apply pressure or leverage when needed
  - Prioritizes results over methods
  - Uses bribery and other unorthodox approaches when they prevent violence

## Relationship Evolution Tracker
- **Pre-Company**: Established diplomatic career with noble houses and trade guilds
- **Client Kidnapping**: Transition point where traditional methods failed
- **Early Company Days**: Initial adjustments to working with a rescue team
- **Current**: Established dual role as diplomat and Company "fixer"
- **Future Development Potential**:
  - Potential deepening of friction with Thorne
  - Further integration of diplomatic skills into Company operations
  - Development of relationship with newer Company members

## Notes on Relationships
- His enchanted journal may contain sensitive information about all these relationships
- The tension with Thorne creates interesting group dynamics without being destructive
- His network of contacts is likely one of his most valuable contributions to the Company
- The "James Bond-style" approach to diplomacy shapes all his professional relationships


---

# Marcus "The Voice" Heartbridge — Dialogue & Psyche

## Core temperament
Smooth, persuasive, and urbane. A trained diplomat and broker who moves social levers with charm and a calculating calm.

## Dialogue instincts
- Public: eloquent, richly phrased when it suits advantage; uses rhetorical questions and polished cadence.
- Negotiation: adaptive—mirrors the other party's tone, then steers toward a soft, inevitable agreement.
- Under pressure: remains composed, layers distraction or humor to buy time while he recalibrates.
- Humor: worldly, slightly theatrical; uses wit to disarm or reframe tense moments.

## Emotional anchors & physical tells
- Hands: small, graceful gestures—palms open when sincere, fingers steepled when calculating.
- Smile: practiced and warm, can mask negotiation posture; a genuine smile is rare and thus meaningful.
- Voice: smooth, variable tempo; he slows to emphasize bargains and speeds up to lighten a mood.
- Eye contact lingers when testing sincerity.

## Conflict & humor rules
- Avoids crude or cruel jokes; prefers irony or urbane barbs.
- Will never publicly admit panic or genuine uncertainty—deflects with plans or flattery.
- Keeps secrets close; jokes may be a cover for truth-testing.

## Writer cues (practical)
- Use Marcus to broker deals, supply political cover, or introduce plausible diversionary plans.
- Let him speak longer than others—his sentences can be a rhythm others respond to.
- When adding dialogue, give him the role of smoothing conflict: pose a rhetorical question, then offer a small concession that secures leverage.

## Drop-in sample lines
- Negotiation opener: "Gentlemen, consider not the wound but the healing—what will it cost you to be remembered kindly?"
- Reassurance/plan: "Leave the politics to me; you do what you do best and I'll make sure the doors stay open."
- Dry aside: "A little discretion and a well-placed smile solve more problems than a locked gate."

## Voice evolution note (chapters 1–9)
- Introduced as the polished broker; increasingly reveals a practical, loyal side to the Company—still urbane, but with clearer personal stakes.

## Usage examples (scenes)
- In meetings: longer, persuasive speeches that reframe risk as opportunity.
- Before a mission: private pep-talks that combine practical logistics with morale-boosting polish.
- In public-facing interactions: the face that turns hostility into manageable friction.

## Notes for editors
- Keep Marcus artful but never obfuscatory—his words should clarify incentives.
- Avoid making him a caricature of charm; anchor his speech with concrete offers and small reveals of genuine concern.


---

# Marcus "The Voice" Heartbridge - Scene Tracker

## Major Scenes
- **[Chapter 12, Scene 2]**: 
  - *Brief Description*: First encounter with the Last Light Company at the Wayward Compass inn.
  - *Significance*: Introduction of Marcus to the story and the Company.
  - *Character's Goal*: Prevent a violent confrontation that would disrupt his own covert operation.
  - *Outcome*: Successfully defused the situation using information and leverage, then introduced himself to the Company.
  - *Emotional State*: Composed, calculating, charming, and in complete control.
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD

## Potential Flashback Scenes
- **The Client Kidnapping Incident**: 
  - *Brief Description*: Marcus's client is kidnapped by a rival house using hired bandits
  - *Significance*: Catalyst for his involvement with the Last Light Company
  - *Character's Goal*: Secure client's release through traditional diplomatic channels
  - *Outcome*: Diplomatic efforts fail, leading him to hire the Company
  - *Emotional State*: Frustration with limitations of traditional methods, concern for client
  
- **First Collaboration with the Company**: 
  - *Brief Description*: Working with the Company on the client rescue
  - *Significance*: Shows transition point in career and methods
  - *Character's Goal*: Rescue client through any effective means
  - *Outcome*: Successful rescue that impresses him with Company's capabilities
  - *Emotional State*: Relief, fascination with direct approach, reassessment of methods

## Character Moments
- **Best Moments**:
  - *Scene Reference*: TBD
  - *Description*: Successfully negotiating a seemingly impossible hostage release
  - *Impact*: Validation of flexible methods over rigid protocols
  
- **Worst Moments**:
  - *Scene Reference*: TBD
  - *Description*: A situation where his diplomatic approaches fail or backfire
  - *Impact*: Forced to reconsider methods or rely on team members' different skills
  
- **Turning Points**:
  - *Scene Reference*: TBD
  - *Description*: Decision to fully embrace "Fixer" role alongside diplomatic career
  - *Before/After Effect*: Transition from pure diplomat to dual-identity operative
  
- **Revelations**:
  - *Scene Reference*: TBD
  - *What Was Revealed*: Perhaps consequences of his pragmatic approach
  - *Impact*: Reassessment of methods or moral framework

## Interaction Log
- **With Veyra Thornwake**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Mission planning, utilizing diplomatic connections
  - *Outcome*: TBD
  - *Relationship Effect*: TBD
  
- **With Captain Thorne Brightward**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Tension over approach to mission (rigid vs. flexible)
  - *Outcome*: TBD
  - *Relationship Effect*: TBD
  
- **With Kaida**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Intelligence gathering partnership
  - *Outcome*: TBD
  - *Relationship Effect*: TBD

## Negotiation Scenes
- **Diplomatic Negotiation**:
  - *Setting*: Formal setting like noble house or council chamber
  - *Stakes*: Political implications, trade agreements, or dispute resolution
  - *Approach*: Formal diplomatic protocols with subtle undercurrents
  - *Outcome*: TBD
  
- **Underworld Deal**:
  - *Setting*: Shadowy location, back room, or secret meeting place
  - *Stakes*: Information exchange, access to restricted areas, or underworld support
  - *Approach*: Direct pragmatism with implied leverage
  - *Outcome*: TBD
  
- **Hostage Negotiation**:
  - *Setting*: Tense standoff or communication with captors
  - *Stakes*: Lives at risk, time pressure, complex demands
  - *Approach*: Calm persuasion, possibly with bardic magic enhancement
  - *Outcome*: TBD

## Journal Scenes
- **Recording Mission Details**:
  - *Context*: After successful or failed operation
  - *Information Noted*: Key contacts, methods used, outcomes, contingencies
  - *Significance*: Shows meticulous attention to detail and record-keeping
  - *Potential Complications*: Sensitive information that could be compromising if discovered

## "Fixer" Moments
- **Bribery Scene**:
  - *Target*: Guard, official, or gatekeeper
  - *Method*: Subtle approach disguised as legitimate transaction
  - *Purpose*: Gain access, information, or cooperation
  - *Outcome*: TBD
  
- **Calling in Favors**:
  - *Contact*: Someone from his extensive network
  - *Nature of Favor*: Access to restricted area, special permission, or vital information
  - *Background Relationship*: Previous deal or mutual benefit arrangement
  - *Outcome*: TBD

## Bardic Magic Scenes
- **Persuasion Enhancement**:
  - *Context*: Critical negotiation where normal persuasion might fail
  - *Magic Applied*: Subtle bardic magic infusing voice with enhanced persuasiveness
  - *Target Response*: Increased receptiveness, lowered resistance
  - *Ethical Implications*: Blurred line between persuasion and manipulation

## Hidden Equipment Scenes
- **Lockpicking with Cufflinks**:
  - *Setting*: Secured area needing discreet entry
  - *Method*: Transforming formal attire element into practical tool
  - *Risk Level*: Discovery would compromise diplomatic cover
  - *Outcome*: TBD
  
- **Using Signet Ring's Hidden Compartment**:
  - *Purpose*: Storing/retrieving small item of importance
  - *Contents*: Possibly poison, message, key, or magical substance
  - *Significance*: Shows preparation and hidden capabilities
  - *Outcome*: TBD

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*: TBD
  - *Key Quotes*: TBD
  - *Subtext*: TBD
  - *Impact*: TBD

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*: TBD
  - *Ending Emotion*: TBD
  - *Catalyst for Change*: TBD
  - *Visible Signs*: TBD

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
*Potential scenes could include:*
- *Complex negotiation where Marcus must navigate competing interests*
- *Scene showing the tension between Marcus and Thorne over mission approach*
- *Intelligence gathering partnership with Kaida in action*
- *Situation where bardic magic subtly enhances persuasion*
- *Diplomatic reception where Marcus balances formal role with covert information gathering*
- *Moment where hidden tools in formal attire prove crucial to mission success*
- *Scene revealing contents of his enchanted journal and the potential power/danger it represents*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

