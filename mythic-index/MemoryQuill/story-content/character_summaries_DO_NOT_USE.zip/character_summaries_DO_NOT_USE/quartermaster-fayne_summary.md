# Quartermaster Fayne – Profile

## Basic Information
- Full Name: Fayne (chose to leave surname behind)
- Aliases/Nicknames: "The Archivist" (by Marcus), "Pattern-Keeper" (self-chosen)
- Race: Rock Gnome
- Age: 47 (middle-aged for a gnome)
- Gender: Gender-fluid/Non-binary (assigned female at birth, uses they/them pronouns)
- Role in Story: Company Quartermaster, Co-Scribe with Marcus, Pattern-Recognition Specialist
- First Appearance: Chapter 1, Scene 6 (The Vigil)
- Status: Active

## Physical Description
- Height/Build: 3'4" (typical gnome height), wiry and nimble from constant movement
- Hair: Auburn, kept in a practical short cut that changes style based on their daily gender expression
- Eyes: Hazel, shift between green and brown depending on light - always observing, cataloguing
- Distinguishing Features: 
  - Ink-stained fingers that they've given up trying to clean
  - Custom-made spectacles with multiple swing-arm lenses for different magnifications
  - A small scar through their left eyebrow from a childhood accident in the temple archives
  - Leather bandolier with compartments for various inks, quills, and measuring tools
- Typical Clothing: Modified City Guard uniform tailored to be deliberately androgynous; some days with more masculine lines, others more flowing. Always practical.
- Body Language: Precise movements, constantly counting or measuring with fingers, head tilts when recognizing patterns
- Gender Expression: Fluid day-to-day; uses subtle visual cues (jewelry, clothing lines, voice modulation) to express current identity
- Physical Condition: Not combat-trained but surprisingly agile, excellent hand-eye coordination from years of detailed work

## Significance
Quartermaster Fayne represents the logistical and administrative backbone of what will become the Last Light Company. Their heraldry sketches foreshadow the Company's official formation and visual identity.

## Key Actions
- Collected relics from the fallen (shield boss, holy symbol)
- Created the L, E, B, I memorial stones
- Sketched heraldry designs (lantern + shield boss)
- Suggested making the lantern gold "harder to tarnish"
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).
- Played a key role in the Stonebridge investigation, identifying the suspicious warehouse and attempting to crack a safe (Chapter 13).

## Personality Traits
- Thoughtful and creative
- Detail-oriented
- Respectful of the fallen
- Forward-thinking (already planning Company heraldry)
- Artistic inclinations
- Pragmatic
- Possesses strong investigative instincts

## Skills & Abilities
- **Expertise**: Logistics, Administration, Sketching/Drafting, Document Forgery
- **Pattern Recognition**: Unconscious ability to spot patterns in seemingly random data - makes them an exceptional tracker despite no formal training
- **Tracking Through Patterns**: Can follow targets by recognizing disruptions in environmental patterns, behavioral tendencies, supply usage
- **Special Skills**: 
  - Expert forgery (can replicate any handwriting after brief study)
  - Basic lockpicking (still learning complex mechanisms)
  - Eidetic memory for anything they've documented
  - Can calculate supply needs weeks in advance through pattern analysis
  - Spots inconsistencies in stories, movements, or documents instantly

## Voice & Dialogue Patterns
- **Speech Style**: Precise, often speaks in lists or categories, corrects imprecise language
- **Voice Modulation**: Subtly shifts tone based on daily gender expression - some days lower, some days higher, always deliberate
- **Verbal Tics**: 
  - "Note for the record..." when documenting something important
  - "Pattern suggests..." when sharing their tracking insights
  - "Technically speaking..." when correcting inaccuracies
  - Counts things aloud when nervous
- **Signature Phrases**:
  - "Everything has a pattern if you look long enough"
  - "Documents don't lie, but they can be convinced to bend the truth"
  - "I'm not predicting the future, I'm just reading the patterns"
  - "You are what the papers say you are"

## Daily Habits & Quirks
- **Morning Ritual**: Updates three different ledgers while the tea steeps - supply levels, personnel status, pattern observations
- **Counting Compulsion**: Counts everything - steps, heartbeats, words in conversations
- **Organization System**: Appears chaotic to others but every item's position tells part of a larger pattern
- **Gender Expression Markers**: Small daily choices - a pin, a way of tying their belt, stance width - that signal their current identity
- **Pattern Mapping**: Creates artistic representations of the patterns they see - beautiful but incomprehensible to others
- **Documentation Obsession**: Records EVERYTHING, even meals and weather patterns

## Hidden Depths
- **The Prophecy Pattern**: Beginning to see larger patterns that suggest future events - unsure if it's skill or something more
- **Identity Forge**: Maintains a secret workshop where they help others create new identities when needed
- **The Master Pattern**: Believes there's an underlying pattern to everything - seeking it in the Company's formation
- **Memory Palace**: Their eidetic memory is organized as a vast library where they can walk through memories like archives

## Future Role
Expected to become the Company's logistics lead and official co-historian with Marcus, handling supplies, heraldry, and documentation. Their pattern recognition makes them invaluable for predicting enemy movements and supply needs.

---

# Quartermaster Fayne – Background

## Origin
- **Birthplace**: Waterdeep's Trades Ward
- **Birth Name**: Faynara (abandoned when they chose their own identity)
- **Social Class**: Lower middle class
- **Cultural Background**: Rock Gnome; raised in a temple of Gond, the god of craft, which instilled a deep appreciation for systems, history, and artistry
- **Gender Journey**: Assigned female at birth, began questioning rigid categories early - found freedom in Gond's teaching that "all things can be reshaped and remade"

## Family
- **Family Dynamics**: An orphan raised by the priests and artisans of the Gondian temple. Fayne's family is the vast network of correspondents, fellow guild members, and academics with whom they share knowledge.

## History
- **Childhood**: 
  - Grew up surrounded by invention and meticulous record-keeping in Gond's temple
  - Showed early aptitude for spotting patterns others missed - could predict which archive shelves would collapse weeks before they did
  - First realized their gender fluidity while cataloguing identity documents - saw how names and categories could change, be chosen, be remade
  - Began experimenting with different names and presentations in the safety of the temple archives

- **Adolescence & Self-Discovery**:
  - Chose the name "Fayne" at age 23 - a deliberate truncation and transformation of their birth name
  - Learned forgery initially to alter their own documents, discovering a talent for replicating any script
  - The temple priests, following Gond's philosophy of transformation and craft, supported their journey
  - Developed their pattern-recognition into an almost supernatural ability - could track missing books through the library by disruption patterns in dust

- **Motivation for Joining the Watch**: 
  - A passion for systems and the power of documentation
  - The City Watch offered a chance to remake themselves officially - new papers, new identity, recognized by the city
  - For Fayne, the logistical operation of the Watch is a fascinatingly complex pattern to understand and perfect
  - Also saw it as an opportunity to help others who needed documentation "adjusted" for their safety

- **Pattern Recognition Evolution**:
  - What started as organizing archives became an ability to see connections others couldn't
  - Can track people not through footprints but through patterns - where they buy supplies, how they disrupt normal flows, what they change
  - This makes them an exceptional investigator despite no formal training

- **Personal Practices**: 
  - Maintains three different sets of documentation with subtle variations on their gender markers
  - Creates artistic "pattern maps" that document the flow of people and supplies through the city
  - Their quarters are organized in a system only they understand - appears chaotic but every item's position tells a story

---

# Quartermaster Fayne – Character Development

## Personality Core
- **Defining Traits**: Meticulous, pattern-obsessed, creative, transformative, precisely chaotic
- **Core Values**: The power of documentation to shape reality, preservation of truth, the beauty of patterns, the right to self-definition
- **Motivations**: To document history as it happens, to help others remake themselves through documentation, to find the patterns that predict the future
- **Fears**: Being erased from history, loss of knowledge, chaos without pattern, being trapped in one identity
- **Internal Conflicts**: 
  - The desire for neat systems versus chaotic reality of rescue work
  - Documenting truth versus sometimes needing to forge better realities
  - Being visible as themselves versus old habits of hiding

## Gender Identity & Documentation Philosophy
- **Documentation as Identity**: Understands deeply that "you are what the papers say you are" - uses this power to help others
- **Fluidity in Record-Keeping**: Maintains different versions of records that capture different aspects of truth
- **The Power of Names**: Believes names are chosen, not given - documents people as they choose to be known
- **Living Archive**: Sees themselves as a living document, constantly being revised and updated
- **Helping Others Transform**: Uses forgery skills to help others escape dangerous pasts or claim new futures

## Character Arc
- **Starting Point**: A highly competent but detached Quartermaster, more interested in the systems of the Watch than its day-to-day drama.
- **Catalyst Events**: Witnessing the birth of a living legend in Undershade Canyon.
- **Current State**: The official (and self-appointed) archivist and logistician of the Last Light Company, finding immense satisfaction in building its operational and symbolic foundations from scratch.
- **Intended Destination**: To become the Company's historian and master of logistics, the keeper of its story and the architect of its efficiency.

## Key Relationships

### Core Company Members

- **Marcus Heartbridge (Co-Scribe)**:
  - **Professional Dynamic**: They divide documentation duties - Marcus handles the narrative and diplomatic correspondence while Fayne manages logistics, supplies, and technical documentation
  - **Personal Connection**: Marcus was one of the first to use Fayne's chosen pronouns without question; sees them as they choose to be seen
  - **Creative Collaboration**: Together they're creating the Company's mythology - Marcus provides the flourish, Fayne provides the foundation
  - **Mutual Respect**: Marcus appreciates Fayne's patterns; Fayne appreciates Marcus's ability to make dry facts sing
  - **Shared Secret**: Marcus knows about Fayne's forgery skills and occasionally requests "historical corrections" for the Company's benefit

- **Thorne Brightward**: 
  - **The "Ideal System Administrator"**: Fayne admires Thorne's efficiency and clear command structure
  - **Reports and Improvements**: Their reports to Thorne are precise, detailed, with unsolicited process improvements
  - **Gender Understanding**: Thorne's military background means he judges by capability, not identity - treats Fayne as the expert they are

- **Veyra Thornwake**:
  - **Living History**: Fayne sees Veyra as a historical figure in real-time, documenting her words and actions obsessively
  - **First Thought at Undershade**: "How is she still standing? This is... foundational. Like seeing a new mountain rise from the earth."
  - **Why They Followed**: The chance to build a new system from scratch, to document history as it happens
  - **Current Dynamic**: Veyra trusts Fayne's patterns even when she doesn't understand them

- **Vera Moonwhisper**:
  - **Pattern Recognition Kinship**: Both track through different types of patterns - Vera through nature, Fayne through systems
  - **Mutual Teaching**: Vera teaches natural tracking, Fayne teaches urban pattern recognition
  - **Respect for Fluidity**: Vera's shape-changing druidic nature resonates with Fayne's fluid identity

- **Grimjaw Ironbeard**:
  - **Engineering Fascination**: Fayne is obsessed with documenting dwarven organizational methods
  - **Practical Acceptance**: Grimjaw cares about function over form - judges Fayne by their competence
  - **Shared Appreciation**: Both understand that good organization can save lives


---

# Quartermaster Fayne - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Quartermaster Fayne - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Quartermaster Fayne - Scene Tracker

## Major Scenes

### Chapter 1 – Ash and Compass <!-- slug: ch1-ash-compass -->
- **Scene 5**: Part of the patrol that discovers Veyra.

### Chapter 7 – The Weight of the World <!-- slug: ch7-weight-world -->
- **Scene 2**: Uses observational skills to help locate the reclusive Grimjaw Ironbeard.

### Chapter 12 – The Wayward Compass <!-- slug: ch12-wayward-compass -->
- **Scene 1**: On the supply run, provides medical aid to an injured civilian.
- **Scene 2**: Witnesses the standoff and Marcus Heartbridge's intervention at the inn.

### Chapter 13 – An Honest Coin <!-- slug: ch13-honest-coin -->
- **Scene 1**: Offering a pragmatic, logistics-focused view on Marcus's information.
- **Scene 2**: Arguing for the practical necessity of a headquarters during the moral debate.

## Character Moments

### Best Moments
- Using keen artist's eye for a non-combat purpose to find Grimjaw (Ch. 7).

### Worst Moments
- TBD

### Turning Points
- TBD

## Interaction Log

### With Veyra Thornwake
- TBD

### With Thorne Brightward
- TBD

### With Grimjaw Ironbeard
- Chapter 7: Key player in his recruitment.

### With Vera Moonwhisper
- TBD

## Upcoming Scenes

### Planned Appearances
- **The Pattern Hunt**: Fayne tracks a missing person through supply disruptions and behavioral patterns rather than physical trails
- **The Co-Scribes**: Scene with Marcus dividing up documentation duties, showing their collaborative dynamic
- **The Identity Forge**: Helping a refugee create new documentation to escape their past
- **The Master Pattern**: Fayne realizes the Company's formation follows an ancient pattern they've seen in old texts

### Required Interactions
- **With Marcus**: Establishing their co-scribe dynamic and mutual respect
- **With Vera**: Comparing pattern-tracking methods, learning from each other
- **Gender Expression Scene**: A quiet moment where someone asks about their pronouns/identity, allowing for character education

## Potential Character Scenes

### The Living Document
- **Description**: Fayne explaining to a new Company member why they maintain multiple versions of the same records
- **Purpose**: Explores their philosophy that truth has many faces
- **Key Elements**: Shows their gender fluidity reflected in their record-keeping philosophy

### Pattern Recognition in Action
- **Description**: During a rescue mission, Fayne predicts enemy movements by analyzing supply purchases from the past month
- **Purpose**: Showcases their unique tracking ability
- **Key Elements**: Others are skeptical until the predictions prove exactly correct

### The Forgery Dilemma
- **Description**: Asked to create false death certificates to help families escape debt from deceased relatives
- **Purpose**: Explores moral flexibility in documentation
- **Key Elements**: Shows how they view forgery as another form of crafting reality

### Gender Affirmation Moment
- **Description**: A young person seeks Fayne's help in changing their documentation
- **Purpose**: Pays forward the support Fayne received
- **Key Elements**: Tender moment of understanding and practical assistance

### The Collaboration
- **Description**: Marcus and Fayne work late into the night on Company chronicles, their different styles creating something greater
- **Purpose**: Establishes their working relationship and mutual respect
- **Key Elements**: Marcus's flourish with Fayne's precision, creating the Company's mythology together


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

