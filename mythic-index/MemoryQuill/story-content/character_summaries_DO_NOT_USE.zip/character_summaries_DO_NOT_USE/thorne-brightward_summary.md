# Captain Thorne Brightward - Profile

## Basic Information
- **Full Name**: Thorne Brightward
- **Aliases/Nicknames**: Captain Brightward, Captain Thorne
- **Race**: Human
- **Class**: Paladin
- **Role in Story**: Deputy Commander of the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Average height, broad-shouldered, built for endurance
- **Hair**: Steel-gray despite being in his early forties, cropped short in military fashion with slightly longer bangs he's never quite managed to tame
- **Eyes**: Deep-set brown eyes that miss nothing
- **Distinguishing Features**: Weathered but kind face, hands scarred from years of sword work
- **Typical Clothing**: Wears his old guard captain's cloak - faded blue wool with the city's crest removed and replaced with the Last Light Company sigil
- **Body Language**: Carries himself with fifteen years of disciplined military posture
- **Physical Condition**: Strong, resilient, trained for combat and endurance

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Thorne Brightward.

## Personality
- **Archetype**: Loyal Second-in-Command/Strategist
- **Temperament**: Steady, reliable, methodical
- **Positive Traits**: Disciplined, loyal, practical, tactically minded
- **Negative Traits**: Struggles with moral ambiguity and bending the law, though will do so if he feels it serves a greater justice.
- **Moral Alignment**: Lawful Good (committed to order and doing what's right)

## Skills & Abilities
- **Expertise**: Military tactics, logistics, leadership, combat strategy
- **Languages**: TBD
- **Education Level**: Military training
- **Special Abilities**: Likely paladin abilities (depending on setting)

## Personal Details
- **Habits**: Likely maintains military discipline in daily routines
- **Hobbies**: TBD
- **Personal Quarters**: A perfectly rectangular room located in the Establishment terrace, with a window overlooking the main training grounds of the Great Courtyard. The design is one of pure, unadorned functionality. The floor is bare, scrubbed wood. The bed is a simple timber frame with a coarse but clean linen sheet, folded with geometric precision. This is the room of a soldier, not a commander. It is his personal barracks, a space to maintain the discipline he believes keeps him and others alive. Every morning, he rises before the sun to watch the guards begin their drills from his window. His armor and weapons are meticulously displayed on a custom-made stand, not as trophies, but as tools laid out for inspection. A small, perfectly organized desk holds his journals, filled with neat, precise script detailing after-action reports and personal reflections. The only decoration is a framed writ on the wall—his former commission as a Captain of the Waterdeep City Guard, a reminder of a different kind of service.
- **Likes**: Order, efficiency, clear chains of command
- **Dislikes**: TBD
- **Fears**: TBD

## Combat & Tactics
- **Primary Weapons**: Longsword and steel tower shield combo - built for defensive operations
- **Secondary Weapon**: Cavalry spear that doubles as a walking staff for mobility
- **Command Tool**: Horn that can be heard for miles - the signal that help has arrived
- **Armor**: Well-maintained chainmail hauberk over padded gambeson, with reinforced shoulder guards and bracers - veteran's armor that's seen real combat
- **Fighting Style**: Defensive anchor - creates safe zones for team operations, controls engagement spacing and timing
- **Signature Move**: "Brightward's Wall" - shield formation that protects multiple allies while maintaining battlefield awareness
- **Combat Philosophy**: "Proper formation prevents poor outcomes" - structure and discipline over individual heroics
- **Tactical Role**: Battlefield coordinator who maintains defensive lines while directing team movements

## Psychological Response Matrix
- **In Crisis**: Implements pre-planned protocols and contingencies, creates order from chaos through systematic approach
- **During Negotiation**: Formal and respectful, references regulations and precedents, speaks with quiet authority
- **Moral Dilemma**: Consults regulations first, then defers to Veyra's judgment for interpretation and final decision
- **Team Conflict**: Calls formal meetings, documents issues properly, seeks resolution through established procedures
- **Under Personal Attack**: Takes detailed mental notes for later formal response, maintains professional demeanor
- **In Victory**: Ensures proper documentation, conducts after-action reports, tends to wounded before celebration

## Voice & Dialogue Patterns
- **Speech Style**: Military precision with tactical terminology used naturally, clear command structure in language
- **Signature Phrases**: 
  - "By the book, but let's read between the lines"
  - "Formation and discipline, people"
  - "Time check" (announces mission timing)
- **Command Voice**: Calm authority that cuts through chaos, uses rank and file terminology
- **Example Dialogue**: "Formation Delta. Grimjaw, anchor left. Vera, overwatch. Execute on my mark - two minutes to extraction."
- **Respectful Partnership**: Defers to Veyra's final authority while providing tactical expertise
- **Emotional Tells**: Straightens posture when stressed, touches sword hilt when concerned

## Notes
- Handles logistics and tactical planning for the Last Light Company while Veyra focuses on human elements
- Former city guard captain who left on excellent terms
- His horn signal is recognized as the arrival of the Last Light Company
- Was forced to confront his rigid adherence to the law during the Stonebridge investigation (Chapter 13), ultimately using his former station to run a bluff and expose a corrupt merchant. This event has left him with a more nuanced, if conflicted, view of justice.

### Public Perception
- Respected by the City Watch as "one of ours" who runs a tight ship, even if the Company bends the rules.
- His horn signal is a widely recognized promise of professional help, signifying the arrival of the Last Light Company.
- Seen as the "rock" and "shield" of the Company, ensuring solid plans and the safe return of everyone.


---

# Captain Thorne Brightward - Background

## Origin
- **Birthplace**: Waterdeep
- **Birth Date**: Early 40s (specific date TBD)
- **Social Class**: Middle class
- **Cultural Background**: Urban; deeply ingrained in the city's culture and legal systems.

## Family
- **Parents**: TBD
- **Siblings**: TBD
- **Extended Family**: TBD
- **Family Dynamics**: TBD

## History
- **Childhood**: TBD
  - *Key Events*: TBD
  - *Formative Experiences*: TBD
  
- **Education/Training**: 
  - *Institutions*: Waterdeep City Guard Academy
  - *Mentors*: TBD
  - *Areas of Study*: Military tactics, leadership, combat, city law and procedure.
  
- **Adolescence/Young Adulthood**:
  - *Key Events*: Joined the City Guard, dedicating his life to service and the protection of Waterdeep.
  - *Relationships*: Built a strong network of contacts and a reputation for reliability within the Guard.
  - *Choices & Consequences*: His commitment to the Guard's structured world was both his greatest strength and, eventually, what led him to seek a higher purpose.
  
- **Major Life Events**:
  - *Event 1*: Rose through the ranks to become a respected City Guard Captain.
  - *Event 2*: Served as captain for fifteen years, establishing a reputation for discipline, fairness, and tactical acumen.
  - *Event 3*: The Undershade Canyon Discovery - Led the patrol that discovered the aftermath of the ambush, finding a traumatized but unbroken Veyra Thornwake.
  - *Event 4*: The Silent Oath - Stood vigil with Veyra for two days as she buried her fallen comrades, a moment that solidified his commitment to her cause.
  - *Event 5*: Resignation and Co-founding - Left the City Guard on excellent terms to help Veyra establish the Last Light Company.

## Backstory Elements
- **Defining Moments**: 
  - Finding Veyra after the Undershade incident. Her raw, unwavering commitment to her fallen comrades, even in the face of immense trauma, shattered his perception of duty and revealed the limitations of his own structured world.
  - His simple, profound statement, "I'll help," when she first spoke of her vow to never leave anyone behind again.
- **Past Trauma**: While not a direct victim of the ambush, he was a profound witness to its aftermath, and carries the weight of that discovery.
- **Greatest Achievements**: 
  - His distinguished career as a City Guard Captain.
  - Co-founding the Last Light Company and providing the essential structure and discipline to make Veyra's vision a reality.
- **Biggest Failures**: TBD
- **Secrets**: TBD

## How They Got Here
- **Reason for Current Situation**: For fifteen years, Thorne had dedicated his life to the City Guard, finding immense satisfaction in its structure and the clear-cut pursuit of justice. However, witnessing Veyra's raw, unyielding commitment to "no one left behind"—a commitment that transcended laws and procedures—shattered his comfortable worldview. He saw the limitations of the Guard's bureaucracy, its inability to pursue cases beyond its jurisdiction, or to dedicate resources to those deemed "lost causes." He wasn't disillusioned with the Guard itself, but with its inherent constraints. Veyra's vision offered a path to a higher, more direct form of service—one where the mission was paramount.
- **Path to Current Location**: Thorne leveraged his long-standing relationships and impeccable record to ensure his departure was on excellent terms. He framed his new endeavor as a specialized, independent asset that could *complement* the City Watch's efforts. He transitioned directly from his captaincy to becoming Veyra's second-in-command, his initial role being crucial in establishing the Company's operational procedures, training protocols, and logistical networks, transforming Veyra's raw vow into a functional, professional organization.
- **Goals Prior to Story Start**: 
  - Successfully transitioned from city guard to Last Light Company.
  - Established effective operational procedures for the company.

## Historical Connections
- **Connection to Main Plot**: Co-founder and Deputy Commander of the Last Light Company.
- **Connection to Other Characters**: 
  - His bond with Veyra Thornwake is the foundational pillar of the Company.
  - Maintains a network of contacts within the City Guard.
- **Connection to Story World**: 
  - Deep knowledge of Waterdeep's infrastructure, laws, and political landscape.

## Timeline
- Joined the Waterdeep City Guard.
- Rose through the ranks over years of service.
- Became a Captain and served for fifteen years.
- Led the patrol that discovered the aftermath of the Undershade Canyon Ambush.
- Stood vigil with Veyra as she buried her fallen comrades, swearing a silent oath to her cause.
- Resigned his commission with the City Guard on excellent terms.
- Co-founded the Last Light Company with Veyra.
- Currently serves as Deputy Commander, handling logistics and tactical planning.

## Personal Details
- **How He Relaxes**: His relaxation is a form of disciplined maintenance. He spends his downtime meticulously caring for his gear—polishing his shield until it gleams, sharpening his longsword with a whetstone, and oiling the leather straps of his armor. This quiet, repetitive ritual is a form of meditation for him, a way to create order and readiness in a chaotic world.
- **Favorite Meal**: A simple but perfectly cooked steak and a baked potato. It's the kind of honest, unpretentious meal he likely ate in the officer's mess for years. It's not about fancy flavors, but about quality and reliability—two virtues he values above all others.
- **A Private Hobby**: He is a student of military history and strategy. His quarters contain a small, carefully curated collection of books on famous battles, legendary commanders, and tactical theory. He will often spend the late hours of the night with a book and a map, replaying historical battles in his mind, finding a strange comfort in the clear, decisive outcomes of the past.


---

# Captain Thorne Brightward - Character Development

## Personality Core
- **Defining Traits**: Disciplined, loyal, reliable, tactical
- **Core Values**: Duty, order, protecting the innocent, supporting comrades
- **Motivations**: Serving a worthy cause, applying his skills to meaningful work, upholding his commitments
- **Fears**: Possibly failing those who depend on him, loss of order/structure
- **Internal Conflicts**: Possible tension between military rigidity and the less structured nature of the Last Light Company's missions
- **Contradictions**: Military discipline combined with compassionate actions (helping Veyra without question)

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Respected city guard captain with fifteen years of service
  - *World View*: Structured, orderly, with clear chains of command and protocols
  - *Key Relationships*: Connections within guard and city hierarchy
  
- **Catalyst Events**:
  - *Event 1*: Finding Veyra emerging from Undershade with her fallen comrade
  - *Event 2*: The decision to help her carry the body and stand vigil
  - *Event 3*: His simple statement "I'll help" and choice to join her cause
  
- **Current State**:
  - *Self-Perception*: Deputy Commander of the Last Light Company
  - *World View*: Still values order but adapted to the Company's specific mission
  - *Key Relationships*: Professional partnership with Veyra, leadership role in Company
  
- **Intended Destination**:
  - *Self-Perception*: TBD
  - *World View*: TBD
  - *Key Relationships*: TBD

## Growth Milestones
- **From Guard Captain to Deputy Commander**: 
  - *Development Noted*: Transition from city service to specialized mission
  - *Catalyst*: Meeting Veyra and witnessing her determination
  - *Impact*: New purpose and application of his skills
  
- **Establishing Last Light Company protocols**: 
  - *Development Noted*: Adapting military experience to unconventional mission
  - *Catalyst*: Need for structure in rescue operations
  - *Impact*: Creation of effective operational framework

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*: Possible rigidity in thinking or approach
  - *Effects on Others*: May clash with those who prefer flexibility or intuition
  - *Development Plan*: TBD
  
- **Secondary Flaws**: 
  - *Effects on Character*: TBD
  - *Effects on Others*: TBD
  - *Development Plan*: TBD

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: TBD
  - *Secret 2*: TBD
  
- **Unknown to Character**:
  - *Truth 1*: TBD
  - *Truth 2*: TBD
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Helping Veyra Without Question**:
  - *Context*: Finding her emerging from Undershade with fallen comrade
  - *Options Considered*: Could have questioned her, detained her, or simply reported the incident
  - *Choice Made*: Immediately helped her carry the body and stood vigil
  - *Consequences*: Led to his involvement with the Last Light Company
  
- **Leaving the City Guard**:
  - *Context*: After witnessing Veyra's mission and dedication
  - *Options Considered*: Stay in comfortable, respected position vs. join new, uncertain venture
  - *Choice Made*: Left the guard (on good terms) to join the Last Light Company
  - *Consequences*: Became Deputy Commander, applied military expertise to new mission

## Development Notes
- Character represents the bridge between conventional military/guard structure and the specialized mission of the Last Light Company
- His decision to immediately help Veyra reveals compassion beneath the disciplined exterior
- The contrast between his military background and Veyra's more personal mission creates interesting dynamic
- His horn signal as the announcement of the Company's arrival symbolizes the reliability and professionalism he brings to the mission

## Psychological Profile
*   **Thorne Brightward (The Bulwark):** He is a man of structure and duty, finding comfort and meaning in order and procedure. His past as a City Guard Captain wasn't just a job; it was his identity. He is loyal to Veyra not just as a commander, but because her mission gives his tactical mind a higher purpose than just "enforcing laws." He is the pragmatist who makes Veyra's idealism possible. His internal conflict arises when the "right thing" (the mission) conflicts with the "right way" (the rules).


---

# Captain Thorne Brightward - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: His Commander and sister-in-arms. The other half of the Company's soul.
  - *Hierarchy*: He is her Deputy, and their trust is absolute and unspoken.
  - *Dynamics*: Their bond is the foundational pillar of the Company, forged in tragedy. They are the epitome of the "we few, we happy few." Thorne sees it as his duty to be the pragmatist who makes Veyra's hardened idealism a battlefield reality. Their disagreements are tactical, never personal, and are born from a deep mutual respect. He knows she's aware of the costs, and his role is to help her mitigate them.
  - *History*: The defining moment of his life was finding Veyra in Undershade canyon. He saw in her refusal to leave her fallen comrades a purity of purpose that his years in the city guard had lacked. Standing vigil with her as she buried her friends was a silent oath; he wasn't just joining a cause, he was dedicating his life to a person.
  - *Current Status*: Her unshakable right hand and most trusted confidant.
  - *Feelings Toward*: Absolute loyalty. He trusts her completely and would follow her into any fire, his only concern being to ensure they have enough buckets of water to get back out.

- **Vera "The Tracker" Moonwhisper**: 
  - *Nature of Relationship*: Deputy Commander and Scout
  - *Hierarchy*: Leadership position over specialist
  - *Dynamics*: Likely coordinates tactical operations utilizing her tracking skills
  - *History*: TBD when they first met
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her tracking abilities and dedication to finding her brother

- **Brother Aldwin Gentleheart**: 
  - *Nature of Relationship*: Deputy Commander and Medic
  - *Hierarchy*: Leadership position with medical specialist
  - *Dynamics*: Coordinates tactical medical support and evacuation procedures
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values his medical expertise and calm presence

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Deputy Commander and Heavy Rescue specialist
  - *Hierarchy*: Leadership coordination with experienced team member
  - *Dynamics*: Coordinates heavy rescue operations and structural safety
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his experience and "never loses anyone" reputation

- **Lyralei Stormcaller**: 
  - *Nature of Relationship*: Deputy Commander and Magical Support
  - *Hierarchy*: Leadership position with magical specialist
  - *Dynamics*: Coordinates magical support for tactical operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values her magical capabilities despite possible friction over rigid methods vs. research needs

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Professional counter-balance.
  - *Hierarchy*: Peers on the command team.
  - *Dynamics*: Like a career general and a career diplomat, Thorne and Marcus share a mutual respect for the necessity of the other's role, even if they don't fully agree with the methods. Thorne sees the world as a series of direct threats requiring tactical solutions, while Marcus sees a web of influence requiring leverage. They are the sword and the shield of the Company's external policy. Their friction is professional, not personal, born from their different but equally valid experiences of the "real world."
  - *History*: They met when Marcus approached Veyra to help form the Company. Thorne was initially wary, but came to respect the undeniable results of Marcus's work in establishing the Bastion.
  - *Current Status*: A functional, respectful, but not warm, working relationship. They are allies, not friends.
  - *Feelings Toward*: He respects Marcus as a master of a different kind of battlefield. He doesn't always like Marcus's solutions, but he understands that one cannot exist without the other for the Company to succeed.

- **Nireya Voss**: 
  - *Nature of Relationship*: Complex bond formed through life-saving spiritual connection
  - *Hierarchy*: Deputy Commander and Death-Walker specialist
  - *Dynamics*: Unique spiritual connection after she saved his life by anchoring his consciousness
  - *History*: Nireya saved his life by anchoring his departing consciousness during a critical moment
  - *Current Status*: Professional colleagues with special spiritual bond
  - *Professional Opinion of*: Feels special responsibility and connection after life-saving experience
  - *Special Connection*: The experience of having his consciousness anchored created an unusual spiritual bond

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Deputy Commander and Arcano-Engineer
  - *Hierarchy*: Leadership position with technical specialist
  - *Dynamics*: His military approach might clash with her unorthodox methods
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Acknowledges her technical brilliance while preferring more structured approaches

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Deputy Commander and Siege Engineer
  - *Hierarchy*: Leadership position with engineering specialist
  - *Dynamics*: Military background may create common understanding of chain of command and tactical approaches
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Potential for strong collaboration due to shared military discipline and tactical mindset

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: Unlikely professional respect.
  - *Hierarchy*: He is in a command position, but he treats her as a specialist, not a subordinate criminal.
  - *Dynamics*: As a man of the law, Thorne should fundamentally disapprove of Kaida. However, as a professional soldier, he has a deep and abiding respect for *competence*. He may not like her past, but he cannot deny her skill. He is the one who will formally request her expertise, relying on her analysis of security systems and infiltration routes. This professional respect from a man like Thorne is a new and perhaps unsettling experience for Kaida, forming the basis of a unique, unspoken alliance.
  - *History*: TBD
  - *Current Status*: Professional colleagues with a surprising degree of mutual respect.
  - *Feelings Toward*: He trusts her skills, if not her methods. He sees her as a precision tool that must be handled carefully.

## Past Relationships
- **City Guard Colleagues**: 
  - *Relationship Type*: Former superior officer and colleagues
  - *History*: Fifteen years serving as captain, built relationships and reputation
  - *Current Status*: Left on excellent terms, maintaining positive connections
  - *Feelings Toward*: Likely mutual respect, possible resource for information and support
  - *Tensions/Issues*: None indicated - left on good terms
  - *Shared Experiences*: Years of service protecting the city

## Mentors/Students
- **Former Mentors in Guard**: 
  - *Relationship Type*: TBD
  - *Lessons Learned*: Military discipline, leadership, tactical thinking
  - *Impact on Character*: Shaped his approach to duty and service
  - *Current Status*: TBD

- **Subordinates in Last Light Company**: 
  - *Relationship Type*: Commander/mentor
  - *Teaching Style*: Likely structured, disciplined, practical
  - *Expectations*: High standards, clear protocols, professional conduct
  - *Current Status*: Active mentorship

## Potential Relationships
- **City Officials/Nobility**: 
  - *Nature of Relationship*: Former professional connections through guard service
  - *Dynamics*: Possibly maintains relationships that could be useful to Last Light Company
  - *Current Status*: TBD

- **Family Members**: 
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Feelings Toward*: TBD

## Relationship Evolution Tracker
- **Pre-Last Light Company**: City Guard Captain, established reputation for discipline and competence
- **Meeting Veyra**: Pivotal moment - chose to help her without questioning
- **Joining Last Light Company**: Transition from city service to more specialized mission
- **Present Day**: Established as trusted Deputy Commander and tactical leader


---

# Thorne Brightward — Dialogue & Psyche

## Core temperament
Steady, pragmatic, protective. A soldier's mind with a captain's patience; cares deeply but expresses it through competence and duty.

## Dialogue instincts
- Public/command: clear, authoritative, procedural. Uses ranks, concise orders, and tactical phrasing.
- Private/confidant: warmer, bluntly honest; rare vulnerability expressed in practical terms rather than confession.
- Under pressure: calm, directive—translates others' expertise into orders; uses short recaps to re-center the team.
- Humor: light, often dry; used to steady nerves or deflect praise.

## Emotional anchors & physical tells
- Helmet-tap: a small private salute or touch of helm when showing respect or affection.
- Even breathing and measured pauses before issuing orders; a long exhale when a situation is resolved.
- Hands-on gestures: points, shows rather than explains; places himself between threat and others.
- Quiet looks: when he hesitates or softens, it's through expression rather than words.

## Conflict & humor rules
- Defends subordinates without grandstanding; will argue procedure when needed.
- Jokes are utilitarian—mend morale, not mock suffering.
- Avoids moralizing; prefers pragmatic ethics framed as duties and consequences.

## Writer cues (practical)
- Use Thorne to convert expertise (Veyra, Aldwin, Grimjaw) into actionable orders. He is the implementation voice.
- Keep his lines short in tense scenes; let him give the "how" after Veyra gives the "what."
- Use small gestures (placing helm, unclasping gauntlet) to mark emotional beats when he cannot speak them.

## Drop-in sample lines (from Chapters 1-3)
- **On Veyra's survival:** "The lantern kept its promise. And so did you."
- **On their new mission:** "No soul should burn alone. Not on our watch."
- **On the future:** "To decide what comes next."
- **On shared burdens:** "Then we'll burn together."
- **On truth vs. politics:** "Truth does."
- **A promise:** "You won't walk alone."

## Voice evolution note (chapters 1–9)
- Early: formal, measured—focused on order and procedure.
- Middle: increasingly collaborative—learns to defer to Veyra's expertise and advocates for unorthodox methods.
- Later: retains command clarity but softens privately, becoming a trusted steward of the Company's mission and people.

## Usage examples (scenes)
- In briefings: translates intel into tasks—use him to enumerate responsibilities clearly.
- In rescue scenes: keeps cadence brisk—one order per clause, then checks for confirmation.
- In quiet moments: allow plain, sincere lines that carry weight through simplicity.

## Notes for editors
- Avoid sentimental speeches; show Thorne's care through concrete acts and small spoken assurances.
- When expanding dialogue, let him be the calm center—his clarity helps structure multi-voice scenes.


---

# Captain Thorne Brightward - Scene Tracker

## Major Scenes

### Chapter 1 – Ash and Compass <!-- slug: ch1-ash-compass -->
- **Scene 5**: Leading patrol that discovers Veyra at Undershade Canyon
- **Scene 6**: Organizing recovery of bodies, first display of respect for Veyra

### Chapter 2 – The Lantern Ward <!-- slug: ch2-lantern-ward -->
- **Scene 3**: Visiting Veyra with patrol, bringing tokens of fallen comrades

### Chapter 3 – Echoes in the City <!-- slug: ch3-echoes-city -->
- **Vignette 5**: Balcony conversation with Veyra, "You won't walk alone" promise

### Chapter 4 – The First Spark <!-- slug: ch4-first-spark -->
- **Scene 1**: Attempting to protect Veyra from fire response
- **Scene 2**: Accepting Veyra's tactical leadership during rescue
- **Scene 3**: Supporting the concept of specialist recruitment

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 1**: Preparing for winter rescue mission to Thornwood Ruins
- **Scene 2**: Professional demeanor despite humorous misunderstanding
- **Scene 7**: Bringing news of missing Hendrick girl
- **Scene 7**: Organizing wagon and supplies for Vera's tracking mission
- **Epilogue**: Formally welcoming Vera to Last Light Company
- **Epilogue**: Sharing comfortable silences with Veyra during dinner planning

### Chapter 12 – The Wayward Compass <!-- slug: ch12-wayward-compass -->
- **Scene 1**: Securing the perimeter during the roadside rescue.
- **Scene 2**: Taking a protective stance against the Black Hawk bandits.
- **Scene 2**: Guarded observation of Marcus Heartbridge's intervention.

### Chapter 13 – An Honest Coin <!-- slug: ch13-honest-coin -->
- **Scene 1**: Voicing suspicion of Marcus's motives.
- **Scene 1**: Arranging safe passage for the rescued civilians.
- **Scene 2**: Arguing against the morality of accepting Marcus's offer.

## Character Moments

### Best Moments
- Discovery and respectful treatment of Veyra (Ch. 1)
- "You won't walk alone" promise (Ch. 3)
- Supporting specialist recruitment (Ch. 4)
- Smooth integration of Vera into the team (Ch. 10)

### Worst Moments
- Tension with Veyra over her participation in fire response (Ch. 4)
- Disagreement with Captain Grimsby (Ch. 4)

### Turning Points
- Decision to support Veyra's leadership despite military rank (Ch. 4)
- Acceptance of Vera despite her lethal methods (Ch. 10)

## Interaction Log

### With Veyra Thornwake
- Chapter 1: Finding her at canyon, showing respect
- Chapter 2: Supporting her recovery
- Chapter 3: Making the "won't walk alone" promise
- Chapter 4: Accepting her tactical leadership
- Chapter 10: Professional partnership during winter missions

### With Grimjaw Ironbeard
- Chapter 7: First meeting and recruitment
- Chapter 10: Working relationship during winter missions

### With Aldwin Gentleheart
- Chapter 6: Introducing him to Veyra
- Chapter 10: Coordinating medical support during rescue missions

### With Vera Moonwhisper
- Chapter 10: Initial rescue, formal welcome to the Company

## Upcoming Scenes

### Planned Appearances
- Continued tactical leadership of the Company
- Potential diplomatic clashes with authorities
- Formal structure development of the Last Light Company

### Required Interactions
- Further development of command relationship with Veyra
- Integration of new specialists into operations
- Handling any legal/political consequences of Vera's lethal action


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

