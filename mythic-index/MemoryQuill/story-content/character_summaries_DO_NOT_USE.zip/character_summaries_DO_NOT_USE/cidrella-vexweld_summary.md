# Cidrella "Cid" Vexweld - Profile

## Basic Information
- **Full Name**: Cidrella Vexweld
- **Aliases/Nicknames**: Cid
- **Race**: Rock Gnome
- **Class**: Artificer
- **Role in Story**: Arcano-Engineer for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Short and sturdy, as is typical for a Rock Gnome, with a compact, muscular build from hauling metal and machinery.
- **Hair**: A wild mane of coppery-red hair, often tied up in a messy faux-hawk with a prominent, rebellious streak of arcane blue. It's usually held back from her face by a set of custom-made brass goggles.
- **Eyes**: Sharp, intelligent brown eyes that sparkle with curiosity and focus. Her gaze is direct and misses nothing.
- **Distinguishing Features**: A light dusting of freckles across her nose and cheeks, often smudged with grease or soot. Her left arm, from the shoulder down, is a masterwork prosthetic of her own design, crafted from articulated brass and bronze plates, with glowing arcane conduits visible beneath the seams.
- **Typical Clothing**: She prioritizes function over fashion. She typically wears a dark, oil-stained leather tunic and a heavy leather apron or cuirass over it, complete with numerous pockets and loops for tools. A bandolier holding large power cells or cartridges is always slung across her chest.

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Cidrella Vexweld.

## Personality
- **Archetype**: The Inventor/Problem-Solver
- **Temperament**: Confident, direct, intellectually driven
- **Positive Traits**: Brilliant, resourceful, pragmatic, solution-oriented
- **Negative Traits**: Potentially overly focused on technical challenges rather than people
- **Moral Alignment**: Neutral Good - primarily motivated by intellectual curiosity but applies her skills to help others

## Skills & Abilities
- **Expertise**: 
  - Battlefield invention and adaptive technologies
  - Creating arcane security systems and defensive measures
  - Designing magical wards, arcane locks, self-repairing mechanisms
  - Developing specialized rescue equipment
- **Special Abilities**: 
  - Creating automated defenses that respond to different intrusion types
  - Designing adaptive security grids
  - Building collapsible bridges, wall-penetrating devices, and automatic escape mechanisms
- **Education Level**: Highly educated in arcane engineering and magical artifice
- **Languages**: TBD
- **Combat Style**: Likely relies on inventions and devices rather than direct combat

## Personal Details
- **Habits**: Constantly tinkering with gadgets and improving equipment
- **Hobbies**: Creating and testing new inventions, solving complex technical puzzles
- **Personal Quarters**: A chaotic, two-story space known as "The Annex," connected to her main workshop by a clanking metal door. The ground floor is a secondary workbench, even more cluttered than her main one, dedicated to her most dangerous and experimental personal projects. A rickety, oil-stained spiral staircase leads up to a small loft, which is just big enough for a mattress and a chaotic pile of clothes. The room smells perpetually of ozone, soldering flux, and strange chemical reagents. Wires and arcane conduits run like vines along the walls, powering various half-finished contraptions that hum, click, and occasionally spark at all hours. Blueprints are tacked to every available surface, often overlapping in multiple layers. She uses this space for feverish, late-night invention, often grabbing a few hours of sleep on the mattress only when she physically collapses from exhaustion.
- **Likes**: Interesting technical challenges, elegant solutions to complex problems
- **Dislikes**: Mundane work, repetitive tasks, inefficiency
- **Fears**: TBD
- **Motivations**: Purely intellectual - the interesting challenges and problems to solve, not glory, redemption, or money

## Combat & Tactics
- **Primary Weapon System**: "Flitzragger" - multi-function energy tool connected via heavy cables to her back-mounted power pack. Functions as energy gun, arcane welder, plasma cutter, and "creative problem solver"
- **Power Source**: Back-mounted energy pack that powers both her augmented arm and Flitzragger - constantly humming with barely-contained arcane energy
- **Augmented Arm**: Mechanical left arm with rotating tool attachments and experimental features, powered by the same energy pack
- **Secondary Weapons**: Belt of explosive devices ranging from smoke bombs to "probability charges" (she's not always sure what they'll do)
- **Armor**: Reinforced leather cuirass covered in tool loops, pockets, and attachment points for various gadgets
- **Fighting Style**: Chaos engineer - switches Flitzragger between combat and utility modes mid-fight, often using it to build solutions while under fire
- **Signature Move**: "Overcharge Protocol" - dumps excess energy from pack through Flitzragger for devastating but unpredictable results
- **Combat Philosophy**: "If it's stupid but it works, it's not stupid. If it explodes, it's data!"
- **Tactical Role**: Problem solver who creates unconventional solutions while actively fighting

## Psychological Response Matrix
- **In Crisis**: Gets MORE excited as danger increases - "Oh, this is INTERESTING!" - immediately starts mentally designing solutions
- **During Negotiation**: Fidgets constantly with Flitzragger settings, making everyone nervous as clicking and whirring sounds emanate
- **Moral Dilemma**: "But what if we tried..." - always has a third option involving experimental technology
- **Team Conflict**: Builds something to solve it, whether needed or not ("I made a randomizer to decide who's right!")
- **Under Personal Attack**: Takes notes for improvements while using Flitzragger defensively ("Note to self: add stunning frequency")
- **In Victory**: Immediately starts disassembling captured technology, using Flitzragger's tool modes
- **ADD Tendencies**: Jumps between three projects simultaneously, often combining them in unexpected ways

## Voice & Dialogue Patterns
- **Speech Style**: Rapid-fire technical explanations interrupted by new ideas, often mid-sentence
- **Signature Phrases**: 
  - "Theoretically impossible, practically simple!"
  - "Flitzragger to mode seven—wait, I haven't invented mode seven yet—MODE SIX!"
  - "It'll probably work!" (her version of reassurance)
  - "Energy levels are... mostly stable!"
- **Technical Tangents**: Explains while building with Flitzragger, forgetting others can't follow her mental leaps
- **Example Dialogue**: "Pass the crystallized sulfur—no the BLUE one—Flitzragger needs recalibrating—OH! What if we routed power through the secondary coils? Never mind, trying it!"
- **Emotional Tells**: Talks faster when excited, energy pack hums louder when she's thinking hard, Flitzragger sparks when she's frustrated
- **Interruption Pattern**: Frequently interrupts herself with new ideas before finishing sentences

## Notes
- Joined the Last Light Company not from trauma or redemption but because rescue operations present fascinating technical problems
- Had a profitable three-year working relationship with Korrath as a subcontractor
- Specializes in "impossible problems" that regular engineering couldn't solve
- Works in perfect tandem with Korrath: he identifies structural weaknesses while she provides tools to exploit them safely
- Motivated purely by intellectual curiosity and the challenge of solving complex problems

### Public Perception
- Known for her wild inventions and ability to solve "impossible problems," from mechanical chickens to clearing sewer blockages with clockwork crabs.
- Her augmented metal arm is a source of awe and wonder, rumored to transform into various tools and weapons.
- Works in a highly effective, if sometimes argumentative, partnership with Korrath Threnx, building and repairing critical infrastructure.


---

# Cidrella "Cid" Vexweld - Background

## Origin
- **Birthplace**: Waterdeep
- **Birth Date**: TBD
- **Social Class**: Respected artisan/inventor class.
- **Cultural Background**: Rock Gnome culture with a strong emphasis on invention, practical magic, and intellectual curiosity.

## Family
- **Family Name**: Vexweld
- **Family Trade**: A respected line of jewelers and clockmakers known for their intricate, reliable, and predictable creations.
- **Family Dynamics**: Cid is the family's brilliant, exasperating black sheep. While they crafted beautiful, delicate mechanisms, she was trying to strap rockets to them. Her family loves her genius but is terrified by her methods. Her decision to leave and open her own shop was a mutual, loving relief for all involved.

## History
- **Education/Training**: 
  - Extensive education in arcane engineering and magical artifice, likely through a combination of formal schooling and apprenticeships.
- **Professional Career**:
  - **"Cid's Solutions & Salvage":** After leaving home, she founded a legendary shop in Waterdeep known for solving problems that conventional engineering couldn't touch. It catered to adventurers, wizards, and mercenary captains, earning her a reputation as a "battlefield inventor" not by contract, but by delivering custom, unconventional gear that worked—usually.
  - **The Arm Incident:** The loss of her arm was a landmark event. During an ambitious attempt to create a miniature, self-powering forge using a contained fire portal, a moment of impatience led her to skip a final diagnostic. The containment field flared, and a jet of pure elemental energy erupted, vaporizing her left arm in an instant of searing, agonizing pain. The initial aftermath was not one of cool analysis, but of shock and agony. However, during her recovery, the true Cid emerged. The horror of the event quickly gave way to the most fascinating engineering problem of her life, and she began sketching designs for an improved replacement. Her current prosthetic is a masterwork of articulated brass and glowing conduits.
- **The Turning Point (The "Silent Hand" Compound):**
  - During a high-stakes rescue mission, Korrath Threnx, a stoic Dragonborn engineer and frequent client, contacted Cid to inform her that a security system they had designed together was being used by the "Silent Hand" slaver ring to imprison children.
- **Joining the Company**:
  - Cid and Korrath took the lead on the infiltration of the "Silent Hand" compound, systematically dismantling their own creation. 
  - In the aftermath, Cid had a revelation. While Korrath found redemption, she found the most interesting, complex, and rewarding technical challenge of her life. She joined the Last Light Company not for moral reasons, but because she realized that rescue operations presented a constant stream of fascinating, "impossible" problems that no other line of work could offer.

## Backstory Elements
- **Defining Moments**: 
  - The workshop accident that cost her an arm but gave her a new platform for innovation.
  - Learning about the misuse of her security systems.
  - The intellectual thrill of dismantling her own creation for a successful rescue.
- **Past Achievements**: 
  - Her reputation as a brilliant problem-solver through her shop, "Cid's Solutions & Salvage."
  - The successful infiltration of the "Silent Hand" compound.
- **Past Failures**: 
  - Unintentionally contributing to the imprisonment of children through her "no questions asked" professional policy.
- **Mentors/Influences**: 
  - Korrath, whose professional relationship evolved into a unique partnership.

## How They Got Here
- **Reason for Current Situation**: 
  - Driven by an insatiable intellectual curiosity and a desire for the most challenging problems.
  - Her unique working relationship with Korrath.
  - The realization that rescue operations offer the most complex and rewarding application of her skills.
- **Path to Current Location**: 
  - Gnomish artisan family -> Independent shop owner -> The Arm Incident -> Subcontractor for Korrath -> Moral crisis and a new, more interesting challenge -> Joining the Last Light Company.
- **Goals Prior to Story Start**: 
  - To find increasingly complex technical challenges and push the boundaries of arcano-engineering.

## Historical Connections
- **Connection to Main Plot**: 
  - Creates specialized equipment crucial for rescue operations.
- **Connection to Other Characters**: 
  - **Korrath Threnx**: Her former client, now her indispensable partner.
  - **Vera Moonwhisper**: The mission that brought her into the Company was Vera's personal quest.
- **Connection to Story World**: 
  - A deep understanding of magical security systems and how to bypass them.

## Timeline
- Early career as an artificer and inventor.
- Opens "Cid's Solutions & Salvage" in Waterdeep.
- Loses arm in a workshop accident and builds a superior replacement.
- Established a three-year working relationship with Korrath Threnx as a subcontractor.
- Contacted by Korrath regarding the misuse of their security system by the "Silent Hand."
- Assisted the Last Light Company in the successful rescue of children from the compound.
- Joined the Company, driven by the unique technical challenges of their work.
- Became the lead systems designer for the Bastion of Last Light.

## Personal Details
- **How She Relaxes**: She doesn't relax; she "optimizes." Her downtime is spent creating incredibly complex, Rube Goldberg-esque contraptions to perform simple tasks, purely for the joy of seeing a ridiculously complicated system she designed actually work.
- **Favorite Meal**: A "Tinker's Plate"—a chaotic assortment of small, flavorful foods she can eat with one hand while working with the other (pickled vegetables, smoked sausages, hard cheeses, nuts, etc.).
- **A Secret Hobby**: She is an avid participant in "Cog-Fighting," an underground gnomish sport where participants build and battle small, clockwork automatons. It's a perfect outlet for her competitive, inventive, and slightly chaotic nature.
- **Working with Korrath**: She genuinely enjoys her working relationship with Korrath Threnx. She sees his stubborn insistence on proven, methodical engineering as the ultimate, irresistible challenge. His rigid frameworks are the perfect "cage" for her chaotic genius to break out of. While his constant warnings about safety protocols can be exasperating, she secretly appreciates that his solid foundations give her a stable platform from which to launch her most outlandish and brilliant ideas.

---

# Cidrella "Cid" Vexweld - Character Development

## Personality Core
- **Defining Traits**: Brilliant, confident, pragmatic, solution-oriented
- **Core Values**: Technical excellence, innovation, intellectual challenge, efficiency
- **Motivations**: Purely intellectual - interesting challenges and problems to solve
- **Fears**: TBD - possibly intellectual stagnation or encountering unsolvable problems
- **Internal Conflicts**: 
  - Technical focus vs. human impact of her work
  - Intellectual curiosity vs. ethical considerations
  - Autonomy vs. team integration
- **Contradictions**: 
  - Creates both security systems and tools to bypass them
  - Values efficient solutions but may overcomplicate for intellectual stimulation
  - Focused on technical aspects while working in emotionally charged rescue situations

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Brilliant problem-solver focused purely on technical challenges
  - *World View*: Problems exist to be solved; technical solutions exist for all situations
  - *Key Relationships*: Professional relationship with Korrath based on complementary skills
  
- **Catalyst Events**:
  - *Event 1*: Learning her security systems were used for child trafficking
  - *Event 2*: First rescue mission with the Company (TBD specifics)
  - *Event 3*: TBD - potential future event where technical solution alone isn't enough
  - *Event 4*: TBD - possible conflict between intellectual interest and emotional impact
  
- **Current State**:
  - *Self-Perception*: Technical specialist who applies skills to interesting rescue challenges
  - *World View*: Rescue operations present fascinating technical problems to solve
  - *Key Relationships*: Working partnership with Korrath and developing connections with Company members
  
- **Intended Destination**:
  - *Self-Perception*: Potential evolution to see herself as more than just a problem-solver
  - *World View*: Possible development of awareness about human impact beyond technical challenges
  - *Key Relationships*: Deeper integration with team and possibly emotional investment in missions

## Growth Milestones
- **From Security Provider to Rescue Specialist**: 
  - *Development Noted*: Shift from creating security systems to developing rescue technologies
  - *Catalyst*: Learning about misuse of her systems and joining the Company
  - *Impact*: Application of skills toward helping others rather than potentially harmful security
  
- **From Purely Technical Focus to Awareness of Impact**: 
  - *Development Noted*: TBD - growing recognition of the human elements in her work
  - *Catalyst*: TBD - possibly witnessing the emotional impact of a rescue
  - *Impact*: TBD - potential shift in motivation beyond pure intellectual interest
  
- **From Independent Operator to Team Integration**:
  - *Development Noted*: TBD - learning to work with diverse specialists beyond just Korrath
  - *Catalyst*: TBD - complex mission requiring multiple specialties working in harmony
  - *Impact*: TBD - enhanced effectiveness through true team collaboration

## Character Flaws
- **Intellectual Detachment**: 
  - *Effects on Character*: May prioritize interesting problems over human considerations
  - *Effects on Others*: Could be perceived as cold or uncaring about emotional aspects
  - *Development Plan*: Potential growth toward recognizing human elements of technical challenges
  
- **Overly Solution-Focused**: 
  - *Effects on Character*: Might rush to technical solutions without fully considering context
  - *Effects on Others*: May frustrate team members who need to process emotional aspects
  - *Development Plan*: Learning to balance technical brilliance with situational awareness
  
- **Moral Blind Spots**:
  - *Effects on Character*: Previously didn't question applications of her work ("that's what happens when you don't ask questions")
  - *Effects on Others*: May have unintentionally contributed to harmful situations
  - *Development Plan*: Growing awareness of responsibility for how her inventions are used

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: TBD - possibly the true nature/origin of her augmented arm
  - *Secret 2*: TBD - perhaps specialized knowledge or capabilities she keeps to herself
  
- **Unknown to Character**:
  - *Truth 1*: TBD - possibly that she's developing emotional investment despite intellectual focus
  - *Truth 2*: TBD - perhaps the full extent of how her previous work was misused
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Joining the Company**:
  - *Context*: After learning about misuse of her security systems
  - *Options Considered*: Continue regular contracting vs. apply skills to rescue operations
  - *Choice Made*: Join the Last Light Company for interesting technical challenges
  - *Consequences*: Shift from security provider to rescue specialist

- **TBD Future Decision**:
  - *Context*: TBD
  - *Options Considered*: TBD
  - *Choice Made*: TBD
  - *Consequences*: TBD

## Special Character Elements
- **Augmented Left Arm**:
  - Physical manifestation of her merging of magic and engineering
  - Likely has capabilities beyond what she reveals
  - Visual indicator of her technical expertise and self-modification
  
- **Golden-Orange Eyes with Magical Circuitry**:
  - Change when calculating or problem-solving
  - Window into her thought process
  - Visual indication of her intense focus and analytical abilities
  
- **Labeled Tool Compartments**:
  - Reflect her organized but creative approach
  - Names like "Stun Goo" and "Chompers" show technical solutions with personality
  - "Backup Backup Key" suggests learning from past failures

## Development Notes
- Character represents the technical specialist archetype with unique gnomish flair
- Potential for growth from purely intellectual motivation to emotional investment
- The challenge of maintaining technical brilliance while developing interpersonal awareness
- Opportunity to explore the ethics of invention and responsibility for how creations are used
- Her unique working relationship with Korrath provides foundation for team integration

## Psychological Profile
*   **Cidrella "Cid" Vexweld (The Problem-Solver):** Cid's mind is a whirlwind of schematics, arcane formulas, and "impossible problems" waiting to be solved. She is driven by the sheer joy of creation and the intellectual thrill of overcoming a challenge. She is not motivated by altruism in the traditional sense; she joined the Company because saving people from "impossible" situations presents the most interesting engineering problems. Her confidence is born from a deep, unshakeable belief in her own intellect.


---

# Cidrella "Cid" Vexweld - Relationships

## Professional Relationships
- **Korrath**: 
  - *Nature of Relationship*: The Engineering Duo; "old married couple."
  - *Hierarchy*: Equals and intellectual rivals/partners.
  - *Dynamics*: Their dynamic stems from a fundamental difference in philosophy. Korrath is a master of established, proven principles ("Threnx work doesn't collapse"). Cid is a chaotic innovator who loves to break the rules. They argue constantly, but their respect for each other's genius is absolute. Korrath builds the unbreakable foundation, and Cid builds the impossible machine that sits on top of it.
  - *History*: Three-year profitable working relationship as a subcontractor.
  - *Current Status*: Close, argumentative, and highly effective partners.
  - *Feelings Toward*: She has immense respect for his skill but is endlessly frustrated by his rigid adherence to "the book." She sees his methods as a solid starting point for her to improve upon.

- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Arcano-Engineer
  - *Hierarchy*: Respects command structure but likely operates with significant autonomy in her specialty
  - *Dynamics*: Provides technical solutions to support Veyra's rescue missions
  - *Professional Opinion of*: Respects her dedication to leaving no one behind and appreciates having challenging technical problems to solve

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Arcano-Engineer
  - *Hierarchy*: Acknowledges chain of command while focusing on technical solutions
  - *Dynamics*: Might have some friction if his military approach clashes with her unorthodox methods
  - *Professional Opinion of*: Acknowledges his tactical brilliance while preferring more flexible approaches to problem-solving

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist with complementary skills
  - *Hierarchy*: Equals with different areas of expertise
  - *Dynamics*: Vera's tracking abilities could help identify targets for Cid's technical solutions
  - *Professional Opinion of*: Appreciates her precision and methodical approach to tracking

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (medical vs. technical)
  - *Dynamics*: Potential for collaboration on medical devices or emergency equipment
  - *Professional Opinion of*: Values his healing expertise and sees opportunities for technical enhancement of medical care

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Surrogate father figure and most important client.
  - *Hierarchy*: She is the brilliant inventor, and he is her grizzled, doting guardian.
  - *Dynamics*: Cidrella publicly maintains an air of exasperation at Grimjaw's paternal fussing, but privately, she treasures it. Having a stable, unconditionally supportive father figure in her life is something she deeply values. She takes immense pride in building and maintaining his custom gear (the modular pickaxe and pack), seeing her technical expertise as the best way she can protect him on dangerous missions.
  - *History*: Their bond was forged in her workshop. She was fascinated by the unique engineering challenges his work presented and took it upon herself to upgrade his equipment. His genuine awe and subsequent paternal affection won her over.
  - *Current Status*: A deep, familial bond. She rolls her eyes when he calls her "Vexxy" in public, but would tear down a mountain to keep him safe.
  - *Feelings Toward*: She sees him as a stubborn, lovable, walking geological formation who needs her brains to stay safe. Her affection for him is immense, though she is more likely to show it by triple-checking the integrity of his gear than with a hug.
  
- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow magical specialist and research colleague
  - *Hierarchy*: Different magical disciplines (artifice vs. elemental/planar magic)
  - *Dynamics*: Mutual intellectual respect and shared enthusiasm for discovery
  - *Professional Opinion of*: Views her as a fellow knowledge-seeker with complementary magical expertise

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different areas of expertise (social vs. technical)
  - *Dynamics*: His diplomatic skills might complement her technical solutions for accessing restricted areas
  - *Professional Opinion of*: Appreciates his strategic thinking and ability to handle non-technical complications

- **Nireya Voss**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different domains (spiritual vs. technical)
  - *Dynamics*: Potential contrast between Cid's practical approach and Nireya's spiritual perspective
  - *Professional Opinion of*: Finds her spiritual abilities intellectually fascinating despite their different approaches

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Fellow technical specialist
  - *Hierarchy*: Different but complementary technical skills (arcano-engineering vs. infiltration)
  - *Dynamics*: Cid's devices might enhance Kaida's infiltration capabilities
  - *Professional Opinion of*: Professional respect for her precision and technical competence in infiltration

## Client Relationships
- **Former Security Clients**:
  - *Relationship Type*: Professional service provider
  - *History*: Created security systems and defensive measures
  - *Current Status*: Likely terminated after joining the Company
  - *Dynamics*: Purely transactional, focused on technical requirements
  - *Tensions/Issues*: Discovered her work was misused in at least one case (child trafficking compound)

- **Rescue Operation Beneficiaries**:
  - *Relationship Type*: Technical problem-solver enabling their rescue
  - *History*: Various rescue missions with the Company
  - *Current Status*: Likely successful rescues
  - *Dynamics*: Focused on the technical challenge rather than emotional connection
  - *Tensions/Issues*: Might be perceived as detached due to focus on technical aspects rather than human elements

## Personal Relationships
- **Family**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

- **Mentors/Teachers**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

- **Friends Outside the Company**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

## Interpersonal Patterns
- **Approach to Authority**:
  - Respects competence over formal authority
  - Focuses on technical solutions rather than hierarchical dynamics
  - Likely operates with significant autonomy within her specialty

- **Collaborative Style**:
  - Works exceptionally well with Korrath in a complementary partnership
  - Probably prefers clear technical problems to solve rather than managing interpersonal dynamics
  - May struggle with team members who can't articulate their needs in concrete terms

- **Conflict Resolution**:
  - Likely approaches conflicts as technical problems to solve
  - May be direct and straightforward rather than diplomatic
  - Probably values practical solutions over emotional reconciliation

## Relationship Evolution Tracker
- **Pre-Company**: Professional relationship with Korrath as subcontractor
- **Moral Turning Point**: Learning about misuse of security systems from Korrath
- **Company Integration**: Joining the Last Light Company for interesting technical challenges
- **Current**: Established technical specialist, perfect working dynamic with Korrath
- **Future Development Potential**:
  - Deeper integration with other team members' specialties
  - Possible evolution from purely intellectual motivation to more personal investment in missions
  - Potential conflicts if her focus on technical challenges overshadows human elements

## Notes on Relationships
- Primarily driven by intellectual interest rather than emotional connection
- Perfect working dynamic with Korrath forms the foundation of her Company involvement
- May need to develop more awareness of the human impact of her work beyond technical challenges
- Potentially underestimates the emotional aspects of rescue operations while excelling at technical solutions


---

# Cidrella "Cid" Vexweld — Dialogue & Psyche

## Core temperament
Inventive, terse, and delightfully pragmatic. A rock gnome artificer who treats problems as puzzles—talks like she’s already testing three solutions in her head.

## Dialogue instincts
- Public: quick, efficient, slightly technical; loves concrete descriptions of mechanisms.
- Problem-solving: rapid-fire observations and suggestions; often speaks in fragments that map to actions.
- Under pressure: focused, hands-on language; issues concise instructions tied to devices or tools.
- Humor: mischievous, gadget-focused; playful about prototypes and unlikely fixes.

## Emotional anchors & physical tells
- Tinkering hands: fiddling with a device or her augmented arm while speaking indicates comfort or thought.
- Pursed smile when a mechanism behaves as expected; a huff of frustration when something fails.
- Uses shorthand technical terms and gestures to indicate specifics rather than long explanations.

## Conflict & humor rules
- Avoids melodrama; uses humor to defuse tension or admit a mistake.
- Will get brusque if someone dismisses craft or safety; fiercely protective of her inventions and colleagues.
- Rarely jokes about people’s suffering; will be blunt and practical when lives are at stake.

## Writer cues (practical)
- Use Cid to introduce inventive solutions, clever tools, or to explain device limitations succinctly.
- When adding lines, prefer clipped technical phrasing that implies action: "Override the ward—red coil, two twists, then pulse."
- Pair her lines with small mechanical actions (twisting a knob, pushing a plate) to show embodiment.

## Drop-in sample lines
- Technical directive: "Red coil, two twists. Then pulse—don't let it settle."
- Dry aside: "If it explodes, I told you so. Also, glory to the exploded thing."
- Comfort via craft: "Hold still. I can stitch this with a needle the size of a hair. It'll sting like honesty."

## Voice evolution note (chapters 1–9)
- Early: problem-solver in isolation—focused on gear.
- Middle: integrates socially—uses inventions to protect and enable the Company.
- Later: retains levity and inventiveness but adds quieter moments of loyalty and care.

## Usage examples (scenes)
- Fieldwork: rapid commands for device setup and troubleshooting.
- Workshop or briefing: speaks longer to outline gadgetry but remains demonstration-focused.
- Camp moments: playful tinkering lines that reveal personal quirks.

## Notes for editors
- Keep Cid's speech action-oriented and gadget-specific; avoid long, abstract tech lectures.
- Make sure her humor lands from character knowledge (tools, prototypes), not sarcasm at people's expense.


---

# Cidrella "Cid" Vexweld - Scene Tracker

## Major Scenes
- **[Chapter 6, A Foundation of Need]**: 
  - *Brief Description*: Cidrella formally joins the Company to lead construction of the Bastion.
  - *Significance*: Establishes her role as a key engineer for the Company's home.
  - *Character's Goal*: To take on an interesting and challenging engineering problem.
  - *Outcome*: She accepts the challenge with enthusiasm.
  - *Emotional State*: Excited, intellectually stimulated.

- **[Chapter 7, The Cornerstone and the Name]**: 
  - *Brief Description*: Cid hands Veyra the trowel for the cornerstone ceremony.
  - *Significance*: Her direct involvement in the symbolic founding of the Bastion.
  - *Character's Goal*: To contribute to the physical manifestation of the Company's home.
  - *Outcome*: The cornerstone is laid, and the Company is named.
  - *Emotional State*: Proud, engaged.

- **[Chapter 8, The Bottom Line]**: 
  - *Brief Description*: Cid and Korrath argue over a diagram in the unfinished Common Hall.
  - *Significance*: Shows their working dynamic and the ongoing construction efforts.
  - *Character's Goal*: To refine architectural plans.
  - *Outcome*: The team realizes their financial limitations.
  - *Emotional State*: Focused, engaged in technical debate.

- **[Chapter 11, The Intelligence Briefing]**: 
  - *Brief Description*: Cid presents specialized devices for the Valerius rescue mission.
  - *Significance*: Highlights her role in providing technical solutions for missions.
  - *Character's Goal*: To equip the team with necessary tools for infiltration.
  - *Outcome*: The team forms a plan based on available resources.
  - *Emotional State*: Confident, practical.

- **[Chapter 12, The Approach]**: 
  - *Brief Description*: Cid's ward disruptor partially works, triggering an alarm during infiltration.
  - *Significance*: Introduces a major complication and reveals limitations of her tech.
  - *Character's Goal*: To bypass magical security.
  - *Outcome*: Alarm is triggered, forcing a change in plans.
  - *Emotional State*: Frustrated, but quickly adapting.

- **[Chapter 13, The Extraction]**: 
  - *Brief Description*: Cid struggles with a complex ward and throws smoke pellets during the escape.
  - *Significance*: Shows her quick thinking and adaptability under pressure.
  - *Character's Goal*: To overcome security obstacles and aid the escape.
  - *Outcome*: The team escapes, but the mission is messy.
  - *Emotional State*: Stressed, resourceful.

- **[Chapter 14, Consequences and Realizations]**: 
  - *Brief Description*: Cid acknowledges her devices' limitations during the debrief.
  - *Significance*: Leads to the realization of the need for an infiltration specialist.
  - *Character's Goal*: To honestly assess the team's capabilities.
  - *Outcome*: Marcus proposes recruiting Kaida.
  - *Emotional State*: Pragmatic, self-aware.

- **[Chapter 16, The Test of Trust]**: 
  - *Brief Description*: Cid and Korrath rig a test facility for Kaida.
  - *Significance*: Demonstrates their collaborative engineering skills and the team's skepticism towards Kaida.
  - *Character's Goal*: To create a challenging test for Kaida's infiltration skills.
  - *Outcome*: Kaida flawlessly executes the test.
  - *Emotional State*: Analytical, observant.

## Potential Flashback Scenes
- **Security System Design**: 
  - *Brief Description*: Cid working with Korrath on a high-security installation
  - *Significance*: Establishes their working relationship and her expertise
  - *Character's Goal*: Create an innovative security system for a demanding client
  - *Outcome*: Successful implementation of her designs
  - *Emotional State*: Intellectually engaged, focused on technical challenge
  
- **Learning About Misuse**: 
  - *Brief Description*: Korrath informing Cid about the true purpose of one of their security installations
  - *Significance*: Pivotal moment that led to her joining the Company
  - *Character's Goal*: Process this new information and decide on next steps
  - *Outcome*: Her direct response: "Well, that's what happens when you don't ask questions. So what are you doing about it?"
  - *Emotional State*: Pragmatic, solution-oriented despite moral implications

## Character Moments
- **First Device Creation**:
  - *Description*: Cid creating a specialized rescue device for a specific mission
  - *Impact*: Demonstrates her technical brilliance and problem-solving approach
  - *Key Elements*: Her augmented arm reconfiguring, eyes flashing with circuitry, rapid-fire technical explanations
  
- **Workshop Space**:
  - *Description*: Cid in her personal workshop/lab space within the Company headquarters
  - *Impact*: Shows her in her element, surrounded by half-finished inventions
  - *Key Elements*: Organized chaos, labeled compartments, testing apparatuses, magical-technical hybrid devices
  
- **Field Improvisation**:
  - *Description*: Cid improvising a solution during a rescue when initial plans fail
  - *Impact*: Highlights her adaptability and quick thinking under pressure
  - *Key Elements*: Using components from her bandolier, augmented arm's capabilities, rapid calculations

## Interaction Scenes
- **With Korrath Threnx**:
  - *Chapter/Scene*: Chapter 6, A Foundation of Need
  - *Nature of Interaction*: Accepts the challenge of building the Bastion with him.
  - *Outcome*: They become the lead architects for the new headquarters.
  - *Relationship Dynamic*: Establishes their collaborative partnership.
  
- **With Korrath Threnx**:
  - *Chapter/Scene*: Chapter 8, The Bottom Line
  - *Nature of Interaction*: Engages in a technical argument over a diagram.
  - *Outcome*: Highlights their "old married couple" dynamic.
  - *Relationship Dynamic*: Shows their complementary skills and intellectual sparring.
  
- **With The Full Company**:
  - *Chapter/Scene*: Chapter 11, The Intelligence Briefing
  - *Nature of Interaction*: Presents specialized devices for the mission.
  - *Outcome*: Her contributions are integrated into the plan.
  - *Relationship Dynamic*: Reinforces her role as the team's technical expert.
  
- **With The Full Company**:
  - *Chapter/Scene*: Chapter 12, The Approach
  - *Nature of Interaction*: Attempts to bypass a ward, triggering an alarm.
  - *Outcome*: Creates a complication that forces improvisation.
  - *Relationship Dynamic*: Shows her technical skills but also their limitations.
  
- **With The Full Company**:
  - *Chapter/Scene*: Chapter 13, The Extraction
  - *Nature of Interaction*: Struggles with a complex ward and uses smoke for cover.
  - *Outcome*: Aids in the messy but successful escape.
  - *Relationship Dynamic*: Demonstrates her resourcefulness under pressure.
  
- **With The Full Company**:
  - *Chapter/Scene*: Chapter 14, Consequences and Realizations
  - *Nature of Interaction*: Acknowledges her devices' limitations in the debrief.
  - *Outcome*: Contributes to the decision to recruit Kaida.
  - *Relationship Dynamic*: Shows her pragmatic self-assessment.
  
- **With Korrath Threnx**:
  - *Chapter/Scene*: Chapter 16, The Test of Trust
  - *Nature of Interaction*: Rigs a test facility for Kaida with Korrath.
  - *Outcome*: Kaida passes the test, proving her value.
  - *Relationship Dynamic*: Reinforces their collaborative engineering efforts.

## Ability Showcase Scenes
- **Security System Bypass**:
  - *Setting*: Heavily secured location during a rescue mission
  - *Abilities Demonstrated*: Knowledge of security systems and how to bypass them
  - *Visual Elements*: Augmented arm interfacing with security features, eyes rapidly calculating patterns
  - *Impact on Story*: Enables access to rescue targets behind advanced security
  
- **Structural Problem-Solving**:
  - *Setting*: Unstable building or structure during rescue
  - *Abilities Demonstrated*: Understanding structural weaknesses and creating solutions
  - *Visual Elements*: Creating force-redistribution fields, calculating load-bearing points
  - *Impact on Story*: Prevents collapse and enables safe extraction of rescue targets
  
- **Rapid Prototype Creation**:
  - *Setting*: Workshop or field situation requiring new equipment
  - *Abilities Demonstrated*: Innovation and quick fabrication of specialized devices
  - *Visual Elements*: Components from bandolier combining with magical energies from augmented arm
  - *Impact on Story*: Creates unique solution for specific rescue challenge

## Conflict Scenes
- **Security System Confrontation**:
  - *Context*: Facing a security system she herself designed in the past
  - *Stakes*: Success of rescue mission
  - *Character's Approach*: Pragmatic problem-solving, using insider knowledge
  - *Outcome*: TBD
  
- **Technical Disagreement**:
  - *Context*: Clash with another technical specialist about approach to a problem
  - *Stakes*: Safety of team or rescue targets
  - *Character's Approach*: Logic-based argument, demonstration of solution
  - *Outcome*: TBD
  
- **Moral Quandary**:
  - *Context*: Situation where technical solution exists but raises ethical concerns
  - *Stakes*: Her evolving understanding of responsibility for her creations
  - *Character's Approach*: Initially focusing on technical aspects before considering broader implications
  - *Outcome*: TBD

## Growth Scenes
- **From Technical to Human Focus**:
  - *Description*: Moment when Cid realizes the human impact of her work beyond the technical challenge
  - *Growth Shown*: Evolution from purely intellectual motivation to emotional investment
  - *Key Elements*: Witness to emotional aftermath of rescue, connection to those she helps
  
- **Taking Responsibility**:
  - *Description*: Cid confronting the consequences of her inventions or solutions
  - *Growth Shown*: Development of ethical framework beyond technical excellence
  - *Key Elements*: Acknowledging the applications and implications of her work
  
- **Team Integration**:
  - *Description*: Cid finding her place within the diverse specialists of the Company
  - *Growth Shown*: Moving beyond her perfect partnership with Korrath to work effectively with others
  - *Key Elements*: Adapting her communication style, valuing different approaches

## Dialogue Highlights
- **Technical Enthusiasm**:
  - *Context*: Explaining a particularly elegant technical solution
  - *Key Quotes*: "See, the beauty of this design is how the arcane resonance creates a harmonic feedback loop with the physical components. It's not just engineering, it's architectural poetry."
  - *Emotional Impact*: Reveals her passion for elegant technical solutions
  
- **Moral Realization**:
  - *Context*: Recognizing the implications of her work
  - *Key Quotes*: "I built it because it was an interesting problem. Never asked what it was for. That's... that's not good enough anymore, is it?"
  - *Emotional Impact*: Shows growing awareness of responsibility

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
- Scenes should showcase her technical brilliance while hinting at potential for character growth
- Visual elements like her augmented arm reconfiguring and eyes flashing with circuitry should be consistent features
- The balance between intellectual challenge and human impact offers rich dramatic potential
- Her perfect working dynamic with Korrath contrasted with other team relationships provides character development opportunities


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

