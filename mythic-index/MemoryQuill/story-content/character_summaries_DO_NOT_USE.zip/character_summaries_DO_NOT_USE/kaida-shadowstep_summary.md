# Kaida "Lockbreaker" Shadowstep - Profile

## Basic Information
- **Full Name**: Kaida Shadowstep
- **Aliases/Nicknames**: Lockbreaker
- **Race**: Tiefling
- **Class**: Rogue
- **Role in Story**: Infiltration Specialist for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: About average height for a tiefling, compact and precise in everything - movement, speech, appearance
- **Skin**: Dark burgundy skin
- **Horns**: Short, curved horns filed to smooth points
- **Hair**: Black hair cut in a practical bob that won't catch on anything
- **Eyes**: Golden eyes with the calculating look of someone always measuring distances and angles
- **Distinguishing Features**: 
  - Small scars marking her fingers from years of lockpicking
  - Habit of unconsciously flexing her hands when thinking
- **Typical Clothing**: 
  - Dark, close-fitting leather that doesn't creak or catch
  - Multiple hidden pockets
  - Reinforced knees
  - Soft-soled boots
- **Physical Condition**: Physically fit and agile, built for stealth and precision work

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Kaida Shadowstep.

## Personality
- **Archetype**: The Professional Thief/Infiltrator
- **Temperament**: Calculating, precise, methodical
- **Positive Traits**: Skilled, intelligent, professional, meticulous
- **Negative Traits**: Unashamed of criminal past, possibly obsessive about precision
- **Moral Alignment**: Chaotic Good - uses criminal skills for rescue work but maintains criminal mindset

## Skills & Abilities
- **Expertise**: 
  - Master lockpicking and infiltration
  - Trap detection and disarmament
  - Physical infiltration and stealth
  - Intelligence gathering through physical means
  - Navigation of trap-filled environments
- **Special Abilities**: 
  - Can move like a ghost without leaving evidence
  - Obsessive precision in planning and execution
  - Immaculate tool organization and maintenance
- **Education Level**: Self-taught master thief with practical expertise
- **Languages**: TBD
- **Combat Style**: Stealth-based, avoiding direct confrontation when possible

## Personal Details
- **Habits**: Unconsciously flexing hands when thinking, obsessive tool maintenance
- **Hobbies**: Likely studying locks, traps, and security systems as intellectual puzzles
- **Personal Quarters**: A small, anonymous room with a single, easily barred window that overlooks a little-used section of the Bastion's outer wall. The furniture is sparse, lightweight, and looks like it could all be packed away in minutes—a simple cot, a small table, one chair. There are no decorations, no personal touches. This is a professional's bolt-hole, not a home. Every item is placed for a quick getaway. The lock on her door is a masterpiece of complex, non-magical tumblers that she designed and changes weekly. She uses the room for the quiet, methodical maintenance of her gear and for studying city maps. A loose floorboard, indistinguishable from the others, conceals a hidden cache containing her old thieving tools, an emergency go-bag with rations and disguises, and a small, waterproofed bag of currency from a half-dozen different city-states.
- **Likes**: Precision, well-executed plans, professional excellence in thievery
- **Dislikes**: Sloppy work, betrayal, being trapped or caught
- **Fears**: Being betrayed again, losing her professional edge
- **Motivations**: 
  - Identifying who betrayed her to the authorities
  - Applying her skills to help others (redirected rather than reformed)
  - Maintaining her professional reputation and abilities

## Combat & Tactics
- **Primary Weapons**: Paired stiletto daggers named "Whisper" (left hand) and "Promise" (right hand) - precision instruments, not brawling weapons
- **Secondary Weapons**: Throwing knives hidden throughout outfit, each balanced for different distances
- **Tools**: Lockpicking set with tools named after betrayers from her past - "using their names for better purposes"
- **Armor**: Form-fitting shadowsilk leather that moves like a second skin, reinforced with flexible steel strips at vital points. Allows complete freedom of movement while providing protection.
- **Fighting Style**: Surgical striker - appears, eliminates threat with precision, vanishes. Combines deadly efficiency with an almost dance-like grace.
- **Signature Move**: "Arterial Mathematics" - precision strikes to incapacitate rather than kill, calculated for maximum effectiveness
- **Combat Philosophy**: "If you see me fighting, I've already failed" - but if you do see it, you'll appreciate the artistry
- **Tactical Role**: Ghost operative who neutralizes sentries and creates entry points while making it look effortless

## Psychological Response Matrix
- **In Crisis**: Calculates optimal solutions with calm confidence, often with a slight smirk at the challenge
- **During Negotiation**: Silent observer with knowing looks, occasionally exchanging meaningful glances with allies
- **Moral Dilemma**: Chooses efficiency with a shrug - "morality is a luxury I can't afford, darling"
- **Team Conflict**: Withdraws with theatrical sigh, makes sly comments from the sidelines
- **Under Personal Attack**: Responds with cutting wit and veiled threats delivered with a smile
- **In Victory**: Allows herself a satisfied smile and perhaps a small, theatrical bow

## Voice & Dialogue Patterns
- **Speech Style**: Precise criminal terminology delivered with subtle flirtation and supreme confidence
- **Signature Phrases**: 
  - "That's a three-pick lock, two-minute job - child's play, really"
  - "I don't do witnesses, but I might make an exception for you"
  - "The math doesn't work, sweetheart"
- **Flirtatious Edge**: Uses terms of endearment ironically, winks at impossible achievements, enjoys being impressive
- **Example Dialogue**: "Entry point seventeen meters up, three guards on rotation, forty-second window. *slight smile* I'll need a distraction at the bell tower - something dramatic would be appreciated."
- **Emotional Tells**: Flexes hands when thinking, smirks when confident, raises eyebrow when amused

## Notes
- Zero shame about her criminal past - views thievery as a skilled profession requiring intelligence, planning, and artistry
- Worked with a crew called "The Architect's Fingers"
- Joined the Company through work-release program after saving a mission and Grimjaw's life
- Not reformed, just redirected - "instead of stealing from people, she's stealing people back from their captors"
- Still methodically working to identify who betrayed her
- Forms perfect intelligence duo with Marcus "The Voice" Heartbridge

### Public Perception
- Known as "Lockbreaker" or a "ghost" for her unparalleled infiltration skills, with rumors of her leaving a black feather as a calling card in impossible-to-breach locations.
- Her involvement in the Company's "acquisitions" is an open secret, often seen by common folk as a form of karmic justice against the corrupt.
- Works in a highly effective, almost silent partnership with Marcus Heartbridge for intelligence gathering and discreet operations.


---

# Kaida "Lockbreaker" Shadowstep - Background

## Origin
- **Birthplace**: TBD (likely an urban area with significant criminal activity)
- **Birth Date**: TBD
- **Social Class**: Lower class, criminal underworld
- **Cultural Background**: Tiefling heritage. She faces the usual prejudice against Tieflings but handles it with a surprising maturity. She sees bias as just another variable in a system—an exploitable weakness an opponent foolishly reveals.

## History
- **The Architect's Fingers**: Kaida's former life was with a small, elite thieving crew.
  - **Silas ("The Eyes"):** The charming intelligence gatherer who found the marks.
  - **Bryn ("The Hammer"):** The stoic half-orc muscle and logistics expert.
  - **Kaida ("The Fingers"):** The master infiltrator who did the delicate work.

- **The Betrayal (The Cassian Heist)**: The crew was betrayed by their own intel man, Silas. He was secretly paid by a rival of their target, Lord Cassian, to set Kaida up. Silas provided a flawless plan but fed them a false date. When Kaida bypassed every security measure and opened the vault, she was met not by treasure, but by Lord Cassian and a dozen City Watch guards led by Captain Thorne Brightward. With no escape, she was arrested.

- **The Recruitment (The Ticking Cage)**: Months later, the Last Light Company was trying to rescue a captive from a trap-filled clock tower. Grimjaw became pinned by a complex clockwork mechanism, moments from death. Thorne, remembering the unparalleled skill of the thief he had arrested, visited Kaida in prison. He offered her a deal: save his man, and he would arrange for her to serve her sentence with the Company. Intrigued by the challenge, she accepted. She navigated the deadly traps with breathtaking artistry, freed Grimjaw, and secured her place with the Company.

## Backstory Elements
- **Defining Moments**: 
  - Joining "The Architect's Fingers" and achieving professional mastery.
  - Being betrayed by Silas and arrested by Thorne.
  - Saving Grimjaw's life and proving her value to the Company.
  
- **Past Achievements**: 
  - Master-level expertise in infiltration and trap navigation.
  - A reputation as a "ghost" who leaves no evidence.
  
- **Biggest Failures**: 
  - Trusting Silas, which led to her capture and the dissolution of her crew.
  
- **Primary Motivation**: 
  - To methodically hunt down Silas and understand the full scope of his betrayal.

## How They Got Here
- **Reason for Current Situation**: Serving her sentence on a work-release program with the Last Light Company.
- **Path to Current Location**: Master Thief → Betrayal & Imprisonment → Recruitment by Thorne → Indispensable Company Asset.
- **Goals Prior to Story Start**: Professional excellence in thievery and survival.

## Philosophical Development
- **Past**: Viewed thievery as a high art and a profession deserving of pride.
- **Present**: "Not reformed, just redirected." She now uses her skills to "steal people back," a challenge she finds more rewarding. She maintains her professional pride and still methodically hunts for Silas, but has found a new, more loyal crew in the Company.


---

# Kaida "Lockbreaker" Shadowstep - Character Development

## Personality Core
- **Defining Traits**: Precise, methodical, professional, unashamed, calculating
- **Core Values**: Professional excellence, precision, competence, self-reliance
- **Motivations**: Identifying her betrayer, maintaining professional standards, applying skills effectively
- **Fears**: Being betrayed again, losing her edge, being trapped or caught
- **Internal Conflicts**: 
  - Criminal identity vs. rescue work integration
  - Trust issues vs. team collaboration needs
  - Professional pride vs. authority cooperation
- **Contradictions**: 
  - Uses criminal skills for lawful/chaotic rescue purposes
  - Maintains criminal mindset while serving community service
  - Values precision but works in chaotic rescue situations

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Professional thief serving forced community service
  - *World View*: Criminal skills are valuable profession; not reformed, just redirected
  - *Key Relationships*: Purely transactional with Company, investigating betrayal
  
- **Catalyst Events**:
  - *Event 1*: The betrayal that led to her capture
  - *Event 2*: Saving Grimjaw's life during the fortress mission
  - *Event 3*: Developing intelligence partnership with Marcus
  - *Event 4*: TBD - potential resolution of betrayal investigation
  
- **Current State**:
  - *Self-Perception*: Skilled infiltration specialist finding purpose in rescue work
  - *World View*: Criminal skills can serve noble purposes without losing professional identity
  - *Key Relationships*: Strong partnership with Marcus, growing trust with team
  
- **Intended Destination**:
  - *Self-Perception*: Professional who chose to redirect skills rather than abandon identity
  - *World View*: Competence and results matter more than conventional morality
  - *Key Relationships*: Fully integrated team member who maintains unique perspective

## Growth Milestones
- **From Forced Service to Chosen Purpose**: 
  - *Development Noted*: Transition from work-release requirement to willing participation
  - *Catalyst*: Saving Grimjaw's life and seeing impact of her skills
  - *Impact*: Found meaning in "stealing people back from their captors"
  
- **From Isolated Wariness to Selective Trust**: 
  - *Development Noted*: Building working relationships despite betrayal trauma
  - *Catalyst*: Successful partnerships with Marcus and respect from team
  - *Impact*: Learning to trust again while maintaining professional caution
  
- **From Criminal vs. Authority to Professional Cooperation**: 
  - *Development Noted*: Working with rather than against authority figures
  - *Catalyst*: Recognizing shared goals despite different methods
  - *Impact*: Effective collaboration while maintaining criminal professional identity

## Character Flaws
- **Obsessive Precision**: 
  - *Effects on Character*: May over-plan or get frustrated with imperfect conditions
  - *Effects on Others*: Could slow down urgent operations or frustrate spontaneous team members
  - *Development Plan*: Learning to balance precision with rescue operation urgency
  
- **Trust Issues from Betrayal**: 
  - *Effects on Character*: Systematic wariness that may limit deeper relationships
  - *Effects on Others*: May seem distant or calculating to team members seeking friendship
  - *Development Plan*: Gradual trust building through shared experiences and proven reliability
  
- **Unashamed Criminal Identity**:
  - *Effects on Character*: May not fully integrate with law-abiding team members
  - *Effects on Others*: Could make some team members uncomfortable with her methods
  - *Development Plan*: Finding balance between maintaining identity and team integration

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: The ongoing investigation into who betrayed her
  - *Secret 2*: Specific details about "The Architect's Fingers" crew and their methods
  
- **Unknown to Character**:
  - *Truth 1*: The true identity of her betrayer (TBD)
  - *Truth 2*: How much she's actually changing through rescue work
  
- **Revelation Timeline**:
  - *Secret/Truth*: Discovery of betrayer's identity
  - *Planned Reveal*: TBD
  - *Expected Impact*: Resolution of trust issues and closure of criminal past

## Key Decisions & Turning Points
- **Choosing to Save Grimjaw**:
  - *Context*: During the trap-filled fortress mission when she could have prioritized her own safety
  - *Options Considered*: Self-preservation vs. using skills to save team member
  - *Choice Made*: Used her expertise to save Grimjaw's life
  - *Consequences*: Transition from temporary work-release to permanent team member

- **Developing Partnership with Marcus**:
  - *Context*: Recognizing complementary intelligence gathering abilities
  - *Options Considered*: Working alone vs. collaborative intelligence operations
  - *Choice Made*: Form perfect intelligence duo combining their skills
  - *Consequences*: More effective operations and deeper Company integration

## Special Character Elements
- **Tool Obsession**:
  - Physical manifestation of her precision and professional standards
  - Immaculate organization reflects her methodical approach
  - Tools are extension of her professional identity
  
- **Hand Flexing Habit**:
  - Unconscious physical tell when thinking or stressed
  - Shows her constant readiness for manual dexterity work
  - Visual indicator of her perpetual mental calculation
  
- **"Architect's Fingers" Legacy**:
  - Connection to criminal past and professional standards
  - Source of techniques and approaches
  - Potential plot thread through betrayal investigation

## Development Notes
- Character represents redemption through redirection rather than reformation
- Professional competence as path to acceptance and integration
- Trust issues create barriers but also make breakthrough moments more meaningful
- Criminal background provides unique skills and perspective valuable to team
- "Not reformed, just redirected" philosophy allows character growth without losing core identity

## Psychological Profile
*   **Kaida Shadowstep (The Professional):** Kaida views thievery not as a crime, but as a high-skill profession, an art form. She is not "reformed"; her skills have simply been "redirected." Her core psychology is that of a meticulous professional who was betrayed by her former crew. This has left her with a deep-seated distrust of teams and a laser-focus on identifying her betrayer. Her loyalty to the Company is conditional, built on their professionalism and their respect for her skills.


---

# Kaida "Lockbreaker" Shadowstep - Relationships

## Professional Relationships
- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Intelligence gathering partner; "The Lock and The Key."
  - *Hierarchy*: Equals and partners.
  - *Dynamics*: Theirs is a partnership of pure, silent professionalism. They communicate in half-sentences and shared glances. Marcus gathers the social intelligence, learning the secrets and schedules of a target. He is "The Key" who finds the right moment to turn. Kaida then uses that information for the physical infiltration. She is "The Lock" that can be opened. There is a deep, unspoken understanding between them, as they are the two members who most comfortably operate in the world's gray areas.
  - *History*: TBD
  - *Current Status*: The Company's primary intelligence and infiltration team.
  - *Feelings Toward*: Immense professional respect. She sees him as a master of a different kind of lockpicking—the kind that opens people instead of doors.

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Fellow Company member whose life she saved
  - *History*: Her skills saved the mission and specifically saved Grimjaw's life during the trap-filled fortress operation
  - *Current Status*: Special bond formed through life-saving event
  - *Dynamics*: Mutual respect and possible protective instinct from both sides
  - *Professional Opinion of*: Respects his experience and dedication
  - *Development Potential*: Deeper trust and collaboration based on shared experience

- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Infiltration Specialist
  - *Hierarchy*: Respects her leadership despite her own criminal background
  - *Dynamics*: Provides infiltration expertise to support Veyra's rescue missions
  - *Professional Opinion of*: Likely respects her mission to leave no one behind, which aligns with Kaida's redirected purpose

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Infiltration Specialist
  - *Hierarchy*: Acknowledges chain of command while maintaining professional criminal mindset
  - *Dynamics*: His military approach might occasionally clash with her criminal methods
  - *Professional Opinion of*: Respects tactical abilities but may find rigid military approach limiting

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: "The Outsiders' Alliance"; quiet friendship.
  - *Hierarchy*: Equals.
  - *Dynamics*: Both Kaida and Vera are deeply wary of people due to past betrayals. They have a quiet, minimalist friendship built on shared observation rather than conversation. They might spend hours together in the courtyard, one practicing with her tools, the other observing the patterns of birds, finding a strange comfort in each other's silent, professional competence. They understand each other's need for space and self-reliance.
  - *History*: TBD
  - *Current Status*: A quiet, unspoken alliance.
  - *Feelings Toward*: A sense of kinship with a fellow outsider. She trusts Vera's professionalism, if not her worldview.

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (infiltration vs. medical)
  - *Dynamics*: His healing abilities support her potentially dangerous infiltration work
  - *Professional Opinion of*: Values his medical expertise for post-mission care

- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different areas of expertise (infiltration vs. magical support)
  - *Dynamics*: Her weather magic might provide cover for Kaida's infiltration activities
  - *Professional Opinion of*: Appreciates magical abilities that complement her physical skills

- **Nireya Voss**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different domains (physical vs. spiritual)
  - *Dynamics*: Contrast between Kaida's concrete, physical approach and Nireya's spiritual methods
  - *Professional Opinion of*: May find spiritual approach mystifying but respects results

- **Cidrella "Cid" Vexweld**:
  - *Nature of Relationship*: Fellow technical specialist
  - *Hierarchy*: Different but complementary technical skills (infiltration vs. arcano-engineering)
  - *Dynamics*: Cid's devices might enhance Kaida's infiltration capabilities
  - *Professional Opinion of*: Professional respect for technical innovation and problem-solving

- **Korrath "Wallbreaker" Threnx**:
  - *Nature of Relationship*: Fellow specialist with complementary abilities
  - *Hierarchy*: Different approaches to accessing secured locations (infiltration vs. siege engineering)
  - *Dynamics*: His structural knowledge complements her infiltration techniques
  - *Professional Opinion of*: Respects his expertise in breaking down barriers

## Former Criminal Connections
- **"The Architect's Fingers" Crew**:
  - *Relationship Type*: Former criminal colleagues
  - *History*: Worked together as highly skilled thieving crew
  - *Current Status*: Crew likely disbanded after her capture
  - *Dynamics*: Professional partnership based on complementary criminal skills
  - *Tensions/Issues*: One member may have been involved in her betrayal

- **The Betrayer**:
  - *Relationship Type*: Unknown former associate who led to her capture
  - *History*: Fed false information to her intelligence gatherer
  - *Current Status*: Unknown identity, actively investigating
  - *Dynamics*: Deep betrayal of professional trust
  - *Tensions/Issues*: Ongoing threat and source of wariness; methodical investigation continues

- **Criminal Contacts**:
  - *Relationship Type*: Former professional network
  - *History*: Connections built during criminal career
  - *Current Status*: Likely severed or complicated by her work-release status
  - *Dynamics*: May view her as traitor for working with authorities
  - *Tensions/Issues*: Potential sources of information but also potential threats

## Authority Relationships
- **Prison/Work-Release Officials**:
  - *Relationship Type*: Legal oversight of her community service
  - *History*: Imprisoned after betrayal, granted work-release for Company missions
  - *Current Status*: Permanent community service arrangement
  - *Dynamics*: Professional compliance with legal requirements
  - *Tensions/Issues*: Balance between serving sentence and maintaining criminal identity

- **Law Enforcement**:
  - *Relationship Type*: Former adversaries, current complicated alliance
  - *History*: Career built on evading law enforcement
  - *Current Status*: Working with rather than against authorities
  - *Dynamics*: Uneasy alliance based on mutual benefit
  - *Tensions/Issues*: Fundamental clash between criminal mindset and authority cooperation

## Interpersonal Patterns
- **Trust Issues**:
  - Highly cautious about trust due to betrayal experience
  - Systematic approach to evaluating trustworthiness
  - Professional relationships easier than personal ones

- **Professional Standards**:
  - Maintains criminal professional identity even in rescue work
  - Values competence and precision in others
  - Judges others by their professional capabilities

- **Collaborative Style**:
  - Works best in partnerships with clearly defined roles
  - Excels when her specific skills are needed and valued
  - May struggle with authority figures who don't understand criminal methods

## Relationship Evolution Tracker
- **Pre-Betrayal**: Strong crew bonds with "The Architect's Fingers"
- **Post-Capture**: Isolation and wariness, systematic investigation of betrayal
- **Work-Release**: Initial purely transactional relationship with Company
- **Life-Saving Event**: Deeper integration after saving Grimjaw and proving worth
- **Current**: Established infiltration specialist with growing team bonds
- **Future Development Potential**:
  - Deeper trust with team members as she proves reliability
  - Resolution of betrayal investigation
  - Evolution from criminal identity to rescue specialist identity

## Notes on Relationships
- Her criminal background creates unique dynamics with law-abiding team members
- Professional competence is her primary way of building relationships
- The betrayal experience makes her cautious but not paranoid
- "Not reformed, just redirected" philosophy affects all her relationships
- Perfect working partnership with Marcus forms foundation of her Company integration
- Life-saving event with Grimjaw created important trust bond


---

# Kaida "Lockbreaker" Shadowstep — Dialogue & Psyche

## Core temperament
Cautious, cunning, and fiercely independent. A master infiltrator who trusts skill over sentiment; keeps people at arm's length until they prove reliable.

## Dialogue instincts
- Public: curt, economical; says only what advances the objective or tests the room.
- Infiltration/skill use: precise, step-oriented cues—short imperatives or single-image descriptions.
- Under pressure: cool and quick; prefers quiet commands and whispered coordination.
- Humor: dry, edged with cynicism; uses wry remarks to deflect praise or uncomfortable emotion.

## Emotional anchors & physical tells
- Fingers toy with lockpicks or a hidden dagger when nervous or thinking.
- Eyes dart to exits; relaxed eye contact indicates trust.
- A small, almost-smirk is rare and meaningful; a cold laugh signals boundary reinforcement.

## Conflict & humor rules
- Avoids sentimentalities and moral grandstanding; has strict personal ethics—she does not steal from those who cannot afford it.
- Will pocket items opportunistically but rarely flaunts it; defends this as "operational prudence."
- Breaks pattern only in rare private moments when she reveals a scar or a secret—these reveal hard-earned loyalty.

## Writer cues (practical)
- Use Kaida for tight, tactical lines during stealth or infiltration scenes.
- When adding dialogue, favor clipped sentences, whispered directions, and concise rationales.
- Let her occasionally needle Marcus or trade barbs with Vera—these show social integration without emotional overshare.

## Drop-in sample lines
- Stealth cue: "Silent feet. Shadow on my left. Move on my count—three, two, one."
- Cold aside: "We stole a rescue, not a purse. Keep the line straight."
- Private, rare softness: "Don't call it loyalty yet. Call it a debt owed."

## Voice evolution note (chapters 1–9)
- Introduced as a wary, skilled thief on work-release; gradually finds a place within the Company's code—still independent, but with emerging, guarded loyalty.

## Usage examples (scenes)
- Infiltration: short, precise instructions and observations that keep the team synchronized.
- Social friction: barbed quips and tests of honesty that reveal trust dynamics.
- Private interactions: minimal confessions or pragmatic admissions that hint at deeper motives.

## Notes for editors
- Keep Kaida's dialogue sharp and economical; avoid long, justifying monologues.
- Her humor should carry a sting and a usefulness—never gratuitous.


---

# Kaida "Lockbreaker" Shadowstep - Scene Tracker

## Major Scenes
- **[Chapter 15, The Proposal to the Warden]**: 
  - *Brief Description*: Kaida is seen in solitary, methodically scratching escape plans, hinting at her calculating nature.
  - *Significance*: Introduces her character and mindset before her direct involvement.
  - *Character's Goal*: To maintain her mental edge and readiness for escape.
  - *Outcome*: Warden agrees to a supervised test for her.
  - *Emotional State*: Calculating, patient, subtly defiant.

- **[Chapter 16, The Test of Trust]**: 
  - *Brief Description*: Kaida flawlessly executes an infiltration test rigged by Cid and Korrath, leaving a black feather for Veyra.
  - *Significance*: Proves her exceptional skills to the skeptical team.
  - *Character's Goal*: To pass the test and secure her work-release.
  - *Outcome*: Team is impressed but wary; she hints at past betrayals.
  - *Emotional State*: Confident, professional, subtly wary.

- **[Chapter 17, The First Joint Mission]**: 
  - *Brief Description*: Kaida pairs with Marcus for intelligence, disables security, and saves Grimjaw from a trap, but pockets a valuable item.
  - *Significance*: Demonstrates her immediate value to the team and highlights her criminal habits.
  - *Character's Goal*: To successfully complete the mission and apply her skills.
  - *Outcome*: Mission success, but a confrontation with Veyra over ethics.
  - *Emotional State*: Professional, resourceful, defiant.

- **[Chapter 18, Integration and Shadows]**: 
  - *Brief Description*: Kaida settles into the Bastion, customizes her quarters, bonds with the team, and examines a clue about her past betrayal.
  - *Significance*: Shows her integration into the Company and sets up her personal quest.
  - *Character's Goal*: To find answers about her betrayal and balance new loyalty with independence.
  - *Outcome*: She begins to see the Company as a new "crew" while pursuing her own agenda.
  - *Emotional State*: Guarded, observant, subtly hopeful.

## Potential Flashback Scenes
- **The Betrayal**: 
  - *Brief Description*: The moment when false intelligence led Kaida into a trap designed specifically for her methods
  - *Significance*: Pivotal event that ended her criminal career and led to her capture
  - *Character's Goal*: Execute what she believed was a routine heist
  - *Outcome*: Capture by authorities, dissolution of "The Architect's Fingers"
  - *Emotional State*: Shock, betrayal, professional pride wounded
  
- **Saving Grimjaw**: 
  - *Brief Description*: Kaida navigating the trap-filled fortress and using her skills to save Grimjaw's life
  - *Significance*: Turning point from work-release to permanent Company member
  - *Character's Goal*: Complete the mission and prove her worth
  - *Outcome*: Mission success, Grimjaw's life saved, permanent position offered
  - *Emotional State*: Professional focus shifting to genuine concern for teammate

## Character Moments
- **Tool Maintenance Ritual**:
  - *Description*: Kaida organizing and maintaining her lockpicking tools with obsessive precision
  - *Impact*: Shows her professional standards and methodical nature
  - *Key Elements*: Hand flexing, tool examination, systematic organization
  
- **Reading a Security System**:
  - *Description*: Kaida assessing a complex security setup, identifying weaknesses and planning approach
  - *Impact*: Demonstrates her expertise and analytical abilities
  - *Key Elements*: Golden eyes calculating distances and angles, mental mapping, professional assessment
  
- **"Not Reformed, Just Redirected" Moment**:
  - *Description*: Scene where Kaida explains her philosophy about maintaining criminal identity while serving rescue missions
  - *Impact*: Clarifies her character motivation and approach to moral questions
  - *Key Elements*: Direct communication, professional pride, no apology for past

## Interaction Scenes
- **With Marcus Heartbridge**: 
  - *Chapter/Scene*: Chapter 15, The Proposal to the Warden
  - *Nature of Interaction*: Marcus proposes her work-release to the warden.
  - *Outcome*: Warden agrees to a test.
  - *Relationship Dynamic*: Establishes Marcus as her advocate and initial contact.

- **With The Full Company**: 
  - *Chapter/Scene*: Chapter 16, The Test of Trust
  - *Nature of Interaction*: Meets the skeptical team and performs her test.
  - *Outcome*: Impresses them with her skills, but leaves them wary.
  - *Relationship Dynamic*: Initial tension and professional assessment.

- **With Vera Moonwhisper**: 
  - *Chapter/Scene*: Chapter 16, The Test of Trust
  - *Nature of Interaction*: Exchanges dry remarks about their respective skills.
  - *Outcome*: Hints at a potential, unlikely camaraderie.
  - *Relationship Dynamic*: Mutual professional respect despite initial wariness.

- **With Marcus Heartbridge**: 
  - *Chapter/Scene*: Chapter 16, The Test of Trust
  - *Nature of Interaction*: Forms a subtle bond over shared cunning.
  - *Outcome*: Establishes their future intelligence partnership.
  - *Relationship Dynamic*: Mutual understanding and respect for their methods.

- **With Marcus Heartbridge**: 
  - *Chapter/Scene*: Chapter 17, The First Joint Mission
  - *Nature of Interaction*: Pairs seamlessly for intelligence work.
  - *Outcome*: Their combined skills lead to mission success.
  - *Relationship Dynamic*: Solidifies their effective professional partnership.

- **With Grimjaw Ironbeard**: 
  - *Chapter/Scene*: Chapter 17, The First Joint Mission
  - *Nature of Interaction*: Saves him from a trap.
  - *Outcome*: Earns his respect and forms an unlikely bond.
  - *Relationship Dynamic*: Demonstrates her value and creates a personal connection.

- **With Veyra Thornwake**: 
  - *Chapter/Scene*: Chapter 17, The First Joint Mission
  - *Nature of Interaction*: Confronted about pocketing a valuable item.
  - *Outcome*: Defends her actions, leading to a discussion about Company ethics.
  - *Relationship Dynamic*: Establishes Veyra's moral boundaries and Kaida's "redirected" philosophy.

- **With The Full Company**: 
  - *Chapter/Scene*: Chapter 18, Integration and Shadows
  - *Nature of Interaction*: Participates in a communal meal and begins to bond.
  - *Outcome*: She starts to see the Company as a new "crew."
  - *Relationship Dynamic*: Gradual integration and softening of her guarded nature.

- **With Veyra Thornwake**: 
  - *Chapter/Scene*: Chapter 18, Integration and Shadows
  - *Nature of Interaction*: Veyra officially welcomes her to the Company.
  - *Outcome*: Kaida is formally accepted into the team.
  - *Relationship Dynamic*: Marks a turning point in her relationship with the Commander.

## Ability Showcase Scenes
- **Master Infiltration**:
  - *Setting*: High-security facility during rescue mission
  - *Abilities Demonstrated*: Lockpicking, trap detection, silent movement, route planning
  - *Visual Elements*: Hand flexing while working, tools arranged with precision, ghost-quiet movement
  - *Impact on Story*: Enables access to secured location where victims are held
  
- **Trap Navigation**:
  - *Setting*: Dangerous passage filled with security measures
  - *Abilities Demonstrated*: Trap detection and disarmament, understanding of security designer's mind
  - *Visual Elements*: Methodical assessment, precise movements, professional competence under pressure
  - *Impact on Story*: Safe passage for team through dangerous area
  
- **Intelligence Gathering**:
  - *Setting*: Pre-mission reconnaissance of target location
  - *Abilities Demonstrated*: Physical observation, security assessment, route planning
  - *Visual Elements*: Calculating gaze, mental mapping, systematic approach
  - *Impact on Story*: Crucial information for mission planning and execution

## Conflict Scenes
- **Criminal Past Confrontation**:
  - *Context*: Encounter with former criminal associates or law enforcement from her past
  - *Stakes*: Her position with the Company and team acceptance
  - *Character's Approach*: Professional handling while maintaining current identity
  - *Outcome*: TBD
  
- **Method Disagreement**:
  - *Context*: Clash with team member over infiltration approach or criminal methods
  - *Stakes*: Mission success and team cohesion
  - *Character's Approach*: Appeals to professional results and practical effectiveness
  - *Outcome*: TBD
  
- **Betrayer Discovery**:
  - *Context*: Potential scene where she identifies or confronts the person who betrayed her
  - *Stakes*: Resolution of past trauma and trust issues
  - *Character's Approach*: Methodical investigation and professional confrontation
  - *Outcome*: TBD

## Growth Scenes
- **From Service to Purpose**:
  - *Description*: Moment when Kaida realizes she wants to continue rescue work beyond her sentence requirements
  - *Growth Shown*: Evolution from forced compliance to chosen purpose
  - *Key Elements*: Recognition of meaningful application of her skills
  
- **Trust Breakthrough**:
  - *Description*: Scene where Kaida allows herself to trust a team member beyond professional requirements
  - *Growth Shown*: Moving past betrayal trauma to form genuine bonds
  - *Key Elements*: Vulnerability beneath professional exterior
  
- **Identity Integration**:
  - *Description*: Kaida finding balance between criminal professional identity and rescue work purpose
  - *Growth Shown*: Maintaining core self while adapting to new context
  - *Key Elements*: Professional pride applied to noble purpose

## Dialogue Highlights
- **Professional Pride**:
  - *Context*: Describing her criminal career and current work
  - *Key Quotes*: "I was good at it. Professional. Took pride in clean work. Now I'm using the same skills to steal people back from their captors instead of stealing from people."
  - *Emotional Impact*: Shows her philosophy and approach to moral questions
  
- **Partnership Dynamics**:
  - *Context*: Working with Marcus on intelligence gathering
  - *Key Quotes*: "We go with your social intelligence and my physical reconnaissance. That's how partnerships work—cover each other's blind spots."
  - *Emotional Impact*: Demonstrates professional competence and collaborative approach

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
- Scenes should emphasize her professional competence and precise methodical approach
- Hand flexing mannerism should be consistently shown during thinking or working moments
- "Not reformed, just redirected" philosophy should be central to character moments
- Her partnership with Marcus and bond with Grimjaw provide relationship development opportunities
- Criminal background creates natural tension and character development potential
- Visual elements of tool organization and stealth movement should be prominent


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

