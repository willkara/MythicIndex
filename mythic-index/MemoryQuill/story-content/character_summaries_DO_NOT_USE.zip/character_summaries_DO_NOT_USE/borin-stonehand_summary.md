# Borin Stonehand – Profile

## Basic Information
- Full Name: Borin Stonehand
- Aliases/Nicknames: None mentioned
- Age: Middle-aged for a dwarf (at time of death)
- Gender: Male
- Role in Story: Party cleric and moral compass
- First Appearance: Chapter 1, Scene 1 (Twilight on the Rim)
- Status: Deceased (Undershade Canyon)

## Physical Description
- Height/Build: Typical dwarven build, sturdy
- Hair: Not specified
- Eyes: Tracked dangers with "healer's caution"
- Distinguishing Features: Silver-braided emblem of Berronar Truesilver
- Typical Clothing: Clerical vestments with holy symbols
- Body Language: Jovial but steadfast
- Physical Condition: Strong enough to wield a war-hammer

## Significance
Borin Stonehand served as the Gilded Compass's healer and moral guide, a devout cleric of Berronar Truesilver (dwarven goddess of hearth and healing). His protective dome spell (Berronar's Embrace) nearly saved the party but couldn't withstand the cult's dragon-fire. His death represents the loss of spiritual protection and guidance.

## Death Scene
Died attempting to shield Elara and escape through the closing gap, using his divine magic to protect others until the very end. His straining hymn was one of the last sounds Veyra heard before the silence.

## Legacy
- Cracked holy symbol recovered and placed at the lantern's base
- Name inscribed in the Hall of Remembrance
- His protective instinct echoes in the Company's mission
- Represents the divine protection that failed but inspired future dedication


---

# Borin Stonehand - Background

## Origin
- **Birthplace**: A large dwarven city, likely Citadel Adbar or a similar stronghold.
- **Social Class**: Respected clerical class.
- **Cultural Background**: Devout follower of the dwarven pantheon, specifically Berronar Truesilver, the goddess of hearth, home, and healing.

## Family
- **Spouse**: Helga, a master brewer.
- **Children**: Three daughters.
- **Family Dynamics**: A loving and proud husband and father, he often spoke of his family with great affection. His role as a protector was deeply rooted in his love for them.

## History
- **Professional Career**: A cleric of Berronar Truesilver who chose to bring his goddess's protection and healing to the wider world rather than remain in a temple. He served as the cleric and moral compass for the Gilded Compass adventuring party.

## Personal Details
- **A Cherished Possession**: His most prized personal item was a beautifully crafted silver-banded drinking horn, a gift from his wife, Helga. He would often boast that no ale ever tasted as good as his wife's, especially when drunk from that horn.
- **How He Relaxed**: He was a surprisingly nimble dancer. On quiet nights in taverns, after a successful adventure, he could be coaxed into performing a traditional, stomping dwarven jig. His infectious, booming laughter during these moments was a source of immense joy and morale for the entire party.
- **Favorite Meal**: A massive "Forge-Tender's Pie," a savory pastry crust filled with slow-cooked meats, root vegetables, and a thick, ale-based gravy. It's a communal, celebratory meal, meant to be shared, which perfectly suited his role as the heart of the party.


---

# Borin Stonehand - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Borin Stonehand - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Borin Stonehand - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Borin Stonehand - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

