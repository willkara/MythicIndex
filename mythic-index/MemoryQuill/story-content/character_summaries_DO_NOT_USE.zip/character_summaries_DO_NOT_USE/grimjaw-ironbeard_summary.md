# Grimjaw Ironbeard - Profile

## Basic Information
- **Full Name**: Grimjaw Ironbeard
- **Aliases/Nicknames**: "Grandpa" (affectionate nickname from Last Light Company)
- **Race**: Dwarf
- **Class**: Barbarian
- **Role in Story**: Heavy Rescue specialist for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Stocky dwarf built for endurance
- **Hair**: Iron-gray beard braided with small metal charms - pieces of rare ore found over the years and tiny tools that have served him well
- **Eyes**: Bright, keen eyes that still hold curiosity despite his age
- **Distinguishing Features**: Weathered hands and face from decades underground
- **Typical Clothing**: Practical mining clothes: reinforced leather with metal studs, thick boots, and a wide belt with various pouches and loops
- **Body Language**: Solid stance, steady movements, tendency to plant feet firmly when making a point
- **Physical Condition**: Remarkably strong and durable despite advanced age

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Grimjaw Ironbeard.

## Personality
- **Archetype**: The Mentor/Guardian
- **Temperament**: Gruff but warm, practical, patient
- **Positive Traits**: Experienced, dependable, nurturing, resourceful
- **Negative Traits**: Possibly stubborn, set in his ways
- **Moral Alignment**: Lawful Good (values order, tradition, and protecting others)

## Skills & Abilities
- **Expertise**: Mining, structural engineering, rescue operations, underground navigation
- **Languages**: Common, Dwarvish, possibly others related to mining or trade
- **Education Level**: Extensive practical training and lifelong experience
- **Special Abilities**: Exceptional strength and endurance, intuitive understanding of cave-ins and structural integrity. His practical engineering knowledge extends to manipulating simple machinery, as when he disabled the pulley system of a cargo lift to ensure a silent infiltration (Chapter 13).

## Personal Details
- **Habits**: Sharing dwarven spirits with warnings about their potency
- **Hobbies**: Collecting rare ore samples, maintaining his tools
- **Personal Quarters**: A low-ceilinged, roughly hewn room deep within the Bastion's foundations. The air is cool and smells of damp earth and stone. One wall is left as natural, unworked bedrock, with a thin trickle of clean water running down its face into a small stone basin. The bed is a wide stone slab covered in thick, warm furs. This is his personal delve, a connection to his home and his past. He feels most at peace here, surrounded by the comforting weight of the earth. The room is lit by magical lanterns that cast a warm, golden glow, mimicking the light of a dwarven mine. The walls are decorated with antique, masterfully crafted mining tools and shelves displaying his personal collection of geological finds—a quartz crystal cluster that pulses with a faint light, a vein of raw, unpolished silver ore. A loose stone in the bedrock wall pivots to reveal a hidden alcove containing a small, perpetually cool cask of potent dwarven ale, which he shares only with those he truly trusts.
- **Likes**: Practical solutions, sharing wisdom through stories, watching younger members grow
- **Dislikes**: Waste of resources, unnecessary risks, being sidelined due to age
- **Fears**: Possibly fear of becoming truly obsolete or unable to contribute

## Combat & Tactics
- **Primary Weapon**: "Tremor" - a masterwork hybrid war-hammer/mining pick forged for him by his clan to honor his status as a master miner. It is both a symbol of his station and the perfect tool for his trade.
- **Secondary Tools**: Reinforced gauntlets for close-quarters grappling and structural work
- **Armor**: Heavy leather mining gear reinforced with steel plates at vital points - practical protection that doubles as work clothing
- **Specialized Gear**: Collapsible supports, emergency rope, and mining charges adapted for combat demolition
- **Fighting Style**: Immovable anchor - controls battlefield space through sheer presence and defensive positioning
- **Signature Move**: "Mountain's Judgment" - overhead strike with Tremor that can shatter stone or crush armor
- **Combat Philosophy**: "Stand behind me. Nothing gets through" - protection over aggression
- **Tactical Role**: Physical barrier who creates safe zones while providing structural expertise

### Future Equipment Development (Post-Cid Partnership)
- **Enhanced Tremor**: Cid will eventually get her hands on Tremor for some... "unauthorized" upgrades, much to Grimjaw's initial chagrin and eventual appreciation.

## Psychological Response Matrix
- **In Crisis**: Becomes the physical and emotional anchor point for the team, provides steady leadership through calm presence
- **During Negotiation**: Stands as silent, imposing protection while offering practical wisdom when asked
- **Moral Dilemma**: Defers to Veyra's judgment but offers perspective based on decades of life experience
- **Team Conflict**: Mediates through paternal wisdom, often suggesting arm wrestling to settle minor disputes
- **Under Personal Attack**: Laughs off insults with "Heard worse from better" while mentally assessing if protection is needed
- **In Victory**: Immediately ensures everyone eats properly and gets rest - caretaker instincts activate

## Voice & Dialogue Patterns
- **Speech Style**: Deep, rumbling bass voice that speaks slowly but with great weight behind each word
- **Signature Phrases**: 
  - "Rocks don't lie, people do"
  - "Proper foundations prevent poor structures"
  - "This'll either solve your problems or make you forget them" (offering his flask)
- **Mining Metaphors**: Uses geological and engineering terms for everything - relationships have "load-bearing points," plans need "proper support beams"
- **Example Dialogue**: "This plan's got cracks running through it. We shore it up with backup plans, or the whole thing collapses when pressure hits."
- **Paternal Voice**: Warm undertone when speaking to younger team members, gruff exterior hiding deep care
- **Emotional Tells**: Strokes beard when thinking, plants feet wide when making important points

## Notes
- Achieved everything he set out to do as a master miner before joining the Company
- Could have transitioned to comfortable clan elder roles but wanted more active purpose
- Reputation as "the old dwarf who never loses anyone" during mine safety consultant days
- Finding purpose in his later years through rescuing people rather than extracting minerals
- Has found a chosen family in the Last Light Company while maintaining clan connections

### Public Perception
- Known as "Grandpa" by the Company, and seen by common folk as a gruff but warm mentor who freely shares his practical wisdom.
- Rumored to possess incredible strength, capable of feats like single-handedly lifting collapsed carts.
- Respected for his unwavering loyalty to the Company and his protective nature, especially towards younger members.


---

# Grimjaw Ironbeard - Background

## Origin
- **Birthplace**: A dwarf stronghold in the Sword Mountains.
- **Birth Date**: Several decades ago (exact age TBD, but in later years).
- **Social Class**: Respected working class, master craftsman.
- **Cultural Background**: Traditional dwarven mining culture.

## Family
- **Parents**: TBD
- **Siblings**: TBD
- **Extended Family**: He is a proud grandfather. While his clan would have been happy to see him accept a comfortable seat on the elder council, they understand his nature and fully support his work with the Company.
- **Family Dynamics**: Maintains strong connections with his clan but has found a new "family" in the Last Light Company.

## History
- **Childhood**: 
  - *Key Events*: Began his mining apprenticeship at a young age, as is dwarven tradition.
  - *Formative Experiences*: Early lessons in stone-craft, mineral identification, and the ever-present dangers of life underground.
  
- **Education/Training**: 
  - *Institutions*: The traditional dwarven apprenticeship system.
  - *Mentors*: Master miners who taught him the craft.
  - *Areas of Study*: Mining techniques, structural engineering, ore identification.
  
- **Professional Career**:
  - *Milestone 1*: Achieved the rank of master miner, becoming a legend in his clan for his skill.
  - *Milestone 2*: Transitioned to a mine safety consultant. This move wasn't born from a single tragedy, but from a lifetime of seeing less-careful miners get injured through carelessness. He has an artisan's intolerance for sloppy work, especially when lives are on the line.
  - *Milestone 3*: Built a legendary reputation as "the old dwarf who never loses anyone."
  
- **Major Life Events**:
  - *Event 1*: The Blackvein Mine Collapse - Hired as a consultant by the nascent Last Light Company for a perilous rescue.
  - *Event 2*: The Joining - After witnessing their unwavering commitment to "no one left behind," a philosophy that mirrored his own, he chose to stay on, transitioning from a one-time consultant to a core member of the team. He found a new purpose and a new family, choosing the work over a comfortable retirement.

## Backstory Elements
- **Defining Moments**: 
  - Reaching the pinnacle of his mining career.
  - Choosing active rescue work over a comfortable clan elder status.
  - The Blackvein Mine Collapse, where he saw in Veyra the same fire and purpose that drove him.
  
- **Greatest Achievements**: 
  - His perfect safety record as a consultant.
  - The successful rescue at the Blackvein Mine.
  - Becoming the beloved patriarch of the Last Light Company.

## How They Got Here
- **Reason for Current Situation**: After a long and successful career, Grimjaw found himself facing a quiet retirement, a fate he found more terrifying than any collapsing mine. He sought continued purpose. The Blackvein Mine Collapse was the catalyst. In the Last Light Company, he saw a group that embodied his hard-won philosophy: "You can always find more gold, but you can't find another person." He joined not for coin or glory, but for the profound satisfaction of doing the work that needed to be done.

## Historical Connections
- **Connection to Main Plot**: Heavy Rescue specialist for the Last Light Company.
- **Connection to Other Characters**: 
  - "Grandpa" figure to the younger Company members.
  - Shares a friendly but fierce professional rivalry with Korrath Threnx. They often engage in spirited debates over the merits of dwarven intuition versus Dragonborn methodology, always resulting in a better plan.
- **Connection to Story World**: 
  - Extensive knowledge of the underground regions of the Sword Coast.
  - Connections to dwarven clans and mining communities.

## Personal Details
- **How He Relaxes**: He finds a deep sense of peace in the simple, repetitive act of sharpening tools. 
- **Favorite Meal**: A slow-roasted cave boar, seasoned with rock salt and wild mushrooms.
- **A Surprising Hobby**: He is a surprisingly talented singer of old dwarven sagas.


---

# Grimjaw Ironbeard - Character Development

## Personality Core
- **Defining Traits**: Experienced, dependable, nurturing, practical
- **Core Values**: Protection of others, sharing wisdom, finding purpose, clan honor
- **Motivations**: Applying lifetime of knowledge to meaningful work, guiding younger generation
- **Fears**: Becoming obsolete, inability to contribute, losing chosen family
- **Internal Conflicts**: Traditional clan expectations vs. chosen family with Company
- **Contradictions**: Gruff exterior with deeply compassionate nature, traditional values with progressive choices

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Accomplished master miner who achieved all professional goals
  - *World View*: Traditional dwarven perspective valuing craft, clan, and mineral wealth
  - *Key Relationships*: Primarily clan and professional connections
  
- **Catalyst Events**:
  - *Event 1*: Reaching pinnacle of mining career
  - *Event 2*: Facing traditional retirement into clan elder role
  - *Event 3*: Possible rescue experience that changed perspective on value of lives
  - *Event 4*: Introduction to Last Light Company and their mission
  
- **Current State**:
  - *Self-Perception*: "Grandpa" figure with purpose beyond traditional roles
  - *World View*: "You can always find more gold, but you can't find another person"
  - *Key Relationships*: Last Light Company as chosen family while maintaining clan ties
  
- **Intended Destination**:
  - *Self-Perception*: TBD - continued growth as mentor figure
  - *World View*: TBD - further integration of traditional values with new purpose
  - *Key Relationships*: TBD - deeper bonds with Company members

## Growth Milestones
- **From Master Miner to Safety Consultant**: 
  - *Development Noted*: Shift from extraction to protection
  - *Catalyst*: Possibly witnessing mine disasters or losing colleagues
  - *Impact*: Reputation as "the old dwarf who never loses anyone"
  
- **From Consultant to Company Member**: 
  - *Development Noted*: Finding new purpose in rescue work
  - *Catalyst*: Seeing value of Last Light Company's mission
  - *Impact*: Integration into new "family" structure
  
- **From Professional to "Grandpa"**: 
  - *Development Noted*: Evolution from technical advisor to emotional support figure
  - *Catalyst*: Building relationships with younger members
  - *Impact*: Development of mentorship style through stories and shared experiences

## Character Flaws
- **Possible Stubbornness**: 
  - *Effects on Character*: May resist new methods or approaches
  - *Effects on Others*: Could create friction with innovative team members
  - *Development Plan*: Learning to balance experience with openness to new ideas
  
- **Overprotectiveness**: 
  - *Effects on Character*: Might take unnecessary risks to protect others
  - *Effects on Others*: Could undermine others' growth by not allowing them to face challenges
  - *Development Plan*: Finding balance between protection and allowing necessary risks

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Possibly harbors regrets from early career prioritizing wealth over safety
  - *Secret 2*: May have specific reasons beyond general purpose for joining Company
  
- **Unknown to Character**:
  - *Truth 1*: TBD - impact of his mentorship on specific Company members
  - *Truth 2*: TBD - how much he's truly needed and valued by the group
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Choosing Safety Over Pure Extraction**:
  - *Context*: Possibly after mining incident
  - *Options Considered*: Continue traditional mining vs. focus on safety
  - *Choice Made*: Shifted focus to protecting miners
  - *Consequences*: Development of perfect safety record and reputation

- **Rejecting Traditional Retirement**:
  - *Context*: Reaching end of active mining career
  - *Options Considered*: Comfortable clan elder role vs. continued active work
  - *Choice Made*: Pursued continued meaningful contribution
  - *Consequences*: Path to Last Light Company

- **Joining Last Light Company Full-Time**:
  - *Context*: Transition from occasional consultant
  - *Options Considered*: Maintain distance vs. full integration
  - *Choice Made*: Embraced Company as chosen family
  - *Consequences*: Development of "Grandpa" role and deeper purpose

## Development Notes
- Character represents transition from traditional values to finding new purpose in later years
- The modular mining pack symbolizes adaptability despite age - old tools with new applications
- Beard charms represent physical manifestation of experiences and stories
- Hip flask of dwarven spirits serves as social bonding tool and metaphor for his advice (potent, effective)
- Mining metaphors in speech reflect how he processes and shares wisdom
- "Grandpa" nickname shows successful integration into new family structure
- Comfort style during difficult moments shows emotional growth beyond technical expertise

## Psychological Profile
*   **Grimjaw Ironbeard (The Patriarch):** Having already lived a full and successful life, Grimjaw is motivated by a desire for continued purpose and a deep-seated need to nurture and protect. He has nothing left to prove, which makes him the perfect mentor. His gruffness is a shield for a deeply warm and paternal heart. He sees the younger members as his "kids" and his clan, and his greatest fear is being seen as obsolete or unable to protect them.


---

# Grimjaw Ironbeard - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Heavy Rescue specialist
  - *Hierarchy*: Respects her leadership while offering experience-based counsel
  - *Dynamics*: Likely sees potential in her and supports her mission
  - *History*: TBD when they first met
  - *Current Status*: Trusted team member, possible advisor
  - *Professional Opinion of*: Respects her dedication to leaving no one behind

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Heavy Rescue specialist
  - *Hierarchy*: Respects chain of command while offering practical insights
  - *Dynamics*: May appreciate Thorne's military discipline as complementary to rescue operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely values his tactical approach to operations

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist in Last Light Company
  - *Hierarchy*: Equals with different expertise
  - *Dynamics*: His underground knowledge may complement her surface tracking
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her skills, may take interest in her search for her brother

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (rescue and medical)
  - *Dynamics*: Would work closely in rescue operations - Grimjaw extracting victims, Aldwin treating them
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely appreciates his healing skills and calm demeanor

- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (rescue and magical support)
  - *Dynamics*: Her weather magic could help create safe conditions for his rescue operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values her magical capabilities and research approach

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (rescue and negotiation)
  - *Dynamics*: His diplomatic skills might help resolve situations before rescue becomes necessary
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates his ability to handle political complications

- **Nireya Voss**:
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (rescue and spiritual)
  - *Dynamics*: Her spiritual abilities might provide information about victims' conditions
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her unique abilities despite finding spiritual approach mysterious

- **Cidrella "Cid" Vexweld**:
  - *Nature of Relationship*: Surrogate daughter and personal quartermaster.
  - *Hierarchy*: He is the grizzled veteran, and she is the brilliant prodigy he has taken under his wing.
  - *Dynamics*: This is one of the warmest and most endearing relationships in the Company. Grimjaw treats Cidrella with the gruff, paternal affection of a dwarven father. He is immensely proud of her intellect and trusts her implicitly with his life and gear. He is fiercely protective of her and often brings her interesting minerals or broken contraptions he finds on missions.
  - *History*: Their bond was forged in the workshop. Cidrella, fascinated by his work, designed and built his advanced modular pickaxe and mining pack. Grimjaw was so impressed by her skill and dedication that he unofficially "adopted" her.
  - *Current Status*: A deep, familial bond. He calls her "Vexxy," and she complains about it, but they would both do anything for each other.
  - *Feelings Toward*: He sees her as the daughter he never had. He is endlessly impressed by her mind and trusts her craftsmanship more than anyone else's.

- **Korrath "Wallbreaker" Threnx**:
  - *Nature of Relationship*: Paternal Triangle; Mentor and Colleague.
  - *Hierarchy*: Peers, but Grimjaw has the seniority of age and experience.
  - *Dynamics*: Grimjaw acts as a warm, nurturing patriarch to the "kids," while Korrath is the stern, demanding father-figure who pushes for perfection to prevent disaster. Grimjaw often has to play mediator between Korrath's rigid safety protocols and Cid's explosive experiments, usually with a calming story and a shared drink.
  - *History*: TBD
  - *Current Status*: Professional colleagues with a paternal dynamic.
  - *Feelings Toward*: He respects Korrath's skill but sometimes finds him too rigid, reminding him to see the people behind the engineering problem.

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Fellow Company member whose skills saved his life
  - *Hierarchy*: Different specialties (rescue and infiltration)
  - *Dynamics*: Special bond formed through life-saving event during trap-filled fortress mission
  - *History*: Kaida's expertise saved the mission and specifically saved Grimjaw's life
  - *Current Status*: Professional colleagues with special gratitude
  - *Professional Opinion of*: Deep respect and gratitude for her professional competence and life-saving skills
  - *Development Potential*: Deeper trust and protective instinct based on shared life-and-death experience

## Mentorship Relationships
- **Younger Company Members**:
  - *Relationship Type*: Mentor/grandfather figure
  - *History*: Built over time through shared missions
  - *Current Status*: Unofficial "Grandpa" of the group
  - *Dynamics*: Offers guidance through stories and mining metaphors
  - *Notable Interactions*: Sharing "proper dwarven spirits" with warnings about potency
  - *Style of Mentoring*: Practical wisdom disguised as rambling tales, comforting presence during difficult moments

## Clan Relationships
- **Dwarven Clan Members**:
  - *Relationship Type*: Kin, elder
  - *History*: Lifetime connection
  - *Current Status*: Maintains connections though less present
  - *Feelings Toward*: Respect and affection, but found new purpose
  - *Tensions/Issues*: Possible disapproval of choosing "outsiders" over clan responsibilities
  - *Shared Experiences*: Mining traditions, clan history

## Former Professional Connections
- **Mining Colleagues**:
  - *Relationship Type*: Former workmates
  - *History*: Years of collaboration
  - *Current Status*: Likely some ongoing connections
  - *Dynamics*: Mutual respect based on shared profession
  - *Notable Individuals*: TBD

- **Safety Consultation Clients**:
  - *Relationship Type*: Professional service
  - *History*: Established reputation as consultant who "never loses anyone"
  - *Current Status*: May still maintain some connections
  - *Dynamics*: Built on proven expertise and results
  - *Notable Clients*: TBD

## "Family" Relationships
- **Last Light Company as Chosen Family**:
  - *Relationship Type*: Surrogate family in later years
  - *History*: Gradual transition from consultant to regular member
  - *Current Status*: Considers the Company his true purpose
  - *Feelings Toward*: Deep attachment, protective instinct
  - *Tensions/Issues*: May worry about losing this new family
  - *Shared Experiences*: Rescue missions, downtime between operations

## Interpersonal Patterns
- **Comfort Style**:
  - Offers stories that start with "Reminds me of the time..."
  - Delivers practical wisdom through mining metaphors
  - During tough moments: "Want to talk about it, or just sit for a while?"
  - Sharing flask of dwarven spirits as bonding ritual

- **Conflict Resolution**:
  - Likely uses experience to defuse tensions
  - May tell stories of past conflicts and their resolutions
  - Probably values direct, honest communication

## Relationship Evolution Tracker
- **Pre-Company**: Clan and mining community relationships
- **Early Consultancy**: Professional relationship with Company
- **Transition**: Growing personal connections beyond professional role
- **Current**: "Grandpa" of the chosen family while maintaining clan ties
- **Future**: TBD

## Notes on Potential Relationships
- May have special bonds with any Company members who've been rescued from underground situations
- Could have particular affinity for any other dwarves in the Company
- Might form special connections with younger members seeking guidance
- Possibly maintains network of contacts in mining communities that provide information


---

# Grimjaw Ironbeard — Dialogue & Psyche

## Core temperament
Gruff, matter-of-fact, and pragmatic. A lifetime working with stone taught him to value competence over talk; his words are reserved but weighted.

## Dialogue instincts
- Public: blunt, short, often in dwarven proverbs or earth metaphors. Speaks with authority on technical matters.
- Teaching: uses practical demonstrations and terse instructions rather than long explanations.
- Under pressure: steady, direct commands; rarely panics and rarely over-explains.
- Humor: dry, sardonic; irony rooted in craft and experience.

## Emotional anchors & physical tells
- Grunt or snort before (or instead of) laughter; a slow, rare grin is genuine approval.
- Hands and posture: always assessing—fingers drumming, eye on structural lines.
- Pulls at beard when thinking; sets pickaxe down deliberately to signal end of business.
- Voice: low, gravelly; cadence measured and economical.

## Conflict & humor rules
- Will mock bureaucracy and empty protocol; values competence and results.
- Avoids sentimentality; when he speaks kindly it's through actions or a short, sincere line.
- Jokes are often about tools, the mountain, or the absurdity of ignorance.

## Writer cues (practical)
- Use Grimjaw for technical, tactical instructions about structure, mining, or heavy rescue.
- Let him give concise, vivid imagery tied to stone and pressure to teach or warn.
- When expanding scenes, let him cut through over-discussion with one-line prescriptions and then demonstrate.

## Drop-in sample lines (from Chapters 7-9)
- **On his retirement:** "I said bugger off."
- **On incompetence:** "Idiots probably using pine bracers."
- **On his philosophy:** "The mountain always wins in the end, son. The trick is knowing when to stop digging."
- **On his methods:** "Save? No. Free? Maybe."
- **On the company's nature:** "Outcasts."
- **On priorities:** "Good tools."
- **Dry humor:** "No, I'm a very short human with excellent taste in beards."
- **On his new home:** "A roof over my head and honest work to be done. It's a start."

## Voice evolution note (chapters 1–9)
- Introduction: an aloof craftsman with a reputation and mastery.
- Middle: gradually integrates socially—shows small softness toward the Company.
- Later: remains terse but increasingly invests himself in training and protecting the group.

## Usage examples (scenes)
- Rescue operations: short, absolute orders—use him to restore control when improvisation fails.
- Campfire moments: spare proverbs and a rare, rough grin reveal his acceptance of the Company.
- Technical explanation: vivid, tactile metaphors about stone and pressure rather than abstract theory.

## Notes for editors
- Keep Grimjaw's language compact and metaphor-rich with geological imagery.
- Avoid making him overly verbose; his authority comes from brevity and demonstration.


---

# Grimjaw "Stoneheart" Ironbeard - Scene Tracker

## Major Scenes

### Chapter 7 – The Weight of the World <!-- slug: ch7-weight-world -->
- **Scene 2**: Introduction at his mountain home, reluctance to help
- **Scene 3**: Rescue leadership at Blackvein Lode, display of engineering mastery
- **Scene 4**: Decision to join the Last Light Company

### Chapter 8 – Foundations of Stone and Spirit <!-- slug: ch8-stone-spirit -->
- **Scene 1**: Journey from his cabin, sharing knowledge and stories
- **Scene 2**: Establishing his mentorship role within the Company

### Chapter 9 – The Westwall Welcome <!-- slug: ch9-westwall-welcome -->
- **Scene 1**: First impressions of the Westwall Watchpost
- **Scene 2**: Integration into the Company's daily life

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 1**: Preparing for winter rescue mission, assessment of ice-covered ruins
- **Scene 2**: Professional evaluation of the Thornwood misunderstanding
- **Scene 4**: Examining the structure of Vera's animal-made windbreak
- **Scene 7**: Selected for tracking mission due to structural expertise
- **Scene 9**: Pragmatic reaction to Vera's execution of trafficker ("Dead men don't answer questions")
- **Epilogue**: Bawdy winter tale about misunderstood invitation during dinner

### Chapter 12 – The Wayward Compass <!-- slug: ch12-wayward-compass -->
- **Scene 1**: Assessing the broken cart axle with professional expertise.
- **Scene 2**: Providing a solid, intimidating presence during the standoff at the inn.

### Chapter 13 – An Honest Coin <!-- slug: ch13-honest-coin -->
- **Scene 1**: Voicing skeptical but pragmatic opinion of Marcus.
- **Scene 2**: Arguing in favor of the practical benefits of Marcus's offer.

## Character Moments

### Best Moments
- Rescue leadership at Blackvein Lode (Ch. 7)
- Knowledge sharing during journey (Ch. 8)
- Engineering assessment of animal-built windbreak (Ch. 10)
- Winter romance story revealing more personal side (Ch. 10)

### Worst Moments
- Initial reluctance to join the Company (Ch. 7)
- Frustration over lost intelligence from dead trafficker (Ch. 10)

### Turning Points
- Decision to join the Last Light Company (Ch. 7)
- Acceptance of Vera's lethal methods despite tactical disagreement (Ch. 10)

## Interaction Log

### With Veyra Thornwake
- Chapter 7: Being recruited after mine rescue
- Chapter 10: Selected for tracking mission, supporting her leadership

### With Thorne Brightward
- Chapter 7: Initial assessment as a capable soldier
- Chapter 10: Professional cooperation during winter missions

### With Aldwin Gentleheart
- Chapter 7: Beginning of working relationship during mine rescue
- Chapter 10: Coordination during child rescue mission

### With Vera Moonwhisper
- Chapter 10: First meeting during her rescue
- Chapter 10: Tactical disagreement over killing trafficker
- Chapter 10: Building rapport during dinner scene

## Upcoming Scenes

### Planned Appearances
- Engineering focus during rescue missions
- Possible contribution to permanent Company headquarters
- Further development of mentorship role with newer members

### Required Interactions
- Further development of relationship with Vera after tactical disagreement
- Possible deeper integration of engineering knowledge with Vera's tracking
- Continued sharing of life experiences and stories with the Company


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

