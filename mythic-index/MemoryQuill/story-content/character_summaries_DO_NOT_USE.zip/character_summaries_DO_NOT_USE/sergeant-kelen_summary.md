# Sergeant Kelen – Profile

## Basic Information
- **Full Name**: Kelen Harwick (surname rarely used - prefers rank)
- **Aliases/Nicknames**: "Sergeant", "Kel" (only by close family), "The Rock" (patrol nickname)
- **Race**: Human (Illuskan)
- **Age**: 44 (veteran but not yet old guard)
- **Gender**: Male
- **Role in Story**: Thorne's second-in-command, Company Senior NCO, Founding Patrol Member
- **First Appearance**: Chapter 1, Scene 5 (Arrival of the Watch)
- **Status**: Active

## Physical Description
- **Height/Build**: 5'10", solid but not bulky - functional strength built from years of practical military work
- **Hair**: Iron-gray, kept regulation short but starting to thin at the temples. Shows his age and experience
- **Eyes**: Weathered brown, always scanning for threats or problems. Crow's feet from years of squinting in sun and smoke
- **Distinguishing Features**: 
  - Scarred, calloused hands that are a roadmap of his career - burn marks, blade nicks, rope cuts
  - Old knife scar along left jawline from early Watch service
  - Arrow scar on right shoulder (visible when out of armor)
  - Slight limp in left leg from an old injury, barely noticeable unless exhausted
- **Typical Clothing**: Immaculately maintained City Guard armor, always checking buckles and straps. Off-duty wears simple, practical clothes in muted colors
- **Body Language**: Perfect military posture even when relaxed, moves with economical precision, instinctively positions himself to protect others
- **Physical Condition**: Combat-ready veteran in excellent shape for his age, built for endurance rather than flash

## Personality
- **Archetype**: The Steadfast Foundation - The Senior NCO who makes everything work
- **Temperament**: Steady, practical, protective, quietly authoritative
- **Positive Traits**: Absolutely reliable, fiercely loyal, protective of his people, calm under pressure, excellent judge of character
- **Negative Traits**: Can be overly cautious, struggles with emotional expression, tends to shoulder too much responsibility alone
- **Moral Alignment**: Lawful Good - believes in doing right by your people within proper structure
- **Core Philosophy**: "Take care of your people, and they'll take care of the mission" / "Lead from the front, but watch everyone's back"
- **Leadership Style**: "Follow me" rather than "Go there" - leads by example and quiet competence

## Significance
Sergeant Kelen serves as Captain Thorne's trusted second-in-command and was part of the patrol that rescued Veyra from Undershade Canyon. His steady presence and loyalty make him a natural choice as a founding member of the Last Light Company. He represents military discipline and the bridge between command and ground operations.

## Key Actions
- Helped stabilize Veyra's lantern during her collapse
- Arranged the bodies of the fallen with respect
- Brought lamp oil to Veyra during recovery
- Participated in the patrol's vigil
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).

## Skills & Abilities
- **Expertise**: Military tactics, personnel management, defensive combat, urban warfare
- **Leadership Skills**: Delegation, crisis management, troop morale, practical problem-solving
- **Combat Abilities**: 
  - Defensive fighting style focused on protection rather than aggression
  - Expert with sword and shield - prioritizes covering others
  - Exceptional situational awareness in combat
  - Training in siege defense and urban patrol tactics
- **Special Skills**: 
  - Can assess character and competence within minutes of meeting someone
  - Network of contacts throughout Waterdeep City Watch
  - Expert in military logistics and supply management
  - Knows the city's security systems and protocols intimately

## Personal Details
- **Habits**: 
  - Up before dawn for equipment inspection and duty roster review
  - Writes weekly letters to his daughter Elspeth (factual, not emotional)
  - Evening equipment maintenance ritual before sleep
  - Always eats last, after ensuring everyone else is fed
- **Hobbies**: 
  - Carves small wooden figures (childhood habit that persists)
  - Reads tactical manuals and military history
  - Takes long walks around perimeter to think and plan
- **Personal Quarters**: A spartan and precisely organized room on the ground floor of the Company barracks, strategically positioned with clear sightlines to the main entrance and quick access to the armory. The room is modest in size, reflecting his practical needs rather than comfort preferences. The furniture is heavy, functional, and made of dark, unadorned wood, all arranged at perfect right angles. The room is immaculately clean and organized. Every item has a designated place and purpose. A small wooden shelf holds carefully curated personal items: a bundle of letters from his daughter Elspeth, a small framed sketch of his late wife Anya, and several carved wooden figures he's made.
- **Likes**: Military efficiency, good equipment maintenance, soldiers who follow orders, protecting his people
- **Dislikes**: Waste (of supplies or lives), unnecessary risks, politicians who endanger troops, incompetent leadership
- **Fears**: Failing his people, his daughter being targeted because of his work, losing more family
- **Motivations**: Providing for and protecting Elspeth, ensuring his people come home safe, building something lasting with the Company

## Voice & Dialogue Patterns
- **Speech Style**: Economical with words, clear directives, gravelly voice from years of shouting orders
- **Voice Quality**: Can speak quietly when needed but naturally projects authority
- **Verbal Tics**: 
  - "Right then..." when making decisions or taking charge
  - "As you were" to dismiss concerns or redirect focus
  - "Watch your six" as general warning about potential dangers
  - Uses ranks/roles rather than names in crisis situations
- **Signature Phrases**:
  - "Take care of your people, and they'll take care of the mission"
  - "I've seen worse. We'll manage."
  - "Good work. Now check your gear."
  - "Lead from the front, watch everyone's back"
- **Communication Style**: Direct but not harsh, gives orders that sound like suggestions to civilians but are clearly understood by military personnel

## Equipment
- **Primary Weapon**: Standard City Watch longsword, well-maintained but not fancy
- **Secondary Weapon**: Military dagger, practical tool as much as weapon
- **Armor**: City Watch plate armor, meticulously maintained with personal modifications for better fit
- **Shield**: Heavy shield with Company emblem, used defensively to protect others
- **Personal Items**: 
  - Carved wooden figures (gifts for Elspeth, stress relief)
  - Military field manual (extensively annotated)
  - Small toolkit for equipment maintenance
  - Letters from his daughter (carefully preserved)

## Combat Style
- **Primary Role**: Defensive coordinator, protects others rather than seeking glory
- **Pre-Combat**: Becomes quieter, checks everyone's equipment twice
- **In Combat**: Positions himself to shield others, calls out threats and coordination
- **Post-Combat**: Immediately shifts to casualty assessment and equipment status
- **Tactical Philosophy**: "Everyone comes home" - values team survival over individual heroics

## Future Role
Expected to become the Company's Senior NCO and operational backbone, handling field operations, maintaining discipline, and serving as the bridge between command decisions and ground implementation. Will likely become the Company's institutional memory and training coordinator.


---

# Sergeant Kelen – Background

## Origin
- **Birthplace**: Waterdeep's Dock Ward - specifically the Fishgut Court tenements
- **Birth Date**: Born during the harsh winter of the Year of the Broken Blade
- **Social Class**: Lower class - dockworker family living in overcrowded conditions
- **Cultural Background**: Urban poor, shaped by the harsh realities of Waterdeep's most dangerous district. Learned early that survival meant structure, loyalty, and watching out for your own.

## Family
- **Father**: Jorik Harwick - dockworker lost in a shipping accident when Kelen was 12. Taught Kelen the value of hard work and keeping your word. His death left the family destitute.
- **Mother**: Mara Harwick - seamstress who took in piecework to support the family. Died of lung fever two years after Jorik's death, worn down by poverty and grief.
- **Spouse**: Anya Harwick (née Millwright) - met her when she was a baker's assistant. Married young for love and stability. She died from red fever during an epidemic ten years ago, leaving Kelen to raise Elspeth alone.
- **Daughter**: Elspeth Harwick, now 22 - apprenticed to Master Bookbinder Aldric Thornton in the Trades Ward. Bright, independent, and skilled with her hands like her grandmother. 
- **Family Dynamics**: 
  - Lost his parents early, learned responsibility young
  - With Anya: Brief happiness interrupted by tragedy - her death taught him that love makes you vulnerable
  - With Elspeth: Protective but distant - sends most of his pay, writes weekly letters, visits rarely to keep her safe from his dangerous work
  - Fears that getting too close to people leads to loss, but can't stop himself from caring

## History

### Early Life (Ages 0-18)
- **Childhood**: Grew up in Fishgut Court tenements after parents' deaths. Survived by doing odd jobs around the docks, learned to read from a sympathetic priest of Tyr.
- **Adolescence**: Avoided the gangs and criminal opportunities of the Dock Ward through sheer stubbornness and the memory of his father's work ethic.
- **Turning Point**: At 16, witnessed a City Watch patrol save a group of children from kidnappers. Realized the Watch offered both structure and purpose.

### Military Career (Ages 18-44)
- **Watch Academy (Age 18-19)**: Excelled in discipline, defensive tactics, and leadership exercises. Graduated top of his class in practical application.
- **Early Service (Ages 19-22)**: Foot patrol in the Dock Ward. Earned reputation for fairness and courage. Received knife scar during a tavern brawl intervention.
- **Promotion to Corporal (Age 23)**: Recognized for preventing a riot during grain shortage. Began developing his protective leadership style.
- **Marriage and Family (Ages 24-34)**: Met and married Anya, had Elspeth. Tried to balance family life with increasingly dangerous Watch duties.
- **The Red Fever Epidemic (Age 34)**: Lost Anya during city-wide plague. Nearly left the Watch but stayed for Elspeth's security.
- **Promotion to Sergeant (Age 36)**: Given command of his own patrol after previous sergeant was killed in action. Arrow scar from defending supply convoy.
- **Partnership with Thorne (Ages 38-44)**: Assigned as second-in-command to Captain Brightward. Developed perfect working relationship over six years.

### Personal Growth & Development
- **Core Trauma**: Multiple losses taught him that caring for people means accepting the risk of losing them
- **Leadership Evolution**: From following orders to taking initiative to protecting his people above all else
- **Emotional Walls**: Built protective distance after Anya's death, but can't stop himself from caring for his patrol family
- **Current Philosophy**: "Take care of your people" became his guiding principle after learning leadership through loss

### The Undershade Canyon Incident
- **The Rescue**: Part of Thorne's patrol that found Veyra. Immediately recognized her soldier's dedication to fallen comrades.
- **Key Moment**: His understanding that "she won't leave without them" showed his recognition of the same protective duty he felt.
- **Decision to Follow**: Initially followed Thorne's lead, but Veyra's commitment to remembering the dead resonated with his own losses.
- **Company Formation**: Saw the Last Light Company as a chance to build something permanent that honors both the living and the fallen.

---

# Sergeant Kelen – Character Development

## Personality Core
- **Defining Traits**: Steady, reliable, pragmatic, protective, quietly authoritative, emotionally guarded
- **Core Values**: Duty to your people above all else, earned respect over rank, the soldier's code of "everyone comes home"
- **Motivations**: 
  - Providing for and protecting Elspeth from a distance
  - Ensuring his people survive and thrive under his protection
  - Building something lasting with the Company that honors both living and dead
  - Breaking the cycle of loss that has defined his life
- **Fears**: 
  - Failing his people like he couldn't save Anya
  - Elspeth being targeted because of his dangerous work
  - Getting too close to Company members only to lose them
  - Making the wrong call that gets someone killed
- **Internal Conflicts**: 
  - Military protocol vs. Company's unconventional methods
  - Protective distance vs. genuine care for Company family
  - Past grief vs. present hope for building something better
  - Duty to daughter vs. duty to Company

## Character Arc

### Act I: The Weary Soldier
- **Starting Point**: Competent but emotionally distant sergeant going through the motions
- **Internal State**: Protective walls built after Anya's death, focus solely on duty and Elspeth's welfare
- **Relationship Pattern**: Professional competence masking deep emotional isolation

### Act II: The Awakening
- **Catalyst Events**: 
  - Undershade Canyon rescue - witnessing Veyra's dedication to fallen comrades
  - Recognition of shared soldier's code and protective duty
  - Decision to follow Thorne into the unknown with the Company
- **Internal Shift**: Purpose reignited, seeing possibility of building something meaningful
- **New Challenges**: Learning to trust and care for new "family" while protecting heart

### Act III: The Foundation Builder
- **Current State**: Becoming emotional and operational anchor for the Company
- **Growth Areas**: 
  - Learning to accept help and emotional support from others
  - Balancing protective instincts with allowing people their own agency
  - Opening up about his past and fears to trusted Company members
- **Relationship Evolution**: From distant protector to engaged patriarch figure

### Act IV: The Patriarch (Future Development)
- **Intended Destination**: Company's senior NCO and emotional cornerstone
- **Full Arc Completion**: 
  - Accepting that caring deeply is worth the risk of loss
  - Allowing Elspeth into his dangerous world when she's ready
  - Becoming the father figure the Company needs while staying connected to his own daughter
  - Building institutional knowledge and training systems for future recruits

## Key Relationships

### Core Command Structure

**Captain Thorne Brightward**:
- **Nature of Bond**: Perfect officer/NCO partnership built on six years of absolute trust
- **Dynamics**: Thorne gives the order, Kelen ensures it's done right. He is the shield to Thorne's sword.
- **Communication**: Largely unspoken understanding, can anticipate each other's needs in crisis
- **Personal Connection**: Mutual respect and genuine friendship beneath professional facade
- **Role**: Kelen handles details so Thorne can focus on strategy; protects Thorne's blind spots

**Commander Veyra Thornwake**:
- **First Impression**: "Another one lost to the wilds. Gods, the look in her eyes... she's seen hell."
- **Recognition Moment**: Watching her meticulous work with fallen comrades' bodies - recognized shared soldier's code
- **Why He Follows**: Initially followed Thorne's lead, but her commitment to "no one left behind" resonated with his protective nature
- **Current Relationship**: Sees her as living embodiment of the protective duty he values
- **Future Dynamic**: Will become her most reliable anchor, translating vision into practical reality

### Original Patrol Family

**Corporal Darric, Archer Venn, Medic Halden, Quartermaster Fayne**:
- **Bond Type**: Surrogate family unit that replaced his lost biological family
- **History**: Years of shared danger, mutual protection, inside jokes and survival
- **His Role**: Protective older brother/father figure who knows each member's strengths and limitations
- **Emotional Investment**: Deeper than professional - these are "his people" in the truest sense
- **Growth**: Learning to express care more openly as they transition from Watch to Company

### Specialists Integration

**Grimjaw Ironbeard**:
- **Common Ground**: Both understand the weight of protecting others, practical approach to problems
- **Mutual Respect**: Recognizes Grimjaw's competence and dedication despite different background
- **Professional Appreciation**: Values his engineering skills and willingness to get dirty
- **Potential Tension**: Grimjaw's informal style vs. Kelen's military structure

**Vera Moonwhisper**:
- **Professional Respect**: Appreciates her tracking abilities and wilderness expertise
- **Protective Instinct**: Sees her youth and wants to keep her safe while respecting her competence
- **Learning Opportunity**: Her different approach to problem-solving challenges his military thinking

**Nireya Voss**:
- **Initial Wariness**: Unsettled by her supernatural abilities and dual nature
- **Growing Understanding**: Comes to appreciate her dedication to remembering the fallen
- **Protective Role**: Recognizes her vulnerability after using her powers, ensures she's cared for
- **Philosophical Connection**: Both deal with loss and honoring the dead in their own ways

**Marcus Heartbridge**:
- **Professional Necessity**: Understands the value of his diplomatic and information skills
- **Cultural Clash**: Marcus's smooth social graces vs. Kelen's blunt honesty
- **Gradual Respect**: Learning to appreciate Marcus's genuine care for the Company's mission
- **Collaborative Potential**: Marcus handles politics, Kelen handles practical implementation

### Personal Relationships

**Daughter Elspeth**:
- **Current Dynamic**: Protective distance maintained through letters and financial support
- **Internal Conflict**: Wants to be closer but fears endangering her
- **Growth Arc**: Learning to trust her independence while staying connected
- **Company Impact**: Other members may help him realize he can have both closeness and safety

**Memory of Anya**:
- **Ongoing Influence**: Her loss still shapes his protective but distant approach to relationships
- **Healing Process**: Company family slowly helping him understand that love doesn't always end in loss
- **Integration**: Learning to honor her memory while building new connections

## Character Growth Milestones

**Milestone 1: Opening Up**
- Sharing personal history with trusted Company members
- Accepting help and emotional support when offered
- Allowing others to see his vulnerabilities

**Milestone 2: Integrated Leadership**
- Becoming comfortable with Company's unconventional methods
- Balancing military discipline with family atmosphere
- Training and mentoring new recruits

**Milestone 3: Emotional Integration**
- Accepting that caring deeply is worth the risk
- Building genuine friendships within the Company
- Finding balance between protection and autonomy

**Milestone 4: Legacy Building**
- Establishing institutional knowledge and traditions
- Preparing successors and training systems
- Reconciling relationship with Elspeth


---

# Sergeant Kelen - Relationships

## Professional Relationships

### Command Structure

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Perfect officer/NCO partnership - the shield to Thorne's sword
  - *Hierarchy*: Thorne's second-in-command with complete operational autonomy
  - *Dynamics*: Six years of building absolute trust - largely unspoken communication, anticipates each other's needs
  - *Professional Opinion of*: The ideal officer - firm but fair, tactically brilliant but compassionate
  - *History*: Assigned as Thorne's sergeant six years ago, developed seamless working relationship
  - *Current Status*: Mutual respect and genuine friendship beneath professional facade
  - *Key Moments*: Countless crisis situations where their partnership kept everyone alive
  - *Future Development*: Will remain Thorne's anchor while expanding role to mentor Company specialists

- **Commander Veyra Thornwake**:
  - *Nature of Relationship*: Soldier recognizing fellow soldier - shared protective code
  - *Hierarchy*: Accepts her overall command while serving as practical implementation specialist
  - *Dynamics*: Initially followed Thorne's lead, now genuinely committed to her vision
  - *Professional Opinion of*: Living embodiment of protective duty he values above all else
  - *First Impression*: "Another one lost to the wilds. Gods, the look in her eyes... she's seen hell."
  - *Recognition Moment*: Watching her meticulous work with fallen comrades - recognized shared soldier's code
  - *Current Status*: Will become her most reliable anchor, translating vision into practical reality
  - *Key Philosophy*: Her "no one left behind" resonates perfectly with his protective nature

### Original Patrol (Surrogate Family)

- **Corporal Darric**:
  - *Nature of Relationship*: Trusted subordinate and surrogate younger brother
  - *Hierarchy*: Clear chain of command but deep personal bond
  - *Dynamics*: Years of shared danger built unshakeable trust
  - *Professional Opinion of*: Absolutely reliable, shares his commitment to protective duty
  - *Personal Connection*: One of "his people" - would risk everything to protect
  - *Growth Area*: Learning to express care more openly as they transition to Company

- **Archer Venn**:
  - *Nature of Relationship*: Veteran team member and tactical specialist
  - *Hierarchy*: Peer-level respect despite rank difference
  - *Dynamics*: Mutual professional competence and shared military humor
  - *Professional Opinion of*: Skilled marksman with good tactical instincts
  - *Personal Connection*: Part of his chosen family unit

- **Medic Halden**:
  - *Nature of Relationship*: Essential team member and voice of medical authority
  - *Hierarchy*: Defers to Halden's medical expertise completely
  - *Dynamics*: Protects Halden so Halden can protect everyone else
  - *Professional Opinion of*: Invaluable specialist whose skills save lives
  - *Personal Connection*: Appreciates his dedication to healing over harming

- **Quartermaster Fayne**:
  - *Nature of Relationship*: Logistics partner and administrative support
  - *Hierarchy*: Collaborative rather than hierarchical
  - *Dynamics*: Appreciates their organizational skills and attention to detail
  - *Professional Opinion of*: Essential for operational efficiency
  - *Personal Connection*: Respects their pattern recognition abilities
  - *Growth Area*: Learning to understand their gender-fluid identity and support their documentation work

### Specialists Integration

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Mutual respect between protective professionals
  - *Hierarchy*: Different specialties, equal importance
  - *Dynamics*: Both understand the weight of protecting others
  - *Professional Opinion of*: Competent engineer with dedication to the Company
  - *Common Ground*: Practical approach to problems, willingness to get dirty
  - *Potential Tension*: Grimjaw's informal style vs. Kelen's military structure
  - *Current Status*: Building mutual respect based on shared protectiveness

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Protective mentor to skilled specialist
  - *Hierarchy*: Different expertise areas
  - *Dynamics*: Sees her youth and wants to keep her safe while respecting competence
  - *Professional Opinion of*: Exceptional tracking abilities, valuable wilderness expertise
  - *Protective Instinct*: Fatherly concern for her safety in dangerous situations
  - *Learning Opportunity*: Her different approach to problem-solving challenges his military thinking
  - *Growth Potential*: Could develop into genuine father-daughter mentorship

- **Nireya Voss**:
  - *Nature of Relationship*: Philosophical connection despite initial wariness
  - *Hierarchy*: Different specialties requiring mutual respect
  - *Dynamics*: Initially unsettled by supernatural abilities, growing understanding of her dedication
  - *Professional Opinion of*: Valuable specialist whose commitment to honoring dead resonates with him
  - *Protective Role*: Recognizes her vulnerability after using powers, ensures she's cared for
  - *Common Ground*: Both deal with loss and honoring the dead in their own ways
  - *Current Status*: Evolving from wariness to protective understanding

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Professional necessity evolving into grudging respect
  - *Hierarchy*: Different specialties with collaborative potential
  - *Dynamics*: Cultural clash between smooth social graces and blunt honesty
  - *Professional Opinion of*: Values his diplomatic skills despite personal style differences
  - *Working Relationship*: Marcus handles politics, Kelen handles practical implementation
  - *Growth Area*: Learning to appreciate Marcus's genuine care for Company mission
  - *Future Potential*: Could develop effective partnership despite personality differences

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Mutual respect between caregivers
  - *Hierarchy*: Different but complementary specialties
  - *Dynamics*: Both focused on protecting and healing their people
  - *Professional Opinion of*: Essential medical support and spiritual anchor
  - *Common Ground*: Understanding the weight of keeping people alive and healthy
  - *Personal Appreciation*: Values Aldwin's calm presence during crisis

- **Other Specialists** (Lyralei, Cidrella, Korrath, Kaida):
  - *General Approach*: Initially skeptical of non-military members
  - *Evolution Pattern*: Gradually developing respect based on competence and dedication
  - *Role Development*: Becoming protective father figure to younger/newer members
  - *Integration Challenge*: Bridging gap between military and civilian approaches

## Personal Relationships

### Family Connections

- **Daughter Elspeth Harwick**:
  - *Relationship Type*: Beloved daughter kept at protective distance
  - *Current Dynamic*: Weekly letters and financial support from afar
  - *History*: Lost her mother at age 12, raised by Kelen alone until apprenticeship
  - *Internal Conflict*: Wants to be closer but fears endangering her
  - *Growth Arc*: Learning to trust her independence while staying connected
  - *Company Impact*: Other members may help him realize closeness and safety can coexist
  - *Future Development*: Potential for Elspeth to visit or even join Company in safe capacity

- **Memory of Anya (deceased wife)**:
  - *Relationship Type*: Ongoing influence of lost love
  - *Impact on Present*: Her loss shapes his protective but distant approach
  - *Healing Process*: Company family slowly helping him understand love doesn't always end in loss
  - *Integration Goal*: Learning to honor her memory while building new connections

### Waterdeep Connections

- **Watch Contacts**:
  - *Relationship Type*: Professional network and information sources
  - *Value*: Provides Company with city intelligence and support
  - *Maintenance*: Careful balance of loyalty to old colleagues vs. new mission
  - *Usage*: Strategic resource for Company operations requiring city access

- **Dock Ward Connections**:
  - *Relationship Type*: Childhood neighborhood ties
  - *Current Status*: Limited but occasionally useful
  - *Emotional Weight*: Reminders of hard early life and lost family
  - *Practical Value*: Understanding of city's underbelly and criminal patterns

## Interpersonal Patterns

### Leadership Style
- **With Subordinates**: "Follow me" rather than "Go there" - leads by example
- **With Peers**: Collaborative but maintains clear operational boundaries
- **With Superiors**: Absolute loyalty balanced with tactical expertise
- **With Specialists**: Protective while respecting their unique capabilities

### Emotional Expression
- **Comfort Level**: More comfortable showing care through actions than words
- **Protective Instincts**: Immediate and sometimes overwhelming
- **Trust Building**: Slow to open up but absolutely loyal once committed
- **Conflict Resolution**: Direct but fair, focuses on practical solutions

### Communication Patterns
- **With Military Personnel**: Clear, economical, uses rank and procedure
- **With Civilians**: Adapts to less formal structure while maintaining authority
- **Under Stress**: Becomes quieter, more focused on practical details
- **In Crisis**: Takes charge naturally, coordinates through clear directives

## Relationship Evolution Tracker

### Pre-Company
- **Emotional State**: Protective isolation following Anya's death
- **Relationship Pattern**: Professional competence masking deep emotional distance
- **Coping Mechanism**: Focus on duty and Elspeth's welfare as way to avoid new attachments

### Early Company Formation
- **Catalyst Moment**: Recognizing Veyra's soldier's code at Undershade Canyon
- **Transition Phase**: Following Thorne's lead while developing independent commitment
- **New Challenges**: Learning to care for expanded "family" while protecting emotional walls

### Current Development
- **Growth Areas**: Opening up to trusted Company members about personal history
- **Relationship Building**: Developing genuine connections beyond professional necessity
- **Integration Process**: Balancing military structure with Company's family atmosphere

### Future Potential
- **Emotional Integration**: Accepting that caring deeply is worth the risk
- **Leadership Evolution**: Becoming Company patriarch while staying connected to Elspeth
- **Legacy Building**: Training successors and establishing institutional knowledge
- **Personal Healing**: Finding balance between honoring past loss and embracing present connections

## Notes on Relationship Dynamics

### Protective Hierarchy
1. **Immediate Family**: Elspeth (biological daughter)
2. **Chosen Family**: Original patrol members
3. **Extended Family**: Company specialists and allies
4. **Professional Network**: Watch contacts and allies

### Trust Levels
- **Absolute Trust**: Thorne, original patrol members
- **Growing Trust**: Veyra, core Company specialists  
- **Professional Trust**: New Company members, Watch contacts
- **Cautious Engagement**: Unknown civilians, political figures

### Communication Preferences
- **Face-to-Face**: For important decisions and personal conversations
- **Written**: For routine reports and letters to Elspeth
- **Indirect**: Uses actions more than words to show care
- **Crisis**: Clear, direct verbal commands with minimal explanation needed

---

# Sergeant Kelen — Dialogue & Voice

## Core Temperament
Steady, pragmatic, and protective. A veteran NCO whose gravelly voice carries natural authority. Economical with words but deeply caring—shows emotion through actions rather than lengthy speeches. His military background shapes every aspect of his communication.

## Dialogue Instincts
- **Command Voice**: Clear, direct orders that civilians hear as suggestions but military personnel understand as absolute
- **Protective Mode**: Becomes quieter and more focused when assessing threats or managing crisis
- **Personal Conversations**: Awkward with emotional expression, prefers practical demonstrations of care
- **Under Pressure**: Even more concise, shifts to rank/role usage instead of names

## Voice Characteristics
- **Tone**: Gravelly from years of shouting orders across battlefields and training yards
- **Volume**: Naturally projects authority but can speak quietly when situation demands
- **Cadence**: Measured, deliberate - every word chosen for purpose
- **Regional Accent**: Slight Waterdeep Dock Ward roughness, mostly smoothed by military service

## Emotional Anchors & Physical Tells
- **Scanning Behavior**: Eyes constantly assess room for threats, positions, escape routes
- **Protective Positioning**: Instinctively places himself between danger and his people
- **Equipment Checks**: Nervous habit of checking gear when uncomfortable or thinking
- **Hand Movements**: Uses precise gestures when giving directions, touches his sword hilt when worried

## Verbal Tics & Signature Phrases

### Command Phrases
- **"Right then..."** - Taking charge of a situation or making a decision
- **"As you were"** - Dismissing concerns or redirecting focus
- **"Watch your six"** - General warning about potential dangers
- **"Good work. Now check your gear."** - Praise followed by practical next step

### Core Philosophy Expressions
- **"Take care of your people, and they'll take care of the mission"**
- **"Lead from the front, watch everyone's back"**
- **"I've seen worse. We'll manage."**
- **"Everyone comes home"** - His fundamental mission objective

### Emotional Expressions (Rare)
- **"That's my responsibility"** - When protecting others from blame
- **"You did what you could"** - Comforting someone after loss
- **"We don't leave people behind"** - Stating core values

## Speech Patterns by Situation

### Crisis Management
- Becomes even more economical with words
- Uses rank/role instead of names for clarity
- Gives orders that sound like casual suggestions to outsiders
- Voice drops to calm, measured tone that cuts through chaos

### Training/Mentoring
- Patient but firm explanations
- Breaks complex tasks into simple steps
- Uses military metaphors and examples
- Emphasizes safety and teamwork over individual glory

### Personal Conversations
- Struggles with emotional vocabulary
- Often deflects to practical matters
- Shows care through actions rather than words
- Uncomfortable with receiving gratitude or praise

### Letters to Elspeth
- More formal than spoken language
- Focuses on factual updates rather than emotions
- Careful to avoid mentioning dangerous aspects of work
- Ends with practical advice or encouragement

## Dialogue Samples by Context

### Taking Command
*"Right then, here's how we're going to handle this. Venn, you're overwatch from that rooftop. Darric, east approach. Halden, you stay with the wounded. Questions?"*

### Reassuring Under Pressure
*"I've seen worse than this, and those times we had half the gear and twice the problems. We'll manage. Just stick to the plan and watch each other's backs."*

### Protective Warning
*"Easy there. You've done enough for one day. Let someone else take point for a while. That's not giving up—that's being smart."*

### Showing Care (Indirectly)
*"Picked this up in the market. Thought it might be useful for your equipment maintenance. Nothing fancy, just practical."*

### Crisis Communication
*"Medic! Two wounded, stable but need attention. Fayne, I need supply count and status report. Everyone else, perimeter check. Move."*

### Philosophical Moment (Rare)
*"Your father would be proud. Not because you never fell down, but because you always got back up. That's what matters."*

## Evolution Through Story Arcs

### Early Company Formation
- More military formal, relies heavily on rank and procedure
- Emotionally distant even from patrol members
- Communication focused purely on mission effectiveness

### Integration Phase
- Begins adapting communication style for specialists
- Shows more patience with non-military approaches
- Occasional glimpses of personal warmth

### Established Company
- More comfortable with informal interactions
- Begins sharing personal experiences when relevant
- Shows trust through delegation and asking for input

### Future Development
- More open emotional expression with trusted family members
- Comfortable mentoring role with newer Company members
- Able to balance military efficiency with family warmth

## Writer Guidelines

### Dialogue Construction
- Keep sentences short and direct
- Use military terminology naturally, not forced
- Show emotion through subtext and action rather than explicit statement
- Let his care show through what he doesn't say as much as what he does

### Voice Consistency
- Never wastes words but never leaves people confused
- Authority comes from competence, not volume
- Protective instincts override personal comfort
- Military precision balanced with genuine warmth

### Character Voice Traps to Avoid
- Don't make him too gruff without showing his caring side
- Avoid military jargon that sounds inauthentic
- Don't let protective instincts make him controlling
- Balance economy of speech with necessary communication

## Contextual Dialogue Variations

### With Military Personnel
*"Sergeant's orders: weapons check, supply count, and rest rotation. You know the drill."*

### With Civilians
*"We're going to need you to stay back while we handle this. For your safety and ours."*

### With Company Family
*"None of that 'sir' business when it's just us. Save the formality for when we have an audience."*

### Under Emotional Stress
*"Just... give me a minute to think this through. Too many variables, not enough good options."*

### Teaching Moment
*"See how she positions herself? Always knows where the exits are, always between the threat and her people. That's how you stay alive and keep others breathing."*

## Notes for Emotional Scenes

### Showing Vulnerability
- Uses longer pauses and hesitation
- Reverts to checking equipment when nervous
- Voice becomes quieter, less projected
- May deflect with practical concerns

### Expressing Pride
- Subtle nod of approval
- "Good work" followed by specific recognition
- Increased trust shown through delegation
- Protective positioning relaxes slightly

### Dealing with Loss
- Becomes very quiet and focused
- Takes on extra responsibilities to cope
- May push others away to protect them
- Shows grief through increased protectiveness of survivors

---

# Sergeant Kelen - Scene Tracker

## Major Scenes

### Chapter 1 – Ash and Compass
- **Scene 5 - Arrival of the Watch**: First appearance as part of Thorne's patrol discovering Veyra
  - *Significance*: Establishes his role as Thorne's trusted second-in-command
  - *Character Moment*: "Look at her face... the burns..." - shows immediate tactical assessment
  - *Key Action*: Recognizes Veyra won't leave without fallen comrades: "We'll need stretchers for the bodies"
  - *Character Growth*: Beginning of recognition of shared soldier's code with Veyra

- **Scene 6 - The Vigil**: Taking command while Thorne cares for Veyra
  - *Leadership Moment*: "Venn, Darric—stretchers. Halden, stabilize her. Fayne, document everything"
  - *Character Insight*: Natural assumption of command responsibility
  - *Emotional Beat*: Respect for the fallen shown through careful arrangement of bodies

### Chapter 2 – The Lantern Ward
- **Recovery and Support**: Bringing lamp oil to Veyra during her recovery
  - *Significance*: Shows practical care and understanding of symbolic importance
  - *Key Quote*: "Someone has to" when asked about maintaining the lantern
  - *Character Trait*: Duty-driven protectiveness extending to important symbols

### Chapter 9 – The Westwall Welcome
- **Company Formation**: Present for the formal naming of the Last Light Company
  - *Significance*: Founding member commitment to new mission
  - *Key Quote*: "The Last Light Company it is" - voice full of pride
  - *Character Growth*: Full emotional investment in the new organization

## Character Development Scenes

### The Protective Leader
- **Description**: Kelen taking charge during crisis while Thorne is occupied
- *Purpose*: Showcase his natural leadership and protective instincts
- *Key Elements*: Quick tactical assessment, delegation, ensuring everyone's safety
- *Character Growth*: Demonstrating competence that extends beyond following orders

### Recognition of Dedication
- **Description**: Understanding Veyra's commitment to fallen comrades at Undershade Canyon
- *Purpose*: Shows his recognition of shared values and soldier's code
- *Key Elements*: Seeing past trauma to recognize duty and dedication
- *Character Growth*: Beginning of personal investment in Company mission

### Quiet Authority
- **Description**: Managing patrol members and specialists with understated leadership
- *Purpose*: Illustrates his "follow me" leadership style
- *Key Elements*: Commands that sound like suggestions, natural positioning to protect others
- *Character Growth*: Adapting military leadership to diverse team

## Potential Future Scenes

### Personal History Revelations

**"The Letter Home"**
- **Description**: Kelen writing his weekly letter to Elspeth, struggling with what to share about Company dangers
- *Purpose*: Shows his relationship with his daughter and internal conflicts
- *Key Elements*: Careful word choice, protecting her from worry while staying connected
- *Character Growth*: Balancing honesty with protection

**"The Watch Contact"**
- **Description**: Using his City Watch network to gather intelligence for Company mission
- *Purpose*: Demonstrates his value beyond combat leadership
- *Key Elements*: Professional relationships, loyalty conflicts, information gathering
- *Character Growth*: Choosing Company over old loyalties when necessary

**"The Patrol Bond"**
- **Description**: Scene with original patrol members showing their family-like connection
- *Purpose*: Illustrates how he's built surrogate family from his squad
- *Key Elements*: Inside jokes, shared experiences, protective dynamics
- *Character Growth*: Learning to express care more openly

### Leadership Development

**"Training the Specialists"**
- **Description**: Kelen teaching basic survival/combat skills to non-military Company members
- *Purpose*: Shows his mentoring abilities and adaptation to diverse team
- *Key Elements*: Patient instruction, safety emphasis, building competence
- *Character Growth*: Learning to work with different learning styles and backgrounds

**"Crisis Command"**
- **Description**: Taking overall command when both Thorne and Veyra are incapacitated
- *Purpose*: Demonstrates his readiness for increased responsibility
- *Key Elements*: Quick decision-making, coordinating specialists, ensuring mission success
- *Character Growth*: Stepping up from second-in-command to primary leader

**"The Moral Choice"**
- **Description**: Situation where following regulations conflicts with protecting his people
- *Purpose*: Tests his loyalty hierarchy and ethical framework
- *Key Elements*: Regulation vs. protection, consequences of choice, team reaction
- *Character Growth*: Choosing people over protocol when necessary

### Personal Relationships

**"Elspeth's Visit"**
- **Description**: His daughter unexpectedly arrives at Company headquarters
- *Purpose*: Forces confrontation with his protective distance strategy
- *Key Elements*: Surprise, fear for her safety, Company members meeting family
- *Character Growth*: Learning to balance protection with connection

**"The Father Figure"**
- **Description**: Younger Company member seeking advice or comfort from Kelen
- *Purpose*: Shows his evolution into patriarch role
- *Key Elements*: Awkward emotional support, practical advice, protective instincts
- *Character Growth*: Accepting role as Company father figure

**"Memory of Anya"**
- **Description**: Scene triggered by anniversary or similar situation to his wife's death
- *Purpose*: Explores ongoing impact of his loss and healing process
- *Key Elements*: Private grief, Company support, moving forward while honoring memory
- *Character Growth*: Integrating past loss with present connections

### Professional Integration

**"Working with Marcus"**
- **Description**: Collaboration between Kelen's practical approach and Marcus's diplomatic skills
- *Purpose*: Shows how different styles can complement each other
- *Key Elements*: Initial tension, finding common ground, effective partnership
- *Character Growth*: Appreciating different approaches to problem-solving

**"Understanding Nireya"**
- **Description**: Kelen ensuring Nireya's care after she uses her spiritual powers
- *Purpose*: Shows his protective instincts extending to supernatural teammates
- *Key Elements*: Overcoming initial wariness, recognizing shared values, practical support
- *Character Growth*: Adapting protection to include supernatural needs

**"Grimjaw's Respect"**
- **Description**: Scene where Kelen and Grimjaw recognize their shared protectiveness
- *Purpose*: Building bridges between different backgrounds
- *Key Elements*: Mutual respect, shared values, different expressions of same goal
- *Character Growth*: Finding common ground despite different approaches

## Interaction Scenes

### With Command Structure
- **Planning Sessions**: Working with Thorne and Veyra on mission strategy
- **Crisis Management**: Taking initiative when leaders are occupied
- **After Action**: Debriefing and learning from missions

### With Original Patrol
- **Shared Memories**: Reminiscing about past missions and bonding experiences
- **Transition Challenges**: Adapting to new Company structure while maintaining bonds
- **Protection Dynamics**: Continued care for "his people" in new context

### With Specialists
- **Integration Challenges**: Learning to work with non-military professionals
- **Skill Exchange**: Teaching military skills while learning specialist knowledge
- **Trust Building**: Developing confidence in unconventional approaches

### Family Connections
- **Letters to Elspeth**: Private moments showing his relationship with daughter
- **Watch Contacts**: Maintaining professional relationships from previous career
- **Memory Moments**: Dealing with grief and moving forward

## Combat/Crisis Scenes

### "Defensive Coordinator"
- **Description**: Combat scene showcasing his protective fighting style
- *Purpose*: Demonstrates his "everyone comes home" philosophy in action
- *Key Elements*: Positioning to shield others, tactical coordination, post-combat care
- *Character Traits*: Protection over glory, team survival focus

### "Equipment Check"
- **Description**: Pre-mission scene showing his thorough preparation
- *Purpose*: Illustrates his attention to detail and care for team safety
- *Key Elements*: Systematic gear inspection, addressing problems before they matter
- *Character Traits*: Practical preparation, prevention over reaction

### "Casualty Management"
- **Description**: Post-combat scene with wounded team members
- *Purpose*: Shows his crisis leadership and care for injured
- *Key Elements*: Immediate assessment, resource allocation, emotional support
- *Character Traits*: Leadership under pressure, protection of vulnerable

## Growth Moment Scenes

### "Opening Up"
- **Description**: Kelen sharing personal history with trusted Company member
- *Purpose*: Shows emotional growth and increasing trust
- *Milestone*: First major step toward emotional integration

### "Accepting Help"
- **Description**: Allowing others to support him during difficult moment
- *Purpose*: Character growth in receiving care, not just giving it
- *Milestone*: Learning that strength includes accepting assistance

### "The Patriarch Moment"
- **Description**: Being formally recognized as Company's emotional anchor
- *Purpose*: Accepting role as father figure and institutional memory
- *Milestone*: Full integration into new family structure

## Scene Notes for Writers

### Key Character Elements to Include
- Constant tactical awareness and positioning
- Protective body language and positioning
- Equipment maintenance as stress response
- Economy of words but clarity of meaning
- Care shown through actions rather than words

### Emotional Beats to Explore
- Conflict between protection and autonomy
- Memories of loss balanced with present hope
- Military structure adapted to family atmosphere
- Professional competence hiding emotional vulnerability

### Relationship Dynamics to Show
- Unspoken communication with Thorne
- Fatherly concern for younger team members
- Respectful integration of specialist skills
- Ongoing connection to daughter despite distance

### Future Arc Potential
- Evolution from distant protector to engaged patriarch
- Learning to balance military efficiency with family warmth
- Integration of past grief with present connections
- Building institutional knowledge and training systems

---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

