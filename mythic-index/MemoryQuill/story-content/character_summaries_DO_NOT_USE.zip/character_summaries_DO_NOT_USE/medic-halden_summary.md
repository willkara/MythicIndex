# Medic Halden – Profile

## Basic Information
- Full Name: Halden (surname not mentioned)
- Aliases/Nicknames: None
- Race: Human (Tethyrian)
- Race: Human (Tethyrian)
- Age: Not specified
- Gender: Male
- Role in Story: Patrol medic, proto-Company member
- First Appearance: Chapter 1, Scene 6 (The Vigil)
- Status: Active

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: A nervous tic at the corner of his left eye that becomes more pronounced under stress.
- Typical Clothing: City Guard armor with medical pack
- Body Language: Careful, methodical
- Physical Condition: Combat-ready

## Significance
Medic Halden serves as the patrol's field medic and represents the medical expertise needed for rescue operations. His practical approach to healing and pain management complements the more mystical healing that will come from clerics like Aldwin.

## Key Actions
- Attempted to treat Veyra at Undershade (respected her wishes to see to the dead first)
- Brought chilled river stones for burn treatment
- Taught Veyra pain management techniques
- Noted her need for frequent dressing changes
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).

## Personality Traits
- Compassionate and respectful
- Practical approach to medicine
- Patient-focused care
- Methodical and disciplined

## Medical Philosophy
"Ice numbs; water cleans. Pain obeys discipline."

## Future Role
Expected to provide field medicine expertise to the Last Light Company, working alongside magical healers.


---

# Medic Halden – Background

## Origin
- **Birthplace**: Waterdeep
- **Social Class**: Middle class
- **Cultural Background**: Human (Tethyrian); raised in a family of artisans.

## Family
- **Family Dynamics**: Halden has no family in the city. He is a solitary man who finds more comfort in the quiet company of his plants than in people.

## History
- **Youth**: Apprenticed to an apothecary, where he showed great promise in the healing arts.
- **Formative Event**: In his youth, the apothecary he worked for secretly sold poisons on the side. A batch that Halden unknowingly helped prepare was used in a high-profile assassination. Though he was officially cleared of any wrongdoing, the guilt from the event has haunted him ever since.
- **Motivation for Joining the Watch**: He joined the City Watch as an act of atonement. He sought to dedicate his life to saving others, to balance the scales for the life he feels he inadvertently helped take. The structured, clearly righteous work of a Watch medic provided a shield against the moral ambiguity that marked his youth.
- **Hobbies**: He is an accomplished botanist, tending to a small but impressive rooftop garden where he cultivates rare plants for poultices, salves, and personal study. His small apartment is filled with medicinal herbs and anatomical charts.

---

# Medic Halden – Character Development

## Personality Core
- **Defining Traits**: Methodical, empathetic, quiet, patient-focused, carries a deep-seated guilt.
- **Core Values**: The sanctity of life, the importance of healing, atonement through service.
- **Motivations**: To balance the scales for a past mistake by saving as many lives as he can.
- **Fears**: His skills failing someone in need, being unable to help, causing unintentional harm.
- **Internal Conflicts**: His gentle nature is often at odds with the brutal violence he must witness and treat as a Watch medic.

## Character Arc
- **Starting Point**: A competent but emotionally withdrawn City Watch medic, quietly serving out his duty.
- **Catalyst Events**: Witnessing Veyra prioritize the dignity of the dead over her own life-threatening injuries.
- **Current State**: A dedicated member of the Last Light Company, finding that its mission of pure rescue aligns perfectly with his need for atonement.
- **Intended Destination**: To become a senior healer within the Company, working alongside Aldwin to blend practical and magical healing, and finally finding peace with his past.

## Key Relationships
- **Relationship to Thorne**: Thorne is his protector. Halden is not a natural soldier and is often unnerved by the violence of their work. He trusts Thorne to create the space and security that allows him to do his job. He sees the Captain as a bulwark against the chaos, a figure of authority who keeps him safe while he tends to the wounded.
- **Reaction to Veyra**:
    - **First Thought**: "The burns... the shock... she needs treatment now." His immediate reaction was purely clinical, a professional assessment of her injuries.
    - **Why He Followed**: He was profoundly moved by her first words: "See to the dead first." As a healer, he had never encountered someone who prioritized the dignity of the fallen over their own intense suffering. It was a profound act of compassion that resonated with his own guilt-ridden soul. When he later taught her pain management, he saw a student with an iron will and a deep respect for the discipline of healing. He follows her not just out of loyalty to Thorne, but because he believes her mission is a purer form of healing than he could practice anywhere else—healing a broken world, one rescue at a time.


---

# Medic Halden - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Medic Halden - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Medic Halden - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

