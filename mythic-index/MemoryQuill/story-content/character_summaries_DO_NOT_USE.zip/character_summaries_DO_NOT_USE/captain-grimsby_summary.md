# Captain Grimsby – Profile

## Basic Information
- Full Name: Grimsby (first name not mentioned)
- Aliases/Nicknames: None
- Age: Not specified (likely a veteran officer)
- Gender: Male
- Role in Story: Antagonistic peer to Captain Thorne Brightward
- First Appearance: Chapter 4, Scene 2 (The First Spark)
- Status: Active

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: None specified
- Typical Clothing: City Watch Captain's uniform
- Body Language: Stern, by-the-book
- Physical Condition: Active duty

## Significance
Captain Grimsby represents the institutional inertia and professional skepticism that Thorne and Veyra must overcome. He is not evil, but he is rigid, following the manual over battlefield realities. His conflict with Thorne serves to highlight Thorne's growing loyalty to Veyra's mission over his formal duties and will likely be the source of future political trouble.

## Key Actions
- Confronted Thorne at the scene of the Dock Ward fire
- Questioned Thorne's decision to bring a "civilian liability" into a hot zone
- Dismissed Veyra's past trauma as a disqualifier rather than a source of expertise
- Was silenced when Veyra's prediction about the fire proved correct

## Personality Traits
- By-the-book traditionalist
- Skeptical of outsiders and unconventional methods
- Concerned with liability and official reports
- Represents the established order of the City Watch

## Future Role
Likely to be a recurring professional antagonist, filing reports about Thorne's "unorthodox" methods and creating political obstacles for the nascent Last Light Company.


---

# Captain Grimsby - Background

## Origin
- **Birthplace**: Waterdeep
- **Social Class**: Likely middle class, a family with a history of civic service.
- **Cultural Background**: Urban, deeply ingrained in the traditions and regulations of the Waterdeep City Watch.

## History
- **Professional Career**: A veteran officer of the City Watch who has risen through the ranks to the position of Captain. He is a contemporary of Thorne Brightward.
- **A Defining Tragedy**: Early in his career, Grimsby was a promising, flexible officer. However, he was the ranking officer at a scene where a junior constable, acting on a "gut feeling" and ignoring protocol, rushed into a hostage situation and was killed. The subsequent inquiry nearly ended Grimsby's career. The incident instilled in him a deep-seated, trauma-induced belief that the rules and the manual are the only things that prevent chaos and keep his officers safe. His rigidity is not born of malice, but of a profound, personal fear of repeating past mistakes.

## Personal Details
- **How He Relaxes**: He is an avid player of "Sovereigns," a highly complex, chess-like board game that has hundreds of rules and established opening moves. He finds the game's rigid structure and predictable outcomes deeply calming. He plays by correspondence with several other Watch captains across the Sword Coast.
- **Favorite Meal**: A very specific, unvarying meal from the officer's mess: boiled beef, potatoes, and carrots, served at precisely six o'clock every evening. He doesn't particularly enjoy it, but he finds comfort in its absolute predictability.


---

# Captain Grimsby - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Captain Grimsby - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Captain Grimsby - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Captain Grimsby - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

