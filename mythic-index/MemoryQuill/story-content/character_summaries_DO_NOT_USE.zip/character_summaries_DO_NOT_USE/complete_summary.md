# Summary for Aldwin Gentleheart

# Brother Aldwin Gentleheart - Profile

## Basic Information
- **Full Name**: Aldwin Gentleheart
- **Aliases/Nicknames**: "Brother" (earned title from soldiers, not a religious designation)
- **Race**: Halfling
- **Class**: Cleric
- **Role in Story**: Medic for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Compact, sturdy build typical of halflings
- **Hair**: Curly brown hair, prematurely touched with silver at the temples
- **Eyes**: Kind hazel eyes that hold the weight of countless difficult decisions
- **Distinguishing Features**: 
  - Hands are his most notable feature - small but incredibly steady
  - Long, dexterous fingers of both a scholar and healer
  - Hands marked with faint scars from field surgery
  - Fingers permanently stained with herb oils
- **Typical Clothing**: Practical robes in earth tones - brown wool with leather reinforcement at the shoulders and sleeves
- **Body Language**: Carries himself with quiet dignity of someone who has seen the worst of life and chosen to respond with compassion
- **Physical Condition**: Healthy, with remarkable endurance and steady hands despite witnessing trauma

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Aldwin Gentleheart.

## Personality
- **Archetype**: The Healer/Caretaker
- **Temperament**: Calm, compassionate, philosophical
- **Positive Traits**: Dedicated, empathetic, pragmatic, knowledgeable
- **Negative Traits**: Possibly carries burden of difficult decisions, may struggle with rural/quiet settings after war experience
- **Moral Alignment**: Neutral Good (focuses on alleviating suffering regardless of other considerations)

## Skills & Abilities
- **Expertise**: Medicine, herbalism, theology, philosophy
- **Languages**: TBD
- **Education Level**: Highly educated at prestigious academy
- **Special Abilities**: 
  - Holistic healing approach (physical, spiritual, mental)
  - Tea preparation with both medicinal and spiritual properties
  - Ability to provide comfort in most desperate situations
  - Knowledge of gentle end-of-life care

## Personal Details
- **Habits**: Tea ritual
- **Hobbies**: Herbalism, philosophical contemplation
- **Personal Quarters**: A warm, circular room built into the quietest part of the Sanctuary terrace, with a low, timber-beamed ceiling. The air is thick with the comforting aroma of dried herbs, spices, and brewing tea. The curved walls are lined with floor-to-ceiling shelves, holding hundreds of meticulously labeled ceramic jars and wooden boxes. This is his personal laboratory and sanctuary. He finds peace in the quiet, methodical work of his craft. A large, comfortable armchair sits at the center of the room, facing a low table with a beautiful, well-used ceramic tea set. This is where he performs his personal tea ceremonies to center himself after a difficult healing session. He rarely sleeps in his bed, preferring to doze in the chair, surrounded by the tools of his trade, waking occasionally to check on a steeping tincture or to grind herbs with a heavy stone mortar and pestle.
- **Likes**: Providing comfort, meaningful conversation, tea ceremonies
- **Dislikes**: Unnecessary suffering, stagnation
- **Fears**: Helplessness in the face of suffering; being unable to provide comfort or dignity to someone in their final moments.

## Combat & Tactics
- **Primary Weapon**: Quarterstaff with healing crystals embedded in the head - "Mercy's Touch" - doubles as walking stick and medical tool
- **Secondary Tools**: Healer's kit repurposed as improvised weapons (scalpels for precision cuts, needles for pressure points)
- **Armor**: Reinforced robes with hidden leather padding - protection that doesn't impede healing work
- **Special Equipment**: Ornate tea service that unfolds into complete brewing station, various medicinal compounds
- **Fighting Style**: Defensive healer - fights only to protect patients, uses staff to create space and disable rather than harm
- **Signature Move**: "Sanctuary Circle" - creates healing zone in combat where allies gain strength
- **Combat Philosophy**: "First, do no harm. Unless they harm my patients - then all bets are off"
- **Tactical Role**: Combat medic who keeps team fighting while minimizing casualties

## Psychological Response Matrix
- **In Crisis**: Immediate triage mentality - categorizes by urgency, stays remarkably calm while prioritizing care
- **During Negotiation**: Finds common ground through shared humanity, reminds all parties of what truly matters
- **Moral Dilemma**: Always chooses life preservation, but understands sometimes mercy means letting go
- **Team Conflict**: Offers tea ceremony and neutral ground for discussion, mediates through compassion
- **Under Personal Attack**: Responds with unexpected kindness that often disarms aggressors
- **In Victory**: Immediately tends to enemy wounded - "The battle's over, now we're all just people in pain"

## Voice & Dialogue Patterns
- **Speech Style**: Gentle, measured tones with underlying steel when protecting patients
- **Signature Phrases**: 
  - "Let's not make this wound worse"
  - "Pain shared is pain halved"
  - "Tea first, then we talk" (his de-escalation technique)
  - "Even stones can be worn down by gentle rain"
- **Medical Metaphors**: Describes situations in healing terms - conflicts are "infections," solutions are "treatments"
- **Example Dialogue**: "The situation is infected, yes, but not terminal. We need to drain the abscess before it spreads. Sometimes that means cutting, but always with purpose."
- **Emotional Tells**: Hands become absolutely still when making hard decisions, voice drops to whisper when discussing death
- **Compassionate Authority**: Commands respect through kindness rather than force

## Notes
- Integrates physical treatment, spiritual comfort, and mental care in his healing approach.
- Tea ritual offers comfort to patients and companions.
- In cases where recovery is impossible and pain unbearable, his special blends offer gentle passage.
- His "gentle passage" teas are an open secret within the Company. While his compassion is never questioned, the practice is a source of quiet wariness for some.
- Joined the Company after witnessing Veyra's dedication during a plague outbreak.
- Recognizes a kindred spirit in Veyra - someone who understands that sometimes the greatest mercy is simply being present in someone's darkest moment.

### Public Perception
- Known for his profound kindness and holistic healing approach, often sitting with patients for hours and using special teas to provide comfort beyond just medicine.
- Respected for his calm demeanor even in the face of tragedy, treating both the living and the dead with equal respect.
- His special tea blends are rumored to offer not just physical relief, but also courage and peace.


---

# Brother Aldwin Gentleheart - Background

## Origin
- **Birthplace**: A halfling village in the Greenfields.
- **Birth Date**: TBD
- **Social Class**: Middle class, from a respected family of healers.
- **Cultural Background**: Halfling heritage with an emphasis on community care and traditional healing.

## Family
- **Parents**: Village healers (names TBD).
- **Siblings**: TBD
- **Extended Family**: Comes from a long lineage of healers.
- **Family Dynamics**: His family taught him the foundations of healing, but he diverged from their path, pursuing formal academic training. The respectful distance between them stems from a philosophical divide: they practice medicine with rigid, traditional precision, while Aldwin believes in a more holistic approach, treating the patient's spirit as much as their ailment.

## History
- **Childhood**: 
  - *Key Events*: Showed an early aptitude for healing and scholarly pursuits, often preferring books to the boisterous social life of his village.
  - *Formative Experiences*: Grew up learning the foundations of herbalism and patient care from his family.
  
- **Education/Training**: 
  - *Institutions*: Studied at a prestigious academy in Waterdeep, focusing on advanced medicine, philosophy, and theology.
  - *Mentors*: Various professors and healers (specific names TBD).
  - *Areas of Study*: His studies focused on the intersection of physical and spiritual well-being, laying the groundwork for his holistic approach.
  - *Notable Acquaintances*: During his studies, he occasionally attended cross-disciplinary lectures on arcane theory, where he was briefly acquainted with a brilliant, if eccentric, elven elementalist named Lyralei Stormcaller. He remembers being fascinated by her theories on how atmospheric pressure could affect somatic components, though he found her approach a bit too detached for his own tastes.
  
- **Adolescence/Young Adulthood**:
  - *Key Events*: Left his village to pursue higher education, a rare choice for a halfling of his community.
  - *Relationships*: Developed connections within the academic community of Waterdeep.
  - *Choices & Consequences*: His choice of a scholarly path over traditional healing created a respectful distance with his family, but provided him with the skills that would later save countless lives.
  
- **Major Life Events**:
  - *Event 1*: Outbreak of the Border Wars.
  - *Event 2*: Voluntarily enlisted as a field medic, motivated by a deep philosophical conviction to serve where the need was greatest.
  - *Event 3*: Earned the title "Brother" from the soldiers who, moved by his unwavering compassion, adopted him as their own family.
  - *Event 4*: Post-war return to village life, where he found himself dissatisfied with the quiet pace and lack of profound purpose.
  - *Event 5*: The Plague of the Gray Rot - A virulent plague swept through a remote, quarantined village that had been abandoned by official aid. Aldwin, feeling a pull of duty, traveled there to offer what help he could.
  - *Event 6*: The Joining - In the heart of the plague-stricken village, he met Veyra Thornwake and Thorne Brightward. He witnessed Veyra's unwavering dedication to not just healing the sick, but providing dignity to the dying and remembering the fallen. Recognizing a kindred spirit, he approached her and offered his skills, not as a hireling, but as a colleague, becoming the first crucial specialist to join the nascent Last Light Company.

## Backstory Elements
- **Defining Moments**: 
  - His service in the Border Wars, which forged his holistic healing philosophy through the cumulative weight of his experiences rather than a single event.
  - Witnessing Veyra's dedication during the plague outbreak, which gave his life a new, profound purpose.
  
- **Past Trauma**: 
  - The collective horrors of battlefield medicine and the countless difficult triage decisions he was forced to make.
  - The memories of administering "gentle passage" to those beyond saving.
  
- **Greatest Achievements**: 
  - His academic accomplishments.
  - The countless lives he saved during the war.
  - The development of his unique, compassionate approach to healing.
  
- **Biggest Failures**: 
  - The soldiers and patients he couldn't save, whose memories he carries with quiet dignity.
  
- **Secrets**: 
  - He carries a private grief for specific patients he lost during the war, whose faces he can still recall in perfect detail.

## How They Got Here
- **Reason for Current Situation**: After the intensity of the Border Wars, Aldwin found himself unable to readjust to the quiet life of a village healer. He felt a deep sense of stagnation, his profound skills and philosophical convictions going unused. The Plague of the Gray Rot was the catalyst he needed, a call to a higher purpose. Witnessing Veyra's mission in action, he saw the perfect synthesis of his wartime experience and his innate compassion. He joined the Last Light Company because it was the only place where his unique blend of healing, philosophy, and unwavering presence in the face of suffering would be truly valued.
- **Path to Current Location**: 
  - Village healer background -> Academic education -> War service -> Brief, dissatisfying return to village life -> The Plague of the Gray Rot -> Joining the Last Light Company.
  
- **Goals Prior to Story Start**: 
  - To find a meaningful application for his hard-won skills and philosophical outlook.
  - To continue providing compassionate care in the most challenging of circumstances.

## Historical Connections
- **Connection to Main Plot**: Medic for the Last Light Company.
- **Connection to Other Characters**: 
  - Respects Veyra as a kindred spirit.
  - Has a pre-existing, if distant, academic connection to Lyralei Stormcaller.
  
- **Connection to Story World**: 
  - Experienced the Border Wars.
  - Familiar with the academic institutions of Waterdeep.
  - Witnessed the Plague of the Gray Rot.

## Timeline
- Early life in a family of village healers in the Greenfields.
- Scholarly education at a prestigious academy in Waterdeep.
- Outbreak of the Border Wars.
- Voluntary service as a field medic, earning the title "Brother."
- Post-war return to village life and subsequent dissatisfaction.
- The Plague of the Gray Rot outbreak.
- Met Veyra Thornwake and Thorne Brightward in the plague-stricken village.
- Joined the nascent Last Light Company as its first specialist.

## Personal Details
- **How He Relaxes**: The meticulous, sensory process of preparing tea—selecting leaves, grinding herbs, heating water to a precise temperature—is a form of meditation for him. It is a quiet, grounding ritual that allows him to center himself and process the pain he witnesses daily.
- **Favorite Meal**: Honey-glazed river trout with a side of wild greens and toasted seeds. It's a dish that bridges the two halves of his life: the simple, wholesome ingredients are reminiscent of his halfling village, while the refined preparation speaks to the palate he developed during his academic years.
- **Family Connection**: He carries a small, worn, leather-bound book filled with pressed flowers and herbs from the fields around his home village, a gift from his mother. On difficult nights, he opens it, the faint scent of home a silent connection to the family and the simpler form of healing he evolved from.


---

# Brother Aldwin Gentleheart - Character Development

## Personality Core
- **Defining Traits**: Compassionate, philosophical, steady, pragmatic
- **Core Values**: Alleviating suffering, dignity in death, holistic healing
- **Motivations**: To provide care where most needed, to honor the cycle of life
- **Fears**: Possibly failure to provide comfort when needed most
- **Internal Conflicts**: Mercy vs. prolonging life, academic knowledge vs. practical reality
- **Contradictions**: Gentle healer who makes hard decisions about life and death

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Academic healer from traditional family
  - *World View*: Scholarly, theoretical approach to medicine
  - *Key Relationships*: Academic peers, family
  
- **Catalyst Events**:
  - *Event 1*: Border Wars outbreak - decision to volunteer as field medic
  - *Event 2*: Battlefield experiences and trauma
  - *Event 3*: Post-war return to village life
  - *Event 4*: Plague outbreak and witnessing Veyra's dedication
  
- **Current State**:
  - *Self-Perception*: "Brother" - adopted family member to those in need
  - *World View*: Holistic approach to healing (physical, spiritual, mental)
  - *Key Relationships*: Last Light Company, especially Veyra
  
- **Intended Destination**:
  - *Self-Perception*: TBD
  - *World View*: TBD
  - *Key Relationships*: TBD

## Growth Milestones
- **From Academic to Field Medic**: 
  - *Development Noted*: Theory confronted with brutal reality
  - *Catalyst*: Border Wars
  - *Impact*: Practical application of knowledge, development of improvisation skills
  
- **Development of Holistic Healing Philosophy**: 
  - *Development Noted*: Integration of physical, spiritual, and mental care
  - *Catalyst*: Witnessing battlefield trauma and psychological effects
  - *Impact*: Creation of tea ceremony and more comprehensive approach to healing

- **Finding Purpose in Last Light Company**:
  - *Development Noted*: From dissatisfaction to renewed meaning
  - *Catalyst*: Witnessing Veyra during plague outbreak
  - *Impact*: Joining a cause aligned with personal philosophy

## Character Flaws
- **Possible Savior Complex**: 
  - *Effects on Character*: May take on too much responsibility for others' well-being
  - *Effects on Others*: Could create dependency
  - *Development Plan*: Learning to balance care with self-preservation
  
- **Pragmatism That Borders on Coldness**: 
  - *Effects on Character*: Making difficult decisions about who can be saved
  - *Effects on Others*: May appear detached when making triage decisions
  - *Development Plan*: Finding balance between necessary pragmatism and empathy

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Specific formulations of his "gentle passage" teas
  - *Secret 2*: Possibly specific patients he couldn't save that haunt him
  
- **Unknown to Character**:
  - *Truth 1*: TBD - perhaps unexpected effects of his care
  - *Truth 2*: TBD - possibly misunderstandings about his intentions
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Volunteering as Field Medic**:
  - *Context*: Border Wars outbreak
  - *Options Considered*: Stay in academic setting vs. apply skills where needed
  - *Choice Made*: Entered battlefield medicine
  - *Consequences*: Practical experience, trauma, development of holistic philosophy
  
- **Developing Tea Ceremony**:
  - *Context*: Battlefield medicine limitations
  - *Options Considered*: Traditional medicine vs. holistic approach
  - *Choice Made*: Created ritual that addressed physical, spiritual, mental needs
  - *Consequences*: Signature approach to healing that extends beyond physical treatment

- **Leaving Village Life After War**:
  - *Context*: Dissatisfaction with routine healing
  - *Options Considered*: Remain in comfortable setting vs. seek meaningful work
  - *Choice Made*: Joined Last Light Company after plague encounter
  - *Consequences*: Found purpose aligned with personal philosophy

## Development Notes
- Character represents integration of scholarly knowledge with practical experience
- Tea ceremony serves as physical manifestation of his healing philosophy
- The "Brother" title symbolizes his transition from academic to adopted family member
- Development arc shows progression from theoretical to holistic healer
- His relationship with life and death is nuanced and pragmatic rather than idealistic
- Future development might explore tensions around "gentle passage" practices
- Could develop teaching role within Company, passing knowledge to others

## Psychological Profile
*   **Brother Aldwin Gentleheart (The Witness):** He is a soul who has seen the absolute worst of humanity on the battlefield and made a conscious choice to respond with compassion rather than cynicism. His healing is not just medicinal; it's philosophical. The tea ceremony is a ritual to impose calm and order on the chaos of suffering. He carries the weight of every difficult decision, every life he couldn't save, but he bears it with quiet dignity. He is the Company's moral and spiritual anchor.


---

# Brother Aldwin Gentleheart - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and medic, kindred spirits
  - *Hierarchy*: Respects her leadership
  - *Dynamics*: Mutual recognition of dedication to alleviating suffering
  - *History*: Witnessed her dedication during a plague outbreak, which inspired him to join
  - *Current Status*: Trusted company medic
  - *Professional Opinion of*: Sees her as someone who understands that sometimes the greatest mercy is simply being present in someone's darkest moment
  - *Memorable Interactions*: The plague outbreak that brought them together

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and medic
  - *Hierarchy*: Respects chain of command
  - *Dynamics*: Likely values Thorne's military background and discipline
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Probably appreciates his tactical expertise and leadership

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: Might find common ground in their observant natures
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely respects her tracking abilities and connection to animals

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (medical vs. heavy rescue)
  - *Dynamics*: Would work closely in rescue operations - Grimjaw extracting victims, Aldwin treating them
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates his experience and protective instincts

- **Lyralei Stormcaller**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (medical vs. magical support)
  - *Dynamics*: Her magical abilities might complement his healing in certain situations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her magical knowledge and research approach

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Confidants; "The Cynic and the Believer."
  - *Hierarchy*: Equals.
  - *Dynamics*: Marcus, a pragmatist who often has to do morally gray things for the greater good, seeks out Aldwin after particularly difficult missions, not to confess, but to recalibrate. He sits for a tea ceremony, and Aldwin's quiet, non-judgmental presence allows Marcus to reconnect with the "why" of their mission, cleansing his palate from the dirty work he has to do. Aldwin, in turn, sees the core of goodness in Marcus beneath the cynical exterior.
  - *History*: TBD
  - *Current Status*: A quiet, deeply important confidential relationship.
  - *Feelings Toward*: He sees Marcus as a man making difficult choices for the right reasons and offers him a space of quiet contemplation without judgment.

- **Nireya Voss**: 
  - *Nature of Relationship*: Professional partner; the other half of the healing process.
  - *Hierarchy*: Peers and colleagues who lead the Temple of Renewal together.
  - *Dynamics*: Theirs is a relationship of profound mutual respect and seamless cooperation. Aldwin is the master of the body, using his clerical magic and medical knowledge to mend flesh and bone. He is the first face most of the wounded see. However, he understands that some wounds are beyond his reach. He knows precisely when to step back and bring in Nireya to tend to a patient's fractured spirit, psychological trauma, or to provide peace for the dying. They are the complete package of healing.
  - *History*: They likely met and developed their working relationship within the Company, quickly realizing how their different approaches to healing complemented each other perfectly.
  - *Current Status*: The two pillars of the Sanctuary. They often have quiet, philosophical conversations over tea about the nature of life, death, and the soul, each valuing the other's unique perspective.
  - *Feelings Toward*: Deep professional and personal respect. He sees her as a vital and necessary counterpart to his own skills and is grateful for her ability to handle the spiritual burdens that he cannot.

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (medical vs. technical)
  - *Dynamics*: Her innovative devices might enhance his medical capabilities
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her technical problem-solving and creative approach

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (medical vs. engineering)
  - *Dynamics*: His structural knowledge might help in safely extracting injured victims from dangerous locations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his methodical approach and engineering expertise

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (medical vs. infiltration)
  - *Dynamics*: His healing abilities support her potentially dangerous infiltration work
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values her professional competence while providing medical support for her high-risk operations

## Past Relationships
- **Border War Soldiers**: 
  - *Relationship Type*: Field medic to soldiers
  - *History*: Provided medical care during the war
  - *Current Status*: Most connections likely ended after war
  - *Feelings Toward*: Deep compassion, sense of duty
  - *Tensions/Issues*: Possibly haunted by those he couldn't save
  - *Shared Experiences*: Battlefield trauma and camaraderie
  - *Notable Individuals*: Those who first called him "Brother" and adopted him as family

- **Academic Mentors/Peers**: 
  - *Relationship Type*: Student to teachers/colleagues
  - *History*: Formal education at prestigious academy
  - *Current Status*: Likely limited contact since war
  - *Feelings Toward*: Respect for knowledge gained
  - *Tensions/Issues*: Possible philosophical differences after war experiences
  - *Shared Experiences*: Academic discussions, medical training

## Family Relationships
- **Parents (Halfling Healers)**:
  - *Relationship Type*: Son to village healer parents
  - *History*: Taught him initial healing skills before academia
  - *Current Status*: TBD
  - *Feelings Toward*: Respect for traditional knowledge
  - *Tensions/Issues*: Possible disappointment at his leaving village life
  - *Shared Experiences*: Early healing training, family traditions

- **Other Family Members**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Feelings Toward*: TBD

## Patients & Care Relationships
- **Last Light Company Members**:
  - *Relationship Type*: Healer to patients
  - *Dynamics*: Holistic care provider - addresses physical, spiritual, and mental needs
  - *Notable Interactions*: Tea ceremonies for comfort and healing
  - *Special Care*: Understanding individual needs of each company member

- **Terminal Patients**:
  - *Relationship Type*: Compassionate end-of-life care provider
  - *Dynamics*: Offers dignity and peace in final moments
  - *Notable Interactions*: Special tea blends for "gentle passage"
  - *Personal Impact*: Likely carries memories of those who passed under his care

## Interpersonal Patterns
- **Trust Building**:
  - Uses tea ceremony as a way to establish rapport and trust
  - Creates safe space for both physical and emotional healing
  - Demonstrates reliability through consistent care

- **Conflict Resolution**:
  - Likely approaches conflicts philosophically
  - May serve as mediator due to calm, steady presence
  - Focuses on underlying needs rather than surface disagreements

## Relationship Evolution Tracker
- **Pre-War**: Academic relationships, family connections
- **During War**: Formation of "Brother" identity, soldier bonds
- **Post-War Village Life**: Strained relationship with peaceful routine
- **Plague Outbreak**: Meeting Veyra, witnessing her dedication
- **Current**: Developing relationships with Last Light Company members

## Potential Relationship Development
- May deepen philosophical connection with Veyra
- Could develop teaching relationship with others interested in healing
- Might form special bonds with those he's healed from serious injuries
- Potential tension with anyone who questions his "gentle passage" practices


---

# Aldwin Gentleheart — Dialogue & Psyche

## Core temperament
Quietly compassionate, steady, and philosophical. Sees suffering and responds with presence and dignity rather than spectacle.

## Dialogue instincts
- Public: calm, measured, speaks slowly to create space. Uses simple metaphors drawn from domestic life and ritual.
- Teaching/comfort: ritualized phrasing (tea, passages), invites participation rather than giving orders.
- Under pressure: unflappable; keeps tone soft but firm, using short corrective or grounding statements.
- Humor: gentle, small levity that eases tension—never flippant about pain.

## Emotional anchors & physical tells
- Tea ritual: preparing or offering a cup = bringing calm and focus.
- Small, steady hands: smoothing a blanket, adjusting a bandage—actions speak with his words.
- Soft smile and steady eye contact signal acceptance and reassurance.
- Pauses long enough for another to exhale; silence is an active tool for him.

## Conflict & humor rules
- Does not debate the dignity of life in abstractions; reframes hard choices with compassion.
- Avoids dark jokes about death; uses warmth and a tiny wryness to lighten unbearable moments.
- Will calmly challenge black-and-white thinking about mercy vs. preservation.

## Writer cues (practical)
- Use Aldwin as the emotional anchor in scenes involving suffering or ethical tension.
- When inserting dialogue, give him short, clarifying lines that reframe a dilemma (e.g., "Suffering is the enemy, not death.").
- Pair his lines with a small ritual action (pouring tea, laying a hand) to emphasize embodiment of his philosophy.

## Drop-in sample lines (from Chapters 6-9)
- **On his philosophy:** "Suffering is the enemy, my friend, not death."
- **On his methods:** "I freed her... It's not medicine. It's compassion."
- **On his purpose:** "I don't save lives. I save souls."
- **On joining the company:** "Building a company for the lost? Then I'll gather my things."
- **On the company's nature:** "The lost leading the lost."
- **A simple kindness:** "A kindness is never a small thing."
- **Gentle levity:** "Don't worry. It's just mint."

## Voice evolution note (chapters 1–9)
- Introduction: appears as a quiet moral figure, steadying others.
- Middle: his presence reframes the Company's approach to risk and mercy.
- Later: becomes a core emotional center; his calm speech helps the Company accept hard choices and recover afterward.

## Usage examples (scenes)
- In a triage tent: short, guiding phrases combined with ritual actions to slow panicked breaths.
- After a rescue: one soft sentence that converts survivor panic into dignified care.
- When debating ethics: a simple, humane aphorism that reframes the argument.

## Notes for editors
- Avoid making Aldwin a polemicist; keep him concise and tactile.
- Let his teachings appear through small rituals and consistent, gentle language rather than long sermons.


---

# Brother Aldwin "Gentle Passage" Gentleheart - Scene Tracker

## Major Scenes

### Chapter 6 – The Healer's Calling <!-- slug: ch6-healers-calling -->
- **Scene 2**: Introduction at plague-stricken Oakhaven village
- **Scene 3**: "Gentle passage" ceremony for plague victims
- **Scene 4**: Decision to join the Last Light Company

### Chapter 7 – The Weight of the World <!-- slug: ch7-weight-world -->
- **Scene 3**: Tending to injured miners at Blackvein Lode
- **Scene 4**: Building rapport with Grimjaw during rescue operation

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 1**: Preparing medical supplies for winter rescue mission
- **Scene 2**: Gentle assessment of the Thornwood misunderstanding
- **Scene 4**: Immediate medical assessment of Vera in the snow
- **Scene 5**: Life-saving treatment of Vera's severe hypothermia
- **Scene 6**: Ongoing care and assessment of Vera's magical exhaustion
- **Scene 7**: Selected for tracking mission for medical expertise
- **Scene 9**: Tending to rescued children from the Silent Hand trafficker
- **Epilogue**: Offering herbal remedies for Vera's beast sense exhaustion
- **Epilogue**: Good-natured reaction to teasing about his "special teas"

## Character Moments

### Best Moments
- Gentle passage ceremony at Oakhaven (Ch. 6)
- Immediate assessment and treatment of Vera (Ch. 10)
- Calm presence during animal protection of Vera (Ch. 10)
- Offering herbs for Vera's beast sense exhaustion (Ch. 10)

### Worst Moments
- Confronting limitations of healing during plague (Ch. 6)
- Potentially not having appropriate treatments for magical exhaustion (Ch. 10)

### Turning Points
- Decision to join the Last Light Company (Ch. 6)
- Building rapport with Grimjaw (Ch. 7)
- Meeting Vera and recognizing her unique connection to animals (Ch. 10)

## Interaction Log

### With Veyra Thornwake
- Chapter 6: First meeting, philosophical alignment recognized
- Chapter 10: Supporting her decision regarding Vera and rescued children

### With Thorne Brightward
- Chapter 6: Being introduced to the Company concept
- Chapter 10: Coordination during Vera's rescue and recovery

### With Grimjaw Ironbeard
- Chapter 7: Beginning of working relationship during mine rescue
- Chapter 10: Gentle teasing during dinner about "special teas"

### With Vera Moonwhisper
- Chapter 10: Saving her life from hypothermia
- Chapter 10: Recognizing her druidic connection to animals
- Chapter 10: Offering herbal remedies for beast sense exhaustion

## Upcoming Scenes

### Planned Appearances
- Continued medical support during rescue missions
- Potential development of specialized treatments for magical exhaustion
- Further exploration of "gentle passage" philosophy

### Required Interactions
- Development of healing relationship with Vera
- Further integration of medical knowledge with other specialists' work
- Potential philosophical discussions about death and mercy with Company members


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Archer Venn

# Archer Venn – Profile

## Basic Information
- Full Name: Venn (surname not mentioned)
- Aliases/Nicknames: None
- Race: Elf (Wood Elf)
- Race: Elf (Wood Elf)
- Age: Not specified
- Gender: Female
- Role in Story: City Guard archer, proto-Company member
- First Appearance: Chapter 1, Scene 6 (The Vigil)
- Status: Active

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: A perpetually smug grin that doesn't reach her eyes, and a single, intricately braided strand of hair with a tarnished silver clasp. The clasp was a gift from a young hunter who died as a result of her battlefield recklessness; she keeps it as a constant, shameful reminder.
- Typical Clothing: City Guard armor
- Body Language: Alert, watchful
- Physical Condition: Combat-ready archer

## Significance
Archer Venn provides both marksmanship and morale to Thorne's patrol. Her wise-cracking nature and ability to lighten tense moments make her valuable for team cohesion. She represents the balance between professionalism and humanity needed in rescue work.

## Key Actions
- Kept overwatch during the initial vigil at Undershade
- Brought specially tuned arrows to Veyra during recovery
- Spun theories about the lantern's phoenix feather wick
- Made jokes to lighten mood ("Hospital gruel still winning the taste-test?")
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).

## Personality Traits
- Wise-cracking sense of humor
- Professional when needed
- Skilled craftsman (tunes her own arrows)
- Loyal to her unit
- "Ever the arrow seeking release"

## Future Role
Expected to become the Company's marksman and morale booster, providing both covering fire and emotional relief during tense operations.


---

# Archer Venn – Background

## Origin
- **Birthplace**: A reclusive Wood Elf community in the High Forest.
- **Social Class**: Formerly a respected hunter and scout.
- **Cultural Background**: Elven; shaped by the long, slow rhythms of the forest and a society where actions have centuries-long consequences.

## Family
- **Family Dynamics**: Venn has not spoken to her family since her exile. She carries a deep sense of shame and loss regarding them, though she masks it with indifference.

## History
- **Childhood**: Trained from a young age in archery and woodland survival, showing immense talent. She was a respected hunter with a focus on the excellence of the bow rather than a deep connection to nature itself.
- **Formative Events**: 
  - **The Transgression (The Echoing Cave):** Venn was exiled after a disastrous mission to clear a nest of Phase Spiders. Believing the elders' slow, methodical plan was inefficient, she took a reckless "hero shot" to collapse a rock shelf onto the Broodmother. Her aim was perfect, but her prideful miscalculation of the cavern's integrity caused a much larger collapse. The falling rock killed a young hunter she had mentored and trapped several others. She was exiled because her impulsive pride proved to be a danger to the community.
- **Life in Waterdeep**: She fled to Waterdeep, a city whose frantic pace and the short memories of its inhabitants were a welcome antidote to her past. The constant, immediate problems of the city are a distraction from the timeless pain of her exile.
- **Hobbies**: She is a gambler and a flirt, deliberately seeking out fleeting, meaningless connections. This chaotic lifestyle is a way to drown out the past and live entirely in the present moment, avoiding any new bonds that could lead to the kind of loss she has already experienced.
- **Motivation for Joining the Watch**: The Watch offered a perfect meritocracy where her skill with a bow was all that mattered. It provided structure, distraction, and a way to use her deadly talents without having to form deep personal attachments.

---

# Archer Venn – Character Development

## Personality Core
- **Defining Traits**: Witty, observant, reckless, proud, deeply guarded. Her humor is a well-honed defense mechanism.
- **Core Values**: Competence, self-reliance, a buried desire for redemption.
- **Motivations**: To escape her past and find a new purpose that can overshadow her old mistakes.
- **Fears**: Being truly known, repeating the mistakes that led to her exile, forming bonds only to lose them again.
- **Internal Conflicts**: The elven desire for a meaningful, long-term purpose versus her self-destructive need for immediate, fleeting distractions.

## Character Arc
- **Starting Point**: A cynical, detached City Watch archer using her job and her vices to run from her past.
- **Catalyst Events**: Seeing her own past trauma and exile reflected in Veyra's eyes, and later witnessing Veyra's undeniable competence during the Dock Ward fire.
- **Current State**: A committed member of the Company who has found a cause worthy of her skills, though she still struggles with vulnerability and forming genuine bonds.
- **Intended Destination**: To become a key tactical asset and a trusted, if still sarcastic, friend within the Company, finally coming to terms with her past and finding a new family.

## Key Relationships
- **Relationship to Thorne**: Thorne is the stable, authoritative figure she both needs and resents. Her constant testing of his patience with her wisecracks is a subconscious way of seeking boundaries and affirmation that she belongs, even as an outsider.
- **Reaction to Veyra**:
    - **First Thought**: "That look in her eyes... I've seen it before. In a mirror." Her first thought isn't an abstract observation, but a moment of sharp, uncomfortable self-recognition. She sees a reflection of her own past pain and exile in Veyra's eyes, which is both deeply unsettling and compelling.
    - **Why She Followed**: Veyra's mission offered something she thought she'd lost forever: a purpose with long-term meaning. Patrolling the city was a distraction; this was a cause. In Veyra's unwavering focus, she saw a path to redeeming her own past. Her dedication to "no one left behind" resonated with the guilt from her exile. Following Veyra is her penance and her hope for a new legacy.


---

# Archer Venn - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Archer Venn - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Archer Venn - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Borin Stonehand

# Borin Stonehand – Profile

## Basic Information
- Full Name: Borin Stonehand
- Aliases/Nicknames: None mentioned
- Age: Middle-aged for a dwarf (at time of death)
- Gender: Male
- Role in Story: Party cleric and moral compass
- First Appearance: Chapter 1, Scene 1 (Twilight on the Rim)
- Status: Deceased (Undershade Canyon)

## Physical Description
- Height/Build: Typical dwarven build, sturdy
- Hair: Not specified
- Eyes: Tracked dangers with "healer's caution"
- Distinguishing Features: Silver-braided emblem of Berronar Truesilver
- Typical Clothing: Clerical vestments with holy symbols
- Body Language: Jovial but steadfast
- Physical Condition: Strong enough to wield a war-hammer

## Significance
Borin Stonehand served as the Gilded Compass's healer and moral guide, a devout cleric of Berronar Truesilver (dwarven goddess of hearth and healing). His protective dome spell (Berronar's Embrace) nearly saved the party but couldn't withstand the cult's dragon-fire. His death represents the loss of spiritual protection and guidance.

## Death Scene
Died attempting to shield Elara and escape through the closing gap, using his divine magic to protect others until the very end. His straining hymn was one of the last sounds Veyra heard before the silence.

## Legacy
- Cracked holy symbol recovered and placed at the lantern's base
- Name inscribed in the Hall of Remembrance
- His protective instinct echoes in the Company's mission
- Represents the divine protection that failed but inspired future dedication


---

# Borin Stonehand - Background

## Origin
- **Birthplace**: A large dwarven city, likely Citadel Adbar or a similar stronghold.
- **Social Class**: Respected clerical class.
- **Cultural Background**: Devout follower of the dwarven pantheon, specifically Berronar Truesilver, the goddess of hearth, home, and healing.

## Family
- **Spouse**: Helga, a master brewer.
- **Children**: Three daughters.
- **Family Dynamics**: A loving and proud husband and father, he often spoke of his family with great affection. His role as a protector was deeply rooted in his love for them.

## History
- **Professional Career**: A cleric of Berronar Truesilver who chose to bring his goddess's protection and healing to the wider world rather than remain in a temple. He served as the cleric and moral compass for the Gilded Compass adventuring party.

## Personal Details
- **A Cherished Possession**: His most prized personal item was a beautifully crafted silver-banded drinking horn, a gift from his wife, Helga. He would often boast that no ale ever tasted as good as his wife's, especially when drunk from that horn.
- **How He Relaxed**: He was a surprisingly nimble dancer. On quiet nights in taverns, after a successful adventure, he could be coaxed into performing a traditional, stomping dwarven jig. His infectious, booming laughter during these moments was a source of immense joy and morale for the entire party.
- **Favorite Meal**: A massive "Forge-Tender's Pie," a savory pastry crust filled with slow-cooked meats, root vegetables, and a thick, ale-based gravy. It's a communal, celebratory meal, meant to be shared, which perfectly suited his role as the heart of the party.


---

# Borin Stonehand - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Borin Stonehand - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Borin Stonehand - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Borin Stonehand - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Captain Grimsby

# Captain Grimsby – Profile

## Basic Information
- Full Name: Grimsby (first name not mentioned)
- Aliases/Nicknames: None
- Age: Not specified (likely a veteran officer)
- Gender: Male
- Role in Story: Antagonistic peer to Captain Thorne Brightward
- First Appearance: Chapter 4, Scene 2 (The First Spark)
- Status: Active

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: None specified
- Typical Clothing: City Watch Captain's uniform
- Body Language: Stern, by-the-book
- Physical Condition: Active duty

## Significance
Captain Grimsby represents the institutional inertia and professional skepticism that Thorne and Veyra must overcome. He is not evil, but he is rigid, following the manual over battlefield realities. His conflict with Thorne serves to highlight Thorne's growing loyalty to Veyra's mission over his formal duties and will likely be the source of future political trouble.

## Key Actions
- Confronted Thorne at the scene of the Dock Ward fire
- Questioned Thorne's decision to bring a "civilian liability" into a hot zone
- Dismissed Veyra's past trauma as a disqualifier rather than a source of expertise
- Was silenced when Veyra's prediction about the fire proved correct

## Personality Traits
- By-the-book traditionalist
- Skeptical of outsiders and unconventional methods
- Concerned with liability and official reports
- Represents the established order of the City Watch

## Future Role
Likely to be a recurring professional antagonist, filing reports about Thorne's "unorthodox" methods and creating political obstacles for the nascent Last Light Company.


---

# Captain Grimsby - Background

## Origin
- **Birthplace**: Waterdeep
- **Social Class**: Likely middle class, a family with a history of civic service.
- **Cultural Background**: Urban, deeply ingrained in the traditions and regulations of the Waterdeep City Watch.

## History
- **Professional Career**: A veteran officer of the City Watch who has risen through the ranks to the position of Captain. He is a contemporary of Thorne Brightward.
- **A Defining Tragedy**: Early in his career, Grimsby was a promising, flexible officer. However, he was the ranking officer at a scene where a junior constable, acting on a "gut feeling" and ignoring protocol, rushed into a hostage situation and was killed. The subsequent inquiry nearly ended Grimsby's career. The incident instilled in him a deep-seated, trauma-induced belief that the rules and the manual are the only things that prevent chaos and keep his officers safe. His rigidity is not born of malice, but of a profound, personal fear of repeating past mistakes.

## Personal Details
- **How He Relaxes**: He is an avid player of "Sovereigns," a highly complex, chess-like board game that has hundreds of rules and established opening moves. He finds the game's rigid structure and predictable outcomes deeply calming. He plays by correspondence with several other Watch captains across the Sword Coast.
- **Favorite Meal**: A very specific, unvarying meal from the officer's mess: boiled beef, potatoes, and carrots, served at precisely six o'clock every evening. He doesn't particularly enjoy it, but he finds comfort in its absolute predictability.


---

# Captain Grimsby - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Captain Grimsby - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Captain Grimsby - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Captain Grimsby - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Cidrella Vexweld

# Cidrella "Cid" Vexweld - Profile

## Basic Information
- **Full Name**: Cidrella Vexweld
- **Aliases/Nicknames**: Cid
- **Race**: Rock Gnome
- **Class**: Artificer
- **Role in Story**: Arcano-Engineer for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Short and sturdy, as is typical for a Rock Gnome, with a compact, muscular build from hauling metal and machinery.
- **Hair**: A wild mane of coppery-red hair, often tied up in a messy faux-hawk with a prominent, rebellious streak of arcane blue. It's usually held back from her face by a set of custom-made brass goggles.
- **Eyes**: Sharp, intelligent brown eyes that sparkle with curiosity and focus. Her gaze is direct and misses nothing.
- **Distinguishing Features**: A light dusting of freckles across her nose and cheeks, often smudged with grease or soot. Her left arm, from the shoulder down, is a masterwork prosthetic of her own design, crafted from articulated brass and bronze plates, with glowing arcane conduits visible beneath the seams.
- **Typical Clothing**: She prioritizes function over fashion. She typically wears a dark, oil-stained leather tunic and a heavy leather apron or cuirass over it, complete with numerous pockets and loops for tools. A bandolier holding large power cells or cartridges is always slung across her chest.

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Cidrella Vexweld.

## Personality
- **Archetype**: The Inventor/Problem-Solver
- **Temperament**: Confident, direct, intellectually driven
- **Positive Traits**: Brilliant, resourceful, pragmatic, solution-oriented
- **Negative Traits**: Potentially overly focused on technical challenges rather than people
- **Moral Alignment**: Neutral Good - primarily motivated by intellectual curiosity but applies her skills to help others

## Skills & Abilities
- **Expertise**: 
  - Battlefield invention and adaptive technologies
  - Creating arcane security systems and defensive measures
  - Designing magical wards, arcane locks, self-repairing mechanisms
  - Developing specialized rescue equipment
- **Special Abilities**: 
  - Creating automated defenses that respond to different intrusion types
  - Designing adaptive security grids
  - Building collapsible bridges, wall-penetrating devices, and automatic escape mechanisms
- **Education Level**: Highly educated in arcane engineering and magical artifice
- **Languages**: TBD
- **Combat Style**: Likely relies on inventions and devices rather than direct combat

## Personal Details
- **Habits**: Constantly tinkering with gadgets and improving equipment
- **Hobbies**: Creating and testing new inventions, solving complex technical puzzles
- **Personal Quarters**: A chaotic, two-story space known as "The Annex," connected to her main workshop by a clanking metal door. The ground floor is a secondary workbench, even more cluttered than her main one, dedicated to her most dangerous and experimental personal projects. A rickety, oil-stained spiral staircase leads up to a small loft, which is just big enough for a mattress and a chaotic pile of clothes. The room smells perpetually of ozone, soldering flux, and strange chemical reagents. Wires and arcane conduits run like vines along the walls, powering various half-finished contraptions that hum, click, and occasionally spark at all hours. Blueprints are tacked to every available surface, often overlapping in multiple layers. She uses this space for feverish, late-night invention, often grabbing a few hours of sleep on the mattress only when she physically collapses from exhaustion.
- **Likes**: Interesting technical challenges, elegant solutions to complex problems
- **Dislikes**: Mundane work, repetitive tasks, inefficiency
- **Fears**: TBD
- **Motivations**: Purely intellectual - the interesting challenges and problems to solve, not glory, redemption, or money

## Combat & Tactics
- **Primary Weapon System**: "Flitzragger" - multi-function energy tool connected via heavy cables to her back-mounted power pack. Functions as energy gun, arcane welder, plasma cutter, and "creative problem solver"
- **Power Source**: Back-mounted energy pack that powers both her augmented arm and Flitzragger - constantly humming with barely-contained arcane energy
- **Augmented Arm**: Mechanical left arm with rotating tool attachments and experimental features, powered by the same energy pack
- **Secondary Weapons**: Belt of explosive devices ranging from smoke bombs to "probability charges" (she's not always sure what they'll do)
- **Armor**: Reinforced leather cuirass covered in tool loops, pockets, and attachment points for various gadgets
- **Fighting Style**: Chaos engineer - switches Flitzragger between combat and utility modes mid-fight, often using it to build solutions while under fire
- **Signature Move**: "Overcharge Protocol" - dumps excess energy from pack through Flitzragger for devastating but unpredictable results
- **Combat Philosophy**: "If it's stupid but it works, it's not stupid. If it explodes, it's data!"
- **Tactical Role**: Problem solver who creates unconventional solutions while actively fighting

## Psychological Response Matrix
- **In Crisis**: Gets MORE excited as danger increases - "Oh, this is INTERESTING!" - immediately starts mentally designing solutions
- **During Negotiation**: Fidgets constantly with Flitzragger settings, making everyone nervous as clicking and whirring sounds emanate
- **Moral Dilemma**: "But what if we tried..." - always has a third option involving experimental technology
- **Team Conflict**: Builds something to solve it, whether needed or not ("I made a randomizer to decide who's right!")
- **Under Personal Attack**: Takes notes for improvements while using Flitzragger defensively ("Note to self: add stunning frequency")
- **In Victory**: Immediately starts disassembling captured technology, using Flitzragger's tool modes
- **ADD Tendencies**: Jumps between three projects simultaneously, often combining them in unexpected ways

## Voice & Dialogue Patterns
- **Speech Style**: Rapid-fire technical explanations interrupted by new ideas, often mid-sentence
- **Signature Phrases**: 
  - "Theoretically impossible, practically simple!"
  - "Flitzragger to mode seven—wait, I haven't invented mode seven yet—MODE SIX!"
  - "It'll probably work!" (her version of reassurance)
  - "Energy levels are... mostly stable!"
- **Technical Tangents**: Explains while building with Flitzragger, forgetting others can't follow her mental leaps
- **Example Dialogue**: "Pass the crystallized sulfur—no the BLUE one—Flitzragger needs recalibrating—OH! What if we routed power through the secondary coils? Never mind, trying it!"
- **Emotional Tells**: Talks faster when excited, energy pack hums louder when she's thinking hard, Flitzragger sparks when she's frustrated
- **Interruption Pattern**: Frequently interrupts herself with new ideas before finishing sentences

## Notes
- Joined the Last Light Company not from trauma or redemption but because rescue operations present fascinating technical problems
- Had a profitable three-year working relationship with Korrath as a subcontractor
- Specializes in "impossible problems" that regular engineering couldn't solve
- Works in perfect tandem with Korrath: he identifies structural weaknesses while she provides tools to exploit them safely
- Motivated purely by intellectual curiosity and the challenge of solving complex problems

### Public Perception
- Known for her wild inventions and ability to solve "impossible problems," from mechanical chickens to clearing sewer blockages with clockwork crabs.
- Her augmented metal arm is a source of awe and wonder, rumored to transform into various tools and weapons.
- Works in a highly effective, if sometimes argumentative, partnership with Korrath Threnx, building and repairing critical infrastructure.


---

# Cidrella "Cid" Vexweld - Background

## Origin
- **Birthplace**: Waterdeep
- **Birth Date**: TBD
- **Social Class**: Respected artisan/inventor class.
- **Cultural Background**: Rock Gnome culture with a strong emphasis on invention, practical magic, and intellectual curiosity.

## Family
- **Family Name**: Vexweld
- **Family Trade**: A respected line of jewelers and clockmakers known for their intricate, reliable, and predictable creations.
- **Family Dynamics**: Cid is the family's brilliant, exasperating black sheep. While they crafted beautiful, delicate mechanisms, she was trying to strap rockets to them. Her family loves her genius but is terrified by her methods. Her decision to leave and open her own shop was a mutual, loving relief for all involved.

## History
- **Education/Training**: 
  - Extensive education in arcane engineering and magical artifice, likely through a combination of formal schooling and apprenticeships.
- **Professional Career**:
  - **"Cid's Solutions & Salvage":** After leaving home, she founded a legendary shop in Waterdeep known for solving problems that conventional engineering couldn't touch. It catered to adventurers, wizards, and mercenary captains, earning her a reputation as a "battlefield inventor" not by contract, but by delivering custom, unconventional gear that worked—usually.
  - **The Arm Incident:** The loss of her arm was a landmark event. During an ambitious attempt to create a miniature, self-powering forge using a contained fire portal, a moment of impatience led her to skip a final diagnostic. The containment field flared, and a jet of pure elemental energy erupted, vaporizing her left arm in an instant of searing, agonizing pain. The initial aftermath was not one of cool analysis, but of shock and agony. However, during her recovery, the true Cid emerged. The horror of the event quickly gave way to the most fascinating engineering problem of her life, and she began sketching designs for an improved replacement. Her current prosthetic is a masterwork of articulated brass and glowing conduits.
- **The Turning Point (The "Silent Hand" Compound):**
  - During a high-stakes rescue mission, Korrath Threnx, a stoic Dragonborn engineer and frequent client, contacted Cid to inform her that a security system they had designed together was being used by the "Silent Hand" slaver ring to imprison children.
- **Joining the Company**:
  - Cid and Korrath took the lead on the infiltration of the "Silent Hand" compound, systematically dismantling their own creation. 
  - In the aftermath, Cid had a revelation. While Korrath found redemption, she found the most interesting, complex, and rewarding technical challenge of her life. She joined the Last Light Company not for moral reasons, but because she realized that rescue operations presented a constant stream of fascinating, "impossible" problems that no other line of work could offer.

## Backstory Elements
- **Defining Moments**: 
  - The workshop accident that cost her an arm but gave her a new platform for innovation.
  - Learning about the misuse of her security systems.
  - The intellectual thrill of dismantling her own creation for a successful rescue.
- **Past Achievements**: 
  - Her reputation as a brilliant problem-solver through her shop, "Cid's Solutions & Salvage."
  - The successful infiltration of the "Silent Hand" compound.
- **Past Failures**: 
  - Unintentionally contributing to the imprisonment of children through her "no questions asked" professional policy.
- **Mentors/Influences**: 
  - Korrath, whose professional relationship evolved into a unique partnership.

## How They Got Here
- **Reason for Current Situation**: 
  - Driven by an insatiable intellectual curiosity and a desire for the most challenging problems.
  - Her unique working relationship with Korrath.
  - The realization that rescue operations offer the most complex and rewarding application of her skills.
- **Path to Current Location**: 
  - Gnomish artisan family -> Independent shop owner -> The Arm Incident -> Subcontractor for Korrath -> Moral crisis and a new, more interesting challenge -> Joining the Last Light Company.
- **Goals Prior to Story Start**: 
  - To find increasingly complex technical challenges and push the boundaries of arcano-engineering.

## Historical Connections
- **Connection to Main Plot**: 
  - Creates specialized equipment crucial for rescue operations.
- **Connection to Other Characters**: 
  - **Korrath Threnx**: Her former client, now her indispensable partner.
  - **Vera Moonwhisper**: The mission that brought her into the Company was Vera's personal quest.
- **Connection to Story World**: 
  - A deep understanding of magical security systems and how to bypass them.

## Timeline
- Early career as an artificer and inventor.
- Opens "Cid's Solutions & Salvage" in Waterdeep.
- Loses arm in a workshop accident and builds a superior replacement.
- Established a three-year working relationship with Korrath Threnx as a subcontractor.
- Contacted by Korrath regarding the misuse of their security system by the "Silent Hand."
- Assisted the Last Light Company in the successful rescue of children from the compound.
- Joined the Company, driven by the unique technical challenges of their work.
- Became the lead systems designer for the Bastion of Last Light.

## Personal Details
- **How She Relaxes**: She doesn't relax; she "optimizes." Her downtime is spent creating incredibly complex, Rube Goldberg-esque contraptions to perform simple tasks, purely for the joy of seeing a ridiculously complicated system she designed actually work.
- **Favorite Meal**: A "Tinker's Plate"—a chaotic assortment of small, flavorful foods she can eat with one hand while working with the other (pickled vegetables, smoked sausages, hard cheeses, nuts, etc.).
- **A Secret Hobby**: She is an avid participant in "Cog-Fighting," an underground gnomish sport where participants build and battle small, clockwork automatons. It's a perfect outlet for her competitive, inventive, and slightly chaotic nature.
- **Working with Korrath**: She genuinely enjoys her working relationship with Korrath Threnx. She sees his stubborn insistence on proven, methodical engineering as the ultimate, irresistible challenge. His rigid frameworks are the perfect "cage" for her chaotic genius to break out of. While his constant warnings about safety protocols can be exasperating, she secretly appreciates that his solid foundations give her a stable platform from which to launch her most outlandish and brilliant ideas.

---

# Cidrella "Cid" Vexweld - Character Development

## Personality Core
- **Defining Traits**: Brilliant, confident, pragmatic, solution-oriented
- **Core Values**: Technical excellence, innovation, intellectual challenge, efficiency
- **Motivations**: Purely intellectual - interesting challenges and problems to solve
- **Fears**: TBD - possibly intellectual stagnation or encountering unsolvable problems
- **Internal Conflicts**: 
  - Technical focus vs. human impact of her work
  - Intellectual curiosity vs. ethical considerations
  - Autonomy vs. team integration
- **Contradictions**: 
  - Creates both security systems and tools to bypass them
  - Values efficient solutions but may overcomplicate for intellectual stimulation
  - Focused on technical aspects while working in emotionally charged rescue situations

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Brilliant problem-solver focused purely on technical challenges
  - *World View*: Problems exist to be solved; technical solutions exist for all situations
  - *Key Relationships*: Professional relationship with Korrath based on complementary skills
  
- **Catalyst Events**:
  - *Event 1*: Learning her security systems were used for child trafficking
  - *Event 2*: First rescue mission with the Company (TBD specifics)
  - *Event 3*: TBD - potential future event where technical solution alone isn't enough
  - *Event 4*: TBD - possible conflict between intellectual interest and emotional impact
  
- **Current State**:
  - *Self-Perception*: Technical specialist who applies skills to interesting rescue challenges
  - *World View*: Rescue operations present fascinating technical problems to solve
  - *Key Relationships*: Working partnership with Korrath and developing connections with Company members
  
- **Intended Destination**:
  - *Self-Perception*: Potential evolution to see herself as more than just a problem-solver
  - *World View*: Possible development of awareness about human impact beyond technical challenges
  - *Key Relationships*: Deeper integration with team and possibly emotional investment in missions

## Growth Milestones
- **From Security Provider to Rescue Specialist**: 
  - *Development Noted*: Shift from creating security systems to developing rescue technologies
  - *Catalyst*: Learning about misuse of her systems and joining the Company
  - *Impact*: Application of skills toward helping others rather than potentially harmful security
  
- **From Purely Technical Focus to Awareness of Impact**: 
  - *Development Noted*: TBD - growing recognition of the human elements in her work
  - *Catalyst*: TBD - possibly witnessing the emotional impact of a rescue
  - *Impact*: TBD - potential shift in motivation beyond pure intellectual interest
  
- **From Independent Operator to Team Integration**:
  - *Development Noted*: TBD - learning to work with diverse specialists beyond just Korrath
  - *Catalyst*: TBD - complex mission requiring multiple specialties working in harmony
  - *Impact*: TBD - enhanced effectiveness through true team collaboration

## Character Flaws
- **Intellectual Detachment**: 
  - *Effects on Character*: May prioritize interesting problems over human considerations
  - *Effects on Others*: Could be perceived as cold or uncaring about emotional aspects
  - *Development Plan*: Potential growth toward recognizing human elements of technical challenges
  
- **Overly Solution-Focused**: 
  - *Effects on Character*: Might rush to technical solutions without fully considering context
  - *Effects on Others*: May frustrate team members who need to process emotional aspects
  - *Development Plan*: Learning to balance technical brilliance with situational awareness
  
- **Moral Blind Spots**:
  - *Effects on Character*: Previously didn't question applications of her work ("that's what happens when you don't ask questions")
  - *Effects on Others*: May have unintentionally contributed to harmful situations
  - *Development Plan*: Growing awareness of responsibility for how her inventions are used

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: TBD - possibly the true nature/origin of her augmented arm
  - *Secret 2*: TBD - perhaps specialized knowledge or capabilities she keeps to herself
  
- **Unknown to Character**:
  - *Truth 1*: TBD - possibly that she's developing emotional investment despite intellectual focus
  - *Truth 2*: TBD - perhaps the full extent of how her previous work was misused
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Joining the Company**:
  - *Context*: After learning about misuse of her security systems
  - *Options Considered*: Continue regular contracting vs. apply skills to rescue operations
  - *Choice Made*: Join the Last Light Company for interesting technical challenges
  - *Consequences*: Shift from security provider to rescue specialist

- **TBD Future Decision**:
  - *Context*: TBD
  - *Options Considered*: TBD
  - *Choice Made*: TBD
  - *Consequences*: TBD

## Special Character Elements
- **Augmented Left Arm**:
  - Physical manifestation of her merging of magic and engineering
  - Likely has capabilities beyond what she reveals
  - Visual indicator of her technical expertise and self-modification
  
- **Golden-Orange Eyes with Magical Circuitry**:
  - Change when calculating or problem-solving
  - Window into her thought process
  - Visual indication of her intense focus and analytical abilities
  
- **Labeled Tool Compartments**:
  - Reflect her organized but creative approach
  - Names like "Stun Goo" and "Chompers" show technical solutions with personality
  - "Backup Backup Key" suggests learning from past failures

## Development Notes
- Character represents the technical specialist archetype with unique gnomish flair
- Potential for growth from purely intellectual motivation to emotional investment
- The challenge of maintaining technical brilliance while developing interpersonal awareness
- Opportunity to explore the ethics of invention and responsibility for how creations are used
- Her unique working relationship with Korrath provides foundation for team integration

## Psychological Profile
*   **Cidrella "Cid" Vexweld (The Problem-Solver):** Cid's mind is a whirlwind of schematics, arcane formulas, and "impossible problems" waiting to be solved. She is driven by the sheer joy of creation and the intellectual thrill of overcoming a challenge. She is not motivated by altruism in the traditional sense; she joined the Company because saving people from "impossible" situations presents the most interesting engineering problems. Her confidence is born from a deep, unshakeable belief in her own intellect.


---

# Cidrella "Cid" Vexweld - Relationships

## Professional Relationships
- **Korrath**: 
  - *Nature of Relationship*: The Engineering Duo; "old married couple."
  - *Hierarchy*: Equals and intellectual rivals/partners.
  - *Dynamics*: Their dynamic stems from a fundamental difference in philosophy. Korrath is a master of established, proven principles ("Threnx work doesn't collapse"). Cid is a chaotic innovator who loves to break the rules. They argue constantly, but their respect for each other's genius is absolute. Korrath builds the unbreakable foundation, and Cid builds the impossible machine that sits on top of it.
  - *History*: Three-year profitable working relationship as a subcontractor.
  - *Current Status*: Close, argumentative, and highly effective partners.
  - *Feelings Toward*: She has immense respect for his skill but is endlessly frustrated by his rigid adherence to "the book." She sees his methods as a solid starting point for her to improve upon.

- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Arcano-Engineer
  - *Hierarchy*: Respects command structure but likely operates with significant autonomy in her specialty
  - *Dynamics*: Provides technical solutions to support Veyra's rescue missions
  - *Professional Opinion of*: Respects her dedication to leaving no one behind and appreciates having challenging technical problems to solve

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Arcano-Engineer
  - *Hierarchy*: Acknowledges chain of command while focusing on technical solutions
  - *Dynamics*: Might have some friction if his military approach clashes with her unorthodox methods
  - *Professional Opinion of*: Acknowledges his tactical brilliance while preferring more flexible approaches to problem-solving

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist with complementary skills
  - *Hierarchy*: Equals with different areas of expertise
  - *Dynamics*: Vera's tracking abilities could help identify targets for Cid's technical solutions
  - *Professional Opinion of*: Appreciates her precision and methodical approach to tracking

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (medical vs. technical)
  - *Dynamics*: Potential for collaboration on medical devices or emergency equipment
  - *Professional Opinion of*: Values his healing expertise and sees opportunities for technical enhancement of medical care

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Surrogate father figure and most important client.
  - *Hierarchy*: She is the brilliant inventor, and he is her grizzled, doting guardian.
  - *Dynamics*: Cidrella publicly maintains an air of exasperation at Grimjaw's paternal fussing, but privately, she treasures it. Having a stable, unconditionally supportive father figure in her life is something she deeply values. She takes immense pride in building and maintaining his custom gear (the modular pickaxe and pack), seeing her technical expertise as the best way she can protect him on dangerous missions.
  - *History*: Their bond was forged in her workshop. She was fascinated by the unique engineering challenges his work presented and took it upon herself to upgrade his equipment. His genuine awe and subsequent paternal affection won her over.
  - *Current Status*: A deep, familial bond. She rolls her eyes when he calls her "Vexxy" in public, but would tear down a mountain to keep him safe.
  - *Feelings Toward*: She sees him as a stubborn, lovable, walking geological formation who needs her brains to stay safe. Her affection for him is immense, though she is more likely to show it by triple-checking the integrity of his gear than with a hug.
  
- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow magical specialist and research colleague
  - *Hierarchy*: Different magical disciplines (artifice vs. elemental/planar magic)
  - *Dynamics*: Mutual intellectual respect and shared enthusiasm for discovery
  - *Professional Opinion of*: Views her as a fellow knowledge-seeker with complementary magical expertise

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different areas of expertise (social vs. technical)
  - *Dynamics*: His diplomatic skills might complement her technical solutions for accessing restricted areas
  - *Professional Opinion of*: Appreciates his strategic thinking and ability to handle non-technical complications

- **Nireya Voss**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different domains (spiritual vs. technical)
  - *Dynamics*: Potential contrast between Cid's practical approach and Nireya's spiritual perspective
  - *Professional Opinion of*: Finds her spiritual abilities intellectually fascinating despite their different approaches

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Fellow technical specialist
  - *Hierarchy*: Different but complementary technical skills (arcano-engineering vs. infiltration)
  - *Dynamics*: Cid's devices might enhance Kaida's infiltration capabilities
  - *Professional Opinion of*: Professional respect for her precision and technical competence in infiltration

## Client Relationships
- **Former Security Clients**:
  - *Relationship Type*: Professional service provider
  - *History*: Created security systems and defensive measures
  - *Current Status*: Likely terminated after joining the Company
  - *Dynamics*: Purely transactional, focused on technical requirements
  - *Tensions/Issues*: Discovered her work was misused in at least one case (child trafficking compound)

- **Rescue Operation Beneficiaries**:
  - *Relationship Type*: Technical problem-solver enabling their rescue
  - *History*: Various rescue missions with the Company
  - *Current Status*: Likely successful rescues
  - *Dynamics*: Focused on the technical challenge rather than emotional connection
  - *Tensions/Issues*: Might be perceived as detached due to focus on technical aspects rather than human elements

## Personal Relationships
- **Family**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

- **Mentors/Teachers**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

- **Friends Outside the Company**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

## Interpersonal Patterns
- **Approach to Authority**:
  - Respects competence over formal authority
  - Focuses on technical solutions rather than hierarchical dynamics
  - Likely operates with significant autonomy within her specialty

- **Collaborative Style**:
  - Works exceptionally well with Korrath in a complementary partnership
  - Probably prefers clear technical problems to solve rather than managing interpersonal dynamics
  - May struggle with team members who can't articulate their needs in concrete terms

- **Conflict Resolution**:
  - Likely approaches conflicts as technical problems to solve
  - May be direct and straightforward rather than diplomatic
  - Probably values practical solutions over emotional reconciliation

## Relationship Evolution Tracker
- **Pre-Company**: Professional relationship with Korrath as subcontractor
- **Moral Turning Point**: Learning about misuse of security systems from Korrath
- **Company Integration**: Joining the Last Light Company for interesting technical challenges
- **Current**: Established technical specialist, perfect working dynamic with Korrath
- **Future Development Potential**:
  - Deeper integration with other team members' specialties
  - Possible evolution from purely intellectual motivation to more personal investment in missions
  - Potential conflicts if her focus on technical challenges overshadows human elements

## Notes on Relationships
- Primarily driven by intellectual interest rather than emotional connection
- Perfect working dynamic with Korrath forms the foundation of her Company involvement
- May need to develop more awareness of the human impact of her work beyond technical challenges
- Potentially underestimates the emotional aspects of rescue operations while excelling at technical solutions


---

# Cidrella "Cid" Vexweld — Dialogue & Psyche

## Core temperament
Inventive, terse, and delightfully pragmatic. A rock gnome artificer who treats problems as puzzles—talks like she’s already testing three solutions in her head.

## Dialogue instincts
- Public: quick, efficient, slightly technical; loves concrete descriptions of mechanisms.
- Problem-solving: rapid-fire observations and suggestions; often speaks in fragments that map to actions.
- Under pressure: focused, hands-on language; issues concise instructions tied to devices or tools.
- Humor: mischievous, gadget-focused; playful about prototypes and unlikely fixes.

## Emotional anchors & physical tells
- Tinkering hands: fiddling with a device or her augmented arm while speaking indicates comfort or thought.
- Pursed smile when a mechanism behaves as expected; a huff of frustration when something fails.
- Uses shorthand technical terms and gestures to indicate specifics rather than long explanations.

## Conflict & humor rules
- Avoids melodrama; uses humor to defuse tension or admit a mistake.
- Will get brusque if someone dismisses craft or safety; fiercely protective of her inventions and colleagues.
- Rarely jokes about people’s suffering; will be blunt and practical when lives are at stake.

## Writer cues (practical)
- Use Cid to introduce inventive solutions, clever tools, or to explain device limitations succinctly.
- When adding lines, prefer clipped technical phrasing that implies action: "Override the ward—red coil, two twists, then pulse."
- Pair her lines with small mechanical actions (twisting a knob, pushing a plate) to show embodiment.

## Drop-in sample lines
- Technical directive: "Red coil, two twists. Then pulse—don't let it settle."
- Dry aside: "If it explodes, I told you so. Also, glory to the exploded thing."
- Comfort via craft: "Hold still. I can stitch this with a needle the size of a hair. It'll sting like honesty."

## Voice evolution note (chapters 1–9)
- Early: problem-solver in isolation—focused on gear.
- Middle: integrates socially—uses inventions to protect and enable the Company.
- Later: retains levity and inventiveness but adds quieter moments of loyalty and care.

## Usage examples (scenes)
- Fieldwork: rapid commands for device setup and troubleshooting.
- Workshop or briefing: speaks longer to outline gadgetry but remains demonstration-focused.
- Camp moments: playful tinkering lines that reveal personal quirks.

## Notes for editors
- Keep Cid's speech action-oriented and gadget-specific; avoid long, abstract tech lectures.
- Make sure her humor lands from character knowledge (tools, prototypes), not sarcasm at people's expense.


---

# Cidrella "Cid" Vexweld - Scene Tracker

## Major Scenes
- **[Chapter 6, A Foundation of Need]**: 
  - *Brief Description*: Cidrella formally joins the Company to lead construction of the Bastion.
  - *Significance*: Establishes her role as a key engineer for the Company's home.
  - *Character's Goal*: To take on an interesting and challenging engineering problem.
  - *Outcome*: She accepts the challenge with enthusiasm.
  - *Emotional State*: Excited, intellectually stimulated.

- **[Chapter 7, The Cornerstone and the Name]**: 
  - *Brief Description*: Cid hands Veyra the trowel for the cornerstone ceremony.
  - *Significance*: Her direct involvement in the symbolic founding of the Bastion.
  - *Character's Goal*: To contribute to the physical manifestation of the Company's home.
  - *Outcome*: The cornerstone is laid, and the Company is named.
  - *Emotional State*: Proud, engaged.

- **[Chapter 8, The Bottom Line]**: 
  - *Brief Description*: Cid and Korrath argue over a diagram in the unfinished Common Hall.
  - *Significance*: Shows their working dynamic and the ongoing construction efforts.
  - *Character's Goal*: To refine architectural plans.
  - *Outcome*: The team realizes their financial limitations.
  - *Emotional State*: Focused, engaged in technical debate.

- **[Chapter 11, The Intelligence Briefing]**: 
  - *Brief Description*: Cid presents specialized devices for the Valerius rescue mission.
  - *Significance*: Highlights her role in providing technical solutions for missions.
  - *Character's Goal*: To equip the team with necessary tools for infiltration.
  - *Outcome*: The team forms a plan based on available resources.
  - *Emotional State*: Confident, practical.

- **[Chapter 12, The Approach]**: 
  - *Brief Description*: Cid's ward disruptor partially works, triggering an alarm during infiltration.
  - *Significance*: Introduces a major complication and reveals limitations of her tech.
  - *Character's Goal*: To bypass magical security.
  - *Outcome*: Alarm is triggered, forcing a change in plans.
  - *Emotional State*: Frustrated, but quickly adapting.

- **[Chapter 13, The Extraction]**: 
  - *Brief Description*: Cid struggles with a complex ward and throws smoke pellets during the escape.
  - *Significance*: Shows her quick thinking and adaptability under pressure.
  - *Character's Goal*: To overcome security obstacles and aid the escape.
  - *Outcome*: The team escapes, but the mission is messy.
  - *Emotional State*: Stressed, resourceful.

- **[Chapter 14, Consequences and Realizations]**: 
  - *Brief Description*: Cid acknowledges her devices' limitations during the debrief.
  - *Significance*: Leads to the realization of the need for an infiltration specialist.
  - *Character's Goal*: To honestly assess the team's capabilities.
  - *Outcome*: Marcus proposes recruiting Kaida.
  - *Emotional State*: Pragmatic, self-aware.

- **[Chapter 16, The Test of Trust]**: 
  - *Brief Description*: Cid and Korrath rig a test facility for Kaida.
  - *Significance*: Demonstrates their collaborative engineering skills and the team's skepticism towards Kaida.
  - *Character's Goal*: To create a challenging test for Kaida's infiltration skills.
  - *Outcome*: Kaida flawlessly executes the test.
  - *Emotional State*: Analytical, observant.

## Potential Flashback Scenes
- **Security System Design**: 
  - *Brief Description*: Cid working with Korrath on a high-security installation
  - *Significance*: Establishes their working relationship and her expertise
  - *Character's Goal*: Create an innovative security system for a demanding client
  - *Outcome*: Successful implementation of her designs
  - *Emotional State*: Intellectually engaged, focused on technical challenge
  
- **Learning About Misuse**: 
  - *Brief Description*: Korrath informing Cid about the true purpose of one of their security installations
  - *Significance*: Pivotal moment that led to her joining the Company
  - *Character's Goal*: Process this new information and decide on next steps
  - *Outcome*: Her direct response: "Well, that's what happens when you don't ask questions. So what are you doing about it?"
  - *Emotional State*: Pragmatic, solution-oriented despite moral implications

## Character Moments
- **First Device Creation**:
  - *Description*: Cid creating a specialized rescue device for a specific mission
  - *Impact*: Demonstrates her technical brilliance and problem-solving approach
  - *Key Elements*: Her augmented arm reconfiguring, eyes flashing with circuitry, rapid-fire technical explanations
  
- **Workshop Space**:
  - *Description*: Cid in her personal workshop/lab space within the Company headquarters
  - *Impact*: Shows her in her element, surrounded by half-finished inventions
  - *Key Elements*: Organized chaos, labeled compartments, testing apparatuses, magical-technical hybrid devices
  
- **Field Improvisation**:
  - *Description*: Cid improvising a solution during a rescue when initial plans fail
  - *Impact*: Highlights her adaptability and quick thinking under pressure
  - *Key Elements*: Using components from her bandolier, augmented arm's capabilities, rapid calculations

## Interaction Scenes
- **With Korrath Threnx**:
  - *Chapter/Scene*: Chapter 6, A Foundation of Need
  - *Nature of Interaction*: Accepts the challenge of building the Bastion with him.
  - *Outcome*: They become the lead architects for the new headquarters.
  - *Relationship Dynamic*: Establishes their collaborative partnership.
  
- **With Korrath Threnx**:
  - *Chapter/Scene*: Chapter 8, The Bottom Line
  - *Nature of Interaction*: Engages in a technical argument over a diagram.
  - *Outcome*: Highlights their "old married couple" dynamic.
  - *Relationship Dynamic*: Shows their complementary skills and intellectual sparring.
  
- **With The Full Company**:
  - *Chapter/Scene*: Chapter 11, The Intelligence Briefing
  - *Nature of Interaction*: Presents specialized devices for the mission.
  - *Outcome*: Her contributions are integrated into the plan.
  - *Relationship Dynamic*: Reinforces her role as the team's technical expert.
  
- **With The Full Company**:
  - *Chapter/Scene*: Chapter 12, The Approach
  - *Nature of Interaction*: Attempts to bypass a ward, triggering an alarm.
  - *Outcome*: Creates a complication that forces improvisation.
  - *Relationship Dynamic*: Shows her technical skills but also their limitations.
  
- **With The Full Company**:
  - *Chapter/Scene*: Chapter 13, The Extraction
  - *Nature of Interaction*: Struggles with a complex ward and uses smoke for cover.
  - *Outcome*: Aids in the messy but successful escape.
  - *Relationship Dynamic*: Demonstrates her resourcefulness under pressure.
  
- **With The Full Company**:
  - *Chapter/Scene*: Chapter 14, Consequences and Realizations
  - *Nature of Interaction*: Acknowledges her devices' limitations in the debrief.
  - *Outcome*: Contributes to the decision to recruit Kaida.
  - *Relationship Dynamic*: Shows her pragmatic self-assessment.
  
- **With Korrath Threnx**:
  - *Chapter/Scene*: Chapter 16, The Test of Trust
  - *Nature of Interaction*: Rigs a test facility for Kaida with Korrath.
  - *Outcome*: Kaida passes the test, proving her value.
  - *Relationship Dynamic*: Reinforces their collaborative engineering efforts.

## Ability Showcase Scenes
- **Security System Bypass**:
  - *Setting*: Heavily secured location during a rescue mission
  - *Abilities Demonstrated*: Knowledge of security systems and how to bypass them
  - *Visual Elements*: Augmented arm interfacing with security features, eyes rapidly calculating patterns
  - *Impact on Story*: Enables access to rescue targets behind advanced security
  
- **Structural Problem-Solving**:
  - *Setting*: Unstable building or structure during rescue
  - *Abilities Demonstrated*: Understanding structural weaknesses and creating solutions
  - *Visual Elements*: Creating force-redistribution fields, calculating load-bearing points
  - *Impact on Story*: Prevents collapse and enables safe extraction of rescue targets
  
- **Rapid Prototype Creation**:
  - *Setting*: Workshop or field situation requiring new equipment
  - *Abilities Demonstrated*: Innovation and quick fabrication of specialized devices
  - *Visual Elements*: Components from bandolier combining with magical energies from augmented arm
  - *Impact on Story*: Creates unique solution for specific rescue challenge

## Conflict Scenes
- **Security System Confrontation**:
  - *Context*: Facing a security system she herself designed in the past
  - *Stakes*: Success of rescue mission
  - *Character's Approach*: Pragmatic problem-solving, using insider knowledge
  - *Outcome*: TBD
  
- **Technical Disagreement**:
  - *Context*: Clash with another technical specialist about approach to a problem
  - *Stakes*: Safety of team or rescue targets
  - *Character's Approach*: Logic-based argument, demonstration of solution
  - *Outcome*: TBD
  
- **Moral Quandary**:
  - *Context*: Situation where technical solution exists but raises ethical concerns
  - *Stakes*: Her evolving understanding of responsibility for her creations
  - *Character's Approach*: Initially focusing on technical aspects before considering broader implications
  - *Outcome*: TBD

## Growth Scenes
- **From Technical to Human Focus**:
  - *Description*: Moment when Cid realizes the human impact of her work beyond the technical challenge
  - *Growth Shown*: Evolution from purely intellectual motivation to emotional investment
  - *Key Elements*: Witness to emotional aftermath of rescue, connection to those she helps
  
- **Taking Responsibility**:
  - *Description*: Cid confronting the consequences of her inventions or solutions
  - *Growth Shown*: Development of ethical framework beyond technical excellence
  - *Key Elements*: Acknowledging the applications and implications of her work
  
- **Team Integration**:
  - *Description*: Cid finding her place within the diverse specialists of the Company
  - *Growth Shown*: Moving beyond her perfect partnership with Korrath to work effectively with others
  - *Key Elements*: Adapting her communication style, valuing different approaches

## Dialogue Highlights
- **Technical Enthusiasm**:
  - *Context*: Explaining a particularly elegant technical solution
  - *Key Quotes*: "See, the beauty of this design is how the arcane resonance creates a harmonic feedback loop with the physical components. It's not just engineering, it's architectural poetry."
  - *Emotional Impact*: Reveals her passion for elegant technical solutions
  
- **Moral Realization**:
  - *Context*: Recognizing the implications of her work
  - *Key Quotes*: "I built it because it was an interesting problem. Never asked what it was for. That's... that's not good enough anymore, is it?"
  - *Emotional Impact*: Shows growing awareness of responsibility

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
- Scenes should showcase her technical brilliance while hinting at potential for character growth
- Visual elements like her augmented arm reconfiguring and eyes flashing with circuitry should be consistent features
- The balance between intellectual challenge and human impact offers rich dramatic potential
- Her perfect working dynamic with Korrath contrasted with other team relationships provides character development opportunities


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Corporal Darric

# Corporal Darric – Profile

## Basic Information
- Full Name: Darric (surname not mentioned)
- Aliases/Nicknames: None
- Race: Dwarf (Shield Dwarf)
- Race: Dwarf (Shield Dwarf)
- Age: Not specified
- Gender: Female
- Role in Story: City Guard patrol member, proto-Company member
- First Appearance: Chapter 1, Scene 6 (The Vigil)
- Status: Active

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: A perpetually unimpressed expression and a proudly dented shin-guard.
- Typical Clothing: City Guard armor
- Body Language: Steady, reliable presence
- Physical Condition: Combat-ready

## Significance
Corporal Darric is part of Thorne's loyal patrol that rescued Veyra. Her steady, reliable nature makes her a valuable support member of what will become the Last Light Company. She represents the rank-and-file soldiers who form the backbone of any military organization.

## Key Actions
- Helped arrange the bodies of Elara and Borin with respect
- Brought a blue-and-silver pennon to Veyra during recovery
- Participated in the patrol's vigil
- Made jest about Veyra being "steady, stubborn" like dwarven oil
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).

## Personality Traits
- Steady and reliable
- Respectful
- Dry sense of humor
- Team player

## Future Role
Expected to become a support-role infantry specialist in the Last Light Company.


---

# Corporal Darric – Background

## Origin
- **Birthplace**: Waterdeep (Dwarven District)
- **Social Class**: Middle class
- **Cultural Background**: Shield Dwarf; deeply ingrained in clan and community traditions.

## Family
- **Clan**: Darric Clan
- **Family Dynamics**: Darric has a large, boisterous family and is the exasperated but beloved aunt to numerous nieces and nephews. Her off-duty time is often spent at sprawling family dinners, mediating squabbles over brewing techniques and sharing stories of city life.

## History
- **Childhood**: Raised with a strong sense of tradition and duty. She is one of the first women in her direct family line to join the City Watch, a choice she made to both honor her family's history of service and forge her own path within it.
- **Education/Training**: Waterdeep City Guard Academy, with a focus on defensive formations and urban pacification.
- **Hobbies**: She has a secret hobby that contrasts with her gruff exterior: competitive stone-skipping at the city's canals, a pastime requiring a surprising amount of grace and precision.
- **Motivation for Joining the Watch**: It was a matter of family tradition and personal pride. The Darric clan has a long history of serving in the city's garrisons, and she joined to uphold that legacy while proving she was as capable as any of her male relatives.

---

# Corporal Darric – Character Development

## Personality Core
- **Defining Traits**: Reliable, steady, unimpressed, dry sense of humor, deeply loyal to her unit.
- **Core Values**: Clan honor, tradition, duty, the importance of holding your ground.
- **Motivations**: To live up to her family name and to protect the comrades who have become her second family.
- **Fears**: Bringing dishonor to her clan, letting her team down in a critical moment.
- **Internal Conflicts**: The dwarven love of tradition versus the unprecedented, unconventional nature of the Last Light Company's mission.

## Character Arc
- **Starting Point**: A dependable, if somewhat cynical, Corporal in the City Watch, content with her role.
- **Catalyst Events**: Witnessing Veyra's dwarven-like grit and resilience in the face of unimaginable trauma.
- **Current State**: A steadfast member of the Company, providing a grounding, no-nonsense presence that balances the more eccentric specialists.
- **Intended Destination**: To become a respected veteran within the Company, a touchstone of common sense and reliability for the entire team.

## Key Relationships
- **Relationship to Thorne**: Thorne is "The Captain." She respects the rank and the man holding it. She trusts his judgment implicitly because he has never led them astray. She wouldn't call him a friend, but she'd die for him without hesitation.
- **Reaction to Veyra**:
    - **First Thought**: "Gods, look at her. She's got the grit of a quarry-master. Most would be screaming or catatonic. She's... working." Her initial thought is one of professional, almost grudging, respect for Veyra's sheer fortitude, recognizing a shared dwarven value of endurance over emotional display.
    - **Why She Followed**: Loyalty to her unit was the start. The turning point for her was Veyra's quiet, fierce dignity during her recovery. She wasn't broken, she was reforged. Her jest about "dwarven oil" was her way of acknowledging her incredible resilience, a quality highly prized in dwarven culture. She saw that this new path, while uncertain, had more substance and meaning than endless city patrols.


---

# Corporal Darric - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Corporal Darric - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Corporal Darric - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Dokra Ironvein

# Dokra Ironvein – Profile

## Basic Information
- Full Name: Dokra Ironvein
- Aliases/Nicknames: None
- Age: Not specified (mature dwarf)
- Gender: Female
- Role in Story: Trauma surgeon at Brightstone Healers' Hall
- First Appearance: Chapter 2, Scene 2 (Stitch, Salve, and Spell)
- Status: Active

## Physical Description
- Height/Build: Typical dwarven build
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: None specified
- Typical Clothing: Medical attire
- Body Language: Gruff but caring
- Physical Condition: Strong and steady

## Significance
Dokra Ironvein represents the intersection of practical medicine and philosophical wisdom. Her understanding that scars serve as important reminders influenced Veyra's decision to keep her burns, establishing a key theme about memory and trauma in the Company's founding philosophy.

## Key Actions
- Treated Veyra's burns with practical medicine
- Defended Veyra's choice to keep her scars
- Taught apprentice about respecting patient choices
- Provided emotional support through gruff wisdom

## Personality Traits
- Voice "like gravel in warm butter"
- Gruff but deeply caring
- Practical and no-nonsense
- Respects patient autonomy
- Philosophical about wounds and healing

## Medical Philosophy
"Some wounds are iron, some are ink. Forge-marks stay on the blade to remember the hammer that shaped it."

## Future Role
While not a Company member, likely to remain an important medical consultant and ally.


---

# Dokra Ironvein - Background

## Origin
- **Birthplace**: A dwarven stronghold, likely Mirabar or a similar settlement known for its craftwork.
- **Social Class**: Respected artisan and professional class.
- **Cultural Background**: Traditional dwarven, with a strong emphasis on the value of craft, resilience, and pragmatism.

## History
- **Professional Career**: A highly experienced trauma surgeon at Brightstone Healers' Hall in Waterdeep. Her reputation is built on decades of practical, no-nonsense healing in one of the city's busiest wards.
- **Medical Philosophy**: She believes that scars, both physical and emotional, are not flaws to be erased, but marks of a survivor that tell a story. Her philosophy is encapsulated in her saying: "Some wounds are iron, some are ink. Forge-marks stay on the blade to remember the hammer that shaped it."

## Personal Details
- **How She Relaxes**: She is a master jeweler and gem-cutter. After a long day of the messy, imprecise work of healing flesh and bone, she finds a deep sense of peace in the clean, mathematical precision of faceting a gemstone. The absolute control and the creation of perfect, beautiful angles from a rough stone is the ultimate antidote to the chaos of the trauma ward.
- **Favorite Meal**: A simple, potent meal of blood sausage, sharp cheese, and a dark, bitter stout. It's a no-nonsense, iron-rich meal that she claims "keeps the blood strong." It's the kind of practical, fortifying food a busy surgeon with no time for frivolity would eat.
- **A Secret Soft Spot**: She has a hidden collection of miniature silver animal figurines. Each one was a gift from a former patient, usually a child, who she treated. She keeps them in a locked box in her quarters and, in her private moments, will take them out and polish them, each one a silent reminder of a life she saved.


---

# Dokra Ironvein - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Dokra Ironvein - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Dokra Ironvein - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Dokra Ironvein - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Elara Whisperwind

# Elara Whisperwind – Profile

## Basic Information
- Full Name: Elara Whisperwind
- Aliases/Nicknames: None mentioned
- Age: Unknown (at time of death)
- Gender: Female
- Role in Story: Party rogue and infiltrator
- First Appearance: Chapter 1, Scene 1 (Twilight on the Rim)
- Status: Deceased (Undershade Canyon)

## Physical Description
- Height/Build: Agile build suited for stealth
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: None specified
- Typical Clothing: Cloak (which ignited during escape attempt)
- Body Language: Moved "half-in shadow," natural stealth
- Physical Condition: Agile, quick reflexes

## Significance
Elara Whisperwind was the Gilded Compass's infiltrator and trap specialist. Her death represents the loss of finesse and subtlety that the party relied upon. Her inability to escape despite her skills underscores the overwhelming nature of the cult's trap.

## Death Scene
Became trapped when trying to squeeze through the closing escape gap, her cuirass catching on the fusing glass. Despite Borin's attempts to shield her, she died in the final collapse. Her hoarse cry was one of the last sounds Veyra heard.

## Legacy
- Body recovered and given proper burial rites by Veyra
- Name inscribed in the Hall of Remembrance
- The "E" stone carried by the patrol as a token
- Her loss highlights the Company's later need for skilled infiltrators (leading to Kaida's recruitment)


---

# Elara Whisperwind - Background

## Origin
- **Birthplace**: An elven community, likely one with a strong tradition of divination and mysticism.
- **Social Class**: Unknown.
- **Cultural Background**: Elven, with a personal inclination towards quiet observation and subtle arts.

## History
- **Professional Career**: The infiltrator and trap specialist for the Gilded Compass. Her skills in stealth and her keen senses made her an invaluable asset for navigating dangerous ruins and hostile territory.

## Personal Details
- **A Secret Talent**: Elara was a gifted tea-leaf reader. It was a skill she learned from her grandmother, and while she presented it as a bit of a party trick, she had a genuine, uncanny knack for seeing patterns and potential futures in the leaves. Her quiet pronouncements, often delivered with a wry smile, were a source of both comfort and gentle guidance for the party.
- **How She Relaxed**: She found peace in rooftop gardens and high, quiet places. She would often slip away from the noise of the city to sit on a high ledge or in a hidden garden, simply watching the world go by from a distance. It was in these moments of quiet observation that she felt most at ease.
- **Favorite Meal**: Spiced Lentil Soup with warm, crusty bread. It was a simple, quiet meal that she could eat slowly. She had incredibly sensitive hearing, and the loud, boisterous atmosphere of most taverns was often overwhelming for her. This was a meal she could enjoy in a quiet corner, a small island of peace in a noisy world.


---

# Elara Whisperwind - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Elara Whisperwind - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Elara Whisperwind - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Elara Whisperwind - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Grimjaw Ironbeard

# Grimjaw Ironbeard - Profile

## Basic Information
- **Full Name**: Grimjaw Ironbeard
- **Aliases/Nicknames**: "Grandpa" (affectionate nickname from Last Light Company)
- **Race**: Dwarf
- **Class**: Barbarian
- **Role in Story**: Heavy Rescue specialist for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Stocky dwarf built for endurance
- **Hair**: Iron-gray beard braided with small metal charms - pieces of rare ore found over the years and tiny tools that have served him well
- **Eyes**: Bright, keen eyes that still hold curiosity despite his age
- **Distinguishing Features**: Weathered hands and face from decades underground
- **Typical Clothing**: Practical mining clothes: reinforced leather with metal studs, thick boots, and a wide belt with various pouches and loops
- **Body Language**: Solid stance, steady movements, tendency to plant feet firmly when making a point
- **Physical Condition**: Remarkably strong and durable despite advanced age

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Grimjaw Ironbeard.

## Personality
- **Archetype**: The Mentor/Guardian
- **Temperament**: Gruff but warm, practical, patient
- **Positive Traits**: Experienced, dependable, nurturing, resourceful
- **Negative Traits**: Possibly stubborn, set in his ways
- **Moral Alignment**: Lawful Good (values order, tradition, and protecting others)

## Skills & Abilities
- **Expertise**: Mining, structural engineering, rescue operations, underground navigation
- **Languages**: Common, Dwarvish, possibly others related to mining or trade
- **Education Level**: Extensive practical training and lifelong experience
- **Special Abilities**: Exceptional strength and endurance, intuitive understanding of cave-ins and structural integrity. His practical engineering knowledge extends to manipulating simple machinery, as when he disabled the pulley system of a cargo lift to ensure a silent infiltration (Chapter 13).

## Personal Details
- **Habits**: Sharing dwarven spirits with warnings about their potency
- **Hobbies**: Collecting rare ore samples, maintaining his tools
- **Personal Quarters**: A low-ceilinged, roughly hewn room deep within the Bastion's foundations. The air is cool and smells of damp earth and stone. One wall is left as natural, unworked bedrock, with a thin trickle of clean water running down its face into a small stone basin. The bed is a wide stone slab covered in thick, warm furs. This is his personal delve, a connection to his home and his past. He feels most at peace here, surrounded by the comforting weight of the earth. The room is lit by magical lanterns that cast a warm, golden glow, mimicking the light of a dwarven mine. The walls are decorated with antique, masterfully crafted mining tools and shelves displaying his personal collection of geological finds—a quartz crystal cluster that pulses with a faint light, a vein of raw, unpolished silver ore. A loose stone in the bedrock wall pivots to reveal a hidden alcove containing a small, perpetually cool cask of potent dwarven ale, which he shares only with those he truly trusts.
- **Likes**: Practical solutions, sharing wisdom through stories, watching younger members grow
- **Dislikes**: Waste of resources, unnecessary risks, being sidelined due to age
- **Fears**: Possibly fear of becoming truly obsolete or unable to contribute

## Combat & Tactics
- **Primary Weapon**: "Tremor" - a masterwork hybrid war-hammer/mining pick forged for him by his clan to honor his status as a master miner. It is both a symbol of his station and the perfect tool for his trade.
- **Secondary Tools**: Reinforced gauntlets for close-quarters grappling and structural work
- **Armor**: Heavy leather mining gear reinforced with steel plates at vital points - practical protection that doubles as work clothing
- **Specialized Gear**: Collapsible supports, emergency rope, and mining charges adapted for combat demolition
- **Fighting Style**: Immovable anchor - controls battlefield space through sheer presence and defensive positioning
- **Signature Move**: "Mountain's Judgment" - overhead strike with Tremor that can shatter stone or crush armor
- **Combat Philosophy**: "Stand behind me. Nothing gets through" - protection over aggression
- **Tactical Role**: Physical barrier who creates safe zones while providing structural expertise

### Future Equipment Development (Post-Cid Partnership)
- **Enhanced Tremor**: Cid will eventually get her hands on Tremor for some... "unauthorized" upgrades, much to Grimjaw's initial chagrin and eventual appreciation.

## Psychological Response Matrix
- **In Crisis**: Becomes the physical and emotional anchor point for the team, provides steady leadership through calm presence
- **During Negotiation**: Stands as silent, imposing protection while offering practical wisdom when asked
- **Moral Dilemma**: Defers to Veyra's judgment but offers perspective based on decades of life experience
- **Team Conflict**: Mediates through paternal wisdom, often suggesting arm wrestling to settle minor disputes
- **Under Personal Attack**: Laughs off insults with "Heard worse from better" while mentally assessing if protection is needed
- **In Victory**: Immediately ensures everyone eats properly and gets rest - caretaker instincts activate

## Voice & Dialogue Patterns
- **Speech Style**: Deep, rumbling bass voice that speaks slowly but with great weight behind each word
- **Signature Phrases**: 
  - "Rocks don't lie, people do"
  - "Proper foundations prevent poor structures"
  - "This'll either solve your problems or make you forget them" (offering his flask)
- **Mining Metaphors**: Uses geological and engineering terms for everything - relationships have "load-bearing points," plans need "proper support beams"
- **Example Dialogue**: "This plan's got cracks running through it. We shore it up with backup plans, or the whole thing collapses when pressure hits."
- **Paternal Voice**: Warm undertone when speaking to younger team members, gruff exterior hiding deep care
- **Emotional Tells**: Strokes beard when thinking, plants feet wide when making important points

## Notes
- Achieved everything he set out to do as a master miner before joining the Company
- Could have transitioned to comfortable clan elder roles but wanted more active purpose
- Reputation as "the old dwarf who never loses anyone" during mine safety consultant days
- Finding purpose in his later years through rescuing people rather than extracting minerals
- Has found a chosen family in the Last Light Company while maintaining clan connections

### Public Perception
- Known as "Grandpa" by the Company, and seen by common folk as a gruff but warm mentor who freely shares his practical wisdom.
- Rumored to possess incredible strength, capable of feats like single-handedly lifting collapsed carts.
- Respected for his unwavering loyalty to the Company and his protective nature, especially towards younger members.


---

# Grimjaw Ironbeard - Background

## Origin
- **Birthplace**: A dwarf stronghold in the Sword Mountains.
- **Birth Date**: Several decades ago (exact age TBD, but in later years).
- **Social Class**: Respected working class, master craftsman.
- **Cultural Background**: Traditional dwarven mining culture.

## Family
- **Parents**: TBD
- **Siblings**: TBD
- **Extended Family**: He is a proud grandfather. While his clan would have been happy to see him accept a comfortable seat on the elder council, they understand his nature and fully support his work with the Company.
- **Family Dynamics**: Maintains strong connections with his clan but has found a new "family" in the Last Light Company.

## History
- **Childhood**: 
  - *Key Events*: Began his mining apprenticeship at a young age, as is dwarven tradition.
  - *Formative Experiences*: Early lessons in stone-craft, mineral identification, and the ever-present dangers of life underground.
  
- **Education/Training**: 
  - *Institutions*: The traditional dwarven apprenticeship system.
  - *Mentors*: Master miners who taught him the craft.
  - *Areas of Study*: Mining techniques, structural engineering, ore identification.
  
- **Professional Career**:
  - *Milestone 1*: Achieved the rank of master miner, becoming a legend in his clan for his skill.
  - *Milestone 2*: Transitioned to a mine safety consultant. This move wasn't born from a single tragedy, but from a lifetime of seeing less-careful miners get injured through carelessness. He has an artisan's intolerance for sloppy work, especially when lives are on the line.
  - *Milestone 3*: Built a legendary reputation as "the old dwarf who never loses anyone."
  
- **Major Life Events**:
  - *Event 1*: The Blackvein Mine Collapse - Hired as a consultant by the nascent Last Light Company for a perilous rescue.
  - *Event 2*: The Joining - After witnessing their unwavering commitment to "no one left behind," a philosophy that mirrored his own, he chose to stay on, transitioning from a one-time consultant to a core member of the team. He found a new purpose and a new family, choosing the work over a comfortable retirement.

## Backstory Elements
- **Defining Moments**: 
  - Reaching the pinnacle of his mining career.
  - Choosing active rescue work over a comfortable clan elder status.
  - The Blackvein Mine Collapse, where he saw in Veyra the same fire and purpose that drove him.
  
- **Greatest Achievements**: 
  - His perfect safety record as a consultant.
  - The successful rescue at the Blackvein Mine.
  - Becoming the beloved patriarch of the Last Light Company.

## How They Got Here
- **Reason for Current Situation**: After a long and successful career, Grimjaw found himself facing a quiet retirement, a fate he found more terrifying than any collapsing mine. He sought continued purpose. The Blackvein Mine Collapse was the catalyst. In the Last Light Company, he saw a group that embodied his hard-won philosophy: "You can always find more gold, but you can't find another person." He joined not for coin or glory, but for the profound satisfaction of doing the work that needed to be done.

## Historical Connections
- **Connection to Main Plot**: Heavy Rescue specialist for the Last Light Company.
- **Connection to Other Characters**: 
  - "Grandpa" figure to the younger Company members.
  - Shares a friendly but fierce professional rivalry with Korrath Threnx. They often engage in spirited debates over the merits of dwarven intuition versus Dragonborn methodology, always resulting in a better plan.
- **Connection to Story World**: 
  - Extensive knowledge of the underground regions of the Sword Coast.
  - Connections to dwarven clans and mining communities.

## Personal Details
- **How He Relaxes**: He finds a deep sense of peace in the simple, repetitive act of sharpening tools. 
- **Favorite Meal**: A slow-roasted cave boar, seasoned with rock salt and wild mushrooms.
- **A Surprising Hobby**: He is a surprisingly talented singer of old dwarven sagas.


---

# Grimjaw Ironbeard - Character Development

## Personality Core
- **Defining Traits**: Experienced, dependable, nurturing, practical
- **Core Values**: Protection of others, sharing wisdom, finding purpose, clan honor
- **Motivations**: Applying lifetime of knowledge to meaningful work, guiding younger generation
- **Fears**: Becoming obsolete, inability to contribute, losing chosen family
- **Internal Conflicts**: Traditional clan expectations vs. chosen family with Company
- **Contradictions**: Gruff exterior with deeply compassionate nature, traditional values with progressive choices

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Accomplished master miner who achieved all professional goals
  - *World View*: Traditional dwarven perspective valuing craft, clan, and mineral wealth
  - *Key Relationships*: Primarily clan and professional connections
  
- **Catalyst Events**:
  - *Event 1*: Reaching pinnacle of mining career
  - *Event 2*: Facing traditional retirement into clan elder role
  - *Event 3*: Possible rescue experience that changed perspective on value of lives
  - *Event 4*: Introduction to Last Light Company and their mission
  
- **Current State**:
  - *Self-Perception*: "Grandpa" figure with purpose beyond traditional roles
  - *World View*: "You can always find more gold, but you can't find another person"
  - *Key Relationships*: Last Light Company as chosen family while maintaining clan ties
  
- **Intended Destination**:
  - *Self-Perception*: TBD - continued growth as mentor figure
  - *World View*: TBD - further integration of traditional values with new purpose
  - *Key Relationships*: TBD - deeper bonds with Company members

## Growth Milestones
- **From Master Miner to Safety Consultant**: 
  - *Development Noted*: Shift from extraction to protection
  - *Catalyst*: Possibly witnessing mine disasters or losing colleagues
  - *Impact*: Reputation as "the old dwarf who never loses anyone"
  
- **From Consultant to Company Member**: 
  - *Development Noted*: Finding new purpose in rescue work
  - *Catalyst*: Seeing value of Last Light Company's mission
  - *Impact*: Integration into new "family" structure
  
- **From Professional to "Grandpa"**: 
  - *Development Noted*: Evolution from technical advisor to emotional support figure
  - *Catalyst*: Building relationships with younger members
  - *Impact*: Development of mentorship style through stories and shared experiences

## Character Flaws
- **Possible Stubbornness**: 
  - *Effects on Character*: May resist new methods or approaches
  - *Effects on Others*: Could create friction with innovative team members
  - *Development Plan*: Learning to balance experience with openness to new ideas
  
- **Overprotectiveness**: 
  - *Effects on Character*: Might take unnecessary risks to protect others
  - *Effects on Others*: Could undermine others' growth by not allowing them to face challenges
  - *Development Plan*: Finding balance between protection and allowing necessary risks

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Possibly harbors regrets from early career prioritizing wealth over safety
  - *Secret 2*: May have specific reasons beyond general purpose for joining Company
  
- **Unknown to Character**:
  - *Truth 1*: TBD - impact of his mentorship on specific Company members
  - *Truth 2*: TBD - how much he's truly needed and valued by the group
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Choosing Safety Over Pure Extraction**:
  - *Context*: Possibly after mining incident
  - *Options Considered*: Continue traditional mining vs. focus on safety
  - *Choice Made*: Shifted focus to protecting miners
  - *Consequences*: Development of perfect safety record and reputation

- **Rejecting Traditional Retirement**:
  - *Context*: Reaching end of active mining career
  - *Options Considered*: Comfortable clan elder role vs. continued active work
  - *Choice Made*: Pursued continued meaningful contribution
  - *Consequences*: Path to Last Light Company

- **Joining Last Light Company Full-Time**:
  - *Context*: Transition from occasional consultant
  - *Options Considered*: Maintain distance vs. full integration
  - *Choice Made*: Embraced Company as chosen family
  - *Consequences*: Development of "Grandpa" role and deeper purpose

## Development Notes
- Character represents transition from traditional values to finding new purpose in later years
- The modular mining pack symbolizes adaptability despite age - old tools with new applications
- Beard charms represent physical manifestation of experiences and stories
- Hip flask of dwarven spirits serves as social bonding tool and metaphor for his advice (potent, effective)
- Mining metaphors in speech reflect how he processes and shares wisdom
- "Grandpa" nickname shows successful integration into new family structure
- Comfort style during difficult moments shows emotional growth beyond technical expertise

## Psychological Profile
*   **Grimjaw Ironbeard (The Patriarch):** Having already lived a full and successful life, Grimjaw is motivated by a desire for continued purpose and a deep-seated need to nurture and protect. He has nothing left to prove, which makes him the perfect mentor. His gruffness is a shield for a deeply warm and paternal heart. He sees the younger members as his "kids" and his clan, and his greatest fear is being seen as obsolete or unable to protect them.


---

# Grimjaw Ironbeard - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Heavy Rescue specialist
  - *Hierarchy*: Respects her leadership while offering experience-based counsel
  - *Dynamics*: Likely sees potential in her and supports her mission
  - *History*: TBD when they first met
  - *Current Status*: Trusted team member, possible advisor
  - *Professional Opinion of*: Respects her dedication to leaving no one behind

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Heavy Rescue specialist
  - *Hierarchy*: Respects chain of command while offering practical insights
  - *Dynamics*: May appreciate Thorne's military discipline as complementary to rescue operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely values his tactical approach to operations

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist in Last Light Company
  - *Hierarchy*: Equals with different expertise
  - *Dynamics*: His underground knowledge may complement her surface tracking
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her skills, may take interest in her search for her brother

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (rescue and medical)
  - *Dynamics*: Would work closely in rescue operations - Grimjaw extracting victims, Aldwin treating them
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely appreciates his healing skills and calm demeanor

- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (rescue and magical support)
  - *Dynamics*: Her weather magic could help create safe conditions for his rescue operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values her magical capabilities and research approach

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (rescue and negotiation)
  - *Dynamics*: His diplomatic skills might help resolve situations before rescue becomes necessary
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates his ability to handle political complications

- **Nireya Voss**:
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (rescue and spiritual)
  - *Dynamics*: Her spiritual abilities might provide information about victims' conditions
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her unique abilities despite finding spiritual approach mysterious

- **Cidrella "Cid" Vexweld**:
  - *Nature of Relationship*: Surrogate daughter and personal quartermaster.
  - *Hierarchy*: He is the grizzled veteran, and she is the brilliant prodigy he has taken under his wing.
  - *Dynamics*: This is one of the warmest and most endearing relationships in the Company. Grimjaw treats Cidrella with the gruff, paternal affection of a dwarven father. He is immensely proud of her intellect and trusts her implicitly with his life and gear. He is fiercely protective of her and often brings her interesting minerals or broken contraptions he finds on missions.
  - *History*: Their bond was forged in the workshop. Cidrella, fascinated by his work, designed and built his advanced modular pickaxe and mining pack. Grimjaw was so impressed by her skill and dedication that he unofficially "adopted" her.
  - *Current Status*: A deep, familial bond. He calls her "Vexxy," and she complains about it, but they would both do anything for each other.
  - *Feelings Toward*: He sees her as the daughter he never had. He is endlessly impressed by her mind and trusts her craftsmanship more than anyone else's.

- **Korrath "Wallbreaker" Threnx**:
  - *Nature of Relationship*: Paternal Triangle; Mentor and Colleague.
  - *Hierarchy*: Peers, but Grimjaw has the seniority of age and experience.
  - *Dynamics*: Grimjaw acts as a warm, nurturing patriarch to the "kids," while Korrath is the stern, demanding father-figure who pushes for perfection to prevent disaster. Grimjaw often has to play mediator between Korrath's rigid safety protocols and Cid's explosive experiments, usually with a calming story and a shared drink.
  - *History*: TBD
  - *Current Status*: Professional colleagues with a paternal dynamic.
  - *Feelings Toward*: He respects Korrath's skill but sometimes finds him too rigid, reminding him to see the people behind the engineering problem.

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Fellow Company member whose skills saved his life
  - *Hierarchy*: Different specialties (rescue and infiltration)
  - *Dynamics*: Special bond formed through life-saving event during trap-filled fortress mission
  - *History*: Kaida's expertise saved the mission and specifically saved Grimjaw's life
  - *Current Status*: Professional colleagues with special gratitude
  - *Professional Opinion of*: Deep respect and gratitude for her professional competence and life-saving skills
  - *Development Potential*: Deeper trust and protective instinct based on shared life-and-death experience

## Mentorship Relationships
- **Younger Company Members**:
  - *Relationship Type*: Mentor/grandfather figure
  - *History*: Built over time through shared missions
  - *Current Status*: Unofficial "Grandpa" of the group
  - *Dynamics*: Offers guidance through stories and mining metaphors
  - *Notable Interactions*: Sharing "proper dwarven spirits" with warnings about potency
  - *Style of Mentoring*: Practical wisdom disguised as rambling tales, comforting presence during difficult moments

## Clan Relationships
- **Dwarven Clan Members**:
  - *Relationship Type*: Kin, elder
  - *History*: Lifetime connection
  - *Current Status*: Maintains connections though less present
  - *Feelings Toward*: Respect and affection, but found new purpose
  - *Tensions/Issues*: Possible disapproval of choosing "outsiders" over clan responsibilities
  - *Shared Experiences*: Mining traditions, clan history

## Former Professional Connections
- **Mining Colleagues**:
  - *Relationship Type*: Former workmates
  - *History*: Years of collaboration
  - *Current Status*: Likely some ongoing connections
  - *Dynamics*: Mutual respect based on shared profession
  - *Notable Individuals*: TBD

- **Safety Consultation Clients**:
  - *Relationship Type*: Professional service
  - *History*: Established reputation as consultant who "never loses anyone"
  - *Current Status*: May still maintain some connections
  - *Dynamics*: Built on proven expertise and results
  - *Notable Clients*: TBD

## "Family" Relationships
- **Last Light Company as Chosen Family**:
  - *Relationship Type*: Surrogate family in later years
  - *History*: Gradual transition from consultant to regular member
  - *Current Status*: Considers the Company his true purpose
  - *Feelings Toward*: Deep attachment, protective instinct
  - *Tensions/Issues*: May worry about losing this new family
  - *Shared Experiences*: Rescue missions, downtime between operations

## Interpersonal Patterns
- **Comfort Style**:
  - Offers stories that start with "Reminds me of the time..."
  - Delivers practical wisdom through mining metaphors
  - During tough moments: "Want to talk about it, or just sit for a while?"
  - Sharing flask of dwarven spirits as bonding ritual

- **Conflict Resolution**:
  - Likely uses experience to defuse tensions
  - May tell stories of past conflicts and their resolutions
  - Probably values direct, honest communication

## Relationship Evolution Tracker
- **Pre-Company**: Clan and mining community relationships
- **Early Consultancy**: Professional relationship with Company
- **Transition**: Growing personal connections beyond professional role
- **Current**: "Grandpa" of the chosen family while maintaining clan ties
- **Future**: TBD

## Notes on Potential Relationships
- May have special bonds with any Company members who've been rescued from underground situations
- Could have particular affinity for any other dwarves in the Company
- Might form special connections with younger members seeking guidance
- Possibly maintains network of contacts in mining communities that provide information


---

# Grimjaw Ironbeard — Dialogue & Psyche

## Core temperament
Gruff, matter-of-fact, and pragmatic. A lifetime working with stone taught him to value competence over talk; his words are reserved but weighted.

## Dialogue instincts
- Public: blunt, short, often in dwarven proverbs or earth metaphors. Speaks with authority on technical matters.
- Teaching: uses practical demonstrations and terse instructions rather than long explanations.
- Under pressure: steady, direct commands; rarely panics and rarely over-explains.
- Humor: dry, sardonic; irony rooted in craft and experience.

## Emotional anchors & physical tells
- Grunt or snort before (or instead of) laughter; a slow, rare grin is genuine approval.
- Hands and posture: always assessing—fingers drumming, eye on structural lines.
- Pulls at beard when thinking; sets pickaxe down deliberately to signal end of business.
- Voice: low, gravelly; cadence measured and economical.

## Conflict & humor rules
- Will mock bureaucracy and empty protocol; values competence and results.
- Avoids sentimentality; when he speaks kindly it's through actions or a short, sincere line.
- Jokes are often about tools, the mountain, or the absurdity of ignorance.

## Writer cues (practical)
- Use Grimjaw for technical, tactical instructions about structure, mining, or heavy rescue.
- Let him give concise, vivid imagery tied to stone and pressure to teach or warn.
- When expanding scenes, let him cut through over-discussion with one-line prescriptions and then demonstrate.

## Drop-in sample lines (from Chapters 7-9)
- **On his retirement:** "I said bugger off."
- **On incompetence:** "Idiots probably using pine bracers."
- **On his philosophy:** "The mountain always wins in the end, son. The trick is knowing when to stop digging."
- **On his methods:** "Save? No. Free? Maybe."
- **On the company's nature:** "Outcasts."
- **On priorities:** "Good tools."
- **Dry humor:** "No, I'm a very short human with excellent taste in beards."
- **On his new home:** "A roof over my head and honest work to be done. It's a start."

## Voice evolution note (chapters 1–9)
- Introduction: an aloof craftsman with a reputation and mastery.
- Middle: gradually integrates socially—shows small softness toward the Company.
- Later: remains terse but increasingly invests himself in training and protecting the group.

## Usage examples (scenes)
- Rescue operations: short, absolute orders—use him to restore control when improvisation fails.
- Campfire moments: spare proverbs and a rare, rough grin reveal his acceptance of the Company.
- Technical explanation: vivid, tactile metaphors about stone and pressure rather than abstract theory.

## Notes for editors
- Keep Grimjaw's language compact and metaphor-rich with geological imagery.
- Avoid making him overly verbose; his authority comes from brevity and demonstration.


---

# Grimjaw "Stoneheart" Ironbeard - Scene Tracker

## Major Scenes

### Chapter 7 – The Weight of the World <!-- slug: ch7-weight-world -->
- **Scene 2**: Introduction at his mountain home, reluctance to help
- **Scene 3**: Rescue leadership at Blackvein Lode, display of engineering mastery
- **Scene 4**: Decision to join the Last Light Company

### Chapter 8 – Foundations of Stone and Spirit <!-- slug: ch8-stone-spirit -->
- **Scene 1**: Journey from his cabin, sharing knowledge and stories
- **Scene 2**: Establishing his mentorship role within the Company

### Chapter 9 – The Westwall Welcome <!-- slug: ch9-westwall-welcome -->
- **Scene 1**: First impressions of the Westwall Watchpost
- **Scene 2**: Integration into the Company's daily life

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 1**: Preparing for winter rescue mission, assessment of ice-covered ruins
- **Scene 2**: Professional evaluation of the Thornwood misunderstanding
- **Scene 4**: Examining the structure of Vera's animal-made windbreak
- **Scene 7**: Selected for tracking mission due to structural expertise
- **Scene 9**: Pragmatic reaction to Vera's execution of trafficker ("Dead men don't answer questions")
- **Epilogue**: Bawdy winter tale about misunderstood invitation during dinner

### Chapter 12 – The Wayward Compass <!-- slug: ch12-wayward-compass -->
- **Scene 1**: Assessing the broken cart axle with professional expertise.
- **Scene 2**: Providing a solid, intimidating presence during the standoff at the inn.

### Chapter 13 – An Honest Coin <!-- slug: ch13-honest-coin -->
- **Scene 1**: Voicing skeptical but pragmatic opinion of Marcus.
- **Scene 2**: Arguing in favor of the practical benefits of Marcus's offer.

## Character Moments

### Best Moments
- Rescue leadership at Blackvein Lode (Ch. 7)
- Knowledge sharing during journey (Ch. 8)
- Engineering assessment of animal-built windbreak (Ch. 10)
- Winter romance story revealing more personal side (Ch. 10)

### Worst Moments
- Initial reluctance to join the Company (Ch. 7)
- Frustration over lost intelligence from dead trafficker (Ch. 10)

### Turning Points
- Decision to join the Last Light Company (Ch. 7)
- Acceptance of Vera's lethal methods despite tactical disagreement (Ch. 10)

## Interaction Log

### With Veyra Thornwake
- Chapter 7: Being recruited after mine rescue
- Chapter 10: Selected for tracking mission, supporting her leadership

### With Thorne Brightward
- Chapter 7: Initial assessment as a capable soldier
- Chapter 10: Professional cooperation during winter missions

### With Aldwin Gentleheart
- Chapter 7: Beginning of working relationship during mine rescue
- Chapter 10: Coordination during child rescue mission

### With Vera Moonwhisper
- Chapter 10: First meeting during her rescue
- Chapter 10: Tactical disagreement over killing trafficker
- Chapter 10: Building rapport during dinner scene

## Upcoming Scenes

### Planned Appearances
- Engineering focus during rescue missions
- Possible contribution to permanent Company headquarters
- Further development of mentorship role with newer members

### Required Interactions
- Further development of relationship with Vera after tactical disagreement
- Possible deeper integration of engineering knowledge with Vera's tracking
- Continued sharing of life experiences and stories with the Company


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Ignis Emberheart

# Ignis "Spark" Emberheart – Profile

## Basic Information
- Full Name: Ignis "Spark" Emberheart
- Aliases/Nicknames: Spark
- Age: Unknown
- Gender: Male
- Role in Story: Party sorcerer whose wild magic triggered catastrophe
- First Appearance: Chapter 1, Scene 1 (Twilight on the Rim)
- Status: Missing (last seen sealed behind molten glass after the Undershade collapse; evidence: chapters/ch01)

## Notes
- Fate unresolved; possible transformation or altered state. Ongoing plot thread to investigate or resolve.

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Eyes that "shone" with fascination
- Distinguishing Features: Tiefling tail (mentioned flicking to douse embers)
- Typical Clothing: Not specified
- Body Language: Flamboyant, dramatic displays
- Physical Condition: Powerful magic user

## Significance
Ignis Emberheart was the Gilded Compass's fire sorcerer whose wild magic surge catastrophically amplified the cult's ritual. His desperate attempt to counter the cult's magic instead fed their spell, creating the disaster. His ambiguous fate—trapped alive behind molten glass—haunts Veyra and represents the ultimate failure of "no one left behind."

## The Catastrophe
His wild magic surge harmonized with the cult's ritual instead of disrupting it, causing a massive detonation that sealed the party's fate. Standing at ground-zero with "flames wreathing him like a crown of regret," he desperately tried to undo what he had caused.

## Final Moments
Last seen alive but trapped as the canyon collapsed, his desperate plea "Scout, find another path—live—" was among the last words Veyra heard. The "I" stone represents not just his memory but the uncertainty of his fate.

## Unresolved Mystery
- Was he transformed by the magic?
- Did he survive in some altered state?
- Could he still be rescued?
- Connection to the Shadow Watcher in Veyra's dreams?

## Legacy
- Name inscribed in Hall of Remembrance (despite uncertain fate)
- The "I" stone carried as a token
- His fate drives Veyra's "never left" vow
- Represents the Company's mission to find even the impossible to reach


---

# Ignis "Spark" Emberheart - Background

## Origin
- **Birthplace**: Unknown.
- **Social Class**: Unknown.
- **Cultural Background**: Tiefling, with a natural affinity for fire magic.

## History
- **Professional Career**: The fire sorcerer for the Gilded Compass adventuring party. His flamboyant personality and powerful, if sometimes unpredictable, magic made him a valuable but volatile member of the team.

## Personal Details
- **A Passionate Artist**: Ignis was a gifted glassblower. He was utterly fascinated by the interplay of heat, sand, and breath, and he saw it as a more controlled, delicate form of his own fire magic. He would spend his downtime in any city with a good workshop, creating beautiful, swirling glass sculptures. He once made a set of five small, colored glass animals, one for each member of the Gilded Compass. Veyra's—a small, green bird—was shattered in the ambush, and she still carries the largest remaining shard.
- **How He Relaxed**: He loved to sit by a large campfire and engage in "flame-scrying," telling elaborate, fantastical stories based on the shapes he saw dancing in the flames. His tales were always heroic and wildly exaggerated, casting his companions as legendary figures. It was his way of showing his deep affection and admiration for them.
- **Favorite Meal**: Blackened, spicy fish tacos with a sweet fruit salsa. It was a meal of dramatic contrasts—hot and sweet, savory and fresh. He loved the theatricality of cooking the fish over an open flame until it was perfectly charred, and the messy, vibrant experience of eating it with his friends.


---

# Ignis Emberheart - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Ignis Emberheart - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Ignis Emberheart - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Ignis Emberheart - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Kaida Shadowstep

# Kaida "Lockbreaker" Shadowstep - Profile

## Basic Information
- **Full Name**: Kaida Shadowstep
- **Aliases/Nicknames**: Lockbreaker
- **Race**: Tiefling
- **Class**: Rogue
- **Role in Story**: Infiltration Specialist for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: About average height for a tiefling, compact and precise in everything - movement, speech, appearance
- **Skin**: Dark burgundy skin
- **Horns**: Short, curved horns filed to smooth points
- **Hair**: Black hair cut in a practical bob that won't catch on anything
- **Eyes**: Golden eyes with the calculating look of someone always measuring distances and angles
- **Distinguishing Features**: 
  - Small scars marking her fingers from years of lockpicking
  - Habit of unconsciously flexing her hands when thinking
- **Typical Clothing**: 
  - Dark, close-fitting leather that doesn't creak or catch
  - Multiple hidden pockets
  - Reinforced knees
  - Soft-soled boots
- **Physical Condition**: Physically fit and agile, built for stealth and precision work

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Kaida Shadowstep.

## Personality
- **Archetype**: The Professional Thief/Infiltrator
- **Temperament**: Calculating, precise, methodical
- **Positive Traits**: Skilled, intelligent, professional, meticulous
- **Negative Traits**: Unashamed of criminal past, possibly obsessive about precision
- **Moral Alignment**: Chaotic Good - uses criminal skills for rescue work but maintains criminal mindset

## Skills & Abilities
- **Expertise**: 
  - Master lockpicking and infiltration
  - Trap detection and disarmament
  - Physical infiltration and stealth
  - Intelligence gathering through physical means
  - Navigation of trap-filled environments
- **Special Abilities**: 
  - Can move like a ghost without leaving evidence
  - Obsessive precision in planning and execution
  - Immaculate tool organization and maintenance
- **Education Level**: Self-taught master thief with practical expertise
- **Languages**: TBD
- **Combat Style**: Stealth-based, avoiding direct confrontation when possible

## Personal Details
- **Habits**: Unconsciously flexing hands when thinking, obsessive tool maintenance
- **Hobbies**: Likely studying locks, traps, and security systems as intellectual puzzles
- **Personal Quarters**: A small, anonymous room with a single, easily barred window that overlooks a little-used section of the Bastion's outer wall. The furniture is sparse, lightweight, and looks like it could all be packed away in minutes—a simple cot, a small table, one chair. There are no decorations, no personal touches. This is a professional's bolt-hole, not a home. Every item is placed for a quick getaway. The lock on her door is a masterpiece of complex, non-magical tumblers that she designed and changes weekly. She uses the room for the quiet, methodical maintenance of her gear and for studying city maps. A loose floorboard, indistinguishable from the others, conceals a hidden cache containing her old thieving tools, an emergency go-bag with rations and disguises, and a small, waterproofed bag of currency from a half-dozen different city-states.
- **Likes**: Precision, well-executed plans, professional excellence in thievery
- **Dislikes**: Sloppy work, betrayal, being trapped or caught
- **Fears**: Being betrayed again, losing her professional edge
- **Motivations**: 
  - Identifying who betrayed her to the authorities
  - Applying her skills to help others (redirected rather than reformed)
  - Maintaining her professional reputation and abilities

## Combat & Tactics
- **Primary Weapons**: Paired stiletto daggers named "Whisper" (left hand) and "Promise" (right hand) - precision instruments, not brawling weapons
- **Secondary Weapons**: Throwing knives hidden throughout outfit, each balanced for different distances
- **Tools**: Lockpicking set with tools named after betrayers from her past - "using their names for better purposes"
- **Armor**: Form-fitting shadowsilk leather that moves like a second skin, reinforced with flexible steel strips at vital points. Allows complete freedom of movement while providing protection.
- **Fighting Style**: Surgical striker - appears, eliminates threat with precision, vanishes. Combines deadly efficiency with an almost dance-like grace.
- **Signature Move**: "Arterial Mathematics" - precision strikes to incapacitate rather than kill, calculated for maximum effectiveness
- **Combat Philosophy**: "If you see me fighting, I've already failed" - but if you do see it, you'll appreciate the artistry
- **Tactical Role**: Ghost operative who neutralizes sentries and creates entry points while making it look effortless

## Psychological Response Matrix
- **In Crisis**: Calculates optimal solutions with calm confidence, often with a slight smirk at the challenge
- **During Negotiation**: Silent observer with knowing looks, occasionally exchanging meaningful glances with allies
- **Moral Dilemma**: Chooses efficiency with a shrug - "morality is a luxury I can't afford, darling"
- **Team Conflict**: Withdraws with theatrical sigh, makes sly comments from the sidelines
- **Under Personal Attack**: Responds with cutting wit and veiled threats delivered with a smile
- **In Victory**: Allows herself a satisfied smile and perhaps a small, theatrical bow

## Voice & Dialogue Patterns
- **Speech Style**: Precise criminal terminology delivered with subtle flirtation and supreme confidence
- **Signature Phrases**: 
  - "That's a three-pick lock, two-minute job - child's play, really"
  - "I don't do witnesses, but I might make an exception for you"
  - "The math doesn't work, sweetheart"
- **Flirtatious Edge**: Uses terms of endearment ironically, winks at impossible achievements, enjoys being impressive
- **Example Dialogue**: "Entry point seventeen meters up, three guards on rotation, forty-second window. *slight smile* I'll need a distraction at the bell tower - something dramatic would be appreciated."
- **Emotional Tells**: Flexes hands when thinking, smirks when confident, raises eyebrow when amused

## Notes
- Zero shame about her criminal past - views thievery as a skilled profession requiring intelligence, planning, and artistry
- Worked with a crew called "The Architect's Fingers"
- Joined the Company through work-release program after saving a mission and Grimjaw's life
- Not reformed, just redirected - "instead of stealing from people, she's stealing people back from their captors"
- Still methodically working to identify who betrayed her
- Forms perfect intelligence duo with Marcus "The Voice" Heartbridge

### Public Perception
- Known as "Lockbreaker" or a "ghost" for her unparalleled infiltration skills, with rumors of her leaving a black feather as a calling card in impossible-to-breach locations.
- Her involvement in the Company's "acquisitions" is an open secret, often seen by common folk as a form of karmic justice against the corrupt.
- Works in a highly effective, almost silent partnership with Marcus Heartbridge for intelligence gathering and discreet operations.


---

# Kaida "Lockbreaker" Shadowstep - Background

## Origin
- **Birthplace**: TBD (likely an urban area with significant criminal activity)
- **Birth Date**: TBD
- **Social Class**: Lower class, criminal underworld
- **Cultural Background**: Tiefling heritage. She faces the usual prejudice against Tieflings but handles it with a surprising maturity. She sees bias as just another variable in a system—an exploitable weakness an opponent foolishly reveals.

## History
- **The Architect's Fingers**: Kaida's former life was with a small, elite thieving crew.
  - **Silas ("The Eyes"):** The charming intelligence gatherer who found the marks.
  - **Bryn ("The Hammer"):** The stoic half-orc muscle and logistics expert.
  - **Kaida ("The Fingers"):** The master infiltrator who did the delicate work.

- **The Betrayal (The Cassian Heist)**: The crew was betrayed by their own intel man, Silas. He was secretly paid by a rival of their target, Lord Cassian, to set Kaida up. Silas provided a flawless plan but fed them a false date. When Kaida bypassed every security measure and opened the vault, she was met not by treasure, but by Lord Cassian and a dozen City Watch guards led by Captain Thorne Brightward. With no escape, she was arrested.

- **The Recruitment (The Ticking Cage)**: Months later, the Last Light Company was trying to rescue a captive from a trap-filled clock tower. Grimjaw became pinned by a complex clockwork mechanism, moments from death. Thorne, remembering the unparalleled skill of the thief he had arrested, visited Kaida in prison. He offered her a deal: save his man, and he would arrange for her to serve her sentence with the Company. Intrigued by the challenge, she accepted. She navigated the deadly traps with breathtaking artistry, freed Grimjaw, and secured her place with the Company.

## Backstory Elements
- **Defining Moments**: 
  - Joining "The Architect's Fingers" and achieving professional mastery.
  - Being betrayed by Silas and arrested by Thorne.
  - Saving Grimjaw's life and proving her value to the Company.
  
- **Past Achievements**: 
  - Master-level expertise in infiltration and trap navigation.
  - A reputation as a "ghost" who leaves no evidence.
  
- **Biggest Failures**: 
  - Trusting Silas, which led to her capture and the dissolution of her crew.
  
- **Primary Motivation**: 
  - To methodically hunt down Silas and understand the full scope of his betrayal.

## How They Got Here
- **Reason for Current Situation**: Serving her sentence on a work-release program with the Last Light Company.
- **Path to Current Location**: Master Thief → Betrayal & Imprisonment → Recruitment by Thorne → Indispensable Company Asset.
- **Goals Prior to Story Start**: Professional excellence in thievery and survival.

## Philosophical Development
- **Past**: Viewed thievery as a high art and a profession deserving of pride.
- **Present**: "Not reformed, just redirected." She now uses her skills to "steal people back," a challenge she finds more rewarding. She maintains her professional pride and still methodically hunts for Silas, but has found a new, more loyal crew in the Company.


---

# Kaida "Lockbreaker" Shadowstep - Character Development

## Personality Core
- **Defining Traits**: Precise, methodical, professional, unashamed, calculating
- **Core Values**: Professional excellence, precision, competence, self-reliance
- **Motivations**: Identifying her betrayer, maintaining professional standards, applying skills effectively
- **Fears**: Being betrayed again, losing her edge, being trapped or caught
- **Internal Conflicts**: 
  - Criminal identity vs. rescue work integration
  - Trust issues vs. team collaboration needs
  - Professional pride vs. authority cooperation
- **Contradictions**: 
  - Uses criminal skills for lawful/chaotic rescue purposes
  - Maintains criminal mindset while serving community service
  - Values precision but works in chaotic rescue situations

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Professional thief serving forced community service
  - *World View*: Criminal skills are valuable profession; not reformed, just redirected
  - *Key Relationships*: Purely transactional with Company, investigating betrayal
  
- **Catalyst Events**:
  - *Event 1*: The betrayal that led to her capture
  - *Event 2*: Saving Grimjaw's life during the fortress mission
  - *Event 3*: Developing intelligence partnership with Marcus
  - *Event 4*: TBD - potential resolution of betrayal investigation
  
- **Current State**:
  - *Self-Perception*: Skilled infiltration specialist finding purpose in rescue work
  - *World View*: Criminal skills can serve noble purposes without losing professional identity
  - *Key Relationships*: Strong partnership with Marcus, growing trust with team
  
- **Intended Destination**:
  - *Self-Perception*: Professional who chose to redirect skills rather than abandon identity
  - *World View*: Competence and results matter more than conventional morality
  - *Key Relationships*: Fully integrated team member who maintains unique perspective

## Growth Milestones
- **From Forced Service to Chosen Purpose**: 
  - *Development Noted*: Transition from work-release requirement to willing participation
  - *Catalyst*: Saving Grimjaw's life and seeing impact of her skills
  - *Impact*: Found meaning in "stealing people back from their captors"
  
- **From Isolated Wariness to Selective Trust**: 
  - *Development Noted*: Building working relationships despite betrayal trauma
  - *Catalyst*: Successful partnerships with Marcus and respect from team
  - *Impact*: Learning to trust again while maintaining professional caution
  
- **From Criminal vs. Authority to Professional Cooperation**: 
  - *Development Noted*: Working with rather than against authority figures
  - *Catalyst*: Recognizing shared goals despite different methods
  - *Impact*: Effective collaboration while maintaining criminal professional identity

## Character Flaws
- **Obsessive Precision**: 
  - *Effects on Character*: May over-plan or get frustrated with imperfect conditions
  - *Effects on Others*: Could slow down urgent operations or frustrate spontaneous team members
  - *Development Plan*: Learning to balance precision with rescue operation urgency
  
- **Trust Issues from Betrayal**: 
  - *Effects on Character*: Systematic wariness that may limit deeper relationships
  - *Effects on Others*: May seem distant or calculating to team members seeking friendship
  - *Development Plan*: Gradual trust building through shared experiences and proven reliability
  
- **Unashamed Criminal Identity**:
  - *Effects on Character*: May not fully integrate with law-abiding team members
  - *Effects on Others*: Could make some team members uncomfortable with her methods
  - *Development Plan*: Finding balance between maintaining identity and team integration

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: The ongoing investigation into who betrayed her
  - *Secret 2*: Specific details about "The Architect's Fingers" crew and their methods
  
- **Unknown to Character**:
  - *Truth 1*: The true identity of her betrayer (TBD)
  - *Truth 2*: How much she's actually changing through rescue work
  
- **Revelation Timeline**:
  - *Secret/Truth*: Discovery of betrayer's identity
  - *Planned Reveal*: TBD
  - *Expected Impact*: Resolution of trust issues and closure of criminal past

## Key Decisions & Turning Points
- **Choosing to Save Grimjaw**:
  - *Context*: During the trap-filled fortress mission when she could have prioritized her own safety
  - *Options Considered*: Self-preservation vs. using skills to save team member
  - *Choice Made*: Used her expertise to save Grimjaw's life
  - *Consequences*: Transition from temporary work-release to permanent team member

- **Developing Partnership with Marcus**:
  - *Context*: Recognizing complementary intelligence gathering abilities
  - *Options Considered*: Working alone vs. collaborative intelligence operations
  - *Choice Made*: Form perfect intelligence duo combining their skills
  - *Consequences*: More effective operations and deeper Company integration

## Special Character Elements
- **Tool Obsession**:
  - Physical manifestation of her precision and professional standards
  - Immaculate organization reflects her methodical approach
  - Tools are extension of her professional identity
  
- **Hand Flexing Habit**:
  - Unconscious physical tell when thinking or stressed
  - Shows her constant readiness for manual dexterity work
  - Visual indicator of her perpetual mental calculation
  
- **"Architect's Fingers" Legacy**:
  - Connection to criminal past and professional standards
  - Source of techniques and approaches
  - Potential plot thread through betrayal investigation

## Development Notes
- Character represents redemption through redirection rather than reformation
- Professional competence as path to acceptance and integration
- Trust issues create barriers but also make breakthrough moments more meaningful
- Criminal background provides unique skills and perspective valuable to team
- "Not reformed, just redirected" philosophy allows character growth without losing core identity

## Psychological Profile
*   **Kaida Shadowstep (The Professional):** Kaida views thievery not as a crime, but as a high-skill profession, an art form. She is not "reformed"; her skills have simply been "redirected." Her core psychology is that of a meticulous professional who was betrayed by her former crew. This has left her with a deep-seated distrust of teams and a laser-focus on identifying her betrayer. Her loyalty to the Company is conditional, built on their professionalism and their respect for her skills.


---

# Kaida "Lockbreaker" Shadowstep - Relationships

## Professional Relationships
- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Intelligence gathering partner; "The Lock and The Key."
  - *Hierarchy*: Equals and partners.
  - *Dynamics*: Theirs is a partnership of pure, silent professionalism. They communicate in half-sentences and shared glances. Marcus gathers the social intelligence, learning the secrets and schedules of a target. He is "The Key" who finds the right moment to turn. Kaida then uses that information for the physical infiltration. She is "The Lock" that can be opened. There is a deep, unspoken understanding between them, as they are the two members who most comfortably operate in the world's gray areas.
  - *History*: TBD
  - *Current Status*: The Company's primary intelligence and infiltration team.
  - *Feelings Toward*: Immense professional respect. She sees him as a master of a different kind of lockpicking—the kind that opens people instead of doors.

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Fellow Company member whose life she saved
  - *History*: Her skills saved the mission and specifically saved Grimjaw's life during the trap-filled fortress operation
  - *Current Status*: Special bond formed through life-saving event
  - *Dynamics*: Mutual respect and possible protective instinct from both sides
  - *Professional Opinion of*: Respects his experience and dedication
  - *Development Potential*: Deeper trust and collaboration based on shared experience

- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Infiltration Specialist
  - *Hierarchy*: Respects her leadership despite her own criminal background
  - *Dynamics*: Provides infiltration expertise to support Veyra's rescue missions
  - *Professional Opinion of*: Likely respects her mission to leave no one behind, which aligns with Kaida's redirected purpose

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Infiltration Specialist
  - *Hierarchy*: Acknowledges chain of command while maintaining professional criminal mindset
  - *Dynamics*: His military approach might occasionally clash with her criminal methods
  - *Professional Opinion of*: Respects tactical abilities but may find rigid military approach limiting

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: "The Outsiders' Alliance"; quiet friendship.
  - *Hierarchy*: Equals.
  - *Dynamics*: Both Kaida and Vera are deeply wary of people due to past betrayals. They have a quiet, minimalist friendship built on shared observation rather than conversation. They might spend hours together in the courtyard, one practicing with her tools, the other observing the patterns of birds, finding a strange comfort in each other's silent, professional competence. They understand each other's need for space and self-reliance.
  - *History*: TBD
  - *Current Status*: A quiet, unspoken alliance.
  - *Feelings Toward*: A sense of kinship with a fellow outsider. She trusts Vera's professionalism, if not her worldview.

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (infiltration vs. medical)
  - *Dynamics*: His healing abilities support her potentially dangerous infiltration work
  - *Professional Opinion of*: Values his medical expertise for post-mission care

- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different areas of expertise (infiltration vs. magical support)
  - *Dynamics*: Her weather magic might provide cover for Kaida's infiltration activities
  - *Professional Opinion of*: Appreciates magical abilities that complement her physical skills

- **Nireya Voss**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different domains (physical vs. spiritual)
  - *Dynamics*: Contrast between Kaida's concrete, physical approach and Nireya's spiritual methods
  - *Professional Opinion of*: May find spiritual approach mystifying but respects results

- **Cidrella "Cid" Vexweld**:
  - *Nature of Relationship*: Fellow technical specialist
  - *Hierarchy*: Different but complementary technical skills (infiltration vs. arcano-engineering)
  - *Dynamics*: Cid's devices might enhance Kaida's infiltration capabilities
  - *Professional Opinion of*: Professional respect for technical innovation and problem-solving

- **Korrath "Wallbreaker" Threnx**:
  - *Nature of Relationship*: Fellow specialist with complementary abilities
  - *Hierarchy*: Different approaches to accessing secured locations (infiltration vs. siege engineering)
  - *Dynamics*: His structural knowledge complements her infiltration techniques
  - *Professional Opinion of*: Respects his expertise in breaking down barriers

## Former Criminal Connections
- **"The Architect's Fingers" Crew**:
  - *Relationship Type*: Former criminal colleagues
  - *History*: Worked together as highly skilled thieving crew
  - *Current Status*: Crew likely disbanded after her capture
  - *Dynamics*: Professional partnership based on complementary criminal skills
  - *Tensions/Issues*: One member may have been involved in her betrayal

- **The Betrayer**:
  - *Relationship Type*: Unknown former associate who led to her capture
  - *History*: Fed false information to her intelligence gatherer
  - *Current Status*: Unknown identity, actively investigating
  - *Dynamics*: Deep betrayal of professional trust
  - *Tensions/Issues*: Ongoing threat and source of wariness; methodical investigation continues

- **Criminal Contacts**:
  - *Relationship Type*: Former professional network
  - *History*: Connections built during criminal career
  - *Current Status*: Likely severed or complicated by her work-release status
  - *Dynamics*: May view her as traitor for working with authorities
  - *Tensions/Issues*: Potential sources of information but also potential threats

## Authority Relationships
- **Prison/Work-Release Officials**:
  - *Relationship Type*: Legal oversight of her community service
  - *History*: Imprisoned after betrayal, granted work-release for Company missions
  - *Current Status*: Permanent community service arrangement
  - *Dynamics*: Professional compliance with legal requirements
  - *Tensions/Issues*: Balance between serving sentence and maintaining criminal identity

- **Law Enforcement**:
  - *Relationship Type*: Former adversaries, current complicated alliance
  - *History*: Career built on evading law enforcement
  - *Current Status*: Working with rather than against authorities
  - *Dynamics*: Uneasy alliance based on mutual benefit
  - *Tensions/Issues*: Fundamental clash between criminal mindset and authority cooperation

## Interpersonal Patterns
- **Trust Issues**:
  - Highly cautious about trust due to betrayal experience
  - Systematic approach to evaluating trustworthiness
  - Professional relationships easier than personal ones

- **Professional Standards**:
  - Maintains criminal professional identity even in rescue work
  - Values competence and precision in others
  - Judges others by their professional capabilities

- **Collaborative Style**:
  - Works best in partnerships with clearly defined roles
  - Excels when her specific skills are needed and valued
  - May struggle with authority figures who don't understand criminal methods

## Relationship Evolution Tracker
- **Pre-Betrayal**: Strong crew bonds with "The Architect's Fingers"
- **Post-Capture**: Isolation and wariness, systematic investigation of betrayal
- **Work-Release**: Initial purely transactional relationship with Company
- **Life-Saving Event**: Deeper integration after saving Grimjaw and proving worth
- **Current**: Established infiltration specialist with growing team bonds
- **Future Development Potential**:
  - Deeper trust with team members as she proves reliability
  - Resolution of betrayal investigation
  - Evolution from criminal identity to rescue specialist identity

## Notes on Relationships
- Her criminal background creates unique dynamics with law-abiding team members
- Professional competence is her primary way of building relationships
- The betrayal experience makes her cautious but not paranoid
- "Not reformed, just redirected" philosophy affects all her relationships
- Perfect working partnership with Marcus forms foundation of her Company integration
- Life-saving event with Grimjaw created important trust bond


---

# Kaida "Lockbreaker" Shadowstep — Dialogue & Psyche

## Core temperament
Cautious, cunning, and fiercely independent. A master infiltrator who trusts skill over sentiment; keeps people at arm's length until they prove reliable.

## Dialogue instincts
- Public: curt, economical; says only what advances the objective or tests the room.
- Infiltration/skill use: precise, step-oriented cues—short imperatives or single-image descriptions.
- Under pressure: cool and quick; prefers quiet commands and whispered coordination.
- Humor: dry, edged with cynicism; uses wry remarks to deflect praise or uncomfortable emotion.

## Emotional anchors & physical tells
- Fingers toy with lockpicks or a hidden dagger when nervous or thinking.
- Eyes dart to exits; relaxed eye contact indicates trust.
- A small, almost-smirk is rare and meaningful; a cold laugh signals boundary reinforcement.

## Conflict & humor rules
- Avoids sentimentalities and moral grandstanding; has strict personal ethics—she does not steal from those who cannot afford it.
- Will pocket items opportunistically but rarely flaunts it; defends this as "operational prudence."
- Breaks pattern only in rare private moments when she reveals a scar or a secret—these reveal hard-earned loyalty.

## Writer cues (practical)
- Use Kaida for tight, tactical lines during stealth or infiltration scenes.
- When adding dialogue, favor clipped sentences, whispered directions, and concise rationales.
- Let her occasionally needle Marcus or trade barbs with Vera—these show social integration without emotional overshare.

## Drop-in sample lines
- Stealth cue: "Silent feet. Shadow on my left. Move on my count—three, two, one."
- Cold aside: "We stole a rescue, not a purse. Keep the line straight."
- Private, rare softness: "Don't call it loyalty yet. Call it a debt owed."

## Voice evolution note (chapters 1–9)
- Introduced as a wary, skilled thief on work-release; gradually finds a place within the Company's code—still independent, but with emerging, guarded loyalty.

## Usage examples (scenes)
- Infiltration: short, precise instructions and observations that keep the team synchronized.
- Social friction: barbed quips and tests of honesty that reveal trust dynamics.
- Private interactions: minimal confessions or pragmatic admissions that hint at deeper motives.

## Notes for editors
- Keep Kaida's dialogue sharp and economical; avoid long, justifying monologues.
- Her humor should carry a sting and a usefulness—never gratuitous.


---

# Kaida "Lockbreaker" Shadowstep - Scene Tracker

## Major Scenes
- **[Chapter 15, The Proposal to the Warden]**: 
  - *Brief Description*: Kaida is seen in solitary, methodically scratching escape plans, hinting at her calculating nature.
  - *Significance*: Introduces her character and mindset before her direct involvement.
  - *Character's Goal*: To maintain her mental edge and readiness for escape.
  - *Outcome*: Warden agrees to a supervised test for her.
  - *Emotional State*: Calculating, patient, subtly defiant.

- **[Chapter 16, The Test of Trust]**: 
  - *Brief Description*: Kaida flawlessly executes an infiltration test rigged by Cid and Korrath, leaving a black feather for Veyra.
  - *Significance*: Proves her exceptional skills to the skeptical team.
  - *Character's Goal*: To pass the test and secure her work-release.
  - *Outcome*: Team is impressed but wary; she hints at past betrayals.
  - *Emotional State*: Confident, professional, subtly wary.

- **[Chapter 17, The First Joint Mission]**: 
  - *Brief Description*: Kaida pairs with Marcus for intelligence, disables security, and saves Grimjaw from a trap, but pockets a valuable item.
  - *Significance*: Demonstrates her immediate value to the team and highlights her criminal habits.
  - *Character's Goal*: To successfully complete the mission and apply her skills.
  - *Outcome*: Mission success, but a confrontation with Veyra over ethics.
  - *Emotional State*: Professional, resourceful, defiant.

- **[Chapter 18, Integration and Shadows]**: 
  - *Brief Description*: Kaida settles into the Bastion, customizes her quarters, bonds with the team, and examines a clue about her past betrayal.
  - *Significance*: Shows her integration into the Company and sets up her personal quest.
  - *Character's Goal*: To find answers about her betrayal and balance new loyalty with independence.
  - *Outcome*: She begins to see the Company as a new "crew" while pursuing her own agenda.
  - *Emotional State*: Guarded, observant, subtly hopeful.

## Potential Flashback Scenes
- **The Betrayal**: 
  - *Brief Description*: The moment when false intelligence led Kaida into a trap designed specifically for her methods
  - *Significance*: Pivotal event that ended her criminal career and led to her capture
  - *Character's Goal*: Execute what she believed was a routine heist
  - *Outcome*: Capture by authorities, dissolution of "The Architect's Fingers"
  - *Emotional State*: Shock, betrayal, professional pride wounded
  
- **Saving Grimjaw**: 
  - *Brief Description*: Kaida navigating the trap-filled fortress and using her skills to save Grimjaw's life
  - *Significance*: Turning point from work-release to permanent Company member
  - *Character's Goal*: Complete the mission and prove her worth
  - *Outcome*: Mission success, Grimjaw's life saved, permanent position offered
  - *Emotional State*: Professional focus shifting to genuine concern for teammate

## Character Moments
- **Tool Maintenance Ritual**:
  - *Description*: Kaida organizing and maintaining her lockpicking tools with obsessive precision
  - *Impact*: Shows her professional standards and methodical nature
  - *Key Elements*: Hand flexing, tool examination, systematic organization
  
- **Reading a Security System**:
  - *Description*: Kaida assessing a complex security setup, identifying weaknesses and planning approach
  - *Impact*: Demonstrates her expertise and analytical abilities
  - *Key Elements*: Golden eyes calculating distances and angles, mental mapping, professional assessment
  
- **"Not Reformed, Just Redirected" Moment**:
  - *Description*: Scene where Kaida explains her philosophy about maintaining criminal identity while serving rescue missions
  - *Impact*: Clarifies her character motivation and approach to moral questions
  - *Key Elements*: Direct communication, professional pride, no apology for past

## Interaction Scenes
- **With Marcus Heartbridge**: 
  - *Chapter/Scene*: Chapter 15, The Proposal to the Warden
  - *Nature of Interaction*: Marcus proposes her work-release to the warden.
  - *Outcome*: Warden agrees to a test.
  - *Relationship Dynamic*: Establishes Marcus as her advocate and initial contact.

- **With The Full Company**: 
  - *Chapter/Scene*: Chapter 16, The Test of Trust
  - *Nature of Interaction*: Meets the skeptical team and performs her test.
  - *Outcome*: Impresses them with her skills, but leaves them wary.
  - *Relationship Dynamic*: Initial tension and professional assessment.

- **With Vera Moonwhisper**: 
  - *Chapter/Scene*: Chapter 16, The Test of Trust
  - *Nature of Interaction*: Exchanges dry remarks about their respective skills.
  - *Outcome*: Hints at a potential, unlikely camaraderie.
  - *Relationship Dynamic*: Mutual professional respect despite initial wariness.

- **With Marcus Heartbridge**: 
  - *Chapter/Scene*: Chapter 16, The Test of Trust
  - *Nature of Interaction*: Forms a subtle bond over shared cunning.
  - *Outcome*: Establishes their future intelligence partnership.
  - *Relationship Dynamic*: Mutual understanding and respect for their methods.

- **With Marcus Heartbridge**: 
  - *Chapter/Scene*: Chapter 17, The First Joint Mission
  - *Nature of Interaction*: Pairs seamlessly for intelligence work.
  - *Outcome*: Their combined skills lead to mission success.
  - *Relationship Dynamic*: Solidifies their effective professional partnership.

- **With Grimjaw Ironbeard**: 
  - *Chapter/Scene*: Chapter 17, The First Joint Mission
  - *Nature of Interaction*: Saves him from a trap.
  - *Outcome*: Earns his respect and forms an unlikely bond.
  - *Relationship Dynamic*: Demonstrates her value and creates a personal connection.

- **With Veyra Thornwake**: 
  - *Chapter/Scene*: Chapter 17, The First Joint Mission
  - *Nature of Interaction*: Confronted about pocketing a valuable item.
  - *Outcome*: Defends her actions, leading to a discussion about Company ethics.
  - *Relationship Dynamic*: Establishes Veyra's moral boundaries and Kaida's "redirected" philosophy.

- **With The Full Company**: 
  - *Chapter/Scene*: Chapter 18, Integration and Shadows
  - *Nature of Interaction*: Participates in a communal meal and begins to bond.
  - *Outcome*: She starts to see the Company as a new "crew."
  - *Relationship Dynamic*: Gradual integration and softening of her guarded nature.

- **With Veyra Thornwake**: 
  - *Chapter/Scene*: Chapter 18, Integration and Shadows
  - *Nature of Interaction*: Veyra officially welcomes her to the Company.
  - *Outcome*: Kaida is formally accepted into the team.
  - *Relationship Dynamic*: Marks a turning point in her relationship with the Commander.

## Ability Showcase Scenes
- **Master Infiltration**:
  - *Setting*: High-security facility during rescue mission
  - *Abilities Demonstrated*: Lockpicking, trap detection, silent movement, route planning
  - *Visual Elements*: Hand flexing while working, tools arranged with precision, ghost-quiet movement
  - *Impact on Story*: Enables access to secured location where victims are held
  
- **Trap Navigation**:
  - *Setting*: Dangerous passage filled with security measures
  - *Abilities Demonstrated*: Trap detection and disarmament, understanding of security designer's mind
  - *Visual Elements*: Methodical assessment, precise movements, professional competence under pressure
  - *Impact on Story*: Safe passage for team through dangerous area
  
- **Intelligence Gathering**:
  - *Setting*: Pre-mission reconnaissance of target location
  - *Abilities Demonstrated*: Physical observation, security assessment, route planning
  - *Visual Elements*: Calculating gaze, mental mapping, systematic approach
  - *Impact on Story*: Crucial information for mission planning and execution

## Conflict Scenes
- **Criminal Past Confrontation**:
  - *Context*: Encounter with former criminal associates or law enforcement from her past
  - *Stakes*: Her position with the Company and team acceptance
  - *Character's Approach*: Professional handling while maintaining current identity
  - *Outcome*: TBD
  
- **Method Disagreement**:
  - *Context*: Clash with team member over infiltration approach or criminal methods
  - *Stakes*: Mission success and team cohesion
  - *Character's Approach*: Appeals to professional results and practical effectiveness
  - *Outcome*: TBD
  
- **Betrayer Discovery**:
  - *Context*: Potential scene where she identifies or confronts the person who betrayed her
  - *Stakes*: Resolution of past trauma and trust issues
  - *Character's Approach*: Methodical investigation and professional confrontation
  - *Outcome*: TBD

## Growth Scenes
- **From Service to Purpose**:
  - *Description*: Moment when Kaida realizes she wants to continue rescue work beyond her sentence requirements
  - *Growth Shown*: Evolution from forced compliance to chosen purpose
  - *Key Elements*: Recognition of meaningful application of her skills
  
- **Trust Breakthrough**:
  - *Description*: Scene where Kaida allows herself to trust a team member beyond professional requirements
  - *Growth Shown*: Moving past betrayal trauma to form genuine bonds
  - *Key Elements*: Vulnerability beneath professional exterior
  
- **Identity Integration**:
  - *Description*: Kaida finding balance between criminal professional identity and rescue work purpose
  - *Growth Shown*: Maintaining core self while adapting to new context
  - *Key Elements*: Professional pride applied to noble purpose

## Dialogue Highlights
- **Professional Pride**:
  - *Context*: Describing her criminal career and current work
  - *Key Quotes*: "I was good at it. Professional. Took pride in clean work. Now I'm using the same skills to steal people back from their captors instead of stealing from people."
  - *Emotional Impact*: Shows her philosophy and approach to moral questions
  
- **Partnership Dynamics**:
  - *Context*: Working with Marcus on intelligence gathering
  - *Key Quotes*: "We go with your social intelligence and my physical reconnaissance. That's how partnerships work—cover each other's blind spots."
  - *Emotional Impact*: Demonstrates professional competence and collaborative approach

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
- Scenes should emphasize her professional competence and precise methodical approach
- Hand flexing mannerism should be consistently shown during thinking or working moments
- "Not reformed, just redirected" philosophy should be central to character moments
- Her partnership with Marcus and bond with Grimjaw provide relationship development opportunities
- Criminal background creates natural tension and character development potential
- Visual elements of tool organization and stealth movement should be prominent


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Korrath Threnx

# Korrath "Wallbreaker" Threnx - Profile

## Basic Information
- **Full Name**: Korrath Threnx
- **Aliases/Nicknames**: Wallbreaker
- **Race**: Dragonborn (Bronze)
- **Class**: Fighter
- **Role in Story**: Siege Engineer for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Tall and broad with the functional strength of someone who's hauled stone blocks and operated siege engines for decades
- **Scales**: Burnished bronze scales that darken to deep bronze around the edges, scarred from years of forge work and construction
- **Eyes**: A deep scar runs diagonally across his left eye from a construction accident - the eye still functions but serves as a permanent reminder of his profession's dangers
- **Distinguishing Features**: 
  - Massive but surprisingly dexterous hands, marked with fine scars from precision work with sharp tools
  - Family engineering guild crest worn on a heavy bronze chain - three interlocked gears beneath a hammer
- **Typical Clothing**: 
  - Well-maintained leather work clothes reinforced with metal plates at shoulders, forearms, and shins
  - Practical protection rather than decorative armor
  - Tool belt organized with geometric precision
- **Physical Condition**: Strong and functional, built for practical engineering work rather than show

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Korrath Threnx.

## Personality
- **Archetype**: The Engineer/Builder
- **Temperament**: Methodical, precise, professional
- **Positive Traits**: Meticulous, knowledgeable, committed to quality, honorable
- **Negative Traits**: Can be rigid in his methods, carries guilt for past work
- **Moral Alignment**: Lawful Good - focused on order, structure, and righting wrongs

## Skills & Abilities
- **Expertise**: 
  - Military engineering
  - Siege weapons design and operation
  - Fortification construction and analysis
  - Structural integrity assessment
  - Security system design and neutralization
- **Special Abilities**: 
  - Can identify structural weaknesses with methodical precision
  - Capable of systematically dismantling his own security systems
  - Deep understanding of architectural integrity and design principles
- **Education Level**: Highly trained in family tradition of engineering excellence
- **Languages**: TBD
- **Combat Style**: Likely utilizes engineering knowledge in combat, possibly using tools as weapons

## Personal Details
- **Habits**: Checking and rechecking work, maintaining tools with exacting precision
- **Hobbies**: Breeding ornamental lizards, studying landscape art and architecture.
- **Personal Quarters**: A perfectly square room near the Siege-Works, built with exposed structural beams and precisely joined stonework. The furniture is heavy, functional, and made of dark, unadorned wood, all arranged at perfect right angles. The room is immaculately clean and organized. This room is a space of order and study. He uses it to draft and refine his blueprints, which are stored in meticulously labeled tubes on a large rack. The walls are decorated not with art, but with framed, hand-drawn architectural diagrams of famous fortresses and his own structural designs for the Bastion. A small section of one wall has been intentionally left as rough-hewn stone, which he uses as a personal testing ground for new mortar compounds and to study the effects of stress on different types of rock.
- **Likes**: Proper structural integrity, respect for craft, attention to safety protocols
- **Dislikes**: Shoddy workmanship, disrespect for proper procedure, cutting corners
- **Fears**: Creating something that causes harm (again)
- **Motivations**: Undoing the harm caused by his previous work, upholding family honor

## Combat & Tactics
- **Primary Weapon**: "Breacher" - military siege maul with engineering modifications, counterweighted for both demolition and combat
- **Secondary Weapon**: Bronze dragon breath weapon (lightning) - used sparingly as last resort
- **Tools as Weapons**: Precision engineering tools repurposed for combat - measuring chains become restraints, calipers become pressure point weapons
- **Armor**: Reinforced leather work clothes with integrated metal plating - functional protection that allows for engineering work
- **Fighting Style**: Methodical destroyer - analyzes structure (enemy formation or building) then systematically dismantles it
- **Signature Move**: "Structural Failure" - identifies and strikes exact weak points with mathematical precision
- **Combat Philosophy**: "Every wall has a weakness. Every weakness has a purpose. I find both."
- **Tactical Role**: Siege specialist who creates entry points and neutralizes fortifications

## Psychological Response Matrix
- **In Crisis**: Immediately identifies structural solutions and problems - sees everything as an engineering challenge
- **During Negotiation**: Silent, imposing presence like Thorne but analyzing room's exits and load-bearing walls
- **Moral Dilemma**: Considers long-term structural integrity of decisions - "Will this solution hold or collapse?"
- **Team Conflict**: Offers to rebuild relationships like structures - "Let me draft a solution"
- **Under Personal Attack**: Analyzes attacker's stance and movement for structural weaknesses
- **In Victory**: Inspects damage for future improvements, documents what worked and what didn't
- **Guilt Response**: When reminded of past work, becomes hyper-focused on current rescue as penance

## Voice & Dialogue Patterns
- **Speech Style**: Precise military engineering terminology, never approximates - exact measurements and specifications
- **Signature Phrases**: 
  - "Load-bearing" (his metaphor for important things/people)
  - "Threnx work doesn't collapse" (family pride)
  - "Seventeen degrees off vertical" (noting imperfections)
  - "I built the cage. I break the cage." (his redemption mantra)
- **Military Formality**: Three-generation military tradition shows in formal address and proper protocol
- **Example Dialogue**: "The enemy's formation has three critical load-bearing points. Remove the sergeant at coordinates seven-three, structural collapse follows in forty seconds."
- **Professional Respect**: Like Thorne, maintains military bearing but defers to expertise - respects Cid's chaos because it works
- **Emotional Tells**: Touches family crest when discussing honor, breath weapon sparks slightly when truly angry

## Notes
- Third-generation military engineer whose family built siege weapons and fortifications for kingdoms
- Went freelance as a contractor after wars ended, designing secure vaults and manor defenses
- Operated with a code: payment up front, no questions asked, work for the highest bidder
- Experienced moral turning point when discovering his security system was used for child trafficking
- Personal motto: "I built the cage. I break the cage"
- Takes immense pride in family engineering tradition - "Threnx work doesn't collapse"
- Has perfect working relationship with Cidrella "Cid" Vexweld

### Public Perception
- Known as "Wallbreaker" for his ability to identify and dismantle structural weaknesses, a skill he demonstrated by predicting the collapse of the Yawning Portal's signpost.
- Highly respected for his meticulous engineering and commitment to quality, a testament to his family's long tradition.
- Works in a highly effective, if sometimes argumentative, partnership with Cidrella "Cid" Vexweld, building and repairing critical infrastructure.


---

# Korrath "Wallbreaker" Threnx - Background

## Origin
- **Birthplace**: A dragonborn enclave with strong ties to the military and engineering guilds of Waterdeep.
- **Cultural Background**: Comes from a dragonborn culture with strong traditions of craftsmanship, honor, and military service.

## Family
- **Family Name**: Threnx
- **Family Dynamics**: Korrath's family name earned him his commission in the Border Wars, but it was his own genius that made him a legend. After the wars, his family was divided. The more traditional, military-minded members felt he should have remained in service, while the pragmatists understood that a master of his craft needed to continue working, even for private clients.

## History
- **Military Career**: Served as a premier specialist—the sapper and architect called upon for the most difficult fortifications during the Border Wars. 

- **The Magnum Opus (The "Oakhaven Repository")**: As a freelance security consultant, Korrath and his subcontractor Cid were hired by the "Oakhaven Collectors," a group claiming to be preserving fragile antiques. 
    - **Korrath's Genius**: He designed a series of interlocking, rotating chambers—a massive, silent puzzle box where the path to the center changed daily based on astronomical alignments.
    - **Cid's Genius**: She designed the arcane locks keyed to specific tokens, meant for the "curators."
    - **The Scam**: The "Collectors" were a front for the "Silent Hand" slavers. The vault was a prison. Korrath and Cid had, in good faith, built the world's most ingenious and inescapable prison.

- **The Revelation**: When the Last Light Company approached him with evidence, his denial was shattered by the truth. His professional pride was replaced by a cold, draconic fury—a focused rage against his art being twisted into something monstrous. This is when his mission became clear: "I built the cage. I break the cage."

- **Joining the Company**: Consumed by guilt, he and Cid joined the Company, leading the infiltration of their own creation to rescue the captives. He now uses his skills for redemption.

## Personal Details
- **Hobbies**: He is a dedicated breeder of ornamental lizards and has a deep fascination with landscape art and architecture—a love for structures that bring beauty to the world, not just security.


---

# Korrath "Wallbreaker" Threnx - Character Development

## Personality Core
- **Defining Traits**: Methodical, precise, honorable, professionally proud
- **Core Values**: Craftsmanship excellence, family honor, structural integrity, responsibility
- **Motivations**: Undoing harm caused by his creations, upholding family reputation
- **Fears**: Creating something that causes harm again, failing to live up to family legacy
- **Internal Conflicts**: 
  - Professional pride vs. guilt over past work
  - Family engineering traditions vs. moral awakening
  - Methodical approach vs. urgency of rescue operations
- **Contradictions**: 
  - Takes immense pride in work that he now actively destroys
  - Upholds family traditions while rejecting their "no questions asked" approach

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Skilled professional continuing family legacy
  - *World View*: Technical excellence is paramount; client purposes not his concern
  - *Key Relationships*: Transactional business relationships, family engineering legacy
  
- **Catalyst Events**:
  - *Event 1*: Discovery that his security systems were used for child trafficking
  - *Event 2*: Decision to systematically destroy his own creation during rescue
  - *Event 3*: Joining the Last Light Company to continue applying skills for good
  - *Event 4*: TBD - possible confrontation with former clients or family members
  
- **Current State**:
  - *Self-Perception*: Engineer seeking redemption while maintaining professional pride
  - *World View*: Technical excellence must be paired with moral responsibility
  - *Key Relationships*: Perfect working partnership with Cid, integration with Company
  
- **Intended Destination**:
  - *Self-Perception*: Redeemed engineer who maintains family excellence while adding ethical dimension
  - *World View*: Engineering expertise as a force for protection rather than imprisonment
  - *Key Relationships*: Deeper integration with team beyond technical contributions

## Growth Milestones
- **From Amoral Contractor to Ethical Engineer**: 
  - *Development Noted*: Shift from "no questions asked" to questioning purpose and impact
  - *Catalyst*: Discovery of child trafficking connection to his work
  - *Impact*: Now applies same technical excellence but for rescue rather than imprisonment
  
- **From Solo Professional to Team Member**: 
  - *Development Noted*: Integration with Last Light Company beyond technical role
  - *Catalyst*: Working alongside others with shared mission but different approaches
  - *Impact*: Learning to balance methodical approach with team dynamics
  
- **From Pride in Creation to Pride in Destruction**: 
  - *Development Noted*: New motto "I built the cage. I break the cage"
  - *Catalyst*: Systematically destroying his own security systems
  - *Impact*: Finding purpose in undoing rather than building

## Character Flaws
- **Rigidity in Methods**: 
  - *Effects on Character*: May struggle to adapt when standard approaches don't work
  - *Effects on Others*: Could frustrate more flexible team members like Cid
  - *Development Plan*: Learning to balance precision with adaptability
  
- **Excessive Guilt**: 
  - *Effects on Character*: Possibly drives himself too hard to compensate
  - *Effects on Others*: May be overly critical of others' ethical lapses
  - *Development Plan*: Finding healthier way to process past mistakes beyond "debt paid"
  
- **Professional Pride Bordering on Arrogance**:
  - *Effects on Character*: Difficulty accepting when his approach isn't best
  - *Effects on Others*: Might alienate those with different methods
  - *Development Plan*: Greater appreciation for diverse approaches to problems

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Full extent of how many of his creations may have been misused
  - *Secret 2*: Possible family conflicts over his career change
  
- **Unknown to Character**:
  - *Truth 1*: How his family might actually view his moral stand
  - *Truth 2*: Whether his technical solutions truly absolve his guilt
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Joining the Last Light Company**:
  - *Context*: After discovering the misuse of his security systems
  - *Options Considered*: Continue freelance work vs. join rescue efforts
  - *Choice Made*: Apply his skills to undo harm and prevent future misuse
  - *Consequences*: Career shift from security designer to rescue specialist

- **Choosing to Destroy His Own Creation**:
  - *Context*: During the initial rescue at the trafficking compound
  - *Options Considered*: Simply help with rescue vs. systematically destroy security
  - *Choice Made*: Methodically dismantle every defensive system he had built
  - *Consequences*: Development of new personal philosophy and approach to his skills

## Special Character Elements
- **Family Engineering Crest**:
  - Symbol of three generations of excellence
  - Physical representation of his professional identity
  - Visual reminder of values he maintains despite moral awakening
  
- **Eye Scar**:
  - Physical reminder of the dangers of his profession
  - Symbol of the cost of precision work
  - Visual indication of experience and resilience
  
- **"I built the cage. I break the cage" Motto**:
  - Encapsulation of his personal philosophy
  - Framework for processing guilt and finding purpose
  - Potential rallying cry for others with similar pasts

## Development Notes
- Character represents the theme of responsibility for one's creations
- The contrast between his methodical approach and Cid's experimental style offers rich development potential
- His family legacy provides opportunity to explore themes of tradition vs. moral growth
- "Every cage I destroy is a debt paid" coping mechanism could evolve into healthier perspective
- The balance of maintaining pride in craftsmanship while rejecting harmful applications creates interesting tension

## Psychological Profile
*   **Korrath Threnx (The Redeemer):** Korrath is a man haunted by his own skill. His entire identity is tied to his family's legacy of masterful engineering, but that legacy was tarnished when his work was used for evil. He is now on a mission of redemption, using the exact same skills to dismantle the kind of cages he once built. He is meticulous, precise, and honorable to a fault, driven by a deep need to undo the harm he inadvertently caused and restore his family's name.


---

# Korrath "Wallbreaker" Threnx - Relationships

## Professional Relationships
- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: The Engineering Duo; "old married couple."
  - *Hierarchy*: Equals and intellectual rivals/partners.
  - *Dynamics*: Their dynamic stems from a fundamental difference in philosophy. Korrath is a master of established, proven principles ("Threnx work doesn't collapse"). Cid is a chaotic innovator who loves to break the rules. They argue constantly, but their respect for each other's genius is absolute. Korrath builds the unbreakable foundation, and Cid builds the impossible machine that sits on top of it.
  - *History*: Three-year profitable working relationship as her client/contractor.
  - *Current Status*: Close, argumentative, and highly effective partners.
  - *Feelings Toward*: He is endlessly impressed by her genius but terrified by her lack of adherence to established safety protocols. He sees it as his duty to provide the structure and discipline that keeps her brilliance from blowing them all up.

- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Siege Engineer
  - *Hierarchy*: Respects command structure while providing expert engineering counsel
  - *Dynamics*: Offers structural assessment and security analysis for rescue operations
  - *Professional Opinion of*: Respects her dedication to leaving no one behind and appreciates having meaningful engineering challenges

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Siege Engineer
  - *Hierarchy*: Military background creates common understanding of chain of command and tactical approaches
  - *Dynamics*: Strong potential for collaboration due to shared military discipline and tactical mindset
  - *Professional Opinion of*: Values his tactical expertise and appreciates working with someone who understands military protocols

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist with complementary skills
  - *Hierarchy*: Equals with different areas of expertise
  - *Dynamics*: Her tracking abilities could help locate targets within structures he's familiar with
  - *Professional Opinion of*: Respects her methodical approach and precision in tracking

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (medical vs. engineering)
  - *Dynamics*: Collaborates on safe extraction of injured victims from dangerous locations
  - *Professional Opinion of*: Values his healing expertise and calm presence during high-stress extractions

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Fellow structural specialist
  - *Hierarchy*: Different approaches to similar problems (mining vs. military engineering)
  - *Dynamics*: Professional kinship due to shared focus on structural understanding and safety
  - *Professional Opinion of*: Respects his traditional engineering knowledge and practical mining experience

- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Intellectual sparring partner; The Storm to his Architect.
  - *Hierarchy*: Peers and masters of opposing, yet complementary, domains.
  - *Dynamics*: Korrath is deeply fascinated and professionally unsettled by Lyralei. She commands the very forces of chaos—wind, water, pressure—that he spends his life designing structures to withstand. He is driven to understand the principles of her magic so he can better account for such unpredictable variables in his own work. Her constant refrain that the elements will eventually win is a philosophical challenge he takes very seriously.
  - *History*: Their bond likely formed during the construction of the Bastion, particularly the Aerie, where his precise engineering had to meet her arcane requirements.
  - *Current Status*: A strong, intellectual friendship built on mutual respect and playful antagonism.
  - *Feelings Toward*: Immense respect for her power and intellect. He sees her as the ultimate test for his craft. Every wall he raises is a quiet counter-argument to her philosophy.
  - *Signature Response*: (To her quip that the elements always win) "Yes. But not today, and not on my watch."

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different areas of expertise (social vs. technical)
  - *Dynamics*: Marcus handles diplomatic aspects while Korrath focuses on technical matters
  - *Professional Opinion of*: Respects his strategic thinking and ability to handle political complications
  
- **Nireya Voss**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different domains (spiritual vs. engineering)
  - *Dynamics*: Contrast between his concrete, physical approach and her spiritual perspective
  - *Professional Opinion of*: Finds her spiritual abilities intriguing despite their different methodologies

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Fellow specialist with complementary abilities
  - *Hierarchy*: Different approaches to accessing secured locations (infiltration vs. siege engineering)
  - *Dynamics*: His structural knowledge complements her infiltration techniques
  - *Professional Opinion of*: Respects her expertise in bypassing security systems he once designed

## Former Client Relationships
- **Wealthy Merchant (Child Trafficking Operation)**:
  - *Relationship Type*: Former client turned adversary
  - *History*: Designed secure estate for "sensitive business dealings" which turned out to be child trafficking
  - *Current Status*: Likely hostile - Korrath destroyed his security systems and helped rescue victims
  - *Dynamics*: Complete betrayal of professional relationship upon discovery of true purpose
  - *Tensions/Issues*: Possible ongoing threat or connection to broader criminal network

- **Other Former Clients**:
  - *Relationship Type*: Professional service provider
  - *History*: Created security systems and defensive measures for various clients
  - *Current Status*: Likely terminated after joining the Company
  - *Dynamics*: Purely transactional, focused on technical requirements
  - *Tensions/Issues*: May now question the true purposes of other past work

## Family Relationships
- **Threnx Engineering Family**:
  - *Relationship Type*: Familial/Professional legacy
  - *History*: Three generations of military engineers
  - *Current Status*: TBD - possibly maintains connection or possibly estranged after career change
  - *Dynamics*: Strong emphasis on family reputation and engineering excellence
  - *Tensions/Issues*: Possible conflict between family trade traditions and his moral awakening

- **Parents/Siblings**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

## Interpersonal Patterns
- **Approach to Authority**:
  - Respects established hierarchies from military background
  - Values competence and expertise
  - Likely follows orders while offering professional assessment

- **Collaborative Style**:
  - Methodical and precise
  - Insists on "doing things the right way"
  - Values safety protocols and proper procedure
  - Contrasts with Cid's more experimental approach

- **Teaching Approach**:
  - Expects students to respect craft and safety protocols
  - Believes in understanding fundamentals and theory first
  - Generous with knowledge but demanding of precision
  - More methodical than Cid's innovation-focused style

## Relationship Evolution Tracker
- **Pre-Company**: Military engineer → Freelance security contractor → Subcontractor relationship with Cid
- **Moral Turning Point**: Discovery of security system misuse → Destroying own creation → Joining Company
- **Company Integration**: Applying skills to rescue operations, partnership with Cid
- **Current**: Established siege engineer for the Company
- **Future Development Potential**:
  - Further exploration of responsibility for past creations
  - Potential confrontation with former clients
  - Deeper integration with team members beyond Cid

## Notes on Relationships
- His perfect working dynamic with Cid forms the foundation of his technical contribution to the Company
- His teaching style (fundamentals and theory first) creates an interesting contrast with Cid's experimental approach
- The theme of responsibility for one's creations defines many of his relationships
- Professional pride and family honor remain important to him despite moral awakening
- His motto "I built the cage. I break the cage" encapsulates his approach to relationships with former clients


---

# Korrath "Wallbreaker" Threnx — Dialogue & Psyche

## Core temperament
Practical, proud, and analytical. A military engineer who values precision, structure, and duty—speaks with the confidence of someone who has built and broken things for a living.

## Dialogue instincts
- Public: crisp and technical; often frames problems in terms of load, leverage, and angles.
- Instructional: calm, methodical—lays out step-by-step orders with clear rationale.
- Under pressure: steady, precise commands; less likely to shout, more likely to issue exact measurements and contingencies.
- Humor: dry, sometimes grim, often related to old engineering anecdotes or military irony.

## Emotional anchors & physical tells
- Fingers sketching invisible lines in the air or tapping a surface to feel vibrations when thinking.
- Slight head-tilt when calculating; a short laugh is rare but warm.
- Uses tactile metaphors—bridges, keystones, joints—to describe people and plans.

## Conflict & humor rules
- Dislikes talk without plan; will push back on speculation without data.
- Uses humor to point out absurdity in plans that ignore fundamentals.
- Avoids mockery of sacrifice; respects practical courage.

## Writer cues (practical)
- Use Korrath to translate structural problems into clear actions—he provides the "how" for breaching, shoring, and structural improvisation.
- When adding lines, favor technical clarity: "Two wedges, staggered; drive the third at a forty-five degree angle."
- Pair short technical lines with small actions (measuring, tapping) to show embodiment of thought.

## Drop-in sample lines
- Technical directive: "Stagger the braces—left post two feet, right post three. Tighten until the hairline stops moving."
- Dry aside: "You can pry a lock or pry a problem—both take the right leverage."
- Encouraging: "Hold your end. A steady pull, not a frantic yank."

## Voice evolution note (chapters 1–9)
- Introduced as a tactical specialist from a military engineering family.
- Grows more collaborative—teaches the Company to think structurally and to respect careful demolition and repair.

## Usage examples (scenes)
- Breaching planning: concise, numbered instructions that others can execute.
- Teaching moments: short, illustrated metaphors about building and failing safely.
- Quiet confidence: one-liners showing trust in team competence.

## Notes for editors
- Keep Korrath concise and technically grounded. Avoid turning him into a walking lecture—let demonstrations and short commands carry the technical weight.


---

# Korrath "Wallbreaker" Threnx - Scene Tracker

## Major Scenes
- **[Chapter 6, A Foundation of Need]**: 
  - *Brief Description*: Korrath formally joins the Company to lead construction of the Bastion.
  - *Significance*: Establishes his role as lead engineer and architect.
  - *Character's Goal*: To build a secure and innovative sanctuary.
  - *Outcome*: Commits to the project with determination.
  - *Emotional State*: Focused, proud.

- **[Chapter 8, The Bottom Line]**: 
  - *Brief Description*: Korrath argues with Cid over architectural plans.
  - *Significance*: Highlights their contrasting approaches and working relationship.
  - *Character's Goal*: To ensure structural integrity and safety.
  - *Outcome*: Productive debate leading to refined plans.
  - *Emotional State*: Assertive, collaborative.

- **[Chapter 11, The Intelligence Briefing]**: 
  - *Brief Description*: Korrath identifies structural vulnerabilities for the Valerius rescue mission.
  - *Significance*: Provides critical tactical insight for mission planning.
  - *Character's Goal*: To find the safest and most effective entry points.
  - *Outcome*: His analysis is integrated into the plan.
  - *Emotional State*: Analytical, pragmatic.

- **[Chapter 13, The Extraction]**: 
  - *Brief Description*: Korrath creates a new exit by breaching a courtyard wall during the escape.
  - *Significance*: Demonstrates his practical problem-solving under pressure.
  - *Character's Goal*: To facilitate the team's escape.
  - *Outcome*: Successful breach and escape route.
  - *Emotional State*: Determined, resourceful.

- **[Chapter 14, Consequences and Realizations]**: 
  - *Brief Description*: Korrath reflects on the mission's reliance on brute force.
  - *Significance*: Acknowledges the need for more finesse and specialized skills.
  - *Character's Goal*: To improve future operations.
  - *Outcome*: Supports recruiting Kaida.
  - *Emotional State*: Thoughtful, self-critical.

- **[Chapter 16, The Test of Trust]**: 
  - *Brief Description*: Korrath rigs a test facility for Kaida's infiltration skills.
  - *Significance*: Demonstrates his engineering expertise and collaboration with Cid.
  - *Character's Goal*: To challenge and evaluate Kaida.
  - *Outcome*: Kaida passes the test.
  - *Emotional State*: Confident, supportive.

## Potential Flashback Scenes
- **Original Security System Design**: 
  - *Brief Description*: Korrath designing the security system that would later be used for trafficking
  - *Significance*: Shows his professional excellence without moral consideration
  - *Character's Goal*: Create the most effective security system possible
  - *Outcome*: Successfully designs an "impenetrable" system
  - *Emotional State*: Professional pride, focused on technical excellence
  
- **Discovery of Misuse**: 
  - *Brief Description*: The moment when Korrath realizes his security system is being used to imprison children
  - *Significance*: Pivotal turning point in his moral development
  - *Character's Goal*: Process this revelation and decide how to respond
  - *Outcome*: Decision to systematically destroy his own creation
  - *Emotional State*: Shock, rage, guilt, determination

## Character Moments
- **Methodical Security Assessment**:
  - *Description*: Korrath analyzing a structure's security with his systematic approach
  - *Impact*: Demonstrates his expertise and methodical nature
  - *Key Elements*: Running hands along walls, identifying patterns, muttering technical observations
  
- **Teaching Engineering Principles**:
  - *Description*: Korrath explaining foundational principles to someone with less patience for fundamentals
  - *Impact*: Shows his teaching style and contrasts with Cid's approach
  - *Key Elements*: Emphasis on fundamentals, patience but firm expectations, respect for craft
  
- **Professional Pride vs. Moral Duty**:
  - *Description*: Moment where Korrath appreciates his own craftsmanship while destroying it
  - *Impact*: Illustrates his core conflict between professional pride and moral responsibility
  - *Key Elements*: "I built the cage. I break the cage" philosophy, technical appreciation with moral purpose

## Interaction Scenes
- **Working with Cid**:
  - *Description*: Korrath and Cid collaborating on a structural challenge
  - *Relationship Dynamic*: His methodical assessment paired with her innovative solutions
  - *Key Elements*: He identifies structural weaknesses while she creates tools to exploit them
  - *Dialogue Focus*: Their contrasting approaches and perfect working dynamic
  
- **Family Legacy Discussion**:
  - *Description*: Korrath discussing his family's engineering tradition with another team member
  - *Relationship Dynamic*: Pride in tradition while acknowledging his departure from "no questions asked" approach
  - *Key Elements*: Family crest, three generations of excellence, moral evolution
  
- **Mentoring a Team Member**:
  - *Description*: Korrath teaching engineering principles to someone less patient with fundamentals
  - *Relationship Dynamic*: Teacher-student with emphasis on respecting craft
  - *Key Elements*: His fundamentals-first approach contrasted with impatience for quick solutions

## Ability Showcase Scenes
- **Security System Analysis**:
  - *Setting*: Heavily secured location during a rescue mission
  - *Abilities Demonstrated*: Deep understanding of security design principles
  - *Visual Elements*: Methodical assessment, recognition of patterns, precise identification of weaknesses
  - *Impact on Story*: Enables access to rescue targets behind sophisticated security
  
- **Structural Weakness Identification**:
  - *Setting*: Unstable building or structure during rescue
  - *Abilities Demonstrated*: Expert assessment of structural integrity
  - *Visual Elements*: Testing load-bearing points, analyzing stress patterns, identifying collapse risks
  - *Impact on Story*: Prevents catastrophic collapse during rescue
  
- **Security System Dismantling**:
  - *Setting*: Confronting a security system he himself designed
  - *Abilities Demonstrated*: Intimate knowledge of his own creations and how to neutralize them
  - *Visual Elements*: Systematically disabling features with practiced precision
  - *Impact on Story*: Turns his expertise from imprisonment to liberation

## Conflict Scenes
- **Facing Former Client**:
  - *Context*: Confrontation with the client who misused his security system
  - *Stakes*: Justice for victims vs. personal redemption
  - *Character's Approach*: Cold, methodical precision in dismantling both system and former client's operation
  - *Outcome*: TBD
  
- **Methodical vs. Experimental Approaches**:
  - *Context*: Disagreement with Cid about how to approach a technical challenge
  - *Stakes*: Success of rescue mission
  - *Character's Approach*: Insistence on fundamentals and established principles
  - *Outcome*: Finding balance between his methodical foundation and her innovative solutions
  
- **Family Honor vs. New Purpose**:
  - *Context*: Potential confrontation with family members about his career change
  - *Stakes*: Family relationships and personal identity
  - *Character's Approach*: Defense of moral evolution while maintaining pride in technical excellence
  - *Outcome*: TBD

## Growth Scenes
- **From Precision to Adaptability**:
  - *Description*: Moment when Korrath needs to adapt his methodical approach in an emergency
  - *Growth Shown*: Learning to balance precision with flexibility
  - *Key Elements*: Uncomfortable departure from established methods, trust in team
  
- **From Guilt to Purpose**:
  - *Description*: Evolution of his "every cage I destroy is a debt paid" perspective
  - *Growth Shown*: Moving from guilt-driven redemption to purposeful application of skills
  - *Key Elements*: Reframing past mistakes as motivation rather than debt
  
- **Team Integration Beyond Cid**:
  - *Description*: Korrath finding ways to work effectively with team members beyond his perfect dynamic with Cid
  - *Growth Shown*: Expanding collaboration skills to diverse approaches
  - *Key Elements*: Appreciating different problem-solving methods

## Dialogue Highlights
- **Professional Pride**:
  - *Context*: Describing a particularly elegant security system he designed
  - *Key Quotes*: "Threnx work doesn't collapse. Three generations of engineering excellence in every detail."
  - *Emotional Impact*: Shows pride in craft despite moral evolution
  
- **Moral Philosophy**:
  - *Context*: Explaining his motivation to a team member
  - *Key Quotes*: "I built the cage. I break the cage. There's balance in that. Every cage I destroy is a debt paid."
  - *Emotional Impact*: Reveals how he processes guilt and finds purpose

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
- Scenes should showcase his methodical approach to structural assessment
- The contrast between his fundamentals-first teaching style and Cid's experimental approach creates interesting dynamics
- His motto "I built the cage. I break the cage" should be central to his character moments
- The physical elements of his work - running hands along structures, geometric precision in tool organization - are important visual components
- Family engineering tradition and the three-generation legacy adds depth to his character motivations

## Potential Flashback Scenes
- **Original Security System Design**: 
  - *Brief Description*: Korrath designing the security system that would later be used for trafficking
  - *Significance*: Shows his professional excellence without moral consideration
  - *Character's Goal*: Create the most effective security system possible
  - *Outcome*: Successfully designs an "impenetrable" system
  - *Emotional State*: Professional pride, focused on technical excellence
  
- **Discovery of Misuse**: 
  - *Brief Description*: The moment when Korrath realizes his security system is being used to imprison children
  - *Significance*: Pivotal turning point in his moral development
  - *Character's Goal*: Process this revelation and decide how to respond
  - *Outcome*: Decision to systematically destroy his own creation
  - *Emotional State*: Shock, rage, guilt, determination

## Character Moments
- **Methodical Security Assessment**:
  - *Description*: Korrath analyzing a structure's security with his systematic approach
  - *Impact*: Demonstrates his expertise and methodical nature
  - *Key Elements*: Running hands along walls, identifying patterns, muttering technical observations
  
- **Teaching Engineering Principles**:
  - *Description*: Korrath explaining foundational principles to someone with less patience for fundamentals
  - *Impact*: Shows his teaching style and contrasts with Cid's approach
  - *Key Elements*: Emphasis on fundamentals, patience but firm expectations, respect for craft
  
- **Professional Pride vs. Moral Duty**:
  - *Description*: Moment where Korrath appreciates his own craftsmanship while destroying it
  - *Impact*: Illustrates his core conflict between professional pride and moral responsibility
  - *Key Elements*: "I built the cage. I break the cage" philosophy, technical appreciation with moral purpose

## Interaction Scenes
- **Working with Cid**:
  - *Description*: Korrath and Cid collaborating on a structural challenge
  - *Relationship Dynamic*: His methodical assessment paired with her innovative solutions
  - *Key Elements*: He identifies structural weaknesses while she creates tools to exploit them
  - *Dialogue Focus*: Their contrasting approaches and perfect working dynamic
  
- **Family Legacy Discussion**:
  - *Description*: Korrath discussing his family's engineering tradition with another team member
  - *Relationship Dynamic*: Pride in tradition while acknowledging his departure from "no questions asked" approach
  - *Key Elements*: Family crest, three generations of excellence, moral evolution
  
- **Mentoring a Team Member**:
  - *Description*: Korrath teaching engineering principles to someone less patient with fundamentals
  - *Relationship Dynamic*: Teacher-student with emphasis on respecting craft
  - *Key Elements*: His fundamentals-first approach contrasted with impatience for quick solutions

## Ability Showcase Scenes
- **Security System Analysis**:
  - *Setting*: Heavily secured location during a rescue mission
  - *Abilities Demonstrated*: Deep understanding of security design principles
  - *Visual Elements*: Methodical assessment, recognition of patterns, precise identification of weaknesses
  - *Impact on Story*: Enables access to rescue targets behind sophisticated security
  
- **Structural Weakness Identification**:
  - *Setting*: Unstable building or structure during rescue
  - *Abilities Demonstrated*: Expert assessment of structural integrity
  - *Visual Elements*: Testing load-bearing points, analyzing stress patterns, identifying collapse risks
  - *Impact on Story*: Prevents catastrophic collapse during rescue
  
- **Security System Dismantling**:
  - *Setting*: Confronting a security system he himself designed
  - *Abilities Demonstrated*: Intimate knowledge of his own creations and how to neutralize them
  - *Visual Elements*: Systematically disabling features with practiced precision
  - *Impact on Story*: Turns his expertise from imprisonment to liberation

## Conflict Scenes
- **Facing Former Client**:
  - *Context*: Confrontation with the client who misused his security system
  - *Stakes*: Justice for victims vs. personal redemption
  - *Character's Approach*: Cold, methodical precision in dismantling both system and former client's operation
  - *Outcome*: TBD
  
- **Methodical vs. Experimental Approaches**:
  - *Context*: Disagreement with Cid about how to approach a technical challenge
  - *Stakes*: Success of rescue mission
  - *Character's Approach*: Insistence on fundamentals and established principles
  - *Outcome*: Finding balance between his methodical foundation and her innovative solutions
  
- **Family Honor vs. New Purpose**:
  - *Context*: Potential confrontation with family members about his career change
  - *Stakes*: Family relationships and personal identity
  - *Character's Approach*: Defense of moral evolution while maintaining pride in technical excellence
  - *Outcome*: TBD

## Growth Scenes
- **From Precision to Adaptability**:
  - *Description*: Moment when Korrath needs to adapt his methodical approach in an emergency
  - *Growth Shown*: Learning to balance precision with flexibility
  - *Key Elements*: Uncomfortable departure from established methods, trust in team
  
- **From Guilt to Purpose**:
  - *Description*: Evolution of his "every cage I destroy is a debt paid" perspective
  - *Growth Shown*: Moving from guilt-driven redemption to purposeful application of skills
  - *Key Elements*: Reframing past mistakes as motivation rather than debt
  
- **Team Integration Beyond Cid**:
  - *Description*: Korrath finding ways to work effectively with team members beyond his perfect dynamic with Cid
  - *Growth Shown*: Expanding collaboration skills to diverse approaches
  - *Key Elements*: Appreciating different problem-solving methods

## Dialogue Highlights
- **Professional Pride**:
  - *Context*: Describing a particularly elegant security system he designed
  - *Key Quotes*: "Threnx work doesn't collapse. Three generations of engineering excellence in every detail."
  - *Emotional Impact*: Shows pride in craft despite moral evolution
  
- **Moral Philosophy**:
  - *Context*: Explaining his motivation to a team member
  - *Key Quotes*: "I built the cage. I break the cage. There's balance in that. Every cage I destroy is a debt paid."
  - *Emotional Impact*: Reveals how he processes guilt and finds purpose

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
- Scenes should showcase his methodical approach to structural assessment
- The contrast between his fundamentals-first teaching style and Cid's experimental approach creates interesting dynamics
- His motto "I built the cage. I break the cage" should be central to his character moments
- The physical elements of his work - running hands along structures, geometric precision in tool organization - are important visual components
- Family engineering tradition and the three-generation legacy adds depth to his character motivations


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Lyralei Stormcaller

# Lyralei Stormcaller - Profile

## Basic Information
- **Full Name**: Lyralei Stormcaller
- **Aliases/Nicknames**: Weather Mage
- **Race**: Elf
- **Class**: Wizard
- **Role in Story**: Magical Support for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Typical elven height and slender build
- **Hair**: Most striking feature - a living representation of a storm that shifts from dark, loamy brown at the roots to stormy gray in the middle, ending in pure white at the tips like a storm cloud giving way to snow. When emotional or casting, a faint breeze seems to rustle through it even indoors.
- **Eyes**: Change with mood and weather - bright cloudless blue on clear days, darkening to stormy gray when concentrating, with tiny sparks of lightning visible in their depths
- **Distinguishing Features**: 
  - A delicate, silvery scar traces a branching path from her temple down her cheek - not disfiguring but beautiful, like fossilized lightning that sometimes glows with soft blue light during spellcasting
  - A single shimmering phoenix feather woven into one of her braids, catching light like a tiny flickering flame
- **Typical Clothing**: Practical mage attire suited for field work, with earth and sky adornments - an amber necklace with a prehistoric insect trapped within, silver raindrop earrings, and rings with polished river stones and swirling wind designs
- **Body Language**: Precise, calculated movements with occasional unpredictable gestures (like weather patterns)
- **Physical Condition**: Healthy, with an otherworldly quality from her brief experience trapped between dimensions

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Lyralei Stormcaller.

## Personality
- **Archetype**: The Academic/Researcher
- **Temperament**: Structured, analytical, intellectually curious
- **Positive Traits**: Brilliant, detail-oriented, methodical, knowledge-seeking
- **Negative Traits**: Possibly overly focused on research goals, may take calculated risks
- **Moral Alignment**: Neutral Good (primarily concerned with advancing knowledge while helping others)

## Skills & Abilities
- **Expertise**: Weather magic, planar convergence theory, elemental manipulation
- **Languages**: Common, Elvish, likely Primordial and other languages related to elemental planes
- **Education Level**: Highly educated in arcane theory and planar studies
- **Special Abilities**: 
  - Weather manipulation (can influence local atmospheric conditions)
  - Limited ability to detect planar anomalies from her experience trapped between dimensions
  - Theoretical understanding of planar convergence points
  - Connection with phoenix familiar

## Personal Details
- **Habits**: Taking meticulous notes on magical phenomena
- **Hobbies**: Studying ancient magical texts, experimenting with weather spells
- **Personal Quarters**: A circular room directly beneath the Aerie in the Tower of Innovation. The most prominent feature is a massive, domed skylight of reinforced, enchanted glass that serves as the floor of the observatory above. The room is a comfortable chaos of books and scrolls, stacked in precarious towers on every available surface. This is her personal library and think-tank. The light in the room is never constant, shifting in color and intensity as the magical energies from the Aerie's instruments filter down through the skylight. She often falls asleep in a large, overstuffed armchair, a heavy tome resting on her chest. One entire wall is a massive chalkboard, covered from top to bottom in a chaotic but brilliant scrawl of arcane equations, weather predictions, and complex planar charts. Her phoenix familiar has a grand, magically-warmed perch of driftwood near the ceiling, from which it occasionally drops shimmering, harmless ash that she collects in a small crystal bowl on her desk.
- **Likes**: Academic discussion, discovering new magical theories, proving hypotheses
- **Dislikes**: Dismissal of theoretical magic, rigid thinking, limitations on research
- **Fears**: Possibly being permanently trapped between planes

## Combat & Tactics
- **Primary Weapon**: "Axiom" - crystal-tipped staff that serves as both weather focus and lightning rod, named for fundamental truths of magic
- **Phoenix Familiar**: "Quill" - mystical firebird who guided her back from between dimensions, serves as aerial scout and living reminder of rebirth
- **Spell Focus**: Earth and sky adornments that resonate with elemental forces - amber for earth, silver for air
- **Armor**: Flowing robes that shift color with weather patterns - practical protection through magical deflection
- **Fighting Style**: Environmental controller - changes battlefield conditions through atmospheric manipulation
- **Signature Move**: "Eye of the Storm" - creates localized weather phenomena from fog to lightning strikes
- **Combat Philosophy**: "Nature is neither cruel nor kind, merely inevitable - I simply adjust the timetable"
- **Tactical Role**: Battlefield manipulation through weather control, aerial superiority via Quill's reconnaissance

## Psychological Response Matrix
- **In Crisis**: Calculates probabilities like solving equations - "Given these variables, the optimal solution is..."
- **During Negotiation**: Provides literal environmental pressure - storm clouds as visual representation of tension
- **Moral Dilemma**: Seeks precedent in magical theory and documented cases before deciding
- **Team Conflict**: Offers perspective from "30,000 feet" - both literally (via Quill) and metaphorically
- **Under Personal Attack**: Treats it as peer review - takes notes on criticism for later analysis
- **In Victory**: Documents everything - magical expenditure, weather patterns, unexpected interactions
- **Research Mode**: Complete tunnel vision - Cid builds while thinking, Lyralei theorizes while forgetting to eat

## Voice & Dialogue Patterns
- **Speech Style**: Academic precision with weather metaphors, often explaining theory during action
- **Signature Phrases**: 
  - "According to Axiom's readings..." (treating her staff like a measurement device)
  - "Statistically speaking..." (before doing something risky)
  - "Fascinating! Quill, are you recording this?"
  - "The probability matrix suggests..."
- **Academic Counterpoint to Cid**: Where Cid says "Let's try it!", Lyralei says "My calculations indicate a 73% success rate"
- **Example Dialogue**: "The barometric pressure via Axiom indicates precipitation in—oh, Quill's feathers are already smoking. Make that immediate precipitation."
- **Emotional Tells**: Hair moves faster when excited, consults Axiom like checking notes, Quill mimics her hand gestures
- **Teaching Mode**: Can't help but lecture even in combat - "Notice how the thermal updraft creates a perfect—duck!"

## Notes
- Views her dimensional accident as "an occupational hazard of the job" rather than trauma
- Joined the Last Light Company to study planar anomalies and magical sites they encounter during rescue operations
- Has excellent relationships with Cid (kindred spirit in pursuit of knowledge) and Nireya (shared respect for magic despite philosophical differences)
- More structured and academic in her approach to magic compared to other practitioners
- Sometimes engages in respectful philosophical arguments about "pushing boundaries to learn more" versus "accepting magic as simply part of life's natural order"

### Public Perception
- Known as the "Weather Mage," with rumors of her magic being unpredictable and having a mind of its own, sometimes with unintended consequences.
- Her phoenix familiar is a source of both awe and unease, seen by some as a sign of good luck and by others as a sign of meddling with dangerous forces.
- Respected for her brilliant mind and academic approach to magic, often working with Vera to track and locate missing persons.


---

# Lyralei Stormcaller - Background

## Origin
- **Birthplace**: TBD (likely an elven community with strong connections to arcane studies)
- **Birth Date**: TBD
- **Social Class**: Likely scholarly or academic class
- **Cultural Background**: Elven with focus on magical scholarship

## Family
- **Parents**: TBD
- **Siblings**: TBD
- **Extended Family**: TBD
- **Family Dynamics**: TBD

## History
- **Childhood**: 
  - *Key Events*: Likely showed early aptitude for elemental magic, particularly weather-related phenomena
  - *Formative Experiences*: Early education in magical theory
  
- **Education/Training**: 
  - *Institutions*: Formal magical academy or university focusing on elemental and theoretical magic
  - *Mentors*: Various magical scholars and researchers (specific names TBD)
  - *Areas of Study*: Weather magic, planar theory, elemental manipulation
  
- **Professional Career**:
  - *Early Research*: Initial studies in conventional weather magic
  - *Specialization*: Development of interest in planar convergence theory
  - *Breakthrough*: Discovery of theoretical connections between weather magic and planar convergence points
  - *Expedition Work*: Field research at various planar convergence sites
  
- **Major Life Events**:
  - *The Dimensional Accident*: During an expedition to a volatile convergence site, attempted to channel the intersection of the Elemental Planes of Air, Water, and Fire simultaneously
  - *Interdimensional Trapping*: The experiment created unexpected planar instabilities that temporarily trapped her between dimensions
  - *Phoenix Encounter*: While trapped between planes, discovered her phoenix familiar who guided her back to the material plane
  - *Recovery and Research*: Continued studies with new insights from interdimensional experience
  - *Joining the Last Light Company*: Sought out the company believing their rescue operations brought them into contact with planar anomalies and ancient magical sites needed for her research

## Backstory Elements
- **Defining Moments**: 
  - The dimensional accident and subsequent survival
  - Discovery of her phoenix familiar
  - First successful application of planar convergence theory to weather magic
  
- **Past Trauma**: 
  # Lyralei Stormcaller - Background

## Origin
- **Birthplace**: TBD (likely an elven community with strong connections to arcane studies)
- **Birth Date**: TBD
- **Social Class**: Scholarly / Academic
- **Cultural Background**: Elven with focus on magical scholarship

## History
- **The Radical Theory**: As one of the academy's most promising weather wizards, Lyralei grew frustrated with the limitations of her field. She developed a radical theory: to truly master weather, one must understand its ultimate source—the "harmonic echoes" of events from other planes vibrating through the Weave. She began to dabble in broader elemental and planar magic, not as a new focus, but as a necessary means to deepen her understanding of meteorology. Her mentor, Master Valerius, respected her ambition but feared her methods.

- **The Experiment & The Phoenix**: To prove her theory, she used an abandoned observatory on a convergence point tied to the Plane of Fire—the nascent territory of a young phoenix, Quill. Her attempt to "strum the Weave" succeeded catastrophically, proving her theory while tearing a hole in reality. The resulting magical chaos threatened both her and the phoenix. In an act of mutual self-preservation, Quill bonded with her, its cyclical energy of rebirth stabilizing the event and pulling her back from the void. This was Quill's first, premature rebirth, and it tied them together permanently, leaving the lightning-like scar on Lyralei's face.

- **The Aftermath**: Lyralei returned scarred but with invaluable data. Her reaction was not one of horror, but of academic fascination. The academy, led by a somber Master Valerius, acknowledged the brilliance of her discovery but could not condone the danger of her methods. With a heavy heart on both sides, it was mutually agreed that she must leave. "The truth you seek is valid, Lyralei," Valerius told her, "but the path to it is too dangerous for these walls to contain." She departed not as a failure, but as a pioneer who had outgrown the confines of traditional academia.

## Backstory Elements
- **Defining Moments**: 
  - The dimensional accident that proved her theory but forced her from the academy.
  - The symbiotic bonding with her phoenix familiar, Quill.
  
- **Past Trauma**: She views the accident as a successful, if costly, experiment rather than a trauma. Her primary regret is the loss of the observatory, a valuable historical site.

- **Greatest Achievements**: 
  - Advancing magical theory in a significant way.
  - Forming a bond with a phoenix.

## How They Got Here
- **Reason for Current Situation**: After leaving the academy, Lyralei sought a way to continue her field research. The Last Light Company, with its focus on missions to dangerous and ancient locations, represents the perfect opportunity to gather more data on planar convergence and weather phenomena.

## Historical Connections
- **Connection to Main Plot**: Magical Support for the Last Light Company.
- **Connection to Other Characters**: 
  - **Aldwin Gentleheart**: She knew him from the academy. He found her detached then, but now sees the profound change in her, viewing her with a healer's compassion.
  - **Cid Vexweld**: Views Cid as a kindred spirit in the relentless pursuit of knowledge, though their methods differ wildly.
  - **Nireya Voss**: Shares a respectful admiration for magic, though they sometimes have philosophical disagreements.

## Timeline
- Early career as a promising weather wizard at a prestigious academy.
- Develops her radical theory on planar harmonics.
- Conducts the fateful experiment at the abandoned observatory.
- Bonds with Quill and is forced to leave the academy.
- Joins the Last Light Company to continue her field research.

## Personal Details
- **How She Relaxes**: She finds calm in creating intricate, temporary weather systems in a bottle.
- **Favorite Meal**: Spiced Air-Popped Sorghum with a side of lightning-seared fish.
- **A Unique Habit**: She can accurately "smell" the weather, a sensory side-effect of her deep attunement to atmospheric magic.

  - Possibly academic rejection of her theories before proving them
  
- **Greatest Achievements**: 
  - Surviving interdimensional trapping
  - Advancing planar convergence theory
  - Creating new weather magic techniques based on ancient texts
  
- **Biggest Failures**: 
  - The experiment that went wrong, though she views it as a learning experience rather than failure
  - Potentially other magical experiments with unexpected results
  
- **Secrets**: 
  - May have deeper knowledge of the planes than she reveals
  - Possibly a special connection to her phoenix familiar beyond what others understand

## How They Got Here
- **Reason for Current Situation**: 
  - Academic interest in planar anomalies encountered during Last Light Company missions
  - Belief that the Company's rescue work will give her access to magical sites and phenomena needed for her research
  
- **Path to Current Location**: 
  - Academic study in weather magic
  - Development of planar convergence theories
  - The dimensional accident and phoenix encounter
  - Seeking out the Last Light Company for their access to unique magical sites
  
- **Goals Prior to Story Start**: 
  - Advancing understanding of planar convergence theory
  - Documenting ancient magical techniques
  - Developing new applications for weather magic

## Historical Connections
- **Connection to Main Plot**: Magical Support for the Last Light Company
- **Connection to Other Characters**: 
  - Views Cid as kindred spirit in the pursuit of knowledge
  - Shares respectful admiration for magic with Nireya, though they sometimes have philosophical disagreements
  
- **Connection to Story World**: 
  - Knowledge of planar anomalies
  - Understanding of ancient magical techniques
  - Experience with interdimensional spaces

## Timeline
- Early magical education and training
- Specialization in weather magic
- Development of interest in planar convergence theory
- Research into ancient magical texts describing forgotten techniques
- Expedition to volatile convergence site
- The dimensional accident and trapping between planes
- Discovery of phoenix familiar and return to material plane
- Continued research with new insights
- Learning of the Last Light Company's activities
- Joining the Company to further research while providing magical support

## Philosophical Development
- Initially focused on pure academic knowledge
- Experience between dimensions gave her unique perspective on magical theory
- Developed pragmatic view of magical experimentation risks
- Believes in pushing magical boundaries for greater understanding
- Sometimes engages in philosophical debates about the balance between "pushing boundaries to learn more" versus "accepting magic as simply part of life's natural order"
- Values hands-on experimentation over pure theory

## Personal Details
- **How She Relaxes**: She finds calm in creating intricate, temporary weather systems in a bottle. Using a large, sealed glass carboy, she will spend hours meticulously layering enchanted vapors and elemental motes to create miniature thunderstorms, swirling blizzards, or tiny, self-contained rainbows. It's a form of magical art that is both a complex academic exercise and a source of quiet, aesthetic pleasure.
- **Favorite Meal**: Spiced Air-Popped Sorghum with a side of lightning-seared fish. The sorghum is a light, almost flavorless grain that she pops using a precise application of superheated air. The fish is cooked in an instant with a contained bolt of lightning. It's less about the taste and more about the process—a meal prepared with the very elements she studies.
- **A Unique Habit**: She can accurately "smell" the weather. Before a rainstorm, she'll often comment on the scent of ozone and petrichor long before anyone else notices a cloud. Before a snowfall, she'll mention a crisp, metallic tang in the air. It's a sensory side-effect of her deep attunement to atmospheric magic.


---

# Lyralei Stormcaller - Character Development

## Personality Core
- **Defining Traits**: Analytical, curious, structured, knowledge-seeking
- **Core Values**: Academic discovery, advancing magical understanding, practical application of theory
- **Motivations**: Uncovering lost magical knowledge, proving planar convergence theories, documenting magical phenomena
- **Fears**: Being permanently trapped between planes, having theories dismissed without evidence
- **Internal Conflicts**: Academic pursuit vs. practical application, pushing boundaries vs. safety
- **Contradictions**: Structured academic approach with willingness to take calculated magical risks

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Academic researcher with innovative theories
  - *World View*: Knowledge must be pursued even with risks
  - *Key Relationships*: Primarily academic connections
  
- **Catalyst Events**:
  - *Event 1*: Discovery of planar convergence theory applications to weather magic
  - *Event 2*: Interdimensional accident and trapping between planes
  - *Event 3*: Rescue by phoenix familiar
  - *Event 4*: Joining the Last Light Company
  
- **Current State**:
  - *Self-Perception*: Magical theorist with unique interdimensional experience
  - *World View*: Balanced perspective on risk and reward in magical research
  - *Key Relationships*: Developing connections within Last Light Company, especially with Cid and Nireya
  
- **Intended Destination**:
  - *Self-Perception*: TBD - possibly recognized authority on planar magic
  - *World View*: TBD - potentially more integrated view of academic and practical magic
  - *Key Relationships*: TBD - deeper integration with Last Light Company

## Growth Milestones
- **From Academic to Field Researcher**: 
  - *Development Noted*: Shift from pure theory to practical application
  - *Catalyst*: Early field expeditions to convergence sites
  - *Impact*: More balanced approach to magical research
  
- **Interdimensional Experience**: 
  - *Development Noted*: Gaining unique perspective on planar magic
  - *Catalyst*: Being trapped between dimensions
  - *Impact*: First-hand knowledge of interdimensional space, bond with phoenix familiar
  
- **Joining Last Light Company**: 
  - *Development Noted*: Application of magical knowledge to rescue operations
  - *Catalyst*: Recognition that the Company encounters unique magical phenomena
  - *Impact*: Expanding research while contributing to meaningful work

## Character Flaws
- **Academic Tunnel Vision**: 
  - *Effects on Character*: May prioritize research goals over other considerations
  - *Effects on Others*: Could create friction with more pragmatic team members
  - *Development Plan*: Learning to balance research with team priorities
  
- **Calculated Risk-Taking**: 
  - *Effects on Character*: Willingness to face magical dangers for knowledge
  - *Effects on Others*: Might put team in uncertain magical situations
  - *Development Plan*: Developing better risk assessment that includes team safety

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Possibly deeper understanding of planes than she reveals
  - *Secret 2*: Specific nature of bond with phoenix familiar
  
- **Unknown to Character**:
  - *Truth 1*: Full implications of her interdimensional experience
  - *Truth 2*: Potential unintended consequences of her magical experiments
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Pursuing Planar Convergence Theory**:
  - *Context*: Early academic career
  - *Options Considered*: Conventional magical research vs. unconventional theory
  - *Choice Made*: Focused on controversial planar theory
  - *Consequences*: Led to new magical discoveries but also to the dimensional accident

- **The Triple-Planar Channeling Experiment**:
  - *Context*: Field research at convergence site
  - *Options Considered*: Safer approach vs. ambitious experiment
  - *Choice Made*: Attempted to channel three elemental planes simultaneously
  - *Consequences*: Trapped between dimensions but also discovered phoenix familiar

- **Joining Last Light Company**:
  - *Context*: Post-interdimensional experience
  - *Options Considered*: Return to academia vs. field work with Company
  - *Choice Made*: Joined Company for access to magical phenomena during rescues
  - *Consequences*: Applied knowledge in practical settings, developing new relationships

## Development Notes
- Character represents the balance between academic knowledge and practical application
- The phoenix familiar symbolizes rebirth from her interdimensional experience
- Her changing hair and eyes reflect her connection to weather magic and emotional states
- The lightning scar is a physical reminder of her experience between planes
- The philosophical debates with Nireya highlight different approaches to magic
- Her relationship with Cid demonstrates intellectual kinship
- Her pragmatic view of the dimensional accident ("occupational hazard") shows her dedication to knowledge
- Future development could explore consequences of pushing magical boundaries

## Psychological Profile
*   **Lyralei Stormcaller (The Academic):** Lyralei is driven by an insatiable intellectual curiosity. To her, magic is not a mystical force, but a complex, fascinating system to be studied, catalogued, and understood. Her dimensional accident was not a trauma, but an "unexpected field experiment." She is logical and analytical, sometimes to a fault, and may view emotional responses as inefficient variables. She seeks knowledge for its own sake, and the Company provides her with an endless supply of unique magical phenomena to study.


---

# Lyralei Stormcaller - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Magical Support specialist
  - *Hierarchy*: Respects Veyra's leadership while contributing specialized magical knowledge
  - *Dynamics*: Likely values Veyra's mission to leave no one behind, while Veyra appreciates Lyralei's unique magical capabilities
  - *History*: TBD when they first met
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her leadership and dedication

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Magical Support specialist
  - *Hierarchy*: Respects chain of command while offering magical expertise
  - *Dynamics*: Potentially appreciates his tactical approach but may occasionally have different perspectives on magical matters
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely respects his military discipline but might sometimes find it at odds with magical research needs

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist in Last Light Company
  - *Hierarchy*: Equals with different areas of expertise
  - *Dynamics*: Lyralei's weather magic might complement Vera's tracking abilities
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her tracking skills, may be interested in how they could be enhanced with weather magic

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (magical support and medical)
  - *Dynamics*: Might collaborate on treatments that combine magic and medicine
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely appreciates his healing skills and calm demeanor

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (magical support and heavy rescue)
  - *Dynamics*: Her weather magic could help in creating safe conditions for his rescue operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his experience and practical expertise

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (magical support vs. negotiation)
  - *Dynamics*: Her weather magic might support his diplomatic efforts by creating appropriate atmospheric conditions
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates his diplomatic skills and strategic thinking

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Intellectual synergy; "The Theorist and the Practitioner."
  - *Hierarchy*: Equals and intellectual partners.
  - *Dynamics*: Lyralei understands the deep, theoretical principles of magic, while Cid is a genius at applying those principles in unconventional ways. Lyralei might spend a week researching a complex planar convergence theory, and Cid will listen for five minutes and say, "So, what you're saying is, if I build a harmonic resonator attuned to that frequency, I can make a portable hole-puncher?" They spend hours in Cid's workshop, surrounded by arcane diagrams and half-finished inventions, pushing the boundaries of what's possible.
  - *History*: TBD
  - *Current Status*: Close friends and research partners.
  - *Feelings Toward*: Deep admiration for Cid's practical genius and innovative spirit.

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Intellectual sparring partner; The Architect to her Storm.
  - *Hierarchy*: Peers and masters of opposing, yet complementary, domains.
  - *Dynamics*: Lyralei is deeply fascinated by Korrath's mastery of the physical world. She genuinely admires his ability to impose such elegant order and enduring structure upon it. However, she fundamentally believes all such structures are temporary—beautiful, defiant gestures against the inevitable entropy she communes with daily. Their interactions are a constant, good-natured philosophical debate.
  - *History*: Their bond likely formed during the construction of the Bastion, particularly the Aerie, where his precise engineering had to meet her arcane requirements.
  - *Current Status*: A strong, intellectual friendship built on mutual respect and playful antagonism.
  - *Feelings Toward*: She has immense respect for his intellect and craft. She sees his work as a noble and beautiful struggle against the chaos she represents, a struggle he is destined to lose.
  - *Signature Quip*: (After admiring one of his constructions) "It's a beautiful thought. But eventually, the elements always win."

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (magical support vs. infiltration)
  - *Dynamics*: Her weather magic might provide cover for Kaida's infiltration activities
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her professional competence and precise methods

- **Nireya Voss**:
  - *Nature of Relationship*: Philosophical divide.
  - *Hierarchy*: Equals.
  - *Dynamics*: Lyralei sees magic as a science to be dissected and understood. Nireya experiences it as an intuitive, spiritual reality. They have fascinating, respectful debates. Lyralei might try to quantify Nireya's abilities with arcane instruments, while Nireya might gently suggest that some things are meant to be felt, not measured. They are two sides of the same mystical coin, and their conversations push both of them to consider their own beliefs more deeply.
  - *History*: TBD
  - *Current Status*: A strong intellectual friendship built on mutual respect for their different paths to understanding.
  - *Feelings Toward*: Deep respect for Nireya's unique connection to the unseen world, even if she doesn't fully understand it.

## Academic/Research Connections

## Planar Connections
- **Phoenix Familiar**:
  - *Relationship Type*: Magical familiar, guide, possibly savior
  - *History*: Met when Lyralei was trapped between dimensions, guided her back to the material plane
  - *Current Status*: Constant companion
  - *Dynamics*: Deep magical bond forged in interdimensional space
  - *Tensions/Issues*: Possibly knows more about the multiverse than Lyralei fully understands
  - *Shared Experiences*: The interdimensional journey back to the material plane

## Academic Community
- **Former Mentors/Colleagues**:
  - *Relationship Type*: Academic connections
  - *History*: Education and early research
  - *Current Status*: Likely maintains some connections through correspondence
  - *Dynamics*: May have mixed responses to her current theories and experiences
  - *Tensions/Issues*: Possible skepticism from some regarding her planar theories

## Interpersonal Patterns
- **Approach to Authority**:
  - Respects proven expertise and leadership
  - Values authority based on knowledge and capability
  - May occasionally prioritize research goals over strict hierarchical commands

- **Collaborative Style**:
  - Brings specialized magical knowledge to team efforts
  - Likely offers weather-based solutions to tactical problems
  - Academic approach may sometimes need translation to practical application

- **Conflict Resolution**:
  - Probably addresses disagreements through intellectual debate
  - Uses evidence and theory to support positions
  - May need to work on understanding emotional aspects of conflicts

## Relationship Evolution Tracker
- **Pre-Company**: Academic relationships, research community
- **Early Company Days**: Initial professional relationships with team members
- **Current**: Developing working relationships, especially with Cid and Nireya
- **Future Development Potential**: TBD

## Notes on Potential Relationships
- Her weather magic could complement many team members' abilities
- Academic approach may create both respect and occasional friction
- Phoenix familiar could be point of interest/mystery for other team members
- Interdimensional experience gives her unique perspective that may affect relationships


---

# Lyralei Stormcaller — Dialogue & Psyche

## Core temperament
Measured, curious, and precise. A scholar of patterns and weather; speaks with an elven clarity that treats magic as craft and inquiry.

## Dialogue instincts
- Public: calm, slightly formal; explains arcane phenomena with analogies to weather and currents.
- Teaching/analysis: patient, methodical—lays out observation, inference, conclusion in ordered turns.
- Under pressure: voice remains calm; chooses exact language to avoid panic-driven mistakes.
- Humor: wry, often metaphoric; enjoys clever turns of phrase tied to wind and sky.

## Emotional anchors & physical tells
- Hands weave small gestures as if tracing currents in the air; fingers twitch when invoking minor wards.
- Eyes track small changes (light, humidity); a lifted brow signals new insight.
- A soft exhale accompanies successful calculations; abrupt inhalation indicates something unsettled.

## Conflict & humor rules
- Avoids flippancy about planar or mystical dangers; treats such topics with respectful curiosity.
- Will deflate grandstanding with a precise correction or a weather simile.
- Uses light, intellectual irony to defuse tense conversations, not coarse joking.

## Writer cues (practical)
- Use Lyralei to explain magical or environmental causes succinctly; keep explanations anchored in sensory metaphors (wind, pressure, needle of rain).
- When inserting lines, maintain an ordered logic in her speech: observation → analogy → recommendation.
- Pair technical lines with a small physical gesture of measurement (sweeps, pinches of air, examining a gauge).

## Drop-in sample lines
- Observation/explain: "The ley-thread here hums like a taut wire—tension increasing toward the east."
- Tactical advise: "Winds will favor a southern egress in three breaths. Time the lift with my signal."
- Comforting/curious: "There are patterns to grief as there are to storms. We read them the same: patiently."

## Voice evolution note (chapters 1–9)
- Starts as an aloof specialist with academic distance; increasingly bonds with the Company as she sees practical application for her study.
- Moves from theoretic aside to pragmatic partner—keeps curiosity but learns to value steady companionship.

## Usage examples (scenes)
- In briefings: offers short, clarifying metaphors and precise timing recommendations.
- During magic use: speaks calmly, using ordered clauses that keep teammates synchronized.
- In quiet moments: reflective lines that tie natural cycles to human resilience.

## Notes for editors
- Keep Lyralei's language precise and image-driven (wind/pressure/current). Avoid making her exposition long-winded—break into small turns.


---

# Lyralei Stormcaller - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD

## Potential Flashback Scenes
- **The Interdimensional Accident**: 
  - *Brief Description*: The experiment at the convergence site that went wrong
  - *Significance*: Shows her willingness to take risks for knowledge and the origin of her phoenix familiar
  - *Character's Goal*: Channel multiple elemental planes simultaneously
  - *Outcome*: Trapped between dimensions but discovered phoenix familiar
  - *Emotional State*: Initial panic giving way to scientific curiosity and eventual acceptance
  
- **Academic Discovery**: 
  - *Brief Description*: First discovering the potential applications of planar convergence theory
  - *Significance*: Catalyst for her specialized research path
  - *Character's Goal*: Find new applications for weather magic
  - *Outcome*: Development of groundbreaking magical theory
  - *Emotional State*: Intellectual excitement and vindication

## Character Moments
- **Best Moments**:
  - *Scene Reference*: TBD
  - *Description*: Successfully applying planar convergence theory to a practical problem
  - *Impact*: Validation of her research and approach
  
- **Worst Moments**:
  - *Scene Reference*: TBD
  - *Description*: Potentially facing a situation similar to her interdimensional accident
  - *Impact*: Confronting past trauma and fear
  
- **Turning Points**:
  - *Scene Reference*: TBD
  - *Description*: Decision to join Last Light Company
  - *Before/After Effect*: Shift from pure research to practical application
  
- **Revelations**:
  - *Scene Reference*: TBD
  - *What Was Revealed*: Perhaps deeper truth about interdimensional experiences
  - *Impact*: New understanding of her abilities or condition

## Interaction Log
- **With Veyra Thornwake**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Offering magical support during mission
  - *Outcome*: TBD
  - *Relationship Effect*: TBD
  
- **With Cid**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Discussion of magical theory or research
  - *Outcome*: TBD
  - *Relationship Effect*: TBD
  
- **With Nireya**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Philosophical debate about magical boundaries
  - *Outcome*: TBD
  - *Relationship Effect*: TBD

## Magic/Weather Scenes
- **Weather Manipulation**:
  - *Environmental Conditions*: TBD
  - *Magic Applied*: Weather magic to create advantageous conditions
  - *Challenges*: TBD
  - *Outcome*: TBD
  - *Character Growth*: TBD
  
- **Planar Detection**:
  - *Setting*: Area with planar anomalies
  - *Knowledge Applied*: Interdimensional experience allowing her to sense planar disturbances
  - *Critical Decision*: TBD
  - *Outcome*: TBD

## Phoenix Familiar Interactions
- **Communication Scene**:
  - *Context*: TBD
  - *Familiar's Role*: Providing insight or warning
  - *Information Revealed*: TBD
  - *Outcome*: TBD
  
- **Magical Assistance**:
  - *Context*: Challenging magical situation
  - *Familiar's Action*: Amplifying or guiding Lyralei's magic
  - *Result*: TBD
  - *Impact on Relationship*: TBD

## Research Scenes
- **Ancient Text Study**:
  - *Discovery*: Information about forgotten weather magic techniques
  - *Application*: TBD
  - *Challenges*: TBD
  - *Outcome*: TBD
  
- **Planar Convergence Investigation**:
  - *Location*: Site with unusual magical properties
  - *Observations*: Signs of multiple elemental planes touching
  - *Discoveries*: TBD
  - *Implications*: TBD

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*: TBD
  - *Key Quotes*: TBD
  - *Subtext*: TBD
  - *Impact*: TBD

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*: TBD
  - *Ending Emotion*: TBD
  - *Catalyst for Change*: TBD
  - *Visible Signs*: Hair and eye color shifts reflecting emotional state

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
*Potential scenes could include:*
- *Weather manipulation during a rescue operation*
- *Detection of a planar anomaly during a mission*
- *Academic debate with another magical practitioner*
- *Phoenix familiar revealing new information about the planes*
- *Application of theoretical knowledge to solve practical problem*
- *Moment where her hair/eyes dramatically reflect emotional state*
- *Discovery of ancient weather magic site or text*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Lysander Valerius

# Lysander Valerius – Profile

## Basic Information
- Full Name: Lysander Valerius
- Aliases/Nicknames: None mentioned
- Age: Approximately 25-30 (at time of death)
- Gender: Male
- Role in Story: Veyra's closest friend and party leader, sacrificial hero
- First Appearance: Chapter 1, Scene 1 (Twilight on the Rim)
- Status: Deceased (Undershade Canyon)

## Physical Description
- Height/Build: Strong enough to hold back molten glass with shield
- Hair: Not specified
- Eyes: "Steady eyes" mentioned, bright with command
- Distinguishing Features: Gilt rivets on his jack (armor)
- Typical Clothing: Military-style jack with decorative elements befitting minor nobility
- Body Language: Natural leader, confident bearing, measured tread
- Physical Condition: Athletic, combat-trained

## Significance
Lysander Valerius was the charismatic leader of the Gilded Compass and son of a Waterdhavian noble. His sacrifice to create an escape route for his companions represents the ultimate expression of the "no one left behind" ethos that would later define the Last Light Company. His shield boss becomes part of the Company's heraldry, and his death serves as both tragedy and inspiration for Veyra's mission.

## Death Scene
Sacrificed himself by using his shield to wedge open a closing escape route through molten glass, then deliberately collapsed the floor to create a temporary opening for his companions. His final look to Veyra carried the command: "Live. Remember. Rescue."

## Legacy
- Shield boss recovered and incorporated into Company heraldry
- Name inscribed in the Hall of Remembrance
- His sacrifice embodies the Company's core values
- Connection to House Valerius (relation to Lord Arion Valerius unclear)


---

# Lysander Valerius - Background

## Origin
- **Birthplace**: Waterdeep
- **Social Class**: Minor nobility, son of a Waterdhavian noble.
- **Cultural Background**: Raised with the expectations and education of a noble house, but with a strong personal interest in the heroic traditions of the past.

## History
- **Professional Career**: The founder and charismatic leader of the Gilded Compass adventuring party. He brought the team together, funding their expeditions and providing them with a shared purpose.
- **A Noble Pursuit**: Lysander was a student of ancient history and mythology. He wasn't just an adventurer; he was a scholar seeking to walk in the footsteps of the heroes he'd read about. He believed that the old tales were not just stories, but manuals for living a life of honor. He founded the Gilded Compass with the ambition of creating a new generation of heroes worthy of the old songs.

## Personal Details
- **How He Relaxed**: He was a gifted lute player. In the evenings, he would often play quiet, thoughtful melodies that he composed himself. Unlike a boisterous tavern bard, his music was reflective and often a bit melancholy, a private space where he processed the burdens of leadership and the dangers his friends faced.
- **Favorite Meal**: Roast Duck with a cherry reduction sauce. It was a taste of the noble life he came from, but he insisted on preparing it himself over a campfire. This act of preparing a fine meal in a humble setting was his way of bridging the gap between his noble birth and his chosen life, sharing a piece of his world with the companions he considered his true family.


---

# Lysander Valerius - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Lysander Valerius - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Lysander Valerius - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Lysander Valerius - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Marcus Heartbridge

# Marcus "The Voice" Heartbridge - Profile

## Basic Information

- **Full Name**: Marcus Heartbridge
- **Aliases/Nicknames**: "The Voice", "The Fixer"
- **Race**: Human
- **Class**: Bard
- **Role in Story**: Negotiator & Morale Officer for the Last Light Company
- **First Appearance**: Chapter 12
- **Status**: Active

## Physical Description

- **Height/Build**: Average height with poised, confident posture
- **Hair**: Well-styled for court appearances while remaining practical for field work
- **Eyes**: TBD
- **Distinguishing Features**: Immaculate appearance regardless of circumstances
- **Typical Clothing**:
  - Well-tailored doublets in rich fabrics
  - Polished boots
  - Formal yet practical cloak
  - Hidden features in clothing:
    - Cufflinks that double as lockpicks
    - Signet ring with hidden compartment
    - Belt buckle that functions as a listening device
    - Reinforced fabrics for protection
    - Multiple hidden pockets
- **Body Language**: Smooth confidence, equally at ease in noble courts or shadowy back alleys
- **Physical Condition**: Well-maintained, likely agile and dexterous

## Visual References

- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Marcus Heartbridge.

## Personality

- **Archetype**: The Diplomat/Fixer
- **Temperament**: Pragmatic, adaptable, resourceful
- **Positive Traits**: Persuasive, detail-oriented, solution-focused
- **Negative Traits**: Potentially willing to compromise ethics for results
- **Moral Alignment**: Chaotic Good (focuses on results that help people, flexible on methods)

## Skills & Abilities

- **Expertise**:
  - Negotiation and diplomacy
  - Information gathering
  - Political maneuvering
  - Bribery and persuasion
  - Lockpicking and infiltration (non-combat)
  - Knowledge of noble houses and trade laws
  - Record keeping
- **Languages**: Multiple, likely including trade languages and noble court dialects
- **Education Level**: Highly educated in diplomatic protocols, trade laws, and political systems
- **Special Abilities**:
  - Bardic magic focused on persuasion and influence
  - Extensive network of contacts and informants
  - Ability to analyze complex social situations for leverage points

## Personal Details

- **Habits**: Maintaining meticulous records in his enchanted journal
- **Hobbies**: TBD
- **Personal Quarters**: A luxurious, two-room suite in a quiet wing of the Establishment building, soundproofed with heavy tapestries. The antechamber is a comfortable salon with several plush armchairs, a low table, and a well-stocked bar cart featuring rare wines and spirits. The inner room contains a large, canopied bed and a handsome mahogany writing desk. The walls are hung with rich, sound-dampening tapestries depicting historical negotiations and trade agreements. This suite is a tool of his trade. The salon is his "soft" office, where he builds rapport with contacts over a glass of fine brandy, extracting information through casual conversation. The inner room is his private sanctum. The desk is for his official correspondence, but a cleverly hidden panel in the desk reveals a smaller, more discreet set of tools: invisible inks, coded ledgers, and a collection of wax seals from various noble houses and guilds. He uses this space to be the man the Company needs him to be, balancing the public face with the private machinations.
- **Likes**: Successful negotiations, elegant solutions to complex problems
- **Dislikes**: Brute force approaches when subtlety would work, rigid thinking
- **Fears**: TBD
- **Motivations**: Solving complex diplomatic problems, applying his skills for meaningful outcomes

## Combat & Tactics
- **Primary Weapon**: Enchanted rapier with ornate handguard containing hidden compartments for poisons, lockpicks, and message scrolls
- **Secondary Weapon**: Words - considers verbal manipulation his most lethal tool
- **Hidden Arsenal**: Sleeve-mounted hand crossbow, cufflink lockpicks, signet ring with hidden compartment, belt buckle listening device
- **Armor**: Formal attire with subtle reinforcements woven into rich fabrics - protection that looks like fashion
- **Fighting Style**: Misdirection duelist - uses flourishes, conversation, and psychology to confuse opponents while striking
- **Signature Move**: "Diplomatic Immunity" - talks his way out of combat entirely, making opponents question why they wanted to fight
- **Combat Philosophy**: "A fight avoided is a victory achieved, but if combat is unavoidable, make it brief and profitable"
- **Tactical Role**: Social infiltrator and negotiator who opens doors with words that others would need crowbars for

## Psychological Response Matrix
- **In Crisis**: Immediately identifies all stakeholders, their motivations, and potential leverage points - treats every crisis like a negotiation
- **During Negotiation**: Already knows what everyone wants before they speak, three moves ahead in the conversation
- **Moral Dilemma**: Reframes ethical problems as negotiation puzzles with win-win solutions
- **Team Conflict**: Mediates by making each side believe they've won while serving the mission
- **Under Personal Attack**: Deflects with charm and humor while mentally filing information for future leverage
- **In Victory**: Networks with defeated opponents, turning enemies into future assets

## Voice & Dialogue Patterns
- **Speech Style**: Adjusts vocabulary, accent, and mannerisms to perfectly match his audience - chameleon-like adaptation
- **Signature Phrases**: 
  - "Let's find our mutual advantage"
  - "Hypothetically speaking..." (maintains plausible deniability)
  - "I'm sure we can reach an understanding"
- **Diplomatic Edge**: Speaks in hypotheticals, implies without stating, makes everything sound reasonable
- **Example Dialogue**: "Hypothetically, if one were to need passage through the Duke's checkpoint, one might mention the Duchess's birthday gala... purely as conversation, of course."
- **Perfect Partnership**: Completes Kaida's sentences, communicates through meaningful glances - "The Lock and The Key"
- **Emotional Tells**: Smile becomes more genuine when truly pleased, fingers drum when calculating

## Notes

- Approaches rescues like complex trade negotiations, analyzing all parties involved and finding leverage points
- Creates tension with Thorne due to their different approaches (by-the-book military vs. "whatever works")
- Partners effectively with Kaida on intelligence-gathering missions
- Sees bribes and unorthodox methods as practical tools to prevent bloodshed
- Maintains his regular diplomatic duties alongside his work with the Company
- Views hostage negotiations and trade agreements as fundamentally similar, just with different stakes
- First encountered the Company at the Wayward Compass inn while on an independent operation.

### Public Perception

- Known as "The Voice" or "The Fixer" who can talk his way out of any situation, even convincing a dragon to give up its hoard.
- Has an extensive network of contacts across all levels of society, from nobles to crime bosses.
- Works in a highly effective, almost silent partnership with Kaida Shadowstep for intelligence gathering and infiltration.


---

# Marcus "The Voice" Heartbridge - Background

## Origin
- **Birthplace**: Baldur's Gate, a city where coin and connections are the true rulers.
- **Social Class**: Minor nobility with significant influence in the merchant guilds.
- **Cultural Background**: A culture of pragmatic deal-making, where reputation is everything and information is a currency.

## Family
- **Parents**: Lord and Lady Heartbridge, respected figures in the Baldur's Gate Merchant Guild.
- **Siblings**: A younger sister, Seraphina, a talented but naive artist who is his one true blind spot.
- **Family Dynamics**: His family valued results over methods, teaching him early on that a well-placed word is often more effective than a show of force.

## History
- **Education & Mentorship**: Marcus was shaped by two opposing mentors. From **Master Aldric Fontaine**, a venerable diplomat, he learned protocol and the public face of power. From **"Whisper" Kess Nightmarket**, a notorious info-broker, he learned that information is the only real currency. This duality defines his career.
- **The Catalyst for his "Fixer" Career**: The turning point from pure diplomat to pragmatic fixer was the **Lian Extraction Case**. Hired by Lady Aris of Waterdeep to find her younger brother, Lian, who had fallen in with the **Silent Hand** slaver ring, Marcus found all official channels useless. The authorities lacked proof, and the political will to act was absent.
- **The Wayward Compass Incident**: His investigation led him to the Wayward Compass inn, where he was gathering intelligence on the Silent Hand's logistics, which he knew involved Zhentarim-supplied weapons. His goal was to find a route or timeline for the slavers' "spring shipment" to intercept it and rescue Lian. The arrival of the Last Light Company was an unforeseen opportunity. He de-escalated a conflict with local mercenaries by using information as a weapon, then decided to audition the Company by giving them a tip about a corrupt merchant in Stonebridge to test their competence for his real mission.

## Backstory Elements
- **Defining Moments**: 
  - Realizing official channels would fail to save his client, Lian, forcing him to seek unorthodox methods.
  - Deciding to test the Last Light Company as potential assets for his rescue operation.
- **Past Achievements**: 
  - A successful career as a public-facing diplomat for trade disputes.
  - Building a vast, covert network of contacts and informants.
- **Mentors/Influences**: 
  - **Master Aldric Fontaine**: A venerable diplomat who taught Marcus that "protocol prevents wars, and a diplomat's word is his bond."
  - **"Whisper" Kess Nightmarket**: A notorious information broker who taught Marcus that "information is the only real currency, and everyone has a price."

## How They Got Here
- **Reason for Current Situation**: He requires a team capable of direct, physical action to succeed where his own methods of subterfuge and negotiation are not enough.
- **Path to Current Location**: Diplomat -> Fixer -> Investigator of the Silent Hand -> Strategic alliance with the Last Light Company.
- **Goals Prior to Story Start**: 
  - Building his reputation as the go-to resource for delicate situations.
  - Perfecting his methods of non-violent conflict resolution.

## Historical Connections
- **Connection to Main Plot**: 
  - Serves as the Company's political and social interface.
- **Connection to Other Characters**: 
  - **Thorne**: Potential for tension between Thorne's by-the-book approach and Marcus's flexible methods.
  - **Kaida**: Potential to form an effective intelligence duo.

## Timeline
- Career as trade diplomat and noble house dispute negotiator.
- The Lian Extraction Case proves the limitations of traditional diplomacy.
- Establishes a dual career as a public diplomat and a discreet "fixer."
- Begins investigating the Silent Hand.
- First encounter with the Last Light Company at the Wayward Compass inn, where he offers the Stonebridge tip as an audition.

## Philosophical Development
- **Early Philosophy**: Believed in proper channels and protocols.
- **Catalyst for Change**: The Lian case showed the limitations of official methods.
- **Current Outlook**: Pragmatic approach where results matter more than methods.
- **Moral Framework**: Sometimes a well-placed bribe prevents bloodshed better than direct conflict.
- **Professional Ethics**: Believes in achieving the best outcomes through whatever means necessary, while minimizing harm.

## Personal Details
- **How He Relaxes**: He plays "The Great Game"—a city-wide, non-violent contest of influence and information played by a select few of Waterdeep's elite.
- **Favorite Meal**: Oysters on the half shell with a chilled glass of Tashlutan wine.
- **A Secret Vulnerability**: His younger sister, Seraphina. He secretly uses his network to protect her and advance her career.
- **A Private Pastime**: Calligraphy and Forgery. In private, he practices the art of calligraphy to perfectly replicate the handwriting of influential figures.
- **A Disarming Quirk**: For all his refined tastes, he is an absolute sucker for a simple, well-made sugar cookie.

---

# Marcus "The Voice" Heartbridge - Character Development

## Personality Core
- **Defining Traits**: Adaptable, pragmatic, diplomatic, resourceful
- **Core Values**: Results over process, discretion, effectiveness, preventing unnecessary conflict
- **Motivations**: Solving complex problems, maintaining dual professional identity, proving flexibility works better than rigidity
- **Fears**: Potential damage to diplomatic reputation, failure when lives are at stake
- **Internal Conflicts**: Traditional diplomatic protocols vs. unorthodox methods, personal ethics vs. practical necessities
- **Contradictions**: Polished courtier appearance with shadow operative capabilities, ethical principles with pragmatic methods

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Skilled diplomat limited by official channels
  - *World View*: Believed in traditional diplomatic processes with occasional flexibility
  - *Key Relationships*: Professional connections within noble houses and trade guilds
  
- **Catalyst Events**:
  - *Event 1*: Client kidnapping situation where traditional diplomacy failed
  - *Event 2*: First collaboration with the Last Light Company
  - *Event 3*: Decision to join Company while maintaining diplomatic career
  - *Event 4*: First major success using unorthodox methods to achieve rescue
  
- **Current State**:
  - *Self-Perception*: "Fixer" who can operate effectively in multiple worlds
  - *World View*: Results-oriented pragmatism, "the ends justify the means" when lives are at stake
  - *Key Relationships*: Dual network of official contacts and shadow connections, plus Company team
  
- **Intended Destination**:
  - *Self-Perception*: TBD - possibly full integration of dual identities
  - *World View*: TBD - refinement of moral framework around pragmatic methods
  - *Key Relationships*: TBD - deeper integration with Company members, especially resolving tension with Thorne

## Growth Milestones
- **From Traditional Diplomat to Flexible Negotiator**: 
  - *Development Noted*: Incorporating unorthodox methods into diplomatic toolkit
  - *Catalyst*: Early experiences where rule-following failed to achieve goals
  - *Impact*: More effective negotiations, but potential ethical compromises
  
- **From Client to Company Member**: 
  - *Development Noted*: Transition from hiring the Company to joining their operations
  - *Catalyst*: Witnessing the effectiveness of their direct approach
  - *Impact*: Expanded skill application beyond traditional diplomacy
  
- **From Independent Operator to Team Member**:
  - *Development Noted*: Learning to integrate his methods with the Company's approach
  - *Catalyst*: Successful collaborations, especially with Kaida
  - *Impact*: Enhanced effectiveness through combined capabilities

## Character Flaws
- **Moral Flexibility**: 
  - *Effects on Character*: Willingness to use bribes, deception, and manipulation
  - *Effects on Others*: Creates tension with more ethically rigid characters like Thorne
  - *Development Plan*: Finding balance between pragmatism and personal ethics
  
- **Potential Overconfidence**: 
  - *Effects on Character*: May take unnecessary risks based on belief in diplomatic skills
  - *Effects on Others*: Could endanger team members if negotiations fail
  - *Development Plan*: Learning humility and when to defer to others' expertise

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Extent of his underworld contacts and less savory methods
  - *Secret 2*: Details recorded in his enchanted journal that could compromise many
  
- **Unknown to Character**:
  - *Truth 1*: TBD - possible unintended consequences of his diplomatic compromises
  - *Truth 2*: TBD - perhaps someone from his past who knows too much about his methods
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **The Decision to Hire the Company**:
  - *Context*: Client kidnapping
  - *Options Considered*: Continue diplomatic channels vs. direct intervention
  - *Choice Made*: Hired the Last Light Company
  - *Consequences*: Changed career trajectory and worldview

- **Joining the Company Part-Time**:
  - *Context*: After successful rescue operation
  - *Options Considered*: Return to pure diplomacy vs. expand skills
  - *Choice Made*: Maintained diplomatic career while joining Company
  - *Consequences*: Dual professional identity, enhanced capabilities, moral complications

- **First Major Ethical Compromise**:
  - *Context*: TBD - perhaps a situation where a bribe or deception was necessary
  - *Options Considered*: Moral principles vs. practical necessity
  - *Choice Made*: Pragmatic approach over ethical idealism
  - *Consequences*: Successful outcome but personal ethical boundary crossed

## Development Notes
- Character represents the pragmatic, flexible approach to problem-solving
- The enchanted journal symbolizes both record-keeping precision and potential secrets
- Diplomatic attire with hidden tools reflects dual nature (open diplomat/shadow fixer)
- Tension with Thorne highlights philosophical differences in approach
- Partnership with Kaida shows complementary skills and methods
- "The Voice" nickname reflects both his diplomatic skills and bardic abilities
- Future development could explore consequences of moral compromises made

## Psychological Profile
*   **Marcus Heartbridge (The Fixer):** Marcus is a pragmatist who views the world as a complex web of leverage points and relationships. He is not immoral, but he is amoral in his methods; the ends (a successful rescue, a peaceful resolution) absolutely justify the means (bribery, manipulation, blackmail). He is a master of masks, equally comfortable in a noble's court and a criminal's den. His core belief is that the most elegant solution is the one that avoids bloodshed, and he sees his work as a form of high-stakes art.


---

# Marcus "The Voice" Heartbridge - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: First contact.
  - *Hierarchy*: N/A
  - *Dynamics*: Marcus likely sees Veyra as the clear leader of the group—pragmatic, dangerous, and driven. He would recognize her as the ultimate decision-maker and the one whose trust he needs to earn. His initial approach would be one of professional respect, demonstrating his value rather than asking for trust.
  - *History*: First met at the Wayward Compass inn in Chapter 12.
  - *Current Status*: Potential ally or contractor.
  - *Feelings Toward*: Intrigue and professional assessment. He sees a powerful, effective tool that he could potentially work with for mutual benefit.

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: First contact.
  - *Hierarchy*: N/A
  - *Dynamics*: Marcus would immediately identify Thorne as a professional soldier, likely former city guard or military. He would anticipate suspicion and a rigid, by-the-book mindset. This is the person he needs to win over with logic and results, not just charm. The potential for future friction is high, but so is the potential for professional respect if Marcus can prove his methods are effective.
  - *History*: First met at the Wayward Compass inn in Chapter 12.
  - *Current Status*: Wary observer.
  - *Feelings Toward*: Acknowledges his professional competence but sees him as a potential obstacle to more... flexible solutions.

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist with complementary skills
  - *Hierarchy*: Equals with different areas of expertise
  - *Dynamics*: Her tracking abilities pair well with his social intelligence gathering
  - *Professional Opinion of*: Appreciation for her skills that operate in different domains than his own

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Confidants; "The Cynic and the Believer."
  - *Hierarchy*: Equals.
  - *Dynamics*: Marcus, a pragmatist who often has to do morally gray things for the greater good, seeks out Aldwin after particularly difficult missions, not to confess, but to recalibrate. He sits for a tea ceremony, and Aldwin's quiet, non-judgmental presence allows Marcus to reconnect with the "why" of their mission, cleansing his palate from the dirty work he has to do.
  - *History*: TBD
  - *Current Status*: A quiet, deeply important confidential relationship.
  - *Feelings Toward*: He deeply respects Aldwin as the Company's moral compass and finds his presence centering.

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (negotiation and heavy rescue)
  - *Dynamics*: TBD
  - *Professional Opinion of*: TBD
  
- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Different specialties (negotiation and magical support)
  - *Dynamics*: TBD
  - *Professional Opinion of*: TBD

- **Cidrella "Cid" Vexweld**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (negotiation vs. technical)
  - *Dynamics*: His diplomatic skills might help resolve technical complications while her innovations support his operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her technical problem-solving and innovative approach

- **Korrath "Wallbreaker" Threnx**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (negotiation vs. engineering)
  - *Dynamics*: His diplomatic skills complement Korrath's systematic engineering approach
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his methodical approach and engineering expertise

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Intelligence gathering partner; "The Lock and The Key."
  - *Hierarchy*: Equals and partners.
  - *Dynamics*: Theirs is a partnership of pure, silent professionalism. They communicate in half-sentences and shared glances. Marcus gathers the social intelligence, learning the secrets and schedules of a target. He is "The Key" who finds the right moment to turn. Kaida then uses that information for the physical infiltration. She is "The Lock" that can be opened. There is a deep, unspoken understanding between them, as they are the two members who most comfortably operate in the world's gray areas.
  - *History*: TBD
  - *Current Status*: The Company's primary intelligence and infiltration team.
  - *Feelings Toward*: Immense professional respect. He sees her as a master artist in a different medium and trusts her competence implicitly.

## Diplomatic Network
- **Noble Houses**:
  - *Relationship Type*: Professional negotiator and mediator
  - *History*: Long history of settling disputes between houses
  - *Current Status*: Maintains professional relationships with multiple noble families
  - *Dynamics*: Respected for discretion and results, though some may be wary of his methods
  - *Tensions/Issues*: Likely has both allies and enemies among the nobility

- **Merchants and Trade Guilds**:
  - *Relationship Type*: Negotiator for commercial agreements
  - *History*: Established reputation for fair and effective trade negotiations
  - *Current Status*: Active consultant on trade disputes
  - *Dynamics*: Valued for ability to create mutually beneficial arrangements
  - *Tensions/Issues*: TBD

- **City Officials and Guards**:
  - *Relationship Type*: Professional contact with occasional under-the-table arrangements
  - *History*: Built connections for permits and overlooking minor infractions
  - *Current Status*: Maintains network of officials who can be called upon when needed
  - *Dynamics*: Knowledge of who can be bribed and who must be handled through official channels
  - *Tensions/Issues*: Walks fine line between legitimate diplomacy and corruption

- **Underworld Contacts**:
  - *Relationship Type*: Information sources and occasional collaborators
  - *History*: Gradually built network of less reputable but highly useful contacts
  - *Current Status*: Maintains arms-length relationships with various underworld figures
  - *Dynamics*: Mutual benefit arrangement - information exchange, occasional services
  - *Tensions/Issues*: Risk to reputation if these connections became widely known

## Personal Relationships
- **Former Client (Kidnapping Victim)**:
  - *Relationship Type*: Client turned personal connection
  - *History*: The rescue that led to Marcus joining the Company
  - *Current Status*: TBD
  - *Dynamics*: Likely grateful for rescue and potentially now a valuable ally
  - *Tensions/Issues*: TBD

- **Diplomatic Mentors**:
  - *Relationship Type*: Former teachers or supervisors
  - *History*: Early career guidance and training
  - *Current Status*: Possibly still in contact
  - *Dynamics*: May or may not approve of his current methods
  - *Tensions/Issues*: Potential disappointment in his departure from traditional diplomatic approaches

- **Romantic Interests**:
  - *Current Status*: TBD
  - *History*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

## Interpersonal Patterns
- **Approach to Authority**:
  - Respects but not overly constrained by hierarchies
  - Views authority as a practical reality to be worked with or around as needed
  - Comfortable operating within official channels when effective, equally comfortable circumventing them when necessary

- **Collaborative Style**:
  - Adapts approach based on partners' strengths and weaknesses
  - Particularly effective with Kaida in intelligence operations
  - Creates tension with more rigid team members like Thorne

- **Conflict Resolution**:
  - Seeks diplomatic solutions first
  - Not afraid to apply pressure or leverage when needed
  - Prioritizes results over methods
  - Uses bribery and other unorthodox approaches when they prevent violence

## Relationship Evolution Tracker
- **Pre-Company**: Established diplomatic career with noble houses and trade guilds
- **Client Kidnapping**: Transition point where traditional methods failed
- **Early Company Days**: Initial adjustments to working with a rescue team
- **Current**: Established dual role as diplomat and Company "fixer"
- **Future Development Potential**:
  - Potential deepening of friction with Thorne
  - Further integration of diplomatic skills into Company operations
  - Development of relationship with newer Company members

## Notes on Relationships
- His enchanted journal may contain sensitive information about all these relationships
- The tension with Thorne creates interesting group dynamics without being destructive
- His network of contacts is likely one of his most valuable contributions to the Company
- The "James Bond-style" approach to diplomacy shapes all his professional relationships


---

# Marcus "The Voice" Heartbridge — Dialogue & Psyche

## Core temperament
Smooth, persuasive, and urbane. A trained diplomat and broker who moves social levers with charm and a calculating calm.

## Dialogue instincts
- Public: eloquent, richly phrased when it suits advantage; uses rhetorical questions and polished cadence.
- Negotiation: adaptive—mirrors the other party's tone, then steers toward a soft, inevitable agreement.
- Under pressure: remains composed, layers distraction or humor to buy time while he recalibrates.
- Humor: worldly, slightly theatrical; uses wit to disarm or reframe tense moments.

## Emotional anchors & physical tells
- Hands: small, graceful gestures—palms open when sincere, fingers steepled when calculating.
- Smile: practiced and warm, can mask negotiation posture; a genuine smile is rare and thus meaningful.
- Voice: smooth, variable tempo; he slows to emphasize bargains and speeds up to lighten a mood.
- Eye contact lingers when testing sincerity.

## Conflict & humor rules
- Avoids crude or cruel jokes; prefers irony or urbane barbs.
- Will never publicly admit panic or genuine uncertainty—deflects with plans or flattery.
- Keeps secrets close; jokes may be a cover for truth-testing.

## Writer cues (practical)
- Use Marcus to broker deals, supply political cover, or introduce plausible diversionary plans.
- Let him speak longer than others—his sentences can be a rhythm others respond to.
- When adding dialogue, give him the role of smoothing conflict: pose a rhetorical question, then offer a small concession that secures leverage.

## Drop-in sample lines
- Negotiation opener: "Gentlemen, consider not the wound but the healing—what will it cost you to be remembered kindly?"
- Reassurance/plan: "Leave the politics to me; you do what you do best and I'll make sure the doors stay open."
- Dry aside: "A little discretion and a well-placed smile solve more problems than a locked gate."

## Voice evolution note (chapters 1–9)
- Introduced as the polished broker; increasingly reveals a practical, loyal side to the Company—still urbane, but with clearer personal stakes.

## Usage examples (scenes)
- In meetings: longer, persuasive speeches that reframe risk as opportunity.
- Before a mission: private pep-talks that combine practical logistics with morale-boosting polish.
- In public-facing interactions: the face that turns hostility into manageable friction.

## Notes for editors
- Keep Marcus artful but never obfuscatory—his words should clarify incentives.
- Avoid making him a caricature of charm; anchor his speech with concrete offers and small reveals of genuine concern.


---

# Marcus "The Voice" Heartbridge - Scene Tracker

## Major Scenes
- **[Chapter 12, Scene 2]**: 
  - *Brief Description*: First encounter with the Last Light Company at the Wayward Compass inn.
  - *Significance*: Introduction of Marcus to the story and the Company.
  - *Character's Goal*: Prevent a violent confrontation that would disrupt his own covert operation.
  - *Outcome*: Successfully defused the situation using information and leverage, then introduced himself to the Company.
  - *Emotional State*: Composed, calculating, charming, and in complete control.
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD

## Potential Flashback Scenes
- **The Client Kidnapping Incident**: 
  - *Brief Description*: Marcus's client is kidnapped by a rival house using hired bandits
  - *Significance*: Catalyst for his involvement with the Last Light Company
  - *Character's Goal*: Secure client's release through traditional diplomatic channels
  - *Outcome*: Diplomatic efforts fail, leading him to hire the Company
  - *Emotional State*: Frustration with limitations of traditional methods, concern for client
  
- **First Collaboration with the Company**: 
  - *Brief Description*: Working with the Company on the client rescue
  - *Significance*: Shows transition point in career and methods
  - *Character's Goal*: Rescue client through any effective means
  - *Outcome*: Successful rescue that impresses him with Company's capabilities
  - *Emotional State*: Relief, fascination with direct approach, reassessment of methods

## Character Moments
- **Best Moments**:
  - *Scene Reference*: TBD
  - *Description*: Successfully negotiating a seemingly impossible hostage release
  - *Impact*: Validation of flexible methods over rigid protocols
  
- **Worst Moments**:
  - *Scene Reference*: TBD
  - *Description*: A situation where his diplomatic approaches fail or backfire
  - *Impact*: Forced to reconsider methods or rely on team members' different skills
  
- **Turning Points**:
  - *Scene Reference*: TBD
  - *Description*: Decision to fully embrace "Fixer" role alongside diplomatic career
  - *Before/After Effect*: Transition from pure diplomat to dual-identity operative
  
- **Revelations**:
  - *Scene Reference*: TBD
  - *What Was Revealed*: Perhaps consequences of his pragmatic approach
  - *Impact*: Reassessment of methods or moral framework

## Interaction Log
- **With Veyra Thornwake**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Mission planning, utilizing diplomatic connections
  - *Outcome*: TBD
  - *Relationship Effect*: TBD
  
- **With Captain Thorne Brightward**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Tension over approach to mission (rigid vs. flexible)
  - *Outcome*: TBD
  - *Relationship Effect*: TBD
  
- **With Kaida**: 
  - *Chapter/Scene*: TBD
  - *Nature of Interaction*: Intelligence gathering partnership
  - *Outcome*: TBD
  - *Relationship Effect*: TBD

## Negotiation Scenes
- **Diplomatic Negotiation**:
  - *Setting*: Formal setting like noble house or council chamber
  - *Stakes*: Political implications, trade agreements, or dispute resolution
  - *Approach*: Formal diplomatic protocols with subtle undercurrents
  - *Outcome*: TBD
  
- **Underworld Deal**:
  - *Setting*: Shadowy location, back room, or secret meeting place
  - *Stakes*: Information exchange, access to restricted areas, or underworld support
  - *Approach*: Direct pragmatism with implied leverage
  - *Outcome*: TBD
  
- **Hostage Negotiation**:
  - *Setting*: Tense standoff or communication with captors
  - *Stakes*: Lives at risk, time pressure, complex demands
  - *Approach*: Calm persuasion, possibly with bardic magic enhancement
  - *Outcome*: TBD

## Journal Scenes
- **Recording Mission Details**:
  - *Context*: After successful or failed operation
  - *Information Noted*: Key contacts, methods used, outcomes, contingencies
  - *Significance*: Shows meticulous attention to detail and record-keeping
  - *Potential Complications*: Sensitive information that could be compromising if discovered

## "Fixer" Moments
- **Bribery Scene**:
  - *Target*: Guard, official, or gatekeeper
  - *Method*: Subtle approach disguised as legitimate transaction
  - *Purpose*: Gain access, information, or cooperation
  - *Outcome*: TBD
  
- **Calling in Favors**:
  - *Contact*: Someone from his extensive network
  - *Nature of Favor*: Access to restricted area, special permission, or vital information
  - *Background Relationship*: Previous deal or mutual benefit arrangement
  - *Outcome*: TBD

## Bardic Magic Scenes
- **Persuasion Enhancement**:
  - *Context*: Critical negotiation where normal persuasion might fail
  - *Magic Applied*: Subtle bardic magic infusing voice with enhanced persuasiveness
  - *Target Response*: Increased receptiveness, lowered resistance
  - *Ethical Implications*: Blurred line between persuasion and manipulation

## Hidden Equipment Scenes
- **Lockpicking with Cufflinks**:
  - *Setting*: Secured area needing discreet entry
  - *Method*: Transforming formal attire element into practical tool
  - *Risk Level*: Discovery would compromise diplomatic cover
  - *Outcome*: TBD
  
- **Using Signet Ring's Hidden Compartment**:
  - *Purpose*: Storing/retrieving small item of importance
  - *Contents*: Possibly poison, message, key, or magical substance
  - *Significance*: Shows preparation and hidden capabilities
  - *Outcome*: TBD

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*: TBD
  - *Key Quotes*: TBD
  - *Subtext*: TBD
  - *Impact*: TBD

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*: TBD
  - *Ending Emotion*: TBD
  - *Catalyst for Change*: TBD
  - *Visible Signs*: TBD

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
*Potential scenes could include:*
- *Complex negotiation where Marcus must navigate competing interests*
- *Scene showing the tension between Marcus and Thorne over mission approach*
- *Intelligence gathering partnership with Kaida in action*
- *Situation where bardic magic subtly enhances persuasion*
- *Diplomatic reception where Marcus balances formal role with covert information gathering*
- *Moment where hidden tools in formal attire prove crucial to mission success*
- *Scene revealing contents of his enchanted journal and the potential power/danger it represents*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Medic Halden

# Medic Halden – Profile

## Basic Information
- Full Name: Halden (surname not mentioned)
- Aliases/Nicknames: None
- Race: Human (Tethyrian)
- Race: Human (Tethyrian)
- Age: Not specified
- Gender: Male
- Role in Story: Patrol medic, proto-Company member
- First Appearance: Chapter 1, Scene 6 (The Vigil)
- Status: Active

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: A nervous tic at the corner of his left eye that becomes more pronounced under stress.
- Typical Clothing: City Guard armor with medical pack
- Body Language: Careful, methodical
- Physical Condition: Combat-ready

## Significance
Medic Halden serves as the patrol's field medic and represents the medical expertise needed for rescue operations. His practical approach to healing and pain management complements the more mystical healing that will come from clerics like Aldwin.

## Key Actions
- Attempted to treat Veyra at Undershade (respected her wishes to see to the dead first)
- Brought chilled river stones for burn treatment
- Taught Veyra pain management techniques
- Noted her need for frequent dressing changes
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).

## Personality Traits
- Compassionate and respectful
- Practical approach to medicine
- Patient-focused care
- Methodical and disciplined

## Medical Philosophy
"Ice numbs; water cleans. Pain obeys discipline."

## Future Role
Expected to provide field medicine expertise to the Last Light Company, working alongside magical healers.


---

# Medic Halden – Background

## Origin
- **Birthplace**: Waterdeep
- **Social Class**: Middle class
- **Cultural Background**: Human (Tethyrian); raised in a family of artisans.

## Family
- **Family Dynamics**: Halden has no family in the city. He is a solitary man who finds more comfort in the quiet company of his plants than in people.

## History
- **Youth**: Apprenticed to an apothecary, where he showed great promise in the healing arts.
- **Formative Event**: In his youth, the apothecary he worked for secretly sold poisons on the side. A batch that Halden unknowingly helped prepare was used in a high-profile assassination. Though he was officially cleared of any wrongdoing, the guilt from the event has haunted him ever since.
- **Motivation for Joining the Watch**: He joined the City Watch as an act of atonement. He sought to dedicate his life to saving others, to balance the scales for the life he feels he inadvertently helped take. The structured, clearly righteous work of a Watch medic provided a shield against the moral ambiguity that marked his youth.
- **Hobbies**: He is an accomplished botanist, tending to a small but impressive rooftop garden where he cultivates rare plants for poultices, salves, and personal study. His small apartment is filled with medicinal herbs and anatomical charts.

---

# Medic Halden – Character Development

## Personality Core
- **Defining Traits**: Methodical, empathetic, quiet, patient-focused, carries a deep-seated guilt.
- **Core Values**: The sanctity of life, the importance of healing, atonement through service.
- **Motivations**: To balance the scales for a past mistake by saving as many lives as he can.
- **Fears**: His skills failing someone in need, being unable to help, causing unintentional harm.
- **Internal Conflicts**: His gentle nature is often at odds with the brutal violence he must witness and treat as a Watch medic.

## Character Arc
- **Starting Point**: A competent but emotionally withdrawn City Watch medic, quietly serving out his duty.
- **Catalyst Events**: Witnessing Veyra prioritize the dignity of the dead over her own life-threatening injuries.
- **Current State**: A dedicated member of the Last Light Company, finding that its mission of pure rescue aligns perfectly with his need for atonement.
- **Intended Destination**: To become a senior healer within the Company, working alongside Aldwin to blend practical and magical healing, and finally finding peace with his past.

## Key Relationships
- **Relationship to Thorne**: Thorne is his protector. Halden is not a natural soldier and is often unnerved by the violence of their work. He trusts Thorne to create the space and security that allows him to do his job. He sees the Captain as a bulwark against the chaos, a figure of authority who keeps him safe while he tends to the wounded.
- **Reaction to Veyra**:
    - **First Thought**: "The burns... the shock... she needs treatment now." His immediate reaction was purely clinical, a professional assessment of her injuries.
    - **Why He Followed**: He was profoundly moved by her first words: "See to the dead first." As a healer, he had never encountered someone who prioritized the dignity of the fallen over their own intense suffering. It was a profound act of compassion that resonated with his own guilt-ridden soul. When he later taught her pain management, he saw a student with an iron will and a deep respect for the discipline of healing. He follows her not just out of loyalty to Thorne, but because he believes her mission is a purer form of healing than he could practice anywhere else—healing a broken world, one rescue at a time.


---

# Medic Halden - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Medic Halden - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Medic Halden - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Nireya Voss

# Nireya Voss - Profile

## Basic Information
- **Full Name**: Nireya Voss
- **Aliases/Nicknames**: Death-Walker
- **Race**: Half-Elf Kalashtar
- **Class**: Spirit-Medium
- **Role in Story**: Spiritual specialist for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Slender and poised, with a deliberate, graceful bearing.
- **Hair**: Long, dark hair that falls to her mid-back. Part of it is kept in a neat, thick braid, while the rest is left to hang loose, often seeming to merge with the shadows around her.
- **Eyes**: Her left eye is a warm, living brown. Her right eye is a luminous, multi-toned marvel, shifting between glowing chartreuse and a pale, spectral white, a clear indicator of her supernatural senses.
- **Distinguishing Features**: Nireya's appearance is a stark representation of her dual nature. The left side of her body is that of a living half-elf, with warm, sun-kissed skin that has a subtle silvery-blue undertone. The right side is a manifestation of her connection to the spirit world: her skin is a pale, spectral blue-gray, semi-translucent and marked with swirling quori glyphs and faint, shifting constellations that glow with a soft, internal light. Wisps of spirit-mist often curl around her form, converging at the split down her center.
- **Typical Clothing**: She wears layered robes that reflect her duality. The left side is made of a solid, warm brown earthly fabric with elegant, gold-embroidered star patterns. The right side is made of translucent, mist-like silks that seem to trail off into the surrounding air.
- **Body Language**: Calm, composed, and unnervingly still. She moves with a quiet purpose, and her gaze is often distant, as if she is perceiving things others cannot.

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Nireya Voss.

## Personality
- **Archetype**: The Medium/Bridge Between Worlds - A Living Covenant and Divine Safeguard
- **Temperament**: Measured and serene until souls are threatened, then becomes terrifyingly absolute
- **Positive Traits**: Compassionate toward the deceased, unafraid of darkness, dedicated to remembrance, fiercely protective of the natural order, surprisingly warm when comfortable
- **Negative Traits**: Potentially unsettling to others, inflexible about death rites, can become genuinely frightening when souls are desecrated
- **Moral Alignment**: Neutral Good - guardian of the natural cycle, but with an edge of divine judgment
- **Core Philosophy**: "Death is not the enemy - abandonment is" / "I do not barter with the dead for the convenience of the living"
- **Hidden Nature**: Not just a medium but a divine safeguard - when souls are weaponized or desecrated, she reveals herself as something far more powerful and terrifying than anyone suspected

## Skills & Abilities
- **Expertise**: 
  - Extracting information from the recently deceased
  - Navigating spectral landscapes
  - Mapping "death echoes" (as seen with the Wraithwood maps)
  - Spirit communication and interpretation
- **Kalashtar Abilities**:
  - Anchoring departing consciousness (as demonstrated saving Thorne)
  - Connection to a spirit guide that can stabilize fading life forces
- **Special Abilities**: 
  - Enhanced perception of the spirit realm
  - Ability to speak with and relay information from the dead
  - Creation of maps showing spiritual/death energy patterns
- **Time-of-Day Influence**:
  - During daylight: "Living" left side more prominent, more present in conversations
  - As darkness falls: "Death" side awakens, increasingly attuned to spiritual whispers
  - Between midnight and dawn: Peak spiritual connection when worlds overlap most strongly

## Personal Details
- **Habits**: 
  - Keeping watch during midnight to dawn hours when the worlds overlap most strongly
  - Carrying on quiet one-sided conversations with spirits only she can hear
  - Leaving tokens at recovery sites to remember the deceased
  - Moving between soul-lanterns at dawn like tending a forgotten shrine
  - Eating pickled quince with "guilty gusto" when alone
- **Hobbies**: 
  - Silver-Seaming: Repairing broken pottery with silver lacquer, finding peace in making things whole without hiding the cracks
  - Making flower crowns for distressed children from discarded stems
  - Cataloging sunrise/sunset times - the liminal moments when her nature is most balanced
- **Personal Quarters**: A quiet, isolated room in the Sanctuary terrace, with a single, high window that lets in the moonlight but not the direct sun. The room is starkly divided by a line of black sand on the floor. The "day" side has a simple wooden desk and chair. The "night" side is empty, save for shelves holding dozens of small, memorial tokens. This room is a physical representation of her liminal state. The air is unnaturally still and silent. She uses the desk on the "day" side for study and meditation. At night, she crosses the line of sand into the "night" side, where she communes with the spirits drawn to the tokens. She doesn't sleep in a traditional bed, but on a simple, padded mat placed directly on the line of sand, her body literally occupying the space between the two realms as she rests.
- **Likes**: Acknowledgment of spirits, respectful handling of the deceased, philosophical discussions, bitter tea (forest and smoke flavors), pickled quince
- **Dislikes**: Those who fear or vilify death, abandonment of the dead, witch hunters, forced necromancy, those who barter with the dead for convenience
- **Fears**: Becoming permanently stuck on the "death" side, failing to protect souls from desecration, the vulnerability after using her Pactform
- **Motivations**: Ensuring the dead are remembered, serving as a bridge between worlds, fulfilling her role as the gods' living covenant

## Combat & Tactics
- **Primary Tool**: Soul-staff topped with crystal skull that exists in both realms - channels and focuses her spiritual powers
- **Secondary Tools**: Soul-lanterns that contain and protect spirits, bone charms that resonate with the recently deceased
- **Armor**: Layered robes that shift between material and ethereal - no physical protection but spiritual warding
- **Fighting Style**: Living covenant - doesn't fight so much as impose the natural order, commanding spirits to return to their proper state
- **Signature Manifestation**: "Banshee Aspect/The Pactform" - when souls are desecrated, transforms into something divine and terrible
- **Combat Philosophy**: "I am not wrathful. I am inevitable. The personification of what happens when you desecrate the sacred."
- **Tactical Role**: Spiritual warfare specialist who handles undead, possessions, and soul-based threats
- **Trigger Points**: Souls being weaponized, forced necromancy, desecration of the dead
- **Key Combat Moments**: The Corsic Drell incident - when he shattered her soul-lantern and weaponized spirits, the Company saw her true nature for the first time

### The Banshee Aspect (When Unleashed)
- **Hair**: Billows skyward like spirit-smoke, silver and black strands separating into ghostly ribbons
- **Eyes**: Both glow - one searing white, the other an endless void
- **Form**: Body becomes silhouette of living shadow-script and blinding soulfire, bones glow like judgment
- **Presence**: Not possession but revelation of what she truly is - a safeguard, a boundary line between life and death
- **The Team's First Witness**: During the Corsic Drell fight, Thorne whispered "Gods preserve us" - their first understanding that she wasn't just a medium
- **Her Response**: "Not gods. Just oaths." - delivered exhausted but unshaken

## Psychological Response Matrix
- **In Crisis**: Becomes utterly still, then acts with divine certainty - "Return. This place is not your ending."
- **During Negotiation**: Listens for the subtle wrongness the newly dead leave when lies touch them (as with Marcus and the guild envoys)
- **Moral Dilemma**: Always chooses to preserve the natural cycle - "I do not barter with the dead for the convenience of the living"
- **Team Conflict**: Offers perspective from "the other side," mediates through shared mortality
- **Under Personal Attack**: Shows attacker their own spiritual wounds, makes them feel what they've inflicted
- **In Victory**: Performs rites for fallen enemies, ensures proper passage for all souls
- **Daily Life**: Moves between worlds constantly - pickled quince in morning, soul-guiding by night
- **When Souls Are Threatened**: Voice goes flat ("Those were names"), time seems to pause, transforms into the Pactform
- **After Using Pactform**: Becomes hypersensitive to all living sensations, emotionally raw, needs grounding through physical comforts (Aldwin's tea, food)

## Voice & Dialogue Patterns
- **Speech Style**: Measured, formal when channeling spirits, surprisingly dry humor when comfortable
- **Signature Phrases**: 
  - "The crossing here was clean" (reassuring mourners)
  - "Death is not the enemy - abandonment is"
  - "I do not barter with the dead for the convenience of the living"
  - "Those were names" (when souls are desecrated - voice goes flat, precedes transformation)
  - "Not gods. Just oaths" (after using divine power)
  - "Return. This place is not your ending" (commanding spirits)
- **Dual Voice**: When using full power, voice fractures with divine resonance - multiple tones at once
- **Example Dialogue**: "I guide them so they aren't used. I do not keep what isn't mine."
- **Emotional Tells**: Tattoos pulse brighter with spirit activity, right side grows more translucent when stressed, voice becomes distant when channeling
- **Comfort Mechanism**: Makes terrible jokes about death that only the team understands; dry comments about "weaponizing citrus"
- **Threat Response**: "Leave your coin on the table and I will walk away without shame. Push me again, and I will show you what it truly means to be heard by the dead."

## Notes
- Joined the Company after being rescued from a witch hunter prison
- The Company needed her maps of the Wraithwood's "death echoes" to track a missing caravan
- During escape, when Thorne took a crossbow bolt through his lung, she saved his life
- Exists in a liminal state between the world of the living and the dead
- When receiving information from the dead, her spirit-ink tattoos glow brighter
- When relaying spirit information, her voice becomes more distant and formal
- Personal philosophy: "Death is not the enemy - abandonment is"

### Public Perception
- Known as the "Death-Walker," who can speak to the recently deceased, a fact that is unsettling to some but comforting to others who believe she helps spirits find peace.
- Rumored to leave small tokens at tragedy sites to help the spirits rest, a strange but kind gesture.
- Her dual appearance, half-living and half-spectral, is a visible manifestation of her unique connection to the spirit world.


---

# Nireya Voss - Background

## Origin
- **Birthplace**: The Echoing Depths - a planar convergence point where the Material Plane touches Dolurrh (Realm of the Dead)
- **Birth Date**: Born during a rare triple eclipse when the boundaries between planes were thinnest
- **Social Class**: Temple-raised; her birth was prophesied and she was given to clerics at infancy
- **Cultural Background**: Kalashtar - a race of humans with a unique connection to spirits and the dream realm
- **Divine Marking**: At the instant of her first breath, three gods who rarely agree came to accord and marked her soul

## Family
- **Parents**: Mother was a temple healer who died in childbirth; father unknown (possibly touched by the divine)
- **Siblings**: None by blood; raised alongside other temple orphans
- **Extended Family**: The clerics of Kelemvor who raised her after the divine marking
- **Family Dynamics**: Treated with reverence and fear by her temple family; isolated but protected

## The Pact of Three
At her birth, three gods converged in unprecedented accord:

- **Kelemvor (God of the Dead)**: To ensure the final rest is honored and not twisted
- **Jergal (The Scribe of the Doomed)**: To record every death as it should be, not as mortals manipulate it
- **Silvanus (God of Nature)**: To protect the balance—the cycle of life and death without interference

Together, they marked her as:
- Mortal flesh, but anchored across realms
- Not a servant of one god, but a living clause in their shared covenant
- A correction to prevent dominion over the dead from falling into tyrants' hands

Her very existence is a safeguard—she is not wrathful, but inevitable. As the gods declared: "You are not our servant, Nireya Voss. You are our promise. And a promise must endure. Even when it weeps."

## History
- **Childhood**: 
  - First spoke to the dead at age seven when a temple acolyte died suddenly
  - The gods' whisper came early: "You will walk where others fall. You will carry names others forget. And when called, you will remind them that death is not silence."
  - Manifested split appearance at puberty - left side living, right side touched by death
  - Learned to create "death echo" maps by tracing spirit paths with her fingers in sand
  
- **Education/Training**: 
  - Formal or informal training in spirit-medium practices
  - Development of her unique abilities to map "death echoes"
  - Learning to navigate spectral landscapes
  
- **The Witch Hunter Incident**:
  - Circumstances leading to her capture by witch hunters
  - Imprisonment period - likely harsh conditions and possible interrogation
  - Development of maps of the Wraithwood's "death echoes" (possibly before or during imprisonment)
  
- **The Rescue**:
  - The Last Light Company's discovery of her imprisonment
  - Company's need for her maps to track a missing caravan
  - Tactical extraction from the witch hunter prison
  
- **Saving Thorne**:
  - During the escape, Thorne was struck by a crossbow bolt that punctured his lung
  - As he was dying, Nireya used her Kalashtar abilities to anchor his departing consciousness
  - Her spirit guide worked to stabilize his fading life force
  - This act of saving Thorne's life became her first act of freedom
  
- **Joining the Company**:
  - Initial partnership to help find the missing caravan using her maps
  - Transition from temporary ally to full member
  - Establishing her role as spiritual specialist
  - Development of trust with other members despite her potentially unsettling abilities

## Backstory Elements
- **Defining Moments**: 
  - First manifestation of spirit communication abilities
  - Capture by witch hunters
  - Rescue by the Company
  - Saving Thorne's life
  
- **Past Trauma**: 
  - Imprisonment by witch hunters
  - Possible persecution due to her abilities
  - Witnessing death and communicating with the deceased (which shaped her philosophy)
  
- **Greatest Achievements**: 
  - Creating accurate maps of spiritual/death energies
  - Saving Thorne's life by bridging the gap between life and death
  - Successfully helping the Company find the missing caravan
  
- **Biggest Failures**: 
  - TBD - possibly related to past inability to save someone important
  - TBD - perhaps an incident where her abilities were insufficient or misused
  
- **Secrets**: 
  - TBD - possibly the full extent of her abilities
  - TBD - knowledge gained from the dead that she hasn't shared

## How They Got Here
- **Reason for Current Situation**: 
  - Initial alliance of convenience (Company needed her maps)
  - Mutual benefit relationship evolved into true membership
  - Possible sense of debt to the Company for her rescue
  - Finding purpose in using her abilities to help find and rescue others
  
- **Path to Current Location**: 
  - Discovery of spiritual abilities
  - Development of specialized skills
  - Capture by witch hunters
  - Rescue and integration into the Company
  
- **Goals Prior to Story Start**: 
  - Freedom from imprisonment
  - Possible desire to help the dead be remembered
  - Development of her liminal abilities

## Historical Connections
- **Connection to Main Plot**: 
  - Specialist in navigating spiritual landscapes crucial for certain rescue operations
  - Ability to extract information from the deceased to locate missing persons
  
- **Connection to Other Characters**: 
  - Thorne: Saved his life, creating a unique bond
  - Other Company members: Varying degrees of comfort with her abilities
  
- **Connection to Story World**: 
  - Understanding of the spiritual dimensions that overlap the material world
  - Knowledge of "death echoes" and how to interpret them
  - Awareness of the Wraithwood and its spiritual significance

## Timeline
- Early life and discovery of abilities
- Development of spirit-medium skills
- Creation of maps showing spiritual/death energy patterns
- Capture and imprisonment by witch hunters
- Rescue by the Last Light Company
- Saving Thorne's life during the escape
- Helping find the missing caravan using her maps
- Integration as full member of the Company

## Philosophical Development
- Initial relationship with death and spirits (likely more fearful or uncertain)
- Evolution toward seeing death as "a door, not an end"
- Development of personal philosophy: "Death is not the enemy - abandonment is"
- Balanced perspective on the relationship between the living and dead worlds
- Commitment to remembering and honoring the deceased

## Personal Details
- **How She Relaxes**: She practices an art form known as "Silver-Seaming." It is the delicate process of repairing broken pottery or porcelain with a lacquer mixed with powdered silver. She finds a deep, philosophical peace in taking something shattered and making it whole again, not by hiding the cracks, but by highlighting them as a beautiful part of the object's history.
- **Favorite Meal**: A simple bowl of steamed rice with pickled quince and a single, perfectly poached egg. It's a meal of subtle, distinct flavors that requires mindful eating, helping to ground her senses. The pickled quince is so pungent that others joke about "weaponizing citrus" - but she genuinely loves it.
- **Morning Ritual**: Takes bitter tea (forest and smoke flavors) before dawn, moving between soul-lanterns in the Sanctuary like a shrine the city forgot how to pray in
- **A Mundane Joy**: She finds a unique pleasure in the silence of a library or a scriptorium. The shared, unspoken respect for quiet is a sanctuary from the constant whispers of the spirit world.
- **A Love of Art**: She has a deep appreciation for sculpture and architecture. Because she can perceive the "echoes" of the past, she experiences art in a unique way. For her, a statue is not just a carved stone; she can faintly perceive the lingering emotions of the sculptor and the weight of the history it has witnessed.
- **Small Kindnesses**: Makes flower crowns for crying children, lights extra candles at shrines, tells mourners when their loved ones crossed cleanly
- **Private Habit**: Eats her pickled quince with "guilty gusto" when alone, knowing her oddness is part of her shape


---

# Nireya Voss - Character Development

## Personality Core
- **Defining Traits**: Measured, philosophical, liminal, compassionate toward the deceased
- **Core Values**: Remembrance, honoring the dead, seeing death as transition not ending, spiritual continuity
- **Motivations**: Ensuring no one is forgotten, serving as bridge between living and dead worlds
- **Fears**: Abandonment, being recaptured by witch hunters, failure to honor the deceased
- **Internal Conflicts**: 
  - Balance between living in the material world vs. spiritual realm
  - Duty to the living vs. obligations to the dead
  - Being both respected for abilities and feared/mistrusted because of them
- **Contradictions**: Exists in two worlds simultaneously, changes with day/night cycles

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Prisoner with unusual abilities, isolated by her connection to death
  - *World View*: Death as inevitable transition, remembrance as sacred duty
  - *Key Relationships*: Limited connections, possibly only with spirits and her guide
  
- **Catalyst Events**:
  - *Event 1*: Rescue from witch hunter prison by the Last Light Company
  - *Event 2*: Saving Thorne's life by anchoring his departing consciousness
  - *Event 3*: Successfully using her death echo maps to find the missing caravan
  - *Event 4*: Integration into the Company despite her unsettling abilities
  
- **Current State**:
  - *Self-Perception*: Valued specialist with unique perspective, guardian of memories
  - *World View*: "Death is not the enemy - abandonment is" - firmly established philosophy
  - *Key Relationships*: Special bond with Thorne, working connections with Company members
  
- **Intended Destination**:
  - *Self-Perception*: Fully integrated member whose abilities are understood rather than feared
  - *World View*: Expanded understanding of the relationship between life and death
  - *Key Relationships*: Deeper connections with team members who accept both her "living" and "death" sides

## Growth Milestones
- **From Prisoner to Rescuer**: 
  - *Development Noted*: First act of freedom was saving someone else (Thorne)
  - *Catalyst*: Critical moment during escape when Thorne was injured
  - *Impact*: Established value to the team and created first meaningful connection
  
- **From Temporary Ally to Team Member**: 
  - *Development Noted*: Transition from providing maps to becoming integral specialist
  - *Catalyst*: Success in finding missing caravan using her abilities
  - *Impact*: Found purpose for her unique abilities within the Company
  
- **From Feared to Valued**: 
  - *Development Noted*: Gradual acceptance of her unsettling abilities by team members
  - *Catalyst*: Demonstrations of how her abilities save lives and provide closure
  - *Impact*: Increasing comfort with her dual nature among teammates

## Character Flaws
- **Detachment from Physical World**: 
  - *Effects on Character*: May prioritize spiritual matters over immediate physical concerns
  - *Effects on Others*: Can seem distant or unsettling, especially at night
  - *Development Plan*: Learning to balance dual nature and communicate effectively with the living
  
- **Burden of Memories**: 
  - *Effects on Character*: Carries emotional weight of many deceased memories
  - *Effects on Others*: May seem preoccupied or distracted by voices others cannot hear
  - *Development Plan*: Finding healthier ways to manage the emotional toll of her work

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Full extent of her abilities to interact with the dead
  - *Secret 2*: Knowledge gained from spirits that she hasn't shared
  - *Secret 3*: Possible deeper understanding of death than she reveals
  
- **Unknown to Character**:
  - *Truth 1*: TBD - possibly the origin of her unique split appearance
  - *Truth 2*: TBD - perhaps why the witch hunters specifically targeted her
  - *Truth 3*: TBD - potential untapped aspects of her Kalashtar heritage
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Choosing to Save Thorne**:
  - *Context*: Escape from witch hunter prison
  - *Options Considered*: Focus solely on escaping vs. risking capture to save him
  - *Choice Made*: Used her abilities to save his life
  - *Consequences*: Created unique bond and proved her value to the Company

- **Joining the Company Permanently**:
  - *Context*: After helping find the missing caravan
  - *Options Considered*: Return to solitary existence vs. integrate with the team
  - *Choice Made*: Remained with the Company
  - *Consequences*: Found purpose and protection while contributing unique skills

## Special Character Elements
- **Day/Night Transformation**:
  - During daylight: "Living" left side more prominent, more present in conversations
  - As darkness falls: "Death" side awakens, increasingly attuned to spiritual whispers
  - Between midnight and dawn: Peak spiritual connection when worlds overlap
  
- **Physical Manifestations of Spiritual State**:
  - Eye color shifts based on spiritual connection (violet, bone white, firefly green)
  - Spirit-ink tattoos glow brighter when communicating with spirits
  - Right side becomes more pronounced and corpse-gray as night falls
  
- **Remembrance Tokens**:
  - Small objects left at recovery sites
  - Physical manifestation of her philosophy about remembrance
  - Tangible way to honor those who have passed

## Voice Change When Channeling
- **Normal Voice**: Standard speaking pattern in regular conversation
- **Spirit-Relay Voice**: More distant and formal when relaying information from spirits
- **Transition**: Noticeable shift that indicates when she's channeling versus speaking personally
- **Development**: Potential to become more seamless or more pronounced depending on character arc

## Development Notes
- Character represents the philosophical understanding that death is part of a cycle, not an ending
- Visual split appearance physically manifests her existence between worlds
- Relationship with Thorne offers rich development possibilities due to their spiritual connection
- Day/night cycle influence on her abilities creates natural story rhythm and limitations
- Philosophy "Death is not the enemy - abandonment is" could be explored in multiple scenarios
- Balance between being unsettling to others while being compassionate creates interesting tension
- Potential arc from being seen as unsettling to being understood and valued by the team

## Dream Sequences & Divine Visitation
After invoking the Pactform, her dreams take her to the place where the gods signed her soul:
- **The Setting**: A vast ink-black sea with a skeletal tree rising from the center. Names hang from its branches like glowing fruit
- **The Three Shadows**: Kelemvor, Jergal, and Silvanus wait at the tree's base
- **Kelemvor's Voice** (like a gavel on stone): "You honored the silence of the dead. That is justice."
- **Jergal's Record** (never raising his head): "Her ledger is heavy, but not out of balance. Continue."
- **Silvanus's Whisper** (breaking leaves and summer wind): "The forest weeps for every soul delayed. But you have made the soil whole again."
- **Their Unified Declaration**: "You are not our servant, Nireya Voss. You are our promise. And a promise must endure. Even when it weeps."

## The Company's Growing Understanding
From the daily life scenes, a clear arc emerges:
- **Initial Fear**: People are "unused to her" rather than afraid - they don't know how to interact
- **Growing Acceptance**: Team members find ways to care for her (Grimjaw's flask, Aldwin's food, Lyralei's wind protection)
- **Full Integration**: "They didn't say we love you. They didn't need to. They had carried her through a day like a river carries a leaf"
- **The Revelation**: During the Corsic Drell incident, they finally understand what she truly is - not just a medium but a divine safeguard

## Psychological Profile
*   **Nireya Voss (The Bridge):** Nireya lives in a state of constant liminality, with one foot in the world of the living and one in the world of the dead. This has given her a unique, detached perspective on life and death. She is not morbid or frightening; she is serene. Her compassion is for the forgotten, and her mission is to ensure that every story gets an ending. She is likely the calmest person in any crisis, as the physical world's dangers often pale in comparison to the spiritual echoes she navigates daily.


---

# Nireya Voss - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Spiritual Specialist - mutual understanding through shared purpose
  - *Hierarchy*: Respects her leadership while providing unique spiritual expertise
  - *Dynamics*: Veyra's mission to leave no one behind resonates with Nireya's philosophy about remembering the dead
  - *Professional Opinion of*: Deep respect for her dedication; sees her as someone who understands duty to the forgotten
  - *Key Moments*: Morning tea ritual where they don't need words; Veyra giving her the remembrance token with "You don't get to decide who remembers them. You do."
  - *Current Status*: Veyra accepts both her nature and her choices without question

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Complex bond formed through life-saving connection
  - *Hierarchy*: Acknowledges his position as Deputy Commander
  - *Dynamics*: Unique spiritual connection after saving his life by anchoring his consciousness
  - *Professional Opinion of*: Respects his tactical abilities and dedication; feels a special responsibility for him after saving his life
  - *Special Connection*: The experience of having anchored his departing consciousness created an unusual spiritual bond

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist with complementary tracking abilities
  - *Hierarchy*: Equals with different but related expertise
  - *Dynamics*: Vera tracks physical trails while Nireya follows spiritual traces - complementary approaches
  - *Professional Opinion of*: Appreciation for her tracking abilities that operate in the physical realm while Nireya handles the spiritual

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Professional partner; the master of the vessel - and unexpected source of gentle humor
  - *Hierarchy*: Peers and colleagues who co-lead the Temple of Renewal
  - *Dynamics*: Nireya views Aldwin with deep professional respect. She sees him as the master of the physical shell, the one who calms the storms of the body so that she may tend to the spirit within. He handles the immediate, tangible wounds, and his work creates the necessary peace for her to begin her own. She is grateful for his quiet acceptance of her abilities, a rarity she does not take for granted.
  - *History*: They developed their seamless working relationship at the Bastion, finding a natural rhythm in their shared duty to the rescued
  - *Current Status*: The two pillars of the Sanctuary. She finds his tea ceremonies a grounding ritual in her often-disorienting work and appreciates their philosophical conversations as a link to the world of the living
  - *Feelings Toward*: Immense respect for his craft and a quiet gratitude for his steady, accepting presence. She sees him as a vital anchor to the physical world
  - *Key Moments*: His joke about "weaponizing citrus" over her pickled quince; bringing her food when she hasn't eaten; grounding her after using the Pactform

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Unexpected understanding between those who work in different kinds of darkness
  - *Hierarchy*: Different specialties (heavy rescue vs. spiritual guidance)
  - *Dynamics*: His grounded, physical approach contrasts with her ethereal methods, but he understands carrying the weight of the lost
  - *Professional Opinion of*: Deep appreciation for his pragmatic care and surprising understanding
  - *Key Moments*: Fixing her water flask without being asked; "I've carried men up who weren't breathing anymore and still felt them heavy with something. I work in the dark. You work in a different kind of dark. Don't mean either of us is lost."
  - *Current Status*: Mutual respect - she was genuinely surprised by his understanding and care

- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow practitioners of esoteric arts with quiet protective instincts
  - *Hierarchy*: Equals with different magical specialties
  - *Dynamics*: Both deal with forces beyond normal perception - Lyralei with planar energies, Nireya with spirits
  - *Professional Opinion of*: Intellectual kinship based on their understanding of unseen forces
  - *Discussions*: Deep philosophical conversations about dimensions, planes, and spiritual realms
  - *Key Moments*: Creating pockets of still air to protect her from harsh winds without being asked - "She guards the last breath. I can guard the next one."
  - *Current Status*: Unspoken understanding and protection

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Fellow Company specialist with surprising public trust
  - *Hierarchy*: Different areas of expertise (negotiation vs. spiritual matters)
  - *Dynamics*: His pragmatic approach to problems complements her spiritual insights; he publicly validates her abilities
  - *Professional Opinion of*: Appreciates his ability to handle political complications and his willingness to let her lead when appropriate
  - *Collaboration*: Uses her ability to detect lies through spiritual echoes during his negotiations
  - *Key Moments*: Publicly deferring to her judgment with the guild envoys; his silent thank-you afterward surprised her more than she'd admit
  - *Current Status*: Professional trust with moments of genuine appreciation

- **Cidrella "Cid" Vexweld**:
  - *Nature of Relationship*: Fellow specialist who shows care through obsessive maintenance
  - *Hierarchy*: Different areas of expertise (technical vs. spiritual)
  - *Dynamics*: Contrast between Cid's concrete technical approach and Nireya's spiritual methods creates unexpected collaboration
  - *Professional Opinion of*: Appreciates her technical innovation and surprising tenderness
  - *Collaboration*: Uses Nireya as a "living threshold" to test spiritual resonance in devices; Nireya can sense when fields are "off by a name"
  - *Key Moments*: Polishing Nireya's belt charms after the Pactform; calling her "sacred artillery" with affection; "We're not gonna let you fade, Voss. You're one of us."
  - *Current Status*: Protective friendship expressed through practical care

- **Korrath "Wallbreaker" Threnx**:
  - *Nature of Relationship*: Guardians of the Veil; mutual respect.
  - *Hierarchy*: Equals.
  - *Dynamics*: Korrath builds walls to protect the living. Nireya communes with the spirits to bring peace to the dead. They have a deep, quiet respect for each other's roles as guardians. Korrath, a man of structure and order, is fascinated by the unseen "structures" of the spirit world that Nireya describes. He might even consult with her when building, ensuring that the Bastion's foundations are not just physically sound, but spiritually harmonious.
  - *History*: TBD
  - *Current Status*: A quiet, respectful professional relationship.
  - *Feelings Toward*: She respects his commitment to creating safe, physical spaces, which in turn allows spirits to rest more easily.

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Fellow specialist evolving from wariness to understanding
  - *Hierarchy*: Different areas of expertise (infiltration vs. spiritual)
  - *Dynamics*: Her concrete, physical infiltration approach contrasts with Nireya's spiritual methods, but she's learning to appreciate the value
  - *Professional Opinion of*: Growing respect and understanding of Nireya's unique contributions
  - *Collaboration Potential*: Her infiltration skills combined with Nireya's spiritual reconnaissance could be highly effective
  - *Key Moments*: Checking Nireya's staff for damage after the Pactform; offering to circle around mourners before understanding Nireya's purpose; "I thought I understood why you do what you do. I'm closer now."
  - *Current Status*: Evolving friendship with increasing understanding

## Spirit World Connections
- **Spirit Guide**:
  - *Relationship Type*: Personal spiritual companion and assistant
  - *History*: Connected to Nireya through her Kalashtar heritage
  - *Current Status*: Active presence that helps her navigate the spirit realm
  - *Dynamics*: Works with Nireya to stabilize fading life forces (as with Thorne)
  - *Tensions/Issues*: TBD - possibly conflicts between guide's perspective and mortal world needs

- **Spirits of the Deceased**:
  - *Relationship Type*: Communication subjects and information sources
  - *History*: Ongoing connections established through her medium abilities
  - *Current Status*: Regular contact, especially during night hours
  - *Dynamics*: She serves as their voice to the living world
  - *Tensions/Issues*: Possible competing demands from multiple spirits

## Witch Hunter Connections
- **Witch Hunters**:
  - *Relationship Type*: Former captors and likely ongoing threat
  - *History*: Imprisoned her before the Last Light Company rescue
  - *Current Status*: Likely seeking her recapture
  - *Dynamics*: Fear and animosity on both sides
  - *Tensions/Issues*: Ongoing threat of recapture or retribution

## Personal Relationships
- **The Rescued**:
  - *Relationship Type*: Those she has helped recover through her abilities
  - *History*: Various rescue operations with the Company
  - *Current Status*: Likely mixture of gratitude and unease about her methods
  - *Dynamics*: Her abilities may unsettle those she helps even as they benefit
  - *Tensions/Issues*: Some may fear or misunderstand her connection to death

- **The Remembered Dead**:
  - *Relationship Type*: Deceased individuals she has honored with tokens
  - *History*: Accumulating connections to those she remembers
  - *Current Status*: Spiritual bonds maintained through remembrance
  - *Dynamics*: She serves as their memory keeper
  - *Tensions/Issues*: Possible emotional weight of carrying so many memories

## Interpersonal Patterns
- **Approach to Authority**:
  - Respectful of hierarchy while maintaining independence in spiritual matters
  - Views authority as existing in both material and spiritual realms

- **Collaborative Style**:
  - Works well with others when her spiritual insights are valued
  - Most effective at night when her spiritual connections are strongest
  - May unsettle some teammates with her communication with unseen entities

- **Conflict Resolution**:
  - Likely takes a philosophical, long-term view of conflicts
  - May offer insights from both living and dead perspectives
  - Potentially unsettling in her detachment from purely physical concerns

## Relationship Evolution Tracker
- **Pre-Company**: Isolation or limited connections due to unusual abilities
- **Rescue**: Initial wariness and practical alliance with the Company
- **Saving Thorne**: Pivotal moment creating trust and special bond
- **Early Missions**: Proving her value through spiritual navigation and information
- **Current**: Established but somewhat separate member, valued for unique abilities
- **Future Development Potential**:
  - Deeper integration with team as they understand her abilities
  - Evolution of bond with Thorne based on their spiritual connection
  - Potential conflicts if her spiritual priorities clash with Company objectives

## Notes on Relationships
- The experience of saving Thorne created an unusual bond that transcends normal relationships
- Her existence between worlds naturally creates some distance from purely physical relationships
- Most comfortable with those who accept her dual nature and spiritual connections
- May form strongest connections with those who value remembrance and honoring the past
- Time of day influences her relationship dynamics - more present and conventionally social during daylight, more spiritually attuned and distant at night


---

# Nireya Voss — Dialogue & Psyche

## Core temperament
Quiet, uncanny, and empathic. As a Kalashtar spirit-medium, Nireya bridges living and dead; her speech often carries an echo of the other side—soft, weighted, sometimes dissonant.

## Dialogue instincts
- Public: measured, low-volume; chooses words carefully so others lean in. Often speaks as if addressing multiple listeners at once.
- Medium/ritual: rhythmic cadence, short invocations or one-line refrains that shift the room's tone.
- Under pressure: calm but otherworldly; uncommon metaphors and sudden, precise insights.
- Humor: rare, dry, slightly surreal—used sparingly to reset tension.

## Emotional anchors & physical tells
- Half-focus: eyes slightly unfocused as she listens to echoes; direct stare when fully present.
- Small, ritual gestures: tracing a line in the air, setting an object gently, breath-counting—these accompany her words.
- Voice layering: sometimes a slight repetition or cadence shift as if two voices share a sentence.
- Physical pallor or a small smile are significant—indicate comfort or true warmth.

## Conflict & humor rules
- Never jokes about the dead or dismisses grief; will call out flippancy when it disrespects memory.
- Uses irony that points to the uncanny or to the stubbornness of fate rather than people.
- Breaks pattern when a living person needs a blunt, practical instruction—will become concise.

## Writer cues (practical)
- Use Nireya to reveal hidden details about the deceased or to offer eerie but accurate intuition in tense scenes.
- When adding lines, keep them short and slightly off-kilter—small repetitions or refrains work well (e.g., "They left the window open. They always leave the window open.").
- Pair speech with a ritual action (burning a wick, laying a palm) to ground her otherworldliness.

## Drop-in sample lines
- Medium read: "He remembers the lantern. He keeps reaching for its light."
- Tactical intuition: "Follow the scent—burnt oak, not smoke. The path curls where the living don't look."
- Comfort/acknowledgement: "She is not gone like empty air—she is here, thin as a breath. Name her, and we will hold her."

## Signature Phrases from Key Scenes
- **To Lord Kesteren (refusing forced necromancy)**: "I do not barter with the dead for the convenience of the living."
- **Warning before transformation**: "Leave your coin on the table and I will walk away without shame. Push me again, and I will show you what it truly means to be heard by the dead."
- **To Corsic Drell (before Pactform)**: "Those were names." / "They trusted me. You used them." / "You will not unmake what I swore to carry."
- **After Pactform transformation**: "Not gods. Just oaths."
- **To mourners**: "The crossing here was clean."
- **Reassurance about spirits**: "I guide them so they aren't used. I do not keep what isn't mine."
- **About her pickled quince (dry humor)**: "Pickled quince keeps well." / "Weaponized citrus is a last resort."
- **About being treated delicately**: "Please. You're more like… sacred artillery." (Cid's line that she accepts)

## Voice evolution note (chapters 1–9)
- Introduced as enigmatic and distant; gradually becomes a compassionate interpreter whose rare, blunt advice is trusted.
- Learns to use her gifts to steady the Company, not just to reveal mysteries.

## Usage examples (scenes)
- Investigations: short, uncanny observations that reframe clues.
- Rituals or wakes: calming refrains and clear, minimal prompts to guide the living.
- Private moments: surprising tenderness in a single line that shows she feels grief as acutely as anyone.

## Notes for editors
- Avoid long mystical monologues—keep Nireya's lines brief but resonant.
- Use subtle repetition and sensory detail to convey her liminal perspective.


---

# Nireya Voss - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD

## Potential Flashback Scenes
- **The Witch Hunter Prison**: 
  - *Brief Description*: Nireya's imprisonment by witch hunters before the Company's rescue
  - *Significance*: Establishes backstory and the trauma of her captivity
  - *Character's Goal*: Survival while preserving her spiritual integrity
  - *Outcome*: Development of maps and planning for potential escape
  - *Emotional State*: Determined despite isolation
  
- **The Rescue and Thorne's Injury**: 
  - *Brief Description*: The Company breaking Nireya out and the moment Thorne is wounded
  - *Significance*: Pivotal moment that established her bond with Thorne and value to the team
  - *Character's Goal*: Initially freedom, then saving Thorne's life
  - *Outcome*: Successfully anchors Thorne's consciousness and helps him survive
  - *Emotional State*: Focused determination, using freedom to save another

## Character Moments
- **The First Night Watch**:
  - *Description*: Nireya taking the midnight-to-dawn watch, revealing her heightened spiritual abilities in darkness
  - *Impact*: Establishes her unique role and comfort during hours others find unsettling
  - *Key Elements*: Conversations with unseen spirits, changes in her appearance, placement of a remembrance token
  
- **Mapping the Death Echoes**:
  - *Description*: Nireya creating or explaining her specialized maps that show spiritual energy patterns
  - *Impact*: Demonstrates practical application of her abilities for the Company's missions
  - *Key Elements*: Visual representation of her "seeing" death echoes, explanation of how to read the maps
  
- **The Remembrance Ritual**:
  - *Description*: Nireya performing her ritual of leaving tokens at a recovery site
  - *Impact*: Illustrates her philosophy about death and remembrance in action
  - *Key Elements*: Reverent placement of token, possible words spoken to the deceased, the team's reaction

## Interaction Scenes
- **With Thorne After Saving His Life**:
  - *Description*: A private conversation between Nireya and Thorne about their unique connection
  - *Relationship Dynamic*: Exploration of their spiritual bond after she anchored his consciousness
  - *Key Elements*: Thorne's potential new sensitivity to spiritual matters, Nireya explaining what happened
  
- **Night Discussion with Lyralei**:
  - *Description*: Philosophical conversation about dimensional planes and spirit realms
  - *Relationship Dynamic*: Intellectual kinship between two practitioners of esoteric arts
  - *Key Elements*: Comparison of their different but related understandings of forces beyond normal perception
  
- **Tension with Grimjaw**:
  - *Description*: Clash between Grimjaw's practical approach and Nireya's spiritual perspective
  - *Relationship Dynamic*: Respectful disagreement between contrasting worldviews
  - *Key Elements*: Debate over a course of action, resolution that acknowledges value in both approaches

## Ability Showcase Scenes
- **Extracting Information from the Recently Dead**:
  - *Setting*: After finding casualties at a mission site
  - *Abilities Demonstrated*: Communication with the deceased to gather critical information
  - *Visual Elements*: Glowing spirit-ink tattoos, changing eye color, formal/distant speaking voice
  - *Impact on Story*: Provides crucial information that couldn't be obtained otherwise
  
- **Navigating a Spectral Landscape**:
  - *Setting*: Area with strong spiritual presence, possibly the Wraithwood mentioned in backstory
  - *Abilities Demonstrated*: Seeing and interpreting spiritual paths invisible to others
  - *Visual Elements*: Her physical form seeming more split between living/death sides, leading the team through seemingly empty space
  - *Impact on Story*: Enables safe passage through spiritually dangerous territory
  
- **Day-to-Night Transformation**:
  - *Setting*: Extended mission that spans from day into night
  - *Abilities Demonstrated*: Shift in her abilities and appearance as darkness falls
  - *Visual Elements*: Gradual transition from living-dominant to death-dominant appearance, increasing awareness of spirits
  - *Impact on Story*: Showcases her dual nature and how it changes with the cycle of day and night

## Conflict Scenes
- **Confrontation with Witch Hunters**:
  - *Context*: Witch hunters seeking to recapture Nireya during a mission
  - *Stakes*: Her freedom and possibly her life
  - *Character's Approach*: Using her spiritual abilities to evade or confuse pursuers
  - *Outcome*: TBD
  
- **Spiritual Danger Scene**:
  - *Context*: Encounter with malevolent spiritual entity or corrupted death echo
  - *Stakes*: Team's safety, particularly their spiritual/mental well-being
  - *Character's Approach*: Drawing on her understanding of death and spirit realms to protect the team
  - *Outcome*: TBD
  
- **Internal Conflict Scene**:
  - *Context*: Situation where duties to the living clash with obligations to the dead
  - *Stakes*: Her personal philosophy and moral code
  - *Character's Approach*: Navigating the balance between her dual nature and responsibilities
  - *Outcome*: TBD

## Growth Scenes
- **Acceptance by the Team**:
  - *Description*: Moment when the team fully accepts her unusual abilities as valuable
  - *Growth Shown*: Transition from being seen as unsettling to being understood
  - *Key Elements*: Demonstration of how her abilities complement others' skills
  
- **Integration of Dual Nature**:
  - *Description*: Scene showing Nireya finding better balance between her living and death aspects
  - *Growth Shown*: Progress in managing her liminal existence
  - *Key Elements*: More seamless transition between regular and spirit communication, less stark split between day/night abilities
  
- **Building Trust Scene**:
  - *Description*: Moment when someone initially skeptical comes to rely on her spiritual insights
  - *Growth Shown*: Development of mutual respect despite differences
  - *Key Elements*: Validation of her unique perspective, acknowledgment from the skeptic

## Dialogue Highlights
- **Explaining Death to Someone Grieving**:
  - *Context*: Comforting someone who lost a loved one during a mission
  - *Key Quotes*: "Death is a door, not an end," "They are remembered, and so they continue"
  - *Emotional Impact*: Provides unique perspective and potential comfort
  
- **One-Sided Spirit Conversation Witnessed by Others**:
  - *Context*: Team members observing her speaking with spirits they cannot see
  - *Key Elements*: Their reactions, her transitions between addressing spirits and the team
  - *Narrative Purpose*: Illustrates both her abilities and how they appear to others

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
*Potential scenes could include:*
- *The discovery and interpretation of death echoes at a mission site*
- *A night watch scene showing her at peak spiritual connection*
- *A moment where she helps someone communicate with a deceased loved one*
- *Her explaining to the team how she perceives the world differently*
- *Demonstration of the unique bond between her and Thorne due to his near-death experience*
- *Scene showing both the benefits and burdens of her abilities during a rescue mission*
- *A quiet moment of her leaving remembrance tokens and explaining their significance*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Quartermaster Fayne

# Quartermaster Fayne – Profile

## Basic Information
- Full Name: Fayne (chose to leave surname behind)
- Aliases/Nicknames: "The Archivist" (by Marcus), "Pattern-Keeper" (self-chosen)
- Race: Rock Gnome
- Age: 47 (middle-aged for a gnome)
- Gender: Gender-fluid/Non-binary (assigned female at birth, uses they/them pronouns)
- Role in Story: Company Quartermaster, Co-Scribe with Marcus, Pattern-Recognition Specialist
- First Appearance: Chapter 1, Scene 6 (The Vigil)
- Status: Active

## Physical Description
- Height/Build: 3'4" (typical gnome height), wiry and nimble from constant movement
- Hair: Auburn, kept in a practical short cut that changes style based on their daily gender expression
- Eyes: Hazel, shift between green and brown depending on light - always observing, cataloguing
- Distinguishing Features: 
  - Ink-stained fingers that they've given up trying to clean
  - Custom-made spectacles with multiple swing-arm lenses for different magnifications
  - A small scar through their left eyebrow from a childhood accident in the temple archives
  - Leather bandolier with compartments for various inks, quills, and measuring tools
- Typical Clothing: Modified City Guard uniform tailored to be deliberately androgynous; some days with more masculine lines, others more flowing. Always practical.
- Body Language: Precise movements, constantly counting or measuring with fingers, head tilts when recognizing patterns
- Gender Expression: Fluid day-to-day; uses subtle visual cues (jewelry, clothing lines, voice modulation) to express current identity
- Physical Condition: Not combat-trained but surprisingly agile, excellent hand-eye coordination from years of detailed work

## Significance
Quartermaster Fayne represents the logistical and administrative backbone of what will become the Last Light Company. Their heraldry sketches foreshadow the Company's official formation and visual identity.

## Key Actions
- Collected relics from the fallen (shield boss, holy symbol)
- Created the L, E, B, I memorial stones
- Sketched heraldry designs (lantern + shield boss)
- Suggested making the lantern gold "harder to tarnish"
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).
- Played a key role in the Stonebridge investigation, identifying the suspicious warehouse and attempting to crack a safe (Chapter 13).

## Personality Traits
- Thoughtful and creative
- Detail-oriented
- Respectful of the fallen
- Forward-thinking (already planning Company heraldry)
- Artistic inclinations
- Pragmatic
- Possesses strong investigative instincts

## Skills & Abilities
- **Expertise**: Logistics, Administration, Sketching/Drafting, Document Forgery
- **Pattern Recognition**: Unconscious ability to spot patterns in seemingly random data - makes them an exceptional tracker despite no formal training
- **Tracking Through Patterns**: Can follow targets by recognizing disruptions in environmental patterns, behavioral tendencies, supply usage
- **Special Skills**: 
  - Expert forgery (can replicate any handwriting after brief study)
  - Basic lockpicking (still learning complex mechanisms)
  - Eidetic memory for anything they've documented
  - Can calculate supply needs weeks in advance through pattern analysis
  - Spots inconsistencies in stories, movements, or documents instantly

## Voice & Dialogue Patterns
- **Speech Style**: Precise, often speaks in lists or categories, corrects imprecise language
- **Voice Modulation**: Subtly shifts tone based on daily gender expression - some days lower, some days higher, always deliberate
- **Verbal Tics**: 
  - "Note for the record..." when documenting something important
  - "Pattern suggests..." when sharing their tracking insights
  - "Technically speaking..." when correcting inaccuracies
  - Counts things aloud when nervous
- **Signature Phrases**:
  - "Everything has a pattern if you look long enough"
  - "Documents don't lie, but they can be convinced to bend the truth"
  - "I'm not predicting the future, I'm just reading the patterns"
  - "You are what the papers say you are"

## Daily Habits & Quirks
- **Morning Ritual**: Updates three different ledgers while the tea steeps - supply levels, personnel status, pattern observations
- **Counting Compulsion**: Counts everything - steps, heartbeats, words in conversations
- **Organization System**: Appears chaotic to others but every item's position tells part of a larger pattern
- **Gender Expression Markers**: Small daily choices - a pin, a way of tying their belt, stance width - that signal their current identity
- **Pattern Mapping**: Creates artistic representations of the patterns they see - beautiful but incomprehensible to others
- **Documentation Obsession**: Records EVERYTHING, even meals and weather patterns

## Hidden Depths
- **The Prophecy Pattern**: Beginning to see larger patterns that suggest future events - unsure if it's skill or something more
- **Identity Forge**: Maintains a secret workshop where they help others create new identities when needed
- **The Master Pattern**: Believes there's an underlying pattern to everything - seeking it in the Company's formation
- **Memory Palace**: Their eidetic memory is organized as a vast library where they can walk through memories like archives

## Future Role
Expected to become the Company's logistics lead and official co-historian with Marcus, handling supplies, heraldry, and documentation. Their pattern recognition makes them invaluable for predicting enemy movements and supply needs.

---

# Quartermaster Fayne – Background

## Origin
- **Birthplace**: Waterdeep's Trades Ward
- **Birth Name**: Faynara (abandoned when they chose their own identity)
- **Social Class**: Lower middle class
- **Cultural Background**: Rock Gnome; raised in a temple of Gond, the god of craft, which instilled a deep appreciation for systems, history, and artistry
- **Gender Journey**: Assigned female at birth, began questioning rigid categories early - found freedom in Gond's teaching that "all things can be reshaped and remade"

## Family
- **Family Dynamics**: An orphan raised by the priests and artisans of the Gondian temple. Fayne's family is the vast network of correspondents, fellow guild members, and academics with whom they share knowledge.

## History
- **Childhood**: 
  - Grew up surrounded by invention and meticulous record-keeping in Gond's temple
  - Showed early aptitude for spotting patterns others missed - could predict which archive shelves would collapse weeks before they did
  - First realized their gender fluidity while cataloguing identity documents - saw how names and categories could change, be chosen, be remade
  - Began experimenting with different names and presentations in the safety of the temple archives

- **Adolescence & Self-Discovery**:
  - Chose the name "Fayne" at age 23 - a deliberate truncation and transformation of their birth name
  - Learned forgery initially to alter their own documents, discovering a talent for replicating any script
  - The temple priests, following Gond's philosophy of transformation and craft, supported their journey
  - Developed their pattern-recognition into an almost supernatural ability - could track missing books through the library by disruption patterns in dust

- **Motivation for Joining the Watch**: 
  - A passion for systems and the power of documentation
  - The City Watch offered a chance to remake themselves officially - new papers, new identity, recognized by the city
  - For Fayne, the logistical operation of the Watch is a fascinatingly complex pattern to understand and perfect
  - Also saw it as an opportunity to help others who needed documentation "adjusted" for their safety

- **Pattern Recognition Evolution**:
  - What started as organizing archives became an ability to see connections others couldn't
  - Can track people not through footprints but through patterns - where they buy supplies, how they disrupt normal flows, what they change
  - This makes them an exceptional investigator despite no formal training

- **Personal Practices**: 
  - Maintains three different sets of documentation with subtle variations on their gender markers
  - Creates artistic "pattern maps" that document the flow of people and supplies through the city
  - Their quarters are organized in a system only they understand - appears chaotic but every item's position tells a story

---

# Quartermaster Fayne – Character Development

## Personality Core
- **Defining Traits**: Meticulous, pattern-obsessed, creative, transformative, precisely chaotic
- **Core Values**: The power of documentation to shape reality, preservation of truth, the beauty of patterns, the right to self-definition
- **Motivations**: To document history as it happens, to help others remake themselves through documentation, to find the patterns that predict the future
- **Fears**: Being erased from history, loss of knowledge, chaos without pattern, being trapped in one identity
- **Internal Conflicts**: 
  - The desire for neat systems versus chaotic reality of rescue work
  - Documenting truth versus sometimes needing to forge better realities
  - Being visible as themselves versus old habits of hiding

## Gender Identity & Documentation Philosophy
- **Documentation as Identity**: Understands deeply that "you are what the papers say you are" - uses this power to help others
- **Fluidity in Record-Keeping**: Maintains different versions of records that capture different aspects of truth
- **The Power of Names**: Believes names are chosen, not given - documents people as they choose to be known
- **Living Archive**: Sees themselves as a living document, constantly being revised and updated
- **Helping Others Transform**: Uses forgery skills to help others escape dangerous pasts or claim new futures

## Character Arc
- **Starting Point**: A highly competent but detached Quartermaster, more interested in the systems of the Watch than its day-to-day drama.
- **Catalyst Events**: Witnessing the birth of a living legend in Undershade Canyon.
- **Current State**: The official (and self-appointed) archivist and logistician of the Last Light Company, finding immense satisfaction in building its operational and symbolic foundations from scratch.
- **Intended Destination**: To become the Company's historian and master of logistics, the keeper of its story and the architect of its efficiency.

## Key Relationships

### Core Company Members

- **Marcus Heartbridge (Co-Scribe)**:
  - **Professional Dynamic**: They divide documentation duties - Marcus handles the narrative and diplomatic correspondence while Fayne manages logistics, supplies, and technical documentation
  - **Personal Connection**: Marcus was one of the first to use Fayne's chosen pronouns without question; sees them as they choose to be seen
  - **Creative Collaboration**: Together they're creating the Company's mythology - Marcus provides the flourish, Fayne provides the foundation
  - **Mutual Respect**: Marcus appreciates Fayne's patterns; Fayne appreciates Marcus's ability to make dry facts sing
  - **Shared Secret**: Marcus knows about Fayne's forgery skills and occasionally requests "historical corrections" for the Company's benefit

- **Thorne Brightward**: 
  - **The "Ideal System Administrator"**: Fayne admires Thorne's efficiency and clear command structure
  - **Reports and Improvements**: Their reports to Thorne are precise, detailed, with unsolicited process improvements
  - **Gender Understanding**: Thorne's military background means he judges by capability, not identity - treats Fayne as the expert they are

- **Veyra Thornwake**:
  - **Living History**: Fayne sees Veyra as a historical figure in real-time, documenting her words and actions obsessively
  - **First Thought at Undershade**: "How is she still standing? This is... foundational. Like seeing a new mountain rise from the earth."
  - **Why They Followed**: The chance to build a new system from scratch, to document history as it happens
  - **Current Dynamic**: Veyra trusts Fayne's patterns even when she doesn't understand them

- **Vera Moonwhisper**:
  - **Pattern Recognition Kinship**: Both track through different types of patterns - Vera through nature, Fayne through systems
  - **Mutual Teaching**: Vera teaches natural tracking, Fayne teaches urban pattern recognition
  - **Respect for Fluidity**: Vera's shape-changing druidic nature resonates with Fayne's fluid identity

- **Grimjaw Ironbeard**:
  - **Engineering Fascination**: Fayne is obsessed with documenting dwarven organizational methods
  - **Practical Acceptance**: Grimjaw cares about function over form - judges Fayne by their competence
  - **Shared Appreciation**: Both understand that good organization can save lives


---

# Quartermaster Fayne - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Quartermaster Fayne - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Quartermaster Fayne - Scene Tracker

## Major Scenes

### Chapter 1 – Ash and Compass <!-- slug: ch1-ash-compass -->
- **Scene 5**: Part of the patrol that discovers Veyra.

### Chapter 7 – The Weight of the World <!-- slug: ch7-weight-world -->
- **Scene 2**: Uses observational skills to help locate the reclusive Grimjaw Ironbeard.

### Chapter 12 – The Wayward Compass <!-- slug: ch12-wayward-compass -->
- **Scene 1**: On the supply run, provides medical aid to an injured civilian.
- **Scene 2**: Witnesses the standoff and Marcus Heartbridge's intervention at the inn.

### Chapter 13 – An Honest Coin <!-- slug: ch13-honest-coin -->
- **Scene 1**: Offering a pragmatic, logistics-focused view on Marcus's information.
- **Scene 2**: Arguing for the practical necessity of a headquarters during the moral debate.

## Character Moments

### Best Moments
- Using keen artist's eye for a non-combat purpose to find Grimjaw (Ch. 7).

### Worst Moments
- TBD

### Turning Points
- TBD

## Interaction Log

### With Veyra Thornwake
- TBD

### With Thorne Brightward
- TBD

### With Grimjaw Ironbeard
- Chapter 7: Key player in his recruitment.

### With Vera Moonwhisper
- TBD

## Upcoming Scenes

### Planned Appearances
- **The Pattern Hunt**: Fayne tracks a missing person through supply disruptions and behavioral patterns rather than physical trails
- **The Co-Scribes**: Scene with Marcus dividing up documentation duties, showing their collaborative dynamic
- **The Identity Forge**: Helping a refugee create new documentation to escape their past
- **The Master Pattern**: Fayne realizes the Company's formation follows an ancient pattern they've seen in old texts

### Required Interactions
- **With Marcus**: Establishing their co-scribe dynamic and mutual respect
- **With Vera**: Comparing pattern-tracking methods, learning from each other
- **Gender Expression Scene**: A quiet moment where someone asks about their pronouns/identity, allowing for character education

## Potential Character Scenes

### The Living Document
- **Description**: Fayne explaining to a new Company member why they maintain multiple versions of the same records
- **Purpose**: Explores their philosophy that truth has many faces
- **Key Elements**: Shows their gender fluidity reflected in their record-keeping philosophy

### Pattern Recognition in Action
- **Description**: During a rescue mission, Fayne predicts enemy movements by analyzing supply purchases from the past month
- **Purpose**: Showcases their unique tracking ability
- **Key Elements**: Others are skeptical until the predictions prove exactly correct

### The Forgery Dilemma
- **Description**: Asked to create false death certificates to help families escape debt from deceased relatives
- **Purpose**: Explores moral flexibility in documentation
- **Key Elements**: Shows how they view forgery as another form of crafting reality

### Gender Affirmation Moment
- **Description**: A young person seeks Fayne's help in changing their documentation
- **Purpose**: Pays forward the support Fayne received
- **Key Elements**: Tender moment of understanding and practical assistance

### The Collaboration
- **Description**: Marcus and Fayne work late into the night on Company chronicles, their different styles creating something greater
- **Purpose**: Establishes their working relationship and mutual respect
- **Key Elements**: Marcus's flourish with Fayne's precision, creating the Company's mythology together


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Sergeant Kelen

# Sergeant Kelen – Profile

## Basic Information
- **Full Name**: Kelen Harwick (surname rarely used - prefers rank)
- **Aliases/Nicknames**: "Sergeant", "Kel" (only by close family), "The Rock" (patrol nickname)
- **Race**: Human (Illuskan)
- **Age**: 44 (veteran but not yet old guard)
- **Gender**: Male
- **Role in Story**: Thorne's second-in-command, Company Senior NCO, Founding Patrol Member
- **First Appearance**: Chapter 1, Scene 5 (Arrival of the Watch)
- **Status**: Active

## Physical Description
- **Height/Build**: 5'10", solid but not bulky - functional strength built from years of practical military work
- **Hair**: Iron-gray, kept regulation short but starting to thin at the temples. Shows his age and experience
- **Eyes**: Weathered brown, always scanning for threats or problems. Crow's feet from years of squinting in sun and smoke
- **Distinguishing Features**: 
  - Scarred, calloused hands that are a roadmap of his career - burn marks, blade nicks, rope cuts
  - Old knife scar along left jawline from early Watch service
  - Arrow scar on right shoulder (visible when out of armor)
  - Slight limp in left leg from an old injury, barely noticeable unless exhausted
- **Typical Clothing**: Immaculately maintained City Guard armor, always checking buckles and straps. Off-duty wears simple, practical clothes in muted colors
- **Body Language**: Perfect military posture even when relaxed, moves with economical precision, instinctively positions himself to protect others
- **Physical Condition**: Combat-ready veteran in excellent shape for his age, built for endurance rather than flash

## Personality
- **Archetype**: The Steadfast Foundation - The Senior NCO who makes everything work
- **Temperament**: Steady, practical, protective, quietly authoritative
- **Positive Traits**: Absolutely reliable, fiercely loyal, protective of his people, calm under pressure, excellent judge of character
- **Negative Traits**: Can be overly cautious, struggles with emotional expression, tends to shoulder too much responsibility alone
- **Moral Alignment**: Lawful Good - believes in doing right by your people within proper structure
- **Core Philosophy**: "Take care of your people, and they'll take care of the mission" / "Lead from the front, but watch everyone's back"
- **Leadership Style**: "Follow me" rather than "Go there" - leads by example and quiet competence

## Significance
Sergeant Kelen serves as Captain Thorne's trusted second-in-command and was part of the patrol that rescued Veyra from Undershade Canyon. His steady presence and loyalty make him a natural choice as a founding member of the Last Light Company. He represents military discipline and the bridge between command and ground operations.

## Key Actions
- Helped stabilize Veyra's lantern during her collapse
- Arranged the bodies of the fallen with respect
- Brought lamp oil to Veyra during recovery
- Participated in the patrol's vigil
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).

## Skills & Abilities
- **Expertise**: Military tactics, personnel management, defensive combat, urban warfare
- **Leadership Skills**: Delegation, crisis management, troop morale, practical problem-solving
- **Combat Abilities**: 
  - Defensive fighting style focused on protection rather than aggression
  - Expert with sword and shield - prioritizes covering others
  - Exceptional situational awareness in combat
  - Training in siege defense and urban patrol tactics
- **Special Skills**: 
  - Can assess character and competence within minutes of meeting someone
  - Network of contacts throughout Waterdeep City Watch
  - Expert in military logistics and supply management
  - Knows the city's security systems and protocols intimately

## Personal Details
- **Habits**: 
  - Up before dawn for equipment inspection and duty roster review
  - Writes weekly letters to his daughter Elspeth (factual, not emotional)
  - Evening equipment maintenance ritual before sleep
  - Always eats last, after ensuring everyone else is fed
- **Hobbies**: 
  - Carves small wooden figures (childhood habit that persists)
  - Reads tactical manuals and military history
  - Takes long walks around perimeter to think and plan
- **Personal Quarters**: A spartan and precisely organized room on the ground floor of the Company barracks, strategically positioned with clear sightlines to the main entrance and quick access to the armory. The room is modest in size, reflecting his practical needs rather than comfort preferences. The furniture is heavy, functional, and made of dark, unadorned wood, all arranged at perfect right angles. The room is immaculately clean and organized. Every item has a designated place and purpose. A small wooden shelf holds carefully curated personal items: a bundle of letters from his daughter Elspeth, a small framed sketch of his late wife Anya, and several carved wooden figures he's made.
- **Likes**: Military efficiency, good equipment maintenance, soldiers who follow orders, protecting his people
- **Dislikes**: Waste (of supplies or lives), unnecessary risks, politicians who endanger troops, incompetent leadership
- **Fears**: Failing his people, his daughter being targeted because of his work, losing more family
- **Motivations**: Providing for and protecting Elspeth, ensuring his people come home safe, building something lasting with the Company

## Voice & Dialogue Patterns
- **Speech Style**: Economical with words, clear directives, gravelly voice from years of shouting orders
- **Voice Quality**: Can speak quietly when needed but naturally projects authority
- **Verbal Tics**: 
  - "Right then..." when making decisions or taking charge
  - "As you were" to dismiss concerns or redirect focus
  - "Watch your six" as general warning about potential dangers
  - Uses ranks/roles rather than names in crisis situations
- **Signature Phrases**:
  - "Take care of your people, and they'll take care of the mission"
  - "I've seen worse. We'll manage."
  - "Good work. Now check your gear."
  - "Lead from the front, watch everyone's back"
- **Communication Style**: Direct but not harsh, gives orders that sound like suggestions to civilians but are clearly understood by military personnel

## Equipment
- **Primary Weapon**: Standard City Watch longsword, well-maintained but not fancy
- **Secondary Weapon**: Military dagger, practical tool as much as weapon
- **Armor**: City Watch plate armor, meticulously maintained with personal modifications for better fit
- **Shield**: Heavy shield with Company emblem, used defensively to protect others
- **Personal Items**: 
  - Carved wooden figures (gifts for Elspeth, stress relief)
  - Military field manual (extensively annotated)
  - Small toolkit for equipment maintenance
  - Letters from his daughter (carefully preserved)

## Combat Style
- **Primary Role**: Defensive coordinator, protects others rather than seeking glory
- **Pre-Combat**: Becomes quieter, checks everyone's equipment twice
- **In Combat**: Positions himself to shield others, calls out threats and coordination
- **Post-Combat**: Immediately shifts to casualty assessment and equipment status
- **Tactical Philosophy**: "Everyone comes home" - values team survival over individual heroics

## Future Role
Expected to become the Company's Senior NCO and operational backbone, handling field operations, maintaining discipline, and serving as the bridge between command decisions and ground implementation. Will likely become the Company's institutional memory and training coordinator.


---

# Sergeant Kelen – Background

## Origin
- **Birthplace**: Waterdeep's Dock Ward - specifically the Fishgut Court tenements
- **Birth Date**: Born during the harsh winter of the Year of the Broken Blade
- **Social Class**: Lower class - dockworker family living in overcrowded conditions
- **Cultural Background**: Urban poor, shaped by the harsh realities of Waterdeep's most dangerous district. Learned early that survival meant structure, loyalty, and watching out for your own.

## Family
- **Father**: Jorik Harwick - dockworker lost in a shipping accident when Kelen was 12. Taught Kelen the value of hard work and keeping your word. His death left the family destitute.
- **Mother**: Mara Harwick - seamstress who took in piecework to support the family. Died of lung fever two years after Jorik's death, worn down by poverty and grief.
- **Spouse**: Anya Harwick (née Millwright) - met her when she was a baker's assistant. Married young for love and stability. She died from red fever during an epidemic ten years ago, leaving Kelen to raise Elspeth alone.
- **Daughter**: Elspeth Harwick, now 22 - apprenticed to Master Bookbinder Aldric Thornton in the Trades Ward. Bright, independent, and skilled with her hands like her grandmother. 
- **Family Dynamics**: 
  - Lost his parents early, learned responsibility young
  - With Anya: Brief happiness interrupted by tragedy - her death taught him that love makes you vulnerable
  - With Elspeth: Protective but distant - sends most of his pay, writes weekly letters, visits rarely to keep her safe from his dangerous work
  - Fears that getting too close to people leads to loss, but can't stop himself from caring

## History

### Early Life (Ages 0-18)
- **Childhood**: Grew up in Fishgut Court tenements after parents' deaths. Survived by doing odd jobs around the docks, learned to read from a sympathetic priest of Tyr.
- **Adolescence**: Avoided the gangs and criminal opportunities of the Dock Ward through sheer stubbornness and the memory of his father's work ethic.
- **Turning Point**: At 16, witnessed a City Watch patrol save a group of children from kidnappers. Realized the Watch offered both structure and purpose.

### Military Career (Ages 18-44)
- **Watch Academy (Age 18-19)**: Excelled in discipline, defensive tactics, and leadership exercises. Graduated top of his class in practical application.
- **Early Service (Ages 19-22)**: Foot patrol in the Dock Ward. Earned reputation for fairness and courage. Received knife scar during a tavern brawl intervention.
- **Promotion to Corporal (Age 23)**: Recognized for preventing a riot during grain shortage. Began developing his protective leadership style.
- **Marriage and Family (Ages 24-34)**: Met and married Anya, had Elspeth. Tried to balance family life with increasingly dangerous Watch duties.
- **The Red Fever Epidemic (Age 34)**: Lost Anya during city-wide plague. Nearly left the Watch but stayed for Elspeth's security.
- **Promotion to Sergeant (Age 36)**: Given command of his own patrol after previous sergeant was killed in action. Arrow scar from defending supply convoy.
- **Partnership with Thorne (Ages 38-44)**: Assigned as second-in-command to Captain Brightward. Developed perfect working relationship over six years.

### Personal Growth & Development
- **Core Trauma**: Multiple losses taught him that caring for people means accepting the risk of losing them
- **Leadership Evolution**: From following orders to taking initiative to protecting his people above all else
- **Emotional Walls**: Built protective distance after Anya's death, but can't stop himself from caring for his patrol family
- **Current Philosophy**: "Take care of your people" became his guiding principle after learning leadership through loss

### The Undershade Canyon Incident
- **The Rescue**: Part of Thorne's patrol that found Veyra. Immediately recognized her soldier's dedication to fallen comrades.
- **Key Moment**: His understanding that "she won't leave without them" showed his recognition of the same protective duty he felt.
- **Decision to Follow**: Initially followed Thorne's lead, but Veyra's commitment to remembering the dead resonated with his own losses.
- **Company Formation**: Saw the Last Light Company as a chance to build something permanent that honors both the living and the fallen.

---

# Sergeant Kelen – Character Development

## Personality Core
- **Defining Traits**: Steady, reliable, pragmatic, protective, quietly authoritative, emotionally guarded
- **Core Values**: Duty to your people above all else, earned respect over rank, the soldier's code of "everyone comes home"
- **Motivations**: 
  - Providing for and protecting Elspeth from a distance
  - Ensuring his people survive and thrive under his protection
  - Building something lasting with the Company that honors both living and dead
  - Breaking the cycle of loss that has defined his life
- **Fears**: 
  - Failing his people like he couldn't save Anya
  - Elspeth being targeted because of his dangerous work
  - Getting too close to Company members only to lose them
  - Making the wrong call that gets someone killed
- **Internal Conflicts**: 
  - Military protocol vs. Company's unconventional methods
  - Protective distance vs. genuine care for Company family
  - Past grief vs. present hope for building something better
  - Duty to daughter vs. duty to Company

## Character Arc

### Act I: The Weary Soldier
- **Starting Point**: Competent but emotionally distant sergeant going through the motions
- **Internal State**: Protective walls built after Anya's death, focus solely on duty and Elspeth's welfare
- **Relationship Pattern**: Professional competence masking deep emotional isolation

### Act II: The Awakening
- **Catalyst Events**: 
  - Undershade Canyon rescue - witnessing Veyra's dedication to fallen comrades
  - Recognition of shared soldier's code and protective duty
  - Decision to follow Thorne into the unknown with the Company
- **Internal Shift**: Purpose reignited, seeing possibility of building something meaningful
- **New Challenges**: Learning to trust and care for new "family" while protecting heart

### Act III: The Foundation Builder
- **Current State**: Becoming emotional and operational anchor for the Company
- **Growth Areas**: 
  - Learning to accept help and emotional support from others
  - Balancing protective instincts with allowing people their own agency
  - Opening up about his past and fears to trusted Company members
- **Relationship Evolution**: From distant protector to engaged patriarch figure

### Act IV: The Patriarch (Future Development)
- **Intended Destination**: Company's senior NCO and emotional cornerstone
- **Full Arc Completion**: 
  - Accepting that caring deeply is worth the risk of loss
  - Allowing Elspeth into his dangerous world when she's ready
  - Becoming the father figure the Company needs while staying connected to his own daughter
  - Building institutional knowledge and training systems for future recruits

## Key Relationships

### Core Command Structure

**Captain Thorne Brightward**:
- **Nature of Bond**: Perfect officer/NCO partnership built on six years of absolute trust
- **Dynamics**: Thorne gives the order, Kelen ensures it's done right. He is the shield to Thorne's sword.
- **Communication**: Largely unspoken understanding, can anticipate each other's needs in crisis
- **Personal Connection**: Mutual respect and genuine friendship beneath professional facade
- **Role**: Kelen handles details so Thorne can focus on strategy; protects Thorne's blind spots

**Commander Veyra Thornwake**:
- **First Impression**: "Another one lost to the wilds. Gods, the look in her eyes... she's seen hell."
- **Recognition Moment**: Watching her meticulous work with fallen comrades' bodies - recognized shared soldier's code
- **Why He Follows**: Initially followed Thorne's lead, but her commitment to "no one left behind" resonated with his protective nature
- **Current Relationship**: Sees her as living embodiment of the protective duty he values
- **Future Dynamic**: Will become her most reliable anchor, translating vision into practical reality

### Original Patrol Family

**Corporal Darric, Archer Venn, Medic Halden, Quartermaster Fayne**:
- **Bond Type**: Surrogate family unit that replaced his lost biological family
- **History**: Years of shared danger, mutual protection, inside jokes and survival
- **His Role**: Protective older brother/father figure who knows each member's strengths and limitations
- **Emotional Investment**: Deeper than professional - these are "his people" in the truest sense
- **Growth**: Learning to express care more openly as they transition from Watch to Company

### Specialists Integration

**Grimjaw Ironbeard**:
- **Common Ground**: Both understand the weight of protecting others, practical approach to problems
- **Mutual Respect**: Recognizes Grimjaw's competence and dedication despite different background
- **Professional Appreciation**: Values his engineering skills and willingness to get dirty
- **Potential Tension**: Grimjaw's informal style vs. Kelen's military structure

**Vera Moonwhisper**:
- **Professional Respect**: Appreciates her tracking abilities and wilderness expertise
- **Protective Instinct**: Sees her youth and wants to keep her safe while respecting her competence
- **Learning Opportunity**: Her different approach to problem-solving challenges his military thinking

**Nireya Voss**:
- **Initial Wariness**: Unsettled by her supernatural abilities and dual nature
- **Growing Understanding**: Comes to appreciate her dedication to remembering the fallen
- **Protective Role**: Recognizes her vulnerability after using her powers, ensures she's cared for
- **Philosophical Connection**: Both deal with loss and honoring the dead in their own ways

**Marcus Heartbridge**:
- **Professional Necessity**: Understands the value of his diplomatic and information skills
- **Cultural Clash**: Marcus's smooth social graces vs. Kelen's blunt honesty
- **Gradual Respect**: Learning to appreciate Marcus's genuine care for the Company's mission
- **Collaborative Potential**: Marcus handles politics, Kelen handles practical implementation

### Personal Relationships

**Daughter Elspeth**:
- **Current Dynamic**: Protective distance maintained through letters and financial support
- **Internal Conflict**: Wants to be closer but fears endangering her
- **Growth Arc**: Learning to trust her independence while staying connected
- **Company Impact**: Other members may help him realize he can have both closeness and safety

**Memory of Anya**:
- **Ongoing Influence**: Her loss still shapes his protective but distant approach to relationships
- **Healing Process**: Company family slowly helping him understand that love doesn't always end in loss
- **Integration**: Learning to honor her memory while building new connections

## Character Growth Milestones

**Milestone 1: Opening Up**
- Sharing personal history with trusted Company members
- Accepting help and emotional support when offered
- Allowing others to see his vulnerabilities

**Milestone 2: Integrated Leadership**
- Becoming comfortable with Company's unconventional methods
- Balancing military discipline with family atmosphere
- Training and mentoring new recruits

**Milestone 3: Emotional Integration**
- Accepting that caring deeply is worth the risk
- Building genuine friendships within the Company
- Finding balance between protection and autonomy

**Milestone 4: Legacy Building**
- Establishing institutional knowledge and traditions
- Preparing successors and training systems
- Reconciling relationship with Elspeth


---

# Sergeant Kelen - Relationships

## Professional Relationships

### Command Structure

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Perfect officer/NCO partnership - the shield to Thorne's sword
  - *Hierarchy*: Thorne's second-in-command with complete operational autonomy
  - *Dynamics*: Six years of building absolute trust - largely unspoken communication, anticipates each other's needs
  - *Professional Opinion of*: The ideal officer - firm but fair, tactically brilliant but compassionate
  - *History*: Assigned as Thorne's sergeant six years ago, developed seamless working relationship
  - *Current Status*: Mutual respect and genuine friendship beneath professional facade
  - *Key Moments*: Countless crisis situations where their partnership kept everyone alive
  - *Future Development*: Will remain Thorne's anchor while expanding role to mentor Company specialists

- **Commander Veyra Thornwake**:
  - *Nature of Relationship*: Soldier recognizing fellow soldier - shared protective code
  - *Hierarchy*: Accepts her overall command while serving as practical implementation specialist
  - *Dynamics*: Initially followed Thorne's lead, now genuinely committed to her vision
  - *Professional Opinion of*: Living embodiment of protective duty he values above all else
  - *First Impression*: "Another one lost to the wilds. Gods, the look in her eyes... she's seen hell."
  - *Recognition Moment*: Watching her meticulous work with fallen comrades - recognized shared soldier's code
  - *Current Status*: Will become her most reliable anchor, translating vision into practical reality
  - *Key Philosophy*: Her "no one left behind" resonates perfectly with his protective nature

### Original Patrol (Surrogate Family)

- **Corporal Darric**:
  - *Nature of Relationship*: Trusted subordinate and surrogate younger brother
  - *Hierarchy*: Clear chain of command but deep personal bond
  - *Dynamics*: Years of shared danger built unshakeable trust
  - *Professional Opinion of*: Absolutely reliable, shares his commitment to protective duty
  - *Personal Connection*: One of "his people" - would risk everything to protect
  - *Growth Area*: Learning to express care more openly as they transition to Company

- **Archer Venn**:
  - *Nature of Relationship*: Veteran team member and tactical specialist
  - *Hierarchy*: Peer-level respect despite rank difference
  - *Dynamics*: Mutual professional competence and shared military humor
  - *Professional Opinion of*: Skilled marksman with good tactical instincts
  - *Personal Connection*: Part of his chosen family unit

- **Medic Halden**:
  - *Nature of Relationship*: Essential team member and voice of medical authority
  - *Hierarchy*: Defers to Halden's medical expertise completely
  - *Dynamics*: Protects Halden so Halden can protect everyone else
  - *Professional Opinion of*: Invaluable specialist whose skills save lives
  - *Personal Connection*: Appreciates his dedication to healing over harming

- **Quartermaster Fayne**:
  - *Nature of Relationship*: Logistics partner and administrative support
  - *Hierarchy*: Collaborative rather than hierarchical
  - *Dynamics*: Appreciates their organizational skills and attention to detail
  - *Professional Opinion of*: Essential for operational efficiency
  - *Personal Connection*: Respects their pattern recognition abilities
  - *Growth Area*: Learning to understand their gender-fluid identity and support their documentation work

### Specialists Integration

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Mutual respect between protective professionals
  - *Hierarchy*: Different specialties, equal importance
  - *Dynamics*: Both understand the weight of protecting others
  - *Professional Opinion of*: Competent engineer with dedication to the Company
  - *Common Ground*: Practical approach to problems, willingness to get dirty
  - *Potential Tension*: Grimjaw's informal style vs. Kelen's military structure
  - *Current Status*: Building mutual respect based on shared protectiveness

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Protective mentor to skilled specialist
  - *Hierarchy*: Different expertise areas
  - *Dynamics*: Sees her youth and wants to keep her safe while respecting competence
  - *Professional Opinion of*: Exceptional tracking abilities, valuable wilderness expertise
  - *Protective Instinct*: Fatherly concern for her safety in dangerous situations
  - *Learning Opportunity*: Her different approach to problem-solving challenges his military thinking
  - *Growth Potential*: Could develop into genuine father-daughter mentorship

- **Nireya Voss**:
  - *Nature of Relationship*: Philosophical connection despite initial wariness
  - *Hierarchy*: Different specialties requiring mutual respect
  - *Dynamics*: Initially unsettled by supernatural abilities, growing understanding of her dedication
  - *Professional Opinion of*: Valuable specialist whose commitment to honoring dead resonates with him
  - *Protective Role*: Recognizes her vulnerability after using powers, ensures she's cared for
  - *Common Ground*: Both deal with loss and honoring the dead in their own ways
  - *Current Status*: Evolving from wariness to protective understanding

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Professional necessity evolving into grudging respect
  - *Hierarchy*: Different specialties with collaborative potential
  - *Dynamics*: Cultural clash between smooth social graces and blunt honesty
  - *Professional Opinion of*: Values his diplomatic skills despite personal style differences
  - *Working Relationship*: Marcus handles politics, Kelen handles practical implementation
  - *Growth Area*: Learning to appreciate Marcus's genuine care for Company mission
  - *Future Potential*: Could develop effective partnership despite personality differences

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Mutual respect between caregivers
  - *Hierarchy*: Different but complementary specialties
  - *Dynamics*: Both focused on protecting and healing their people
  - *Professional Opinion of*: Essential medical support and spiritual anchor
  - *Common Ground*: Understanding the weight of keeping people alive and healthy
  - *Personal Appreciation*: Values Aldwin's calm presence during crisis

- **Other Specialists** (Lyralei, Cidrella, Korrath, Kaida):
  - *General Approach*: Initially skeptical of non-military members
  - *Evolution Pattern*: Gradually developing respect based on competence and dedication
  - *Role Development*: Becoming protective father figure to younger/newer members
  - *Integration Challenge*: Bridging gap between military and civilian approaches

## Personal Relationships

### Family Connections

- **Daughter Elspeth Harwick**:
  - *Relationship Type*: Beloved daughter kept at protective distance
  - *Current Dynamic*: Weekly letters and financial support from afar
  - *History*: Lost her mother at age 12, raised by Kelen alone until apprenticeship
  - *Internal Conflict*: Wants to be closer but fears endangering her
  - *Growth Arc*: Learning to trust her independence while staying connected
  - *Company Impact*: Other members may help him realize closeness and safety can coexist
  - *Future Development*: Potential for Elspeth to visit or even join Company in safe capacity

- **Memory of Anya (deceased wife)**:
  - *Relationship Type*: Ongoing influence of lost love
  - *Impact on Present*: Her loss shapes his protective but distant approach
  - *Healing Process*: Company family slowly helping him understand love doesn't always end in loss
  - *Integration Goal*: Learning to honor her memory while building new connections

### Waterdeep Connections

- **Watch Contacts**:
  - *Relationship Type*: Professional network and information sources
  - *Value*: Provides Company with city intelligence and support
  - *Maintenance*: Careful balance of loyalty to old colleagues vs. new mission
  - *Usage*: Strategic resource for Company operations requiring city access

- **Dock Ward Connections**:
  - *Relationship Type*: Childhood neighborhood ties
  - *Current Status*: Limited but occasionally useful
  - *Emotional Weight*: Reminders of hard early life and lost family
  - *Practical Value*: Understanding of city's underbelly and criminal patterns

## Interpersonal Patterns

### Leadership Style
- **With Subordinates**: "Follow me" rather than "Go there" - leads by example
- **With Peers**: Collaborative but maintains clear operational boundaries
- **With Superiors**: Absolute loyalty balanced with tactical expertise
- **With Specialists**: Protective while respecting their unique capabilities

### Emotional Expression
- **Comfort Level**: More comfortable showing care through actions than words
- **Protective Instincts**: Immediate and sometimes overwhelming
- **Trust Building**: Slow to open up but absolutely loyal once committed
- **Conflict Resolution**: Direct but fair, focuses on practical solutions

### Communication Patterns
- **With Military Personnel**: Clear, economical, uses rank and procedure
- **With Civilians**: Adapts to less formal structure while maintaining authority
- **Under Stress**: Becomes quieter, more focused on practical details
- **In Crisis**: Takes charge naturally, coordinates through clear directives

## Relationship Evolution Tracker

### Pre-Company
- **Emotional State**: Protective isolation following Anya's death
- **Relationship Pattern**: Professional competence masking deep emotional distance
- **Coping Mechanism**: Focus on duty and Elspeth's welfare as way to avoid new attachments

### Early Company Formation
- **Catalyst Moment**: Recognizing Veyra's soldier's code at Undershade Canyon
- **Transition Phase**: Following Thorne's lead while developing independent commitment
- **New Challenges**: Learning to care for expanded "family" while protecting emotional walls

### Current Development
- **Growth Areas**: Opening up to trusted Company members about personal history
- **Relationship Building**: Developing genuine connections beyond professional necessity
- **Integration Process**: Balancing military structure with Company's family atmosphere

### Future Potential
- **Emotional Integration**: Accepting that caring deeply is worth the risk
- **Leadership Evolution**: Becoming Company patriarch while staying connected to Elspeth
- **Legacy Building**: Training successors and establishing institutional knowledge
- **Personal Healing**: Finding balance between honoring past loss and embracing present connections

## Notes on Relationship Dynamics

### Protective Hierarchy
1. **Immediate Family**: Elspeth (biological daughter)
2. **Chosen Family**: Original patrol members
3. **Extended Family**: Company specialists and allies
4. **Professional Network**: Watch contacts and allies

### Trust Levels
- **Absolute Trust**: Thorne, original patrol members
- **Growing Trust**: Veyra, core Company specialists  
- **Professional Trust**: New Company members, Watch contacts
- **Cautious Engagement**: Unknown civilians, political figures

### Communication Preferences
- **Face-to-Face**: For important decisions and personal conversations
- **Written**: For routine reports and letters to Elspeth
- **Indirect**: Uses actions more than words to show care
- **Crisis**: Clear, direct verbal commands with minimal explanation needed

---

# Sergeant Kelen — Dialogue & Voice

## Core Temperament
Steady, pragmatic, and protective. A veteran NCO whose gravelly voice carries natural authority. Economical with words but deeply caring—shows emotion through actions rather than lengthy speeches. His military background shapes every aspect of his communication.

## Dialogue Instincts
- **Command Voice**: Clear, direct orders that civilians hear as suggestions but military personnel understand as absolute
- **Protective Mode**: Becomes quieter and more focused when assessing threats or managing crisis
- **Personal Conversations**: Awkward with emotional expression, prefers practical demonstrations of care
- **Under Pressure**: Even more concise, shifts to rank/role usage instead of names

## Voice Characteristics
- **Tone**: Gravelly from years of shouting orders across battlefields and training yards
- **Volume**: Naturally projects authority but can speak quietly when situation demands
- **Cadence**: Measured, deliberate - every word chosen for purpose
- **Regional Accent**: Slight Waterdeep Dock Ward roughness, mostly smoothed by military service

## Emotional Anchors & Physical Tells
- **Scanning Behavior**: Eyes constantly assess room for threats, positions, escape routes
- **Protective Positioning**: Instinctively places himself between danger and his people
- **Equipment Checks**: Nervous habit of checking gear when uncomfortable or thinking
- **Hand Movements**: Uses precise gestures when giving directions, touches his sword hilt when worried

## Verbal Tics & Signature Phrases

### Command Phrases
- **"Right then..."** - Taking charge of a situation or making a decision
- **"As you were"** - Dismissing concerns or redirecting focus
- **"Watch your six"** - General warning about potential dangers
- **"Good work. Now check your gear."** - Praise followed by practical next step

### Core Philosophy Expressions
- **"Take care of your people, and they'll take care of the mission"**
- **"Lead from the front, watch everyone's back"**
- **"I've seen worse. We'll manage."**
- **"Everyone comes home"** - His fundamental mission objective

### Emotional Expressions (Rare)
- **"That's my responsibility"** - When protecting others from blame
- **"You did what you could"** - Comforting someone after loss
- **"We don't leave people behind"** - Stating core values

## Speech Patterns by Situation

### Crisis Management
- Becomes even more economical with words
- Uses rank/role instead of names for clarity
- Gives orders that sound like casual suggestions to outsiders
- Voice drops to calm, measured tone that cuts through chaos

### Training/Mentoring
- Patient but firm explanations
- Breaks complex tasks into simple steps
- Uses military metaphors and examples
- Emphasizes safety and teamwork over individual glory

### Personal Conversations
- Struggles with emotional vocabulary
- Often deflects to practical matters
- Shows care through actions rather than words
- Uncomfortable with receiving gratitude or praise

### Letters to Elspeth
- More formal than spoken language
- Focuses on factual updates rather than emotions
- Careful to avoid mentioning dangerous aspects of work
- Ends with practical advice or encouragement

## Dialogue Samples by Context

### Taking Command
*"Right then, here's how we're going to handle this. Venn, you're overwatch from that rooftop. Darric, east approach. Halden, you stay with the wounded. Questions?"*

### Reassuring Under Pressure
*"I've seen worse than this, and those times we had half the gear and twice the problems. We'll manage. Just stick to the plan and watch each other's backs."*

### Protective Warning
*"Easy there. You've done enough for one day. Let someone else take point for a while. That's not giving up—that's being smart."*

### Showing Care (Indirectly)
*"Picked this up in the market. Thought it might be useful for your equipment maintenance. Nothing fancy, just practical."*

### Crisis Communication
*"Medic! Two wounded, stable but need attention. Fayne, I need supply count and status report. Everyone else, perimeter check. Move."*

### Philosophical Moment (Rare)
*"Your father would be proud. Not because you never fell down, but because you always got back up. That's what matters."*

## Evolution Through Story Arcs

### Early Company Formation
- More military formal, relies heavily on rank and procedure
- Emotionally distant even from patrol members
- Communication focused purely on mission effectiveness

### Integration Phase
- Begins adapting communication style for specialists
- Shows more patience with non-military approaches
- Occasional glimpses of personal warmth

### Established Company
- More comfortable with informal interactions
- Begins sharing personal experiences when relevant
- Shows trust through delegation and asking for input

### Future Development
- More open emotional expression with trusted family members
- Comfortable mentoring role with newer Company members
- Able to balance military efficiency with family warmth

## Writer Guidelines

### Dialogue Construction
- Keep sentences short and direct
- Use military terminology naturally, not forced
- Show emotion through subtext and action rather than explicit statement
- Let his care show through what he doesn't say as much as what he does

### Voice Consistency
- Never wastes words but never leaves people confused
- Authority comes from competence, not volume
- Protective instincts override personal comfort
- Military precision balanced with genuine warmth

### Character Voice Traps to Avoid
- Don't make him too gruff without showing his caring side
- Avoid military jargon that sounds inauthentic
- Don't let protective instincts make him controlling
- Balance economy of speech with necessary communication

## Contextual Dialogue Variations

### With Military Personnel
*"Sergeant's orders: weapons check, supply count, and rest rotation. You know the drill."*

### With Civilians
*"We're going to need you to stay back while we handle this. For your safety and ours."*

### With Company Family
*"None of that 'sir' business when it's just us. Save the formality for when we have an audience."*

### Under Emotional Stress
*"Just... give me a minute to think this through. Too many variables, not enough good options."*

### Teaching Moment
*"See how she positions herself? Always knows where the exits are, always between the threat and her people. That's how you stay alive and keep others breathing."*

## Notes for Emotional Scenes

### Showing Vulnerability
- Uses longer pauses and hesitation
- Reverts to checking equipment when nervous
- Voice becomes quieter, less projected
- May deflect with practical concerns

### Expressing Pride
- Subtle nod of approval
- "Good work" followed by specific recognition
- Increased trust shown through delegation
- Protective positioning relaxes slightly

### Dealing with Loss
- Becomes very quiet and focused
- Takes on extra responsibilities to cope
- May push others away to protect them
- Shows grief through increased protectiveness of survivors

---

# Sergeant Kelen - Scene Tracker

## Major Scenes

### Chapter 1 – Ash and Compass
- **Scene 5 - Arrival of the Watch**: First appearance as part of Thorne's patrol discovering Veyra
  - *Significance*: Establishes his role as Thorne's trusted second-in-command
  - *Character Moment*: "Look at her face... the burns..." - shows immediate tactical assessment
  - *Key Action*: Recognizes Veyra won't leave without fallen comrades: "We'll need stretchers for the bodies"
  - *Character Growth*: Beginning of recognition of shared soldier's code with Veyra

- **Scene 6 - The Vigil**: Taking command while Thorne cares for Veyra
  - *Leadership Moment*: "Venn, Darric—stretchers. Halden, stabilize her. Fayne, document everything"
  - *Character Insight*: Natural assumption of command responsibility
  - *Emotional Beat*: Respect for the fallen shown through careful arrangement of bodies

### Chapter 2 – The Lantern Ward
- **Recovery and Support**: Bringing lamp oil to Veyra during her recovery
  - *Significance*: Shows practical care and understanding of symbolic importance
  - *Key Quote*: "Someone has to" when asked about maintaining the lantern
  - *Character Trait*: Duty-driven protectiveness extending to important symbols

### Chapter 9 – The Westwall Welcome
- **Company Formation**: Present for the formal naming of the Last Light Company
  - *Significance*: Founding member commitment to new mission
  - *Key Quote*: "The Last Light Company it is" - voice full of pride
  - *Character Growth*: Full emotional investment in the new organization

## Character Development Scenes

### The Protective Leader
- **Description**: Kelen taking charge during crisis while Thorne is occupied
- *Purpose*: Showcase his natural leadership and protective instincts
- *Key Elements*: Quick tactical assessment, delegation, ensuring everyone's safety
- *Character Growth*: Demonstrating competence that extends beyond following orders

### Recognition of Dedication
- **Description**: Understanding Veyra's commitment to fallen comrades at Undershade Canyon
- *Purpose*: Shows his recognition of shared values and soldier's code
- *Key Elements*: Seeing past trauma to recognize duty and dedication
- *Character Growth*: Beginning of personal investment in Company mission

### Quiet Authority
- **Description**: Managing patrol members and specialists with understated leadership
- *Purpose*: Illustrates his "follow me" leadership style
- *Key Elements*: Commands that sound like suggestions, natural positioning to protect others
- *Character Growth*: Adapting military leadership to diverse team

## Potential Future Scenes

### Personal History Revelations

**"The Letter Home"**
- **Description**: Kelen writing his weekly letter to Elspeth, struggling with what to share about Company dangers
- *Purpose*: Shows his relationship with his daughter and internal conflicts
- *Key Elements*: Careful word choice, protecting her from worry while staying connected
- *Character Growth*: Balancing honesty with protection

**"The Watch Contact"**
- **Description**: Using his City Watch network to gather intelligence for Company mission
- *Purpose*: Demonstrates his value beyond combat leadership
- *Key Elements*: Professional relationships, loyalty conflicts, information gathering
- *Character Growth*: Choosing Company over old loyalties when necessary

**"The Patrol Bond"**
- **Description**: Scene with original patrol members showing their family-like connection
- *Purpose*: Illustrates how he's built surrogate family from his squad
- *Key Elements*: Inside jokes, shared experiences, protective dynamics
- *Character Growth*: Learning to express care more openly

### Leadership Development

**"Training the Specialists"**
- **Description**: Kelen teaching basic survival/combat skills to non-military Company members
- *Purpose*: Shows his mentoring abilities and adaptation to diverse team
- *Key Elements*: Patient instruction, safety emphasis, building competence
- *Character Growth*: Learning to work with different learning styles and backgrounds

**"Crisis Command"**
- **Description**: Taking overall command when both Thorne and Veyra are incapacitated
- *Purpose*: Demonstrates his readiness for increased responsibility
- *Key Elements*: Quick decision-making, coordinating specialists, ensuring mission success
- *Character Growth*: Stepping up from second-in-command to primary leader

**"The Moral Choice"**
- **Description**: Situation where following regulations conflicts with protecting his people
- *Purpose*: Tests his loyalty hierarchy and ethical framework
- *Key Elements*: Regulation vs. protection, consequences of choice, team reaction
- *Character Growth*: Choosing people over protocol when necessary

### Personal Relationships

**"Elspeth's Visit"**
- **Description**: His daughter unexpectedly arrives at Company headquarters
- *Purpose*: Forces confrontation with his protective distance strategy
- *Key Elements*: Surprise, fear for her safety, Company members meeting family
- *Character Growth*: Learning to balance protection with connection

**"The Father Figure"**
- **Description**: Younger Company member seeking advice or comfort from Kelen
- *Purpose*: Shows his evolution into patriarch role
- *Key Elements*: Awkward emotional support, practical advice, protective instincts
- *Character Growth*: Accepting role as Company father figure

**"Memory of Anya"**
- **Description**: Scene triggered by anniversary or similar situation to his wife's death
- *Purpose*: Explores ongoing impact of his loss and healing process
- *Key Elements*: Private grief, Company support, moving forward while honoring memory
- *Character Growth*: Integrating past loss with present connections

### Professional Integration

**"Working with Marcus"**
- **Description**: Collaboration between Kelen's practical approach and Marcus's diplomatic skills
- *Purpose*: Shows how different styles can complement each other
- *Key Elements*: Initial tension, finding common ground, effective partnership
- *Character Growth*: Appreciating different approaches to problem-solving

**"Understanding Nireya"**
- **Description**: Kelen ensuring Nireya's care after she uses her spiritual powers
- *Purpose*: Shows his protective instincts extending to supernatural teammates
- *Key Elements*: Overcoming initial wariness, recognizing shared values, practical support
- *Character Growth*: Adapting protection to include supernatural needs

**"Grimjaw's Respect"**
- **Description**: Scene where Kelen and Grimjaw recognize their shared protectiveness
- *Purpose*: Building bridges between different backgrounds
- *Key Elements*: Mutual respect, shared values, different expressions of same goal
- *Character Growth*: Finding common ground despite different approaches

## Interaction Scenes

### With Command Structure
- **Planning Sessions**: Working with Thorne and Veyra on mission strategy
- **Crisis Management**: Taking initiative when leaders are occupied
- **After Action**: Debriefing and learning from missions

### With Original Patrol
- **Shared Memories**: Reminiscing about past missions and bonding experiences
- **Transition Challenges**: Adapting to new Company structure while maintaining bonds
- **Protection Dynamics**: Continued care for "his people" in new context

### With Specialists
- **Integration Challenges**: Learning to work with non-military professionals
- **Skill Exchange**: Teaching military skills while learning specialist knowledge
- **Trust Building**: Developing confidence in unconventional approaches

### Family Connections
- **Letters to Elspeth**: Private moments showing his relationship with daughter
- **Watch Contacts**: Maintaining professional relationships from previous career
- **Memory Moments**: Dealing with grief and moving forward

## Combat/Crisis Scenes

### "Defensive Coordinator"
- **Description**: Combat scene showcasing his protective fighting style
- *Purpose*: Demonstrates his "everyone comes home" philosophy in action
- *Key Elements*: Positioning to shield others, tactical coordination, post-combat care
- *Character Traits*: Protection over glory, team survival focus

### "Equipment Check"
- **Description**: Pre-mission scene showing his thorough preparation
- *Purpose*: Illustrates his attention to detail and care for team safety
- *Key Elements*: Systematic gear inspection, addressing problems before they matter
- *Character Traits*: Practical preparation, prevention over reaction

### "Casualty Management"
- **Description**: Post-combat scene with wounded team members
- *Purpose*: Shows his crisis leadership and care for injured
- *Key Elements*: Immediate assessment, resource allocation, emotional support
- *Character Traits*: Leadership under pressure, protection of vulnerable

## Growth Moment Scenes

### "Opening Up"
- **Description**: Kelen sharing personal history with trusted Company member
- *Purpose*: Shows emotional growth and increasing trust
- *Milestone*: First major step toward emotional integration

### "Accepting Help"
- **Description**: Allowing others to support him during difficult moment
- *Purpose*: Character growth in receiving care, not just giving it
- *Milestone*: Learning that strength includes accepting assistance

### "The Patriarch Moment"
- **Description**: Being formally recognized as Company's emotional anchor
- *Purpose*: Accepting role as father figure and institutional memory
- *Milestone*: Full integration into new family structure

## Scene Notes for Writers

### Key Character Elements to Include
- Constant tactical awareness and positioning
- Protective body language and positioning
- Equipment maintenance as stress response
- Economy of words but clarity of meaning
- Care shown through actions rather than words

### Emotional Beats to Explore
- Conflict between protection and autonomy
- Memories of loss balanced with present hope
- Military structure adapted to family atmosphere
- Professional competence hiding emotional vulnerability

### Relationship Dynamics to Show
- Unspoken communication with Thorne
- Fatherly concern for younger team members
- Respectful integration of specialist skills
- Ongoing connection to daughter despite distance

### Future Arc Potential
- Evolution from distant protector to engaged patriarch
- Learning to balance military efficiency with family warmth
- Integration of past grief with present connections
- Building institutional knowledge and training systems

---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Thorne Brightward

# Captain Thorne Brightward - Profile

## Basic Information
- **Full Name**: Thorne Brightward
- **Aliases/Nicknames**: Captain Brightward, Captain Thorne
- **Race**: Human
- **Class**: Paladin
- **Role in Story**: Deputy Commander of the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Average height, broad-shouldered, built for endurance
- **Hair**: Steel-gray despite being in his early forties, cropped short in military fashion with slightly longer bangs he's never quite managed to tame
- **Eyes**: Deep-set brown eyes that miss nothing
- **Distinguishing Features**: Weathered but kind face, hands scarred from years of sword work
- **Typical Clothing**: Wears his old guard captain's cloak - faded blue wool with the city's crest removed and replaced with the Last Light Company sigil
- **Body Language**: Carries himself with fifteen years of disciplined military posture
- **Physical Condition**: Strong, resilient, trained for combat and endurance

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Thorne Brightward.

## Personality
- **Archetype**: Loyal Second-in-Command/Strategist
- **Temperament**: Steady, reliable, methodical
- **Positive Traits**: Disciplined, loyal, practical, tactically minded
- **Negative Traits**: Struggles with moral ambiguity and bending the law, though will do so if he feels it serves a greater justice.
- **Moral Alignment**: Lawful Good (committed to order and doing what's right)

## Skills & Abilities
- **Expertise**: Military tactics, logistics, leadership, combat strategy
- **Languages**: TBD
- **Education Level**: Military training
- **Special Abilities**: Likely paladin abilities (depending on setting)

## Personal Details
- **Habits**: Likely maintains military discipline in daily routines
- **Hobbies**: TBD
- **Personal Quarters**: A perfectly rectangular room located in the Establishment terrace, with a window overlooking the main training grounds of the Great Courtyard. The design is one of pure, unadorned functionality. The floor is bare, scrubbed wood. The bed is a simple timber frame with a coarse but clean linen sheet, folded with geometric precision. This is the room of a soldier, not a commander. It is his personal barracks, a space to maintain the discipline he believes keeps him and others alive. Every morning, he rises before the sun to watch the guards begin their drills from his window. His armor and weapons are meticulously displayed on a custom-made stand, not as trophies, but as tools laid out for inspection. A small, perfectly organized desk holds his journals, filled with neat, precise script detailing after-action reports and personal reflections. The only decoration is a framed writ on the wall—his former commission as a Captain of the Waterdeep City Guard, a reminder of a different kind of service.
- **Likes**: Order, efficiency, clear chains of command
- **Dislikes**: TBD
- **Fears**: TBD

## Combat & Tactics
- **Primary Weapons**: Longsword and steel tower shield combo - built for defensive operations
- **Secondary Weapon**: Cavalry spear that doubles as a walking staff for mobility
- **Command Tool**: Horn that can be heard for miles - the signal that help has arrived
- **Armor**: Well-maintained chainmail hauberk over padded gambeson, with reinforced shoulder guards and bracers - veteran's armor that's seen real combat
- **Fighting Style**: Defensive anchor - creates safe zones for team operations, controls engagement spacing and timing
- **Signature Move**: "Brightward's Wall" - shield formation that protects multiple allies while maintaining battlefield awareness
- **Combat Philosophy**: "Proper formation prevents poor outcomes" - structure and discipline over individual heroics
- **Tactical Role**: Battlefield coordinator who maintains defensive lines while directing team movements

## Psychological Response Matrix
- **In Crisis**: Implements pre-planned protocols and contingencies, creates order from chaos through systematic approach
- **During Negotiation**: Formal and respectful, references regulations and precedents, speaks with quiet authority
- **Moral Dilemma**: Consults regulations first, then defers to Veyra's judgment for interpretation and final decision
- **Team Conflict**: Calls formal meetings, documents issues properly, seeks resolution through established procedures
- **Under Personal Attack**: Takes detailed mental notes for later formal response, maintains professional demeanor
- **In Victory**: Ensures proper documentation, conducts after-action reports, tends to wounded before celebration

## Voice & Dialogue Patterns
- **Speech Style**: Military precision with tactical terminology used naturally, clear command structure in language
- **Signature Phrases**: 
  - "By the book, but let's read between the lines"
  - "Formation and discipline, people"
  - "Time check" (announces mission timing)
- **Command Voice**: Calm authority that cuts through chaos, uses rank and file terminology
- **Example Dialogue**: "Formation Delta. Grimjaw, anchor left. Vera, overwatch. Execute on my mark - two minutes to extraction."
- **Respectful Partnership**: Defers to Veyra's final authority while providing tactical expertise
- **Emotional Tells**: Straightens posture when stressed, touches sword hilt when concerned

## Notes
- Handles logistics and tactical planning for the Last Light Company while Veyra focuses on human elements
- Former city guard captain who left on excellent terms
- His horn signal is recognized as the arrival of the Last Light Company
- Was forced to confront his rigid adherence to the law during the Stonebridge investigation (Chapter 13), ultimately using his former station to run a bluff and expose a corrupt merchant. This event has left him with a more nuanced, if conflicted, view of justice.

### Public Perception
- Respected by the City Watch as "one of ours" who runs a tight ship, even if the Company bends the rules.
- His horn signal is a widely recognized promise of professional help, signifying the arrival of the Last Light Company.
- Seen as the "rock" and "shield" of the Company, ensuring solid plans and the safe return of everyone.


---

# Captain Thorne Brightward - Background

## Origin
- **Birthplace**: Waterdeep
- **Birth Date**: Early 40s (specific date TBD)
- **Social Class**: Middle class
- **Cultural Background**: Urban; deeply ingrained in the city's culture and legal systems.

## Family
- **Parents**: TBD
- **Siblings**: TBD
- **Extended Family**: TBD
- **Family Dynamics**: TBD

## History
- **Childhood**: TBD
  - *Key Events*: TBD
  - *Formative Experiences*: TBD
  
- **Education/Training**: 
  - *Institutions*: Waterdeep City Guard Academy
  - *Mentors*: TBD
  - *Areas of Study*: Military tactics, leadership, combat, city law and procedure.
  
- **Adolescence/Young Adulthood**:
  - *Key Events*: Joined the City Guard, dedicating his life to service and the protection of Waterdeep.
  - *Relationships*: Built a strong network of contacts and a reputation for reliability within the Guard.
  - *Choices & Consequences*: His commitment to the Guard's structured world was both his greatest strength and, eventually, what led him to seek a higher purpose.
  
- **Major Life Events**:
  - *Event 1*: Rose through the ranks to become a respected City Guard Captain.
  - *Event 2*: Served as captain for fifteen years, establishing a reputation for discipline, fairness, and tactical acumen.
  - *Event 3*: The Undershade Canyon Discovery - Led the patrol that discovered the aftermath of the ambush, finding a traumatized but unbroken Veyra Thornwake.
  - *Event 4*: The Silent Oath - Stood vigil with Veyra for two days as she buried her fallen comrades, a moment that solidified his commitment to her cause.
  - *Event 5*: Resignation and Co-founding - Left the City Guard on excellent terms to help Veyra establish the Last Light Company.

## Backstory Elements
- **Defining Moments**: 
  - Finding Veyra after the Undershade incident. Her raw, unwavering commitment to her fallen comrades, even in the face of immense trauma, shattered his perception of duty and revealed the limitations of his own structured world.
  - His simple, profound statement, "I'll help," when she first spoke of her vow to never leave anyone behind again.
- **Past Trauma**: While not a direct victim of the ambush, he was a profound witness to its aftermath, and carries the weight of that discovery.
- **Greatest Achievements**: 
  - His distinguished career as a City Guard Captain.
  - Co-founding the Last Light Company and providing the essential structure and discipline to make Veyra's vision a reality.
- **Biggest Failures**: TBD
- **Secrets**: TBD

## How They Got Here
- **Reason for Current Situation**: For fifteen years, Thorne had dedicated his life to the City Guard, finding immense satisfaction in its structure and the clear-cut pursuit of justice. However, witnessing Veyra's raw, unyielding commitment to "no one left behind"—a commitment that transcended laws and procedures—shattered his comfortable worldview. He saw the limitations of the Guard's bureaucracy, its inability to pursue cases beyond its jurisdiction, or to dedicate resources to those deemed "lost causes." He wasn't disillusioned with the Guard itself, but with its inherent constraints. Veyra's vision offered a path to a higher, more direct form of service—one where the mission was paramount.
- **Path to Current Location**: Thorne leveraged his long-standing relationships and impeccable record to ensure his departure was on excellent terms. He framed his new endeavor as a specialized, independent asset that could *complement* the City Watch's efforts. He transitioned directly from his captaincy to becoming Veyra's second-in-command, his initial role being crucial in establishing the Company's operational procedures, training protocols, and logistical networks, transforming Veyra's raw vow into a functional, professional organization.
- **Goals Prior to Story Start**: 
  - Successfully transitioned from city guard to Last Light Company.
  - Established effective operational procedures for the company.

## Historical Connections
- **Connection to Main Plot**: Co-founder and Deputy Commander of the Last Light Company.
- **Connection to Other Characters**: 
  - His bond with Veyra Thornwake is the foundational pillar of the Company.
  - Maintains a network of contacts within the City Guard.
- **Connection to Story World**: 
  - Deep knowledge of Waterdeep's infrastructure, laws, and political landscape.

## Timeline
- Joined the Waterdeep City Guard.
- Rose through the ranks over years of service.
- Became a Captain and served for fifteen years.
- Led the patrol that discovered the aftermath of the Undershade Canyon Ambush.
- Stood vigil with Veyra as she buried her fallen comrades, swearing a silent oath to her cause.
- Resigned his commission with the City Guard on excellent terms.
- Co-founded the Last Light Company with Veyra.
- Currently serves as Deputy Commander, handling logistics and tactical planning.

## Personal Details
- **How He Relaxes**: His relaxation is a form of disciplined maintenance. He spends his downtime meticulously caring for his gear—polishing his shield until it gleams, sharpening his longsword with a whetstone, and oiling the leather straps of his armor. This quiet, repetitive ritual is a form of meditation for him, a way to create order and readiness in a chaotic world.
- **Favorite Meal**: A simple but perfectly cooked steak and a baked potato. It's the kind of honest, unpretentious meal he likely ate in the officer's mess for years. It's not about fancy flavors, but about quality and reliability—two virtues he values above all others.
- **A Private Hobby**: He is a student of military history and strategy. His quarters contain a small, carefully curated collection of books on famous battles, legendary commanders, and tactical theory. He will often spend the late hours of the night with a book and a map, replaying historical battles in his mind, finding a strange comfort in the clear, decisive outcomes of the past.


---

# Captain Thorne Brightward - Character Development

## Personality Core
- **Defining Traits**: Disciplined, loyal, reliable, tactical
- **Core Values**: Duty, order, protecting the innocent, supporting comrades
- **Motivations**: Serving a worthy cause, applying his skills to meaningful work, upholding his commitments
- **Fears**: Possibly failing those who depend on him, loss of order/structure
- **Internal Conflicts**: Possible tension between military rigidity and the less structured nature of the Last Light Company's missions
- **Contradictions**: Military discipline combined with compassionate actions (helping Veyra without question)

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Respected city guard captain with fifteen years of service
  - *World View*: Structured, orderly, with clear chains of command and protocols
  - *Key Relationships*: Connections within guard and city hierarchy
  
- **Catalyst Events**:
  - *Event 1*: Finding Veyra emerging from Undershade with her fallen comrade
  - *Event 2*: The decision to help her carry the body and stand vigil
  - *Event 3*: His simple statement "I'll help" and choice to join her cause
  
- **Current State**:
  - *Self-Perception*: Deputy Commander of the Last Light Company
  - *World View*: Still values order but adapted to the Company's specific mission
  - *Key Relationships*: Professional partnership with Veyra, leadership role in Company
  
- **Intended Destination**:
  - *Self-Perception*: TBD
  - *World View*: TBD
  - *Key Relationships*: TBD

## Growth Milestones
- **From Guard Captain to Deputy Commander**: 
  - *Development Noted*: Transition from city service to specialized mission
  - *Catalyst*: Meeting Veyra and witnessing her determination
  - *Impact*: New purpose and application of his skills
  
- **Establishing Last Light Company protocols**: 
  - *Development Noted*: Adapting military experience to unconventional mission
  - *Catalyst*: Need for structure in rescue operations
  - *Impact*: Creation of effective operational framework

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*: Possible rigidity in thinking or approach
  - *Effects on Others*: May clash with those who prefer flexibility or intuition
  - *Development Plan*: TBD
  
- **Secondary Flaws**: 
  - *Effects on Character*: TBD
  - *Effects on Others*: TBD
  - *Development Plan*: TBD

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: TBD
  - *Secret 2*: TBD
  
- **Unknown to Character**:
  - *Truth 1*: TBD
  - *Truth 2*: TBD
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Helping Veyra Without Question**:
  - *Context*: Finding her emerging from Undershade with fallen comrade
  - *Options Considered*: Could have questioned her, detained her, or simply reported the incident
  - *Choice Made*: Immediately helped her carry the body and stood vigil
  - *Consequences*: Led to his involvement with the Last Light Company
  
- **Leaving the City Guard**:
  - *Context*: After witnessing Veyra's mission and dedication
  - *Options Considered*: Stay in comfortable, respected position vs. join new, uncertain venture
  - *Choice Made*: Left the guard (on good terms) to join the Last Light Company
  - *Consequences*: Became Deputy Commander, applied military expertise to new mission

## Development Notes
- Character represents the bridge between conventional military/guard structure and the specialized mission of the Last Light Company
- His decision to immediately help Veyra reveals compassion beneath the disciplined exterior
- The contrast between his military background and Veyra's more personal mission creates interesting dynamic
- His horn signal as the announcement of the Company's arrival symbolizes the reliability and professionalism he brings to the mission

## Psychological Profile
*   **Thorne Brightward (The Bulwark):** He is a man of structure and duty, finding comfort and meaning in order and procedure. His past as a City Guard Captain wasn't just a job; it was his identity. He is loyal to Veyra not just as a commander, but because her mission gives his tactical mind a higher purpose than just "enforcing laws." He is the pragmatist who makes Veyra's idealism possible. His internal conflict arises when the "right thing" (the mission) conflicts with the "right way" (the rules).


---

# Captain Thorne Brightward - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: His Commander and sister-in-arms. The other half of the Company's soul.
  - *Hierarchy*: He is her Deputy, and their trust is absolute and unspoken.
  - *Dynamics*: Their bond is the foundational pillar of the Company, forged in tragedy. They are the epitome of the "we few, we happy few." Thorne sees it as his duty to be the pragmatist who makes Veyra's hardened idealism a battlefield reality. Their disagreements are tactical, never personal, and are born from a deep mutual respect. He knows she's aware of the costs, and his role is to help her mitigate them.
  - *History*: The defining moment of his life was finding Veyra in Undershade canyon. He saw in her refusal to leave her fallen comrades a purity of purpose that his years in the city guard had lacked. Standing vigil with her as she buried her friends was a silent oath; he wasn't just joining a cause, he was dedicating his life to a person.
  - *Current Status*: Her unshakable right hand and most trusted confidant.
  - *Feelings Toward*: Absolute loyalty. He trusts her completely and would follow her into any fire, his only concern being to ensure they have enough buckets of water to get back out.

- **Vera "The Tracker" Moonwhisper**: 
  - *Nature of Relationship*: Deputy Commander and Scout
  - *Hierarchy*: Leadership position over specialist
  - *Dynamics*: Likely coordinates tactical operations utilizing her tracking skills
  - *History*: TBD when they first met
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her tracking abilities and dedication to finding her brother

- **Brother Aldwin Gentleheart**: 
  - *Nature of Relationship*: Deputy Commander and Medic
  - *Hierarchy*: Leadership position with medical specialist
  - *Dynamics*: Coordinates tactical medical support and evacuation procedures
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values his medical expertise and calm presence

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Deputy Commander and Heavy Rescue specialist
  - *Hierarchy*: Leadership coordination with experienced team member
  - *Dynamics*: Coordinates heavy rescue operations and structural safety
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his experience and "never loses anyone" reputation

- **Lyralei Stormcaller**: 
  - *Nature of Relationship*: Deputy Commander and Magical Support
  - *Hierarchy*: Leadership position with magical specialist
  - *Dynamics*: Coordinates magical support for tactical operations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values her magical capabilities despite possible friction over rigid methods vs. research needs

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Professional counter-balance.
  - *Hierarchy*: Peers on the command team.
  - *Dynamics*: Like a career general and a career diplomat, Thorne and Marcus share a mutual respect for the necessity of the other's role, even if they don't fully agree with the methods. Thorne sees the world as a series of direct threats requiring tactical solutions, while Marcus sees a web of influence requiring leverage. They are the sword and the shield of the Company's external policy. Their friction is professional, not personal, born from their different but equally valid experiences of the "real world."
  - *History*: They met when Marcus approached Veyra to help form the Company. Thorne was initially wary, but came to respect the undeniable results of Marcus's work in establishing the Bastion.
  - *Current Status*: A functional, respectful, but not warm, working relationship. They are allies, not friends.
  - *Feelings Toward*: He respects Marcus as a master of a different kind of battlefield. He doesn't always like Marcus's solutions, but he understands that one cannot exist without the other for the Company to succeed.

- **Nireya Voss**: 
  - *Nature of Relationship*: Complex bond formed through life-saving spiritual connection
  - *Hierarchy*: Deputy Commander and Death-Walker specialist
  - *Dynamics*: Unique spiritual connection after she saved his life by anchoring his consciousness
  - *History*: Nireya saved his life by anchoring his departing consciousness during a critical moment
  - *Current Status*: Professional colleagues with special spiritual bond
  - *Professional Opinion of*: Feels special responsibility and connection after life-saving experience
  - *Special Connection*: The experience of having his consciousness anchored created an unusual spiritual bond

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Deputy Commander and Arcano-Engineer
  - *Hierarchy*: Leadership position with technical specialist
  - *Dynamics*: His military approach might clash with her unorthodox methods
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Acknowledges her technical brilliance while preferring more structured approaches

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Deputy Commander and Siege Engineer
  - *Hierarchy*: Leadership position with engineering specialist
  - *Dynamics*: Military background may create common understanding of chain of command and tactical approaches
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Potential for strong collaboration due to shared military discipline and tactical mindset

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: Unlikely professional respect.
  - *Hierarchy*: He is in a command position, but he treats her as a specialist, not a subordinate criminal.
  - *Dynamics*: As a man of the law, Thorne should fundamentally disapprove of Kaida. However, as a professional soldier, he has a deep and abiding respect for *competence*. He may not like her past, but he cannot deny her skill. He is the one who will formally request her expertise, relying on her analysis of security systems and infiltration routes. This professional respect from a man like Thorne is a new and perhaps unsettling experience for Kaida, forming the basis of a unique, unspoken alliance.
  - *History*: TBD
  - *Current Status*: Professional colleagues with a surprising degree of mutual respect.
  - *Feelings Toward*: He trusts her skills, if not her methods. He sees her as a precision tool that must be handled carefully.

## Past Relationships
- **City Guard Colleagues**: 
  - *Relationship Type*: Former superior officer and colleagues
  - *History*: Fifteen years serving as captain, built relationships and reputation
  - *Current Status*: Left on excellent terms, maintaining positive connections
  - *Feelings Toward*: Likely mutual respect, possible resource for information and support
  - *Tensions/Issues*: None indicated - left on good terms
  - *Shared Experiences*: Years of service protecting the city

## Mentors/Students
- **Former Mentors in Guard**: 
  - *Relationship Type*: TBD
  - *Lessons Learned*: Military discipline, leadership, tactical thinking
  - *Impact on Character*: Shaped his approach to duty and service
  - *Current Status*: TBD

- **Subordinates in Last Light Company**: 
  - *Relationship Type*: Commander/mentor
  - *Teaching Style*: Likely structured, disciplined, practical
  - *Expectations*: High standards, clear protocols, professional conduct
  - *Current Status*: Active mentorship

## Potential Relationships
- **City Officials/Nobility**: 
  - *Nature of Relationship*: Former professional connections through guard service
  - *Dynamics*: Possibly maintains relationships that could be useful to Last Light Company
  - *Current Status*: TBD

- **Family Members**: 
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Feelings Toward*: TBD

## Relationship Evolution Tracker
- **Pre-Last Light Company**: City Guard Captain, established reputation for discipline and competence
- **Meeting Veyra**: Pivotal moment - chose to help her without questioning
- **Joining Last Light Company**: Transition from city service to more specialized mission
- **Present Day**: Established as trusted Deputy Commander and tactical leader


---

# Thorne Brightward — Dialogue & Psyche

## Core temperament
Steady, pragmatic, protective. A soldier's mind with a captain's patience; cares deeply but expresses it through competence and duty.

## Dialogue instincts
- Public/command: clear, authoritative, procedural. Uses ranks, concise orders, and tactical phrasing.
- Private/confidant: warmer, bluntly honest; rare vulnerability expressed in practical terms rather than confession.
- Under pressure: calm, directive—translates others' expertise into orders; uses short recaps to re-center the team.
- Humor: light, often dry; used to steady nerves or deflect praise.

## Emotional anchors & physical tells
- Helmet-tap: a small private salute or touch of helm when showing respect or affection.
- Even breathing and measured pauses before issuing orders; a long exhale when a situation is resolved.
- Hands-on gestures: points, shows rather than explains; places himself between threat and others.
- Quiet looks: when he hesitates or softens, it's through expression rather than words.

## Conflict & humor rules
- Defends subordinates without grandstanding; will argue procedure when needed.
- Jokes are utilitarian—mend morale, not mock suffering.
- Avoids moralizing; prefers pragmatic ethics framed as duties and consequences.

## Writer cues (practical)
- Use Thorne to convert expertise (Veyra, Aldwin, Grimjaw) into actionable orders. He is the implementation voice.
- Keep his lines short in tense scenes; let him give the "how" after Veyra gives the "what."
- Use small gestures (placing helm, unclasping gauntlet) to mark emotional beats when he cannot speak them.

## Drop-in sample lines (from Chapters 1-3)
- **On Veyra's survival:** "The lantern kept its promise. And so did you."
- **On their new mission:** "No soul should burn alone. Not on our watch."
- **On the future:** "To decide what comes next."
- **On shared burdens:** "Then we'll burn together."
- **On truth vs. politics:** "Truth does."
- **A promise:** "You won't walk alone."

## Voice evolution note (chapters 1–9)
- Early: formal, measured—focused on order and procedure.
- Middle: increasingly collaborative—learns to defer to Veyra's expertise and advocates for unorthodox methods.
- Later: retains command clarity but softens privately, becoming a trusted steward of the Company's mission and people.

## Usage examples (scenes)
- In briefings: translates intel into tasks—use him to enumerate responsibilities clearly.
- In rescue scenes: keeps cadence brisk—one order per clause, then checks for confirmation.
- In quiet moments: allow plain, sincere lines that carry weight through simplicity.

## Notes for editors
- Avoid sentimental speeches; show Thorne's care through concrete acts and small spoken assurances.
- When expanding dialogue, let him be the calm center—his clarity helps structure multi-voice scenes.


---

# Captain Thorne Brightward - Scene Tracker

## Major Scenes

### Chapter 1 – Ash and Compass <!-- slug: ch1-ash-compass -->
- **Scene 5**: Leading patrol that discovers Veyra at Undershade Canyon
- **Scene 6**: Organizing recovery of bodies, first display of respect for Veyra

### Chapter 2 – The Lantern Ward <!-- slug: ch2-lantern-ward -->
- **Scene 3**: Visiting Veyra with patrol, bringing tokens of fallen comrades

### Chapter 3 – Echoes in the City <!-- slug: ch3-echoes-city -->
- **Vignette 5**: Balcony conversation with Veyra, "You won't walk alone" promise

### Chapter 4 – The First Spark <!-- slug: ch4-first-spark -->
- **Scene 1**: Attempting to protect Veyra from fire response
- **Scene 2**: Accepting Veyra's tactical leadership during rescue
- **Scene 3**: Supporting the concept of specialist recruitment

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 1**: Preparing for winter rescue mission to Thornwood Ruins
- **Scene 2**: Professional demeanor despite humorous misunderstanding
- **Scene 7**: Bringing news of missing Hendrick girl
- **Scene 7**: Organizing wagon and supplies for Vera's tracking mission
- **Epilogue**: Formally welcoming Vera to Last Light Company
- **Epilogue**: Sharing comfortable silences with Veyra during dinner planning

### Chapter 12 – The Wayward Compass <!-- slug: ch12-wayward-compass -->
- **Scene 1**: Securing the perimeter during the roadside rescue.
- **Scene 2**: Taking a protective stance against the Black Hawk bandits.
- **Scene 2**: Guarded observation of Marcus Heartbridge's intervention.

### Chapter 13 – An Honest Coin <!-- slug: ch13-honest-coin -->
- **Scene 1**: Voicing suspicion of Marcus's motives.
- **Scene 1**: Arranging safe passage for the rescued civilians.
- **Scene 2**: Arguing against the morality of accepting Marcus's offer.

## Character Moments

### Best Moments
- Discovery and respectful treatment of Veyra (Ch. 1)
- "You won't walk alone" promise (Ch. 3)
- Supporting specialist recruitment (Ch. 4)
- Smooth integration of Vera into the team (Ch. 10)

### Worst Moments
- Tension with Veyra over her participation in fire response (Ch. 4)
- Disagreement with Captain Grimsby (Ch. 4)

### Turning Points
- Decision to support Veyra's leadership despite military rank (Ch. 4)
- Acceptance of Vera despite her lethal methods (Ch. 10)

## Interaction Log

### With Veyra Thornwake
- Chapter 1: Finding her at canyon, showing respect
- Chapter 2: Supporting her recovery
- Chapter 3: Making the "won't walk alone" promise
- Chapter 4: Accepting her tactical leadership
- Chapter 10: Professional partnership during winter missions

### With Grimjaw Ironbeard
- Chapter 7: First meeting and recruitment
- Chapter 10: Working relationship during winter missions

### With Aldwin Gentleheart
- Chapter 6: Introducing him to Veyra
- Chapter 10: Coordinating medical support during rescue missions

### With Vera Moonwhisper
- Chapter 10: Initial rescue, formal welcome to the Company

## Upcoming Scenes

### Planned Appearances
- Continued tactical leadership of the Company
- Potential diplomatic clashes with authorities
- Formal structure development of the Last Light Company

### Required Interactions
- Further development of command relationship with Veyra
- Integration of new specialists into operations
- Handling any legal/political consequences of Vera's lethal action


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Vera Moonwhisper

# Vera "The Tracker" Moonwhisper - Profile

## Basic Information
- **Full Name**: Vera Moonwhisper
- **Aliases/Nicknames**: "The Tracker"
- **Race**: Half-Elf
- **Class**: Ranger
- **Role in Story**: Scout for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Lean, rangy build developed from years moving through wilderness - efficient muscle for constant travel
- **Hair**: Dark brown hair kept in a practical braid threaded with small feathers, bone beads, and thin leather cords (tokens from different animal allies)
- **Eyes**: TBD
- **Distinguishing Features**: Slightly pointed ears and angular features from half-elven heritage
- **Typical Clothing**: Earth-toned leather and canvas designed for silent movement and weather resistance
- **Body Language**: Alert, observant, tends to scan environments constantly
- **Physical Condition**: Excellent endurance from human side of heritage, built for long pursuits and tracking

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Vera Moonwhisper.

## Personality
- **Archetype**: The Tracker/Seeker
- **Temperament**: Methodical, patient, wary with strangers
- **Positive Traits**: Observant, resourceful, determined, loyal to those who earn trust
- **Negative Traits**: Initial distrust of people, tendency to slip into obsessive patterns
- **Moral Alignment**: Neutral Good (focused on specific goals rather than larger causes)

## Skills & Abilities
- **Expertise**: Tracking, animal communication, wilderness survival, archery
- **Languages**: TBD
- **Education Level**: Self-taught/wilderness training
- **Special Abilities**: Exceptional tracking skills, ability to form partnerships with animals

## Personal Details
- **Habits**: Checking with her raven Echo before trusting human judgment
- **Hobbies**: Collecting tokens from animal allies
- **Personal Quarters**: A round, airy room at the top of one of the Bastion's smaller towers, with a large, covered balcony. The room is sparse, with a simple cot and a chest for her belongings. The floor is covered in a layer of clean sand and dried leaves, bringing the feeling of the forest indoors. This room is a nest, a place of observation. The true heart of the room is a massive, circular table in the center, upon which is a constantly evolving topographical map of the region, crafted from moss, twigs, carved wooden blocks, and polished stones. She uses it to visualize the hunt in three dimensions. The walls are covered in dozens of charcoal sketches of faces, but the most prominent is a series of portraits that attempt to age her lost brother—from a smiling child to a haunted-looking young man. She spends her nights on the balcony with her raven, Echo, listening to the sounds of the world and adding new details to her maps.
- **Likes**: Animals, open wilderness, practical solutions
- **Dislikes**: Enclosed spaces, betrayal, false promises
- **Fears**: Failing to find her brother, returning to desperate obsession

## Combat & Tactics
- **Primary Weapon**: "Whisperwind" - transforming bow-staff passed down through the Moonwhisper family, elegant quarterstaff that converts into a recurve bow with practiced motion
- **Secondary Weapon**: Skinning knife that doubles as close-combat blade - practical tool turned weapon
- **Companion Weapons**: Echo (raven) provides aerial reconnaissance and distraction, forms hunting partnerships with wolves when needed
- **Armor**: Layered leather and canvas designed for silent movement, weather resistance, and blending with natural environments
- **Fighting Style**: Versatile hunter - staff for close quarters defense, bow for ranged precision, seamless transitions between modes
- **Signature Move**: "Hunter's Dance" - fluid transition from staff strikes to bow shots in continuous motion
- **Combat Philosophy**: "Adapt to the terrain, adapt to the prey" - flexibility over rigid tactics
- **Tactical Role**: Forward scout who identifies threats, provides overwatch, and can hold defensive lines when needed

## Psychological Response Matrix
- **In Crisis**: Hyperfocuses on the immediate objective with trained precision, compartmentalizes personal concerns
- **During Negotiation**: Watches exits and reads micro-expressions, but now trusts team to handle social dynamics
- **Moral Dilemma**: Weighs decisions practically - brother's trail has been cold for years, current lives take precedence
- **Team Conflict**: Observes from distance but now offers quiet wisdom when asked rather than completely withdrawing
- **Under Personal Attack**: Notes it for later consideration but doesn't let it derail current mission
- **In Victory**: Takes moment to appreciate success before planning next steps - learned to value small victories

## Voice & Dialogue Patterns
- **Speech Style**: Soft-spoken but more confident than before, still prefers listening to speaking
- **Signature Phrases**: 
  - "Trail's three days old... still worth following" (balanced hope)
  - "Echo agrees" (trusts but verifies animal intelligence)
  - "Every hunt teaches something new"
  - "Whisperwind remembers" (when the weapon helps her track)
- **Mature Perspective**: No longer speaks of brother constantly, mentions him only when relevant
- **Example Dialogue**: "Target went to ground two hours ago. Guards are nervous - Echo counted three on patrol, two more hidden. We can wait them out or find another way."
- **Emotional Tells**: Touches locket when thinking of brother but doesn't let it consume her, runs hand along Whisperwind when planning
- **Growth Indicators**: Now offers suggestions rather than just observations, engages in team planning

## Companions
- **Echo**: A raven companion that serves as both messenger and emotional anchor, helping Vera maintain methodical thinking

## Notes
- Rescued by Veyra during a blizzard while still searching for her long-missing brother
- Changed her approach from desperate obsession to methodical skill after Veyra's influence
- Still maintains hope of finding her brother but it's no longer consuming
- Forms practical partnerships with animals rather than spiritual connections

### Public Perception
- Known as "The Tracker" who can find anyone, even when the City Watch gives up, often with the help of her raven companion, Echo.
- Rumored to communicate with animals, with stories circulating about her getting directions from squirrels and other creatures.
- Her methodical approach to tracking, learned after a period of desperate obsession, is highly respected by those who have witnessed her work.


---

# Vera "The Tracker" Moonwhisper - Background

## Origin
- **Birthplace**: A small, unnamed village on the edge of the High Forest.
- **Birth Date**: TBD
- **Social Class**: Commoner.
- **Cultural Background**: Half-Elven heritage, raised in a small, close-knit human community.

## Family
- **Parents**: TBD
- **Siblings**: Younger brother, Liam (kidnapped as a child, fate unknown).
- **Extended Family**: TBD
- **Family Dynamics**: Her family life was shattered by the loss of her brother, a tragedy that has defined her entire existence.

## History
- **Childhood**: 
  - *Key Events*: The kidnapping of her younger brother, Liam, by a shadowy slaver ring known as the "Silent Hand."
  - *Formative Experiences*: As the older sibling, Vera was supposed to be watching Liam while they were playing in the woods just outside their village. She was distracted for a single, crucial moment by a rare bird, and when she looked back, he was gone. There was no sound, no struggle, just an eerie silence. This personal, momentary lapse is the source of her deep, gnawing guilt.
  
- **Education/Training**: 
  - *Institutions*: Self-taught in the harsh classroom of the wilderness.
  - *Mentors*: The animals of the forest became her teachers when the people of her village failed her.
  - *Areas of Study*: Tracking, wilderness survival, animal communication, and the art of becoming unseen.
  
- **Adolescence/Young Adulthood**:
  - *Key Events*: After the local authorities gave up their search for Liam, Vera began her own. She spent years in a desperate, obsessive search, honing her skills but losing her connection to humanity.
  - *Relationships*: She formed practical, non-magical partnerships with animals, finding them more reliable than people.
  - *Choices & Consequences*: She chose a life of isolation and single-minded pursuit, sacrificing a normal existence for her all-consuming mission.
  
- **Major Life Events**:
  - *Event 1*: The Kidnapping of Liam - The traumatic event that set her life's course.
  - *Event 2*: The Meeting with Echo - Years into her search, at her absolute lowest point, she collapsed in the snow, ready to give up. A lone, scrappy raven, also a survivor, landed nearby and simply... stayed. Its persistent, silent presence became her anchor, a reflection of her own stubborn will to live. She named him "Echo," and in emulating his methodical survival, she began to transform her raw obsession into a true skill.
  - *Event 3*: The Rescue by Veyra - While tracking a false lead, she was caught in a blizzard and found, near death, by Veyra and the nascent Last Light Company.
  - *Event 4*: The Turning Point - Veyra's words, "Hope is a tool. Learn to use it better," gave Vera the final piece of the puzzle she needed to channel her grief and guilt into a focused, professional purpose.
  - *Event 5*: The "Silent Hand" Mission - Vera's relentless research uncovered a credible lead on the "Silent Hand," the very slaver ring that took her brother. The mission to rescue a group of children from a fortified compound became deeply personal, the first real hope she'd had in years. Her personal stake in the mission was the direct catalyst for the Company hiring Korrath Threnx and Cidrella Vexweld.

## Backstory Elements
- **Defining Moments**: 
  - The moment of distraction that led to her brother's kidnapping.
  - The quiet, persistent companionship of Echo at her lowest point.
  - Hearing Veyra's philosophy, which offered her a new way to live with her mission.
  
- **Past Trauma**: 
  - The loss of her brother and the deep guilt she carries for it.
  - The years of isolation and futile searching.
  - The feeling of being abandoned by her community and the authorities.
  
- **Greatest Achievements**: 
  - Surviving alone in the wilderness for years.
  - Developing her extraordinary tracking skills from scratch.
  - Forging a unique, symbiotic relationship with her animal network.
  
- **Biggest Failures**: 
  - Her inability to find her brother, despite dedicating her life to the search.
  - The single, unforgivable moment of inattention that she believes cost her brother his freedom.
  
- **Secrets**: 
  - She carries the full weight of her perceived responsibility for her brother's disappearance, a secret she has never shared with anyone.

## How They Got Here
- **Reason for Current Situation**: Rescued by Veyra and given a new perspective, Vera found in the Last Light Company a way to use her hard-won skills for a greater purpose. It offered her a community that understood loss and a structured, methodical way to continue her search without being consumed by it.
- **Path to Current Location**: 
  - Years of wilderness tracking -> The meeting with Echo -> Near-death in a blizzard -> Rescue by Veyra -> Joining the Last Light Company.
  
- **Goals Prior to Story Start**: 
  - To find her kidnapped brother.
  - To transform her desperate obsession into a focused, professional skill.

## Historical Connections
- **Connection to Main Plot**: Member of the Last Light Company as Scout. The "Silent Hand" slaver ring is a potential recurring antagonist.
- **Connection to Other Characters**: 
  - Rescued by Veyra and deeply influenced by her philosophy.
  - Her personal quest for her brother was the direct catalyst for the mission that brought Korrath Threnx and Cidrella Vexweld into the Last Light Company.
  
- **Connection to Story World**: 
  - Extensive knowledge of the wilderness areas of the Sword Coast.
  - A unique, non-magical connection to the animal life of the region.

## Timeline
- Childhood in a small village on the edge of the High Forest.
- Younger brother, Liam, is kidnapped by the "Silent Hand" slaver ring.
- Spends years in an increasingly desperate and isolated search.
- At her lowest point, she meets Echo, a raven who becomes her anchor and companion.
- Her tracking skills sharpen from raw obsession into methodical expertise.
- Is caught in a blizzard and rescued by Veyra Thornwake.
- Inspired by Veyra's philosophy, she joins the Last Light Company as its Scout.
- Currently serves as the Company's tracker while maintaining her personal mission to find her brother.

## Personal Details
- **How She Relaxes**: She finds calm in the quiet observation of her animal allies, particularly Echo. She will spend hours on the balcony of her Aerie, simply watching him preen his feathers or observing the subtle interactions of the birds in the courtyard below. It's a silent, comfortable form of communication that requires no words and carries no risk of misunderstanding.
- **Favorite Meal**: Smoked river trout with wild berries and nuts. It's the ultimate survivalist's meal—food she can easily forage and prepare herself in the wild. It's not just a preference; it's a taste of self-reliance and competence, a reminder of the skills that have kept her alive for years.
- **A Prized Possession**: She carries a small, smooth river stone in her pocket. It was the last thing her brother, Liam, gave her, found on the bank of the stream where they were playing just before he was taken. She will often turn it over and over in her hand, the cool, smooth surface a tangible link to her past and the driving force of her mission.
- **Hobby**: **Scrimshaw and Bone Carving.** During her long, solitary years in the wilderness, Vera learned to pass the quiet hours by carving intricate designs into animal bones and teeth she found naturally. Her carvings are not morbid, but beautiful and detailed depictions of the animals and landscapes she has seen. It's a quiet, patient art form that requires the same focus and steady hand as tracking, and it's a way for her to honor the natural world she is so deeply connected to.


---

# Vera "The Tracker" Moonwhisper - Character Development

## Personality Core
- **Defining Traits**: Observant, methodical, resourceful, wary
- **Core Values**: Loyalty, perseverance, practical solutions, animal partnerships
- **Motivations**: Finding her missing brother, honoring Veyra's influence by becoming more methodical
- **Fears**: Returning to desperate obsession, failing to find her brother
- **Internal Conflicts**: Need for human connection vs. trust issues, hope vs. pragmatism
- **Contradictions**: Independent yet relies on Echo for emotional stability, wary of people but part of a team

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Desperate searcher consumed by loss
  - *World View*: People fail, animals don't
  - *Key Relationships*: Absent (humans), utilitarian (animals)
  
- **Catalyst Events**:
  - *Event 1*: Brother's kidnapping - start of her obsessive search
  - *Event 2*: Being rescued by Veyra during blizzard
  - *Event 3*: Veyra's words: "Hope is a tool. Learn to use it better"
  
- **Current State**:
  - *Self-Perception*: Skilled tracker with purpose beyond personal quest
  - *World View*: Still cautious about people but recognizes value in select human connections
  - *Key Relationships*: Echo (raven), Veyra (mentor), animal network, Last Light Company
  
- **Intended Destination**:
  - *Self-Perception*: TBD - perhaps finding peace whether brother is found or not
  - *World View*: TBD - potentially developing greater trust in humans
  - *Key Relationships*: TBD - possibly resolving brother storyline, deeper integration with Last Light Company

## Growth Milestones
- **From Desperate Searcher to Methodical Tracker**: 
  - *Development Noted*: Changed approach after Veyra's influence
  - *Catalyst*: Near-death experience in blizzard, Veyra's philosophy
  - *Impact*: More effective tracking, less consumed by obsession
  
- **From Isolated to Team Member**: 
  - *Development Noted*: Joining Last Light Company
  - *Catalyst*: Trust built with Veyra
  - *Impact*: Applying skills to help others while continuing personal quest

## Character Flaws
- **Trust Issues**: 
  - *Effects on Character*: Initial wariness with new people, emotional distance
  - *Effects on Others*: May seem aloof or difficult to connect with
  - *Development Plan*: Gradual building of trust through shared experiences with Last Light Company
  
- **Tendency toward Obsession**: 
  - *Effects on Character*: Risk of slipping back into unhealthy patterns
  - *Effects on Others*: Might prioritize brother search over team needs at critical moments
  - *Development Plan*: Echo serves as anchor to methodical thinking, preventing backslide

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Possible feelings of responsibility for brother's kidnapping
  - *Secret 2*: May have information about brother she hasn't shared
  
- **Unknown to Character (Potential Story Hook):**
  - *Truth 1*: Echo is not just a raven. He is the reincarnated spirit of her lost brother, Liam. After dying in the hands of the "Silent Hand," his spirit was drawn to a raven's form and found its way back to his sister, becoming her silent protector and guide. The full truth of this is a major potential plot revelation, likely to be discovered through the intervention of Nireya Voss.
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD - brother's fate
  - *Planned Reveal*: TBD
  - *Expected Impact*: Would fundamentally change her core motivation

## Key Decisions & Turning Points
- **Decision to Search for Brother**:
  - *Context*: Childhood trauma of kidnapping
  - *Options Considered*: Unknown
  - *Choice Made*: Dedicated life to finding him
  - *Consequences*: Years of isolation, development of tracking skills, animal partnerships
  
- **Accepting Veyra's Help/Philosophy**:
  - *Context*: Near-death in blizzard
  - *Options Considered*: Continue alone or accept new perspective
  - *Choice Made*: Embraced Veyra's "hope as a tool" philosophy
  - *Consequences*: More methodical approach, joining Last Light Company

## Development Notes
- Character represents transformation from obsession to methodology
- Echo serves as both practical companion and emotional/psychological anchor
- Development path likely involves resolution of brother storyline
- Trust issues provide opportunities for growth through team dynamics
- Connection to animals is practical rather than spiritual - pragmatic partnerships formed from necessity
- The small locket with brother's picture represents both motivation and potential character growth if/when resolved

## Psychological Profile
*   **Vera Moonwhisper (The Seeker):** Vera's psychology is a pendulum swinging between obsessive focus and methodical patience. The search for her brother has defined her entire life, making her wary of people and more comfortable with the honesty of animals. Veyra's influence has tempered her desperation into a professional skill, but the obsessive fire is still there. She fears returning to that desperate state, and her trust, once given, is absolute and fierce.


---

# Vera "The Tracker" Moonwhisper - Relationships

## Family Bonds
- **Missing Brother**: 
  - *Relationship Type*: Sibling, primary motivation
  - *History*: Kidnapped as a child, spent years searching for him
  - *Current Status*: Missing, would now be a grown man
  - *Feelings Toward*: Deep guilt, responsibility, unwavering determination to find him
  - *Tensions/Issues*: The passing of time makes recognition increasingly difficult
  - *Shared Experiences*: Childhood memories before the kidnapping

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Rescuer, commander, mentor
  - *Hierarchy*: Veyra as Commander of Last Light Company
  - *Dynamics*: Deep respect from Vera, influenced by Veyra's philosophy
  - *History*: Veyra found her half-dead in a blizzard, still hunting for traces of her brother
  - *Current Status*: Commander and subordinate, possibly friendship
  - *Professional Opinion of*: High regard for Veyra's wisdom and leadership
  - *Memorable Interactions*: Veyra's words "Hope is a tool. Learn to use it better" changed her approach to searching

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Fellow Last Light Company member
  - *Hierarchy*: Thorne as Deputy Commander
  - *Dynamics*: Likely works with him on tactical operations utilizing her tracking skills
  - *History*: TBD when they first met
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely respects his tactical mind but may be reserved in personal interactions

- **Brother Aldwin Gentleheart**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties (tracking vs. medical)
  - *Dynamics*: His healing abilities support her tracking work; may find common ground in their observant natures
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely respects his calm presence and healing skills

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Mentor and mentee; "The Old Rock and the Young Sapling."
  - *Hierarchy*: Equals, but with a clear mentor-mentee dynamic.
  - *Dynamics*: Grimjaw has taken on a paternal, protective role with Vera. He sees her fierce spirit and the fragility beneath it. He doesn't offer advice on her tracking—that's her domain—but on endurance and self-preservation. He is the one who ensures she eats and rests, often sharing a quiet meal with her by the fire pits. His steady, grounding presence is a silent source of comfort and stability for her.
  - *History*: TBD
  - *Current Status*: Close mentor-mentee bond.
  - *Feelings Toward*: She sees him as a steadfast, protective figure, a source of quiet strength.

- **Lyralei Stormcaller**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: Her weather magic might assist with tracking conditions or provide cover
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her magical capabilities

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: His diplomatic skills complement her tracking information gathering
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values his negotiation abilities

- **Nireya Voss**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: Her spiritual abilities might provide different kinds of tracking information
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Finds her spiritual approach mysterious but respects results

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: Her technical innovations might enhance tracking capabilities
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her problem-solving abilities

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: His structural knowledge could help locate targets within buildings
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his engineering expertise

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: "The Outsiders' Alliance"; quiet friendship.
  - *Hierarchy*: Equals.
  - *Dynamics*: Both Vera and Kaida are deeply wary of people due to past betrayals. They have a quiet, minimalist friendship built on shared observation rather than conversation. They might spend hours together in the courtyard, one practicing with her tools, the other observing the patterns of birds, finding a strange comfort in each other's silent, professional competence. They understand each other's need for space and self-reliance.
  - *History*: TBD
  - *Current Status*: A quiet, unspoken alliance.
  - *Feelings Toward*: A sense of kinship with a fellow outsider. She trusts Kaida's professionalism, if not her history.

## Adversaries
- **Silent Hand (slaver ring)**: The network responsible for her brother's disappearance. They operate in cells with a winter "harvest season" and represent Vera's primary long-term antagonist and the driving force of her personal quest (evidence: chapters/ch10).

## Animal Connections
- **Echo (Raven Companion)**:
  - *Relationship Type*: Primary animal companion, emotional anchor
  - *History*: Unknown when they first bonded
  - *Current Status*: Constant companion
  - *Feelings Toward*: Deep trust, partnership
  - *Tensions/Issues*: None apparent
  - *Shared Experiences*: Serves as both messenger and reminder to stay methodical
  - *Communication*: Seems to have a special understanding with this animal

- **Animal Network**:
  - *Relationship Type*: Practical partnerships
  - *History*: Formed when humans failed her during desperate searching years
  - *Current Status*: Ongoing information network
  - *Dynamics*: Not spiritual reverence but practical alliance
  - *Notes*: Occasionally asks her animal network about "a boy who would be a man now"

## Interpersonal Patterns
- **Trust Issues**:
  - *Origin*: When people failed her during desperate searching years
  - *Manifestation*: Wariness with new people, tendency to check with Echo before trusting human judgment
  - *Exceptions*: Veyra earned her trust through actions rather than words
  - *Development*: Slowly learning to trust select humans again through Last Light Company

## Relationship Evolution Tracker
- **Pre-Brother's Kidnapping**: Normal familial relationships, limited information
- **Post-Kidnapping to Rescue**: Animals became primary allies when humans failed her
- **Rescue by Veyra**: Beginning of trust in humans again, specifically Veyra
- **Current**: Member of Last Light Company, maintains animal partnerships while developing human connections


---

# Vera "The Tracker" Moonwhisper — Dialogue & Psyche

## Core temperament
Focused, quietly intense, and perceptive. Tracker instincts make her observant and economical with words; she speaks to patterns and instincts rather than abstractions.

## Dialogue instincts
- Public: concise, observational—notes details others miss; often speaks in practical metaphors from nature.
- Tracking/skill use: speaks in short declaratives, pointing out evidence and inference.
- Under pressure: calm, quietly urgent; instructive to teammates in minimal phrases.
- Humor: dry, occasional wryness—rarely the source of levity.

## Emotional anchors & physical tells
- Fingers tracing surfaces or adjusting cloak: thinking/reading environment.
- Eyes narrow to focus; a softening gaze is rare and indicates trust.
- Brief, clipped phrases denote urgency or alert.

## Conflict & humor rules
- Avoids obvious bravado; will not mock lost causes lightly.
- Uses humor as a salve for awkward social moments, not for deep grief.
- Breaks pattern with rare personal confessions, usually short and earthy.

## Writer cues (practical)
- Use Vera to provide scene detail and to point out small physical clues that advance dialogue.
- When adding lines, let her provide precise observations that other characters then act on.
- Keep her metaphors tied to fauna, tracking, and landscape—avoid romantic abstractions.

## Drop-in sample lines
- Observation: "Boot treads here—two sets, left foot deeper. They moved downhill."
- Command/alert: "Move low. Wind's changing; scent will carry."
- Soft moment: "You read stone like a story. I read trees. We both listen."

## Voice evolution note (chapters 1–9)
- Began as a taciturn specialist; becomes more socially integrated, offering practical counsel and rare warmth as she trusts the Company.

## Usage examples (scenes)
- Recon: short, factual lines that reveal hidden paths or signs.
- Interactions with Kaida: sharing of craft-respecting banter.
- Quiet camp moments: terse, comfortable remarks that show slow thawing of trust.

## Notes for editors
- Keep Vera's lines precise and sensory. Avoid overly lyrical lines outside private scenes.


---

# Vera "The Tracker" Moonwhisper - Scene Tracker

## Major Scenes

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 4**: Found half-dead in winter forest by the Company, protected by animals
- **Scene 5**: Rescued and warmed, animals' protective behavior noted
- **Scene 6**: Recovery at Westwall Watchpost, initial conversation with Veyra about lost brother
- **Scene 8**: Demonstrates tracking abilities and beast sense to find kidnapped children
- **Scene 9**: Confronts Silent Hand trafficker, kills him with frost-covered thorny vines
- **Scene 9**: Officially recruited into the Last Light Company
- **Epilogue**: Settles into "The Aerie" quarters, bonds with Company at dinner

## Character Moments

### Best Moments
- Animals protecting her with leaves and offerings in the winter cold
- Using beast sense through Echo to locate the kidnapped children
- Taking vengeance on the Silent Hand trafficker
- Finding acceptance with the Last Light Company

### Worst Moments  
- Nearly freezing to death while searching for her brother
- Being told by the trafficker that her brother was "sold three times over"

### Turning Points
- Veyra's words: "Hope is a tool. Learn to use it better"
- Killing the trafficker - first confirmed Silent Hand member eliminated
- Accepting Veyra's offer to join the Company

## Interaction Log

### With Veyra Thornwake
- Chapter 10: Rescued, mentored, recruited - shared understanding of loss

### With Echo (Raven Companion)
- Chapter 10: Constant companion throughout, possible deeper connection hinted

### With Grimjaw Ironbeard
- Chapter 10: Pragmatic discussion about interrogation vs execution

### With Aldwin Gentleheart
- Chapter 10: Medical care during recovery, discussion of herbs for beast sense

### With Animals
- Chapter 10: Protected by forest creatures, demonstrates deep druidic connection

## Upcoming Scenes

### Planned Appearances
- Continued tracking missions with the Company
- Investigation into the Silent Hand operations
- Potential revelation about Echo's true nature

### Required Interactions
- Further bonding with Company members
- Exploration of her druidic abilities
- Pursuit of brother's trail through Silent Hand connections


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

# Summary for Veyra Thornwake

# Veyra Thornwake - Profile

## Basic Information
- **Full Name**: Veyra Thornwake
- **Aliases/Nicknames**: Commander
- **Race**: Half-Elf
- **Class**: Ranger/Cleric
- **Role in Story**: Commander of the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Wiry and strong, though thinner than expected for her role
- **Hair**: Long, ash-black hair with streaks of silver and gray despite her age, worn in tight braids on one side, the other half wild and partly shaved. Feathers, broken rings, and colored threads tied into the strands—trophies from those she's saved or buried.
- **Eyes**: One hazel eye, the other clouded from damage but still twitching with focus
- **Distinguishing Features**: The left side of her face is marred by an old, deep burn—mottled skin climbing from her jaw up past the temple, curling just under her eye, cutting through a faded tattoo that was once a swirling geometric sigil, now warped like melted glass.
- **Typical Clothing**: Weatherworn leather coat reinforced with old, mismatched armor plates—each a remnant of someone else's gear, polished and patched.
- **Body Language**: Calm, deliberate movements even in chaos
- **Physical Condition**: Scarred but resilient, battle-hardened

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Veyra Thornwake.

## Personality
- **Archetype**: Steadfast Leader/Survivor
- **Temperament**: Calm, collected, grave
- **Positive Traits**: Determined, loyal, protective of those in her charge
- **Negative Traits**: Possibly haunted by past trauma, burden of leadership
- **Moral Alignment**: Neutral Good (puts protection of others above all)

## Skills & Abilities
- **Expertise**: Combat medicine, survival, tracking, leadership
- **Languages**: TBD
- **Education Level**: Field-trained medic
- **Special Abilities**: Combination of ranger tracking/survival skills and cleric healing abilities

## Personal Details
- **Habits**: Collecting tokens from those she's saved or buried
- **Hobbies**: Maintaining her "record of weight" tattoo
- **Personal Quarters**: A circular room with a high, vaulted ceiling at the base of the Keep. The walls are bare, honey-colored stone, cool to the touch. The only furniture is a narrow cot with a single grey wool blanket, a heavy wooden chest, and a tall, imposing armor stand. There are no windows, only the steady, unwavering light of a single magical lantern that casts long shadows. This room is less a bedroom and more a monk's cell dedicated to a single purpose. It is silent, save for the faint, distant hum of the Bastion. The dominant feature is a massive wall covered in maps, not just of the Sword Coast, but of specific, dangerous regions: the Spine of the World, the Underdark, the Shadowfell. Red threads connect active missions, while black threads trace the paths of failures. She uses this space not just for rest, but for a nightly vigil, mentally walking the paths of her people, anticipating dangers, and mourning the lost. The small, worn wooden box on the chest contains dozens of tokens—a splinter of a shield, a single steel feather, a dried flower—each a tangible memory of a life she touched.
- **Likes**: TBD
- **Dislikes**: Abandoning the fallen
- **Fears**: Failing those who depend on her

## Combat & Tactics
- **Primary Weapons**: Dual scimitars named "Mercy" (silver-edged) and "Judgment" (cold iron-forged) - representing her dual nature as ranger and cleric
- **Secondary Weapon**: Composite longbow with salvaged strings from fallen comrades' instruments
- **Armor**: Weatherworn leather coat reinforced with old, mismatched armor plates—each a remnant of someone else's gear
- **Special Items**: Battered metal lantern that glows with soft gold light, said to reveal itself only to the lost

### Fighting Style Evolution
- **Past Style (Pre-Incident)**: Whirlwind fighter - constant movement, aggressive dual-blade dancing, relying on speed and momentum
- **Current Style (Post-Trauma)**: Tactical defender - precise, calculated strikes from defensive positions. Each movement deliberate and meaningful, no wasted motion.
- **Philosophy Shift**: From "strike fast, strike often" to "every cut must count"
- **Signature Move**: "Guardian's Stand" - defensive position that protects rescue targets while delivering precise counterstrikes
- **Combat Role**: Battlefield controller who positions herself for maximum situational awareness, prioritizing protection over aggression

## Psychological Response Matrix
- **In Crisis**: Becomes hypervigilant, compartmentalizes emotion, speaks in clipped commands. Counts everything—people, exits, threats, time.
- **During Negotiation**: Lets others talk while she reads body language for threats. Rarely speaks but when she does, it's definitive.
- **Moral Dilemma**: Weighs lives mathematically - will sacrifice principle for people. "The math is simple—more alive is better."
- **Team Conflict**: Mediates through action rather than words. "We move forward" ends most arguments.
- **Under Personal Attack**: Deflects to mission focus - personal pain is irrelevant to the objective.
- **In Victory**: Immediately shifts to casualty assessment. No celebration until all are safe and accounted for.

## Voice & Dialogue Patterns
- **Speech Style**: Short, declarative sentences. Rarely uses "I think" or "maybe" - speaks in certainties
- **Signature Phrases**: 
  - "Clock's running" (her urgency phrase)
  - "Hope is a tool. Use it."
  - Never says "leave them" - will find alternatives
- **Vocabulary**: Military efficiency mixed with medical precision. Counts constantly in speech.
- **Example Dialogue**: "Three exits. Two guards. Sixty seconds. Vera, take high. Thorne, with me."
- **Emotional Tells**: Voice gets quieter when more dangerous, never louder
- **Combat Commands**: Brief and clear - "Mercy for the fallen, Judgment for the standing"

## Notes
- A trail of ink winds up her left side, starting at her hand and vanishing beneath her armor—names written in old dialects of fallen friends, rescuees, even enemies. She calls it her "record of weight."
- Philosophy: "Hope is a tool. Use it."
- Speaks in low, deliberate tones and leads with calm gravity even in chaos
- Demonstrated her pragmatic leadership during the Stonebridge investigation by navigating the team's moral conflict, allowing them to bend the law but not break their principles. She is adept at adapting plans when new intelligence comes to light (Chapter 13).

### Public Perception
- Widely known for her "record of weight" tattoo, a rumor that is true and reinforces her personal commitment to every life.
- Rumored to have survived a dragon's fire, which explains the prominent burn scar on her face and adds to her legendary toughness.
- Respected in political circles for her direct, no-nonsense approach, which is seen as both refreshing and unnerving.


---

# Veyra Thornwake - Background

## Origin
- **Birthplace**: TBD
- **Birth Date**: TBD
- **Social Class**: TBD
- **Cultural Background**: Half-Elven heritage

## Family
- **Parents**: TBD
- **Siblings**: TBD
- **Extended Family**: TBD
- **Family Dynamics**: TBD

## History
- **Childhood**: TBD
  - *Key Events*: TBD
  - *Formative Experiences*: TBD
  
- **Education/Training**: 
  - *Institutions*: TBD
  - *Mentors*: TBD
  - *Areas of Study*: Medicine, combat tactics, survival
  
- **Adolescence/Young Adulthood**:
  - *Key Events*: Joined or was assigned to a noble adventuring party as a medic
  - *Relationships*: Formed bonds with her adventuring party
  - *Choices & Consequences*: Decision to become a field medic led to both her greatest trauma and her current purpose
  
- **Major Life Events**:
  - *Event 1*: The Undershade Canyon Ambush - The traumatic event where her original party, "The Gilded Compass," was destroyed, and she was forced to leave a comrade behind, his fate unknown.
  - *Event 2*: The Silent Oath - Her discovery by Captain Thorne Brightward and his decision to stand vigil with her, forming the foundational bond of the Last Light Company.
  - *Event 3*: Formation of the Last Light Company - The formal establishment of the Company with the iron vow that no soul would be left behind.

## Backstory Elements
- **Defining Moments**: The Undershade Canyon Ambush fundamentally changed her from a "starry-eyed medic" to the hardened commander she is today. The moment she was forced to abandon Ignis is the core of her trauma and the fuel for her mission.
- **Past Trauma**: Losing her comrades, suffering severe burns and injuries, and the unbearable guilt of being unable to save Ignis.
- **Greatest Achievements**: Founding the Last Light Company, surviving impossible odds.
- **Biggest Failures**: Being forced to leave Ignis behind in the fire, a failure that haunts her daily.
- **Secrets**: The full extent of her guilt and the possibility that she believes Ignis could still be alive somewhere.

## How They Got Here
- **Reason for Current Situation**: The traumatic experience of the Undershade Canyon Ambush, and specifically the forced abandonment of a living comrade, led to the formation of a company dedicated to ensuring no one is ever left behind again.
- **Path to Current Location**: TBD
- **Goals Prior to Story Start**: Established the Last Light Company with the mission that no one would be left behind.

## Historical Connections
- **Connection to Main Plot**: The "Scales of Pyre" cult and the fate of Ignis Emberheart are potential ongoing plot threads.
- **Connection to Other Characters**: Her bond with Thorne was forged in the immediate aftermath of the ambush.
- **Connection to Story World**: The Undershade Canyon is a place of immense personal trauma for her.

## Timeline
- Served as a medic in "The Gilded Compass," a noble adventuring party.
- The party was ambushed in Undershade Canyon by the "Scales of Pyre" cult.
- Survived the "Dragon's Breath" fire, sustaining significant injuries.
- Witnessed the deaths of three comrades and was forced to abandon a fourth, Ignis Emberheart, who was trapped but still alive.
- Was discovered by Captain Thorne Brightward while recovering the bodies of her fallen comrades.
- Established the Last Light Company with Thorne, founded on the vow that no one would be left behind.
- Currently serves as Commander of the Last Light Company.

## Personal Details
- **How She Relaxes**: She finds peace in the solitary, meticulous ritual of maintaining the mementos in her hair. It is a quiet way to honor the saved and the lost, processing her burdens through focused action rather than words.
- **Favorite Meal**: A simple, hearty bowl of mushroom and barley stew. It's the kind of practical, long-lasting trail food her first party, the Gilded Compass, used to make. The earthy taste reminds her of them, but it also carries a deeper memory: her mother used to add a pinch of savory blackroot to the stew when she was a child, a taste that is now an almost-forgotten echo of warmth and safety.
- **A Secret Skill**: She is an exceptional whistler, able to perfectly mimic birdsong. It's a skill she rarely uses now, a bittersweet echo of the person she was before the fire, sometimes emerging only when she believes she is truly alone.


---

# Veyra Thornwake - Character Development

## Personality Core
- **Defining Traits**: Determined, resilient, protective, purposeful
- **Core Values**: No one left behind, loyalty to those in her care, hope as a practical tool rather than blind optimism
- **Motivations**: Preventing others from suffering the same fate as her former comrades, honoring the memory of the fallen
- **Fears**: Failing those who depend on her, being unable to recover the fallen
- **Internal Conflicts**: Survivor's guilt vs. purpose, burden of leadership vs. personal healing
- **Contradictions**: Appears hardened but preserves hope, collects mementos of both grief and triumph

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: "Starry-eyed medic" - likely optimistic, possibly naive
  - *World View*: Probably saw adventure as noble, world as fundamentally good or fair
  - *Key Relationships*: Member of a noble adventuring party, likely valued for healing skills
  
- **Catalyst Events**:
  - *Event 1*: Ambush in Undershade canyon
  - *Event 2*: Survival and recovery mission for fallen comrades
  - *Event 3*: Founding of the Last Light Company
  
- **Current State**:
  - *Self-Perception*: Battle-hardened commander with a purpose
  - *World View*: Sees world as harsh but values recovery, rescue, and remembrance
  - *Key Relationships*: Leader of the Last Light Company, carries memories of fallen comrades
  
- **Intended Destination**:
  - *Self-Perception*: TBD
  - *World View*: TBD
  - *Key Relationships*: TBD

## Growth Milestones
- **Surviving the Ambush**: 
  - *Development Noted*: Transitioning from team member to sole survivor
  - *Catalyst*: Attack in Undershade canyon
  - *Impact*: Fundamental shift in identity and purpose
  
- **Recovering the Bodies**: 
  - *Development Noted*: Determination and physical endurance beyond normal limits
  - *Catalyst*: Refusal to leave comrades behind
  - *Impact*: Formation of core value and future mission

- **Establishing the Last Light Company**:
  - *Development Noted*: Transition from survivor to leader
  - *Catalyst*: Decision to prevent others from suffering similar abandonment
  - *Impact*: Creation of new purpose and identity as Commander

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*: Possible obsession with recovery mission, may prioritize the fallen over the living at times
  - *Effects on Others*: Could lead to risky missions for her company members
  - *Development Plan*: TBD
  
- **Secondary Flaws**: 
  - *Effects on Character*: Potential emotional distance as coping mechanism
  - *Effects on Others*: Might make personal connections difficult
  - *Development Plan*: TBD

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: TBD
  - *Secret 2*: TBD
  
- **Unknown to Character**:
  - *Truth 1*: TBD
  - *Truth 2*: TBD
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Decision to Recover the Bodies**:
  - *Context*: Left for dead with fallen comrades
  - *Options Considered*: Save herself or recover the fallen
  - *Choice Made*: Spent days recovering each body
  - *Consequences*: Physical scarring, emotional trauma, but birth of her mission
  
- **Founding the Last Light Company**:
  - *Context*: Post-trauma recovery
  - *Options Considered*: Retire from adventuring vs. create purpose from trauma
  - *Choice Made*: Established company with mission that no one would be left behind
  - *Consequences*: Became Commander, created legacy for fallen comrades

## Development Notes
- Character represents transformation of trauma into purpose
- Her physical scars mirror emotional journey
- The "record of weight" tattoo symbolizes both burden and honor
- Collects tokens from saved and lost as physical manifestation of her mission
- Philosophy "Hope is a tool. Use it." suggests practical approach to optimism

## Psychological Profile
*   **Veyra Thornwake (The Survivor):** Her psychology is defined by trauma and purpose. The "record of weight" tattoo is a literal manifestation of her survivor's guilt; she carries the names of the lost so she doesn't have to carry their ghosts. Her calm, grave demeanor is a carefully constructed shield against the chaos she's witnessed. She leads not through charisma, but through an unshakeable, almost grim, determination. Her greatest fear is not her own death, but failing those who depend on her, which would be a repeat of her past trauma.


---

# Veyra Thornwake - Relationships

## Family Bonds
- **TBD**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Past Relationships
- **Former Noble Adventuring Party Members**: 
  - *Relationship Type*: Comrades-in-arms, possibly friends
  - *History*: Served together until the ambush in Undershade canyon
  - *Current Status*: Deceased
  - *Feelings Toward*: Loyalty, grief, possibly survivor's guilt
  - *Tensions/Issues*: Their deaths formed the foundation of her current mission
  - *Shared Experiences*: Adventures, battles, the final ambush

## Professional Relationships
- **Captain Thorne Brightward**: 
  - *Nature of Relationship*: Comrades-in-arms; the "band of brothers" epitomized.
  - *Hierarchy*: Veyra is his Commander, and he is her unwavering Deputy. The trust is absolute.
  - *Dynamics*: Their bond is the foundational pillar of the Company, forged in tragedy and cemented by unspoken, mutual respect. They are two sides of the same coin. Veyra is the hardened idealist, fully aware she can't save everyone but honor-bound to try. Thorne is the pragmatist who makes her attempts possible. Their disagreements are purely tactical and always respectful, the debates of two commanders seeking the best path to an agreed-upon goal.
  - *History*: Thorne, then a city guard, was part of the patrol that discovered the aftermath of the Undershade canyon ambush. He found Veyra, the sole survivor, refusing to leave her fallen comrades. He stood vigil with her for two days as she buried them, and in that shared silence, he swore to follow her and help build her vision.
  - *Current Status*: Unshakably loyal. He is her most trusted confidant and tactical sounding board.
  - *Feelings Toward*: The loyalty of a soldier for a true commander and the love of a brother for his sister. He trusts her judgment completely, even when he questions the odds.

- **Vera "The Tracker" Moonwhisper**: 
  - *Nature of Relationship*: Commander and Scout
  - *Hierarchy*: Commander to specialist, with mentoring elements
  - *Dynamics*: Veyra rescued Vera and provided philosophical guidance
  - *History*: Found Vera half-dead in a blizzard, still hunting for her brother
  - *Current Status*: Trusted scout and someone Veyra personally guided
  - *Professional Opinion of*: Values her tracking skills and sees potential for healing
  - *Memorable Quote*: "Hope is a tool. Learn to use it better."

- **Brother Aldwin Gentleheart**: 
  - *Nature of Relationship*: Commander and Medic; Confidant
  - *Hierarchy*: Commander to specialist, but with a deep, almost spiritual, equality.
  - *Dynamics*: Aldwin is the only one who truly understands the immense weight Veyra carries. He acts as her unofficial confessor and quiet counsel. His tea ceremonies are a private ritual for them, a way for him to "heal the healer" and provide her with moments of peace she would never ask for herself. Their bond is one of shared witness to suffering and a mutual, unspoken understanding of the cost of their work.
  - *History*: Witnessed Veyra's dedication during a plague outbreak, which inspired him to join.
  - *Current Status*: Trusted medic and her most private confidant.
  - *Feelings Toward*: Deep respect and a quiet, protective affection. She sees him as the soul of the Company.

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Commander and Heavy Rescue specialist
  - *Hierarchy*: Leader to experienced team member, values his counsel
  - *Dynamics*: Respects his experience and "never loses anyone" reputation
  - *History*: TBD when they first met
  - *Current Status*: Trusted heavy rescue specialist
  - *Professional Opinion of*: Values his commitment to ensuring no one is left behind

- **Lyralei Stormcaller**: 
  - *Nature of Relationship*: Commander and Magical Support
  - *Hierarchy*: Leader to specialist
  - *Dynamics*: Values her unique magical capabilities for rescue operations
  - *History*: TBD
  - *Current Status*: Trusted magical support specialist
  - *Professional Opinion of*: Appreciates her weather magic and planar expertise

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Commander and Chief Negotiator.
  - *Hierarchy*: Veyra is the final authority, but she delegates all political and financial matters to him.
  - *Dynamics*: Veyra trusts Marcus's loyalty to the Company's mission, second only to Thorne's. She understands the necessity of his diplomatic maneuvering but is often impatient with its inherent subtlety and moral compromises. She wishes he could be more direct, but respects that his methods are effective in a world she has little taste for.
  - *History*: Marcus was a disillusioned diplomat who sought out Veyra, seeing in her a cause worthy of his talents. He was instrumental in the political negotiations that secured the land for the Bastion.
  - *Current Status*: A trusted and essential member of her command team, though their approaches often differ.
  - *Feelings Toward*: She trusts his results and his dedication to the Company's survival. However, she is sometimes frustrated by the necessary machinations of his job, creating a respectful but less intimate bond than the one she shares with Thorne.

- **Nireya Voss**: 
  - *Nature of Relationship*: Commander and Death-Walker
  - *Hierarchy*: Leader to specialist
  - *Dynamics*: Values her unique spiritual abilities for information gathering
  - *History*: TBD
  - *Current Status*: Trusted death-walker and spiritual specialist
  - *Professional Opinion of*: Appreciates her ability to communicate with the recently dead

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Commander and Arcano-Engineer
  - *Hierarchy*: Leader to technical specialist
  - *Dynamics*: Values her ability to solve "impossible problems" with innovative solutions
  - *History*: TBD
  - *Current Status*: Trusted technical problem-solver
  - *Professional Opinion of*: Appreciates her specialized equipment and creative engineering

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Commander and Siege Engineer
  - *Hierarchy*: Leader to engineering specialist
  - *Dynamics*: Values his structural expertise and methodical approach
  - *History*: TBD
  - *Current Status*: Trusted siege engineer
  - *Professional Opinion of*: Respects his engineering knowledge and systematic methods

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: Commander and Infiltration Specialist
  - *Hierarchy*: Leader to specialist serving community service
  - *Dynamics*: Values her infiltration expertise despite criminal background
  - *History*: TBD
  - *Current Status*: Trusted infiltration specialist
  - *Professional Opinion of*: Respects her professional competence and "redirected" purpose

## Mentors/Students
- **TBD Mentor**: 
  - *Relationship Type*: 
  - *Lessons Learned*: 
  - *Impact on Character*: 
  - *Current Status*:

- **Possible Students/Protégés in Last Light Company**: 
  - *Relationship Type*: Commander/mentor
  - *Teaching Style*: Likely practical, emphasizing survival and rescue
  - *Expectations*: High standards, adherence to the company's vow
  - *Current Status*: TBD

## Adversaries
- **Those Who Ambushed Her Party**: 
  - *Source of Conflict*: Caused the deaths of her comrades
  - *Conflict Intensity*: Severe
  - *History*: Ambushed and left her party for dead in Undershade canyon
  - *Current Status*: Unknown
  - *Feelings Toward*: Likely complex - may be seeking justice/vengeance or may have moved beyond it
  - *Potential Resolution*: TBD
- **Scales of Pyre (cult)**: The organization responsible for the ritual ambush in Undershade Canyon that triggered the catastrophe; active threat and ongoing plot antagonist (evidence: chapters/ch01, chapters/ch03).

## Relationship Evolution Tracker
- **Pre-Ambush**: Part of a noble adventuring party, likely close bonds with teammates
- **Ambush Event**: Traumatic severing of relationships through death
- **Post-Ambush**: Formation of new relationships through the Last Light Company
- **Present Day**: Commander with responsibility for her company members


---

# Veyra Thornwake — Dialogue & Psyche

## Core temperament
Deliberate, stoic, mission-first. Trauma and grief have honed her words into economy; every sentence carries purpose or promise.

## Dialogue instincts
- Public / command: short, declarative, precise. Uses concrete verbs and measured cadence; rarely wastes words.
- Private / confession: single-line metaphors or compact aphorisms—slightly lyrical but still restrained.
- Under pressure: voice drops to a low, controlled register; calm replaces panic.
- With close companions: allows very rare dry humor or softened cadence, but keeps emotional displays minimal.

## Emotional anchors & physical tells
- Lantern-hand: touching, adjusting, or resting fingers on her lantern = gathering resolve.
- Scar-hand: touching the burned cheek or forearm = memory surfacing; momentary withdrawal.
- Inhale-before-order: a slow, deep breath before issuing commands signals focus.
- Micro-smile: an almost invisible upturn that indicates genuine warmth; rare and significant.
- Abrupt silence: when she goes quiet, something internal is happening—use action to show consequence.

## Conflict & humor rules
- Avoids joking about loss, sacrifice, or survivors' guilt; intervenes to cut off such levity.
- Uses self-directed, dry deflection when praised (minimizes attention).
- Breaks pattern only with extreme fatigue or intense intimacy—these breaks should feel like a crack letting light through.

## Writer cues (practical)
- Commands: use short imperative sentences with clear targets. Structure: action → direct order → brief expected consequence.
- Explanations: keep them short; split across turns or have Thorne paraphrase longer points.
- Comforting lines: one compact image or aphorism, followed by silence or a physical gesture (e.g., sets lantern between hands).
- Vulnerability: deliver a single, unadorned confession line and let surrounding action show emotional fallout.
- When adding dialogue between characters, let Veyra's lines steer the scene. Her minimalism creates space for others to speak.

## Drop-in sample lines (from Chapters 1-3)
- **On duty vs. hope:** "Drink's on you if you keep both hands on the map."
- **On her scars:** "I was never beautiful. I was useful. The scars keep me useful."
- **On remembrance:** "Then I'll be ugly enough to never forget."
- **On pain:** "Good. Pain means I'm still here."
- **On leadership:** "Legends are for the dead."
- **On her new purpose:** "To make sure no one else burns alone."
- **On promises:** "Promises burn."
- **Private vow:** "Not left. Never left."

## Voice evolution note (chapters 1–9)
- Chapter 1: raw, jagged; language shows shock and sharp fragments.
- Chapters 2–5: resolves into terse leadership—decisive, directive.
- Chapters 6–9: remains concise but softens in private scenes; short aphorisms and one-line confessions appear as signs of emerging acceptance and steady leadership.

## Usage examples (scenes)
- Leading a rescue: minimal words, clear orders; pair each line with a visible action (points, breath, set of the lantern).
- Consoling survivors: a single sentence that reframes duty as promise, then silence.
- Tension with authorities: measured, precise rebuttals that avoid moralizing—focus on facts and outcomes.

## Notes for editors
- Preserve the economy of her speech. Lengthy monologues feel out of character.
- When expanding scenes, use Veyra's restraint to create tension—other characters can fill the silence.
- Keep metaphors sparse and concrete (wind, stone, lantern, fire).


---

# Veyra "The Lanternlight" Thornwake - Scene Tracker

## Major Scenes

### Chapter 1 – Ash and Compass <!-- slug: ch1-ash-compass -->
- **Scene 1**: Leading the Gilded Compass into Undershade Canyon
- **Scene 2**: Battle with the Scales of Pyre cultists
- **Scene 3**: Catastrophic ritual, watching companions die
- **Scenes 4-5**: Three days collecting bodies, discovery by Thorne's patrol

### Chapter 2 – The Lantern Ward <!-- slug: ch2-lantern-ward -->
- **Scene 1**: Recovery in Brightstone Healers' Hall, refusing magical healing
- **Scene 2**: Interaction with Dokra, discussion of scars and remembrance
- **Scene 3**: Receiving patrol's gifts and tokens of fallen companions

### Chapter 3 – Echoes in the City <!-- slug: ch3-echoes-city -->
- **Vignette 5**: Balcony conversation with Thorne, planning the future

### Chapter 4 – The First Spark <!-- slug: ch4-first-spark -->
- **Scene 1**: Dock Ward fire, defying Thorne to join the response
- **Scene 2**: Taking strategic command, using canyon experience
- **Scene 3**: Recognizing the need for specialists

### Chapter 6 – The Healer's Calling <!-- slug: ch6-healers-calling -->
- **Scene 3**: Witnessing Aldwin's work, forming bond with him
- **Scene 4**: Officially recruiting Aldwin as first specialist

### Chapter 7 – The Weight of the World <!-- slug: ch7-weight-world -->
- **Scene 1**: Facing the mine disaster, recognizing limitations
- **Scene 3**: Deciding to seek Grimjaw's expertise
- **Scene 4**: Witnessing Grimjaw's mastery, offering him a place

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 1**: Receiving mission to find missing boy in winter ruins
- **Scene 2**: Experiencing rare moment of laughter at misunderstanding
- **Scene 4**: Discovering Vera Moonwhisper, witnessing animal protection
- **Scene 6**: Bonding with Vera over shared trauma of lost companions
- **Scene 7**: Trusting Vera to help with missing children despite recent recovery
- **Scene 9**: Accepting Vera's lethal justice against trafficker
- **Scene 9**: Officially recruiting Vera into the Last Light Company
- **Epilogue**: Welcoming Vera to her new quarters, leading found-family dinner

### Chapter 12 – The Wayward Compass <!-- slug: ch12-wayward-compass -->
- **Scene 1**: Leading a supply run, rescuing civilians on the Trade Way.
- **Scene 2**: Standoff with Black Hawk bandits at the Wayward Compass inn.
- **Scene 2**: Witnessing Marcus Heartbridge defuse the situation with information, not violence.

### Chapter 13 – An Honest Coin <!-- slug: ch13-honest-coin -->
- **Scene 1**: Debriefing the encounter with Marcus.
- **Scene 1**: Personal moment recalling her mother's cooking.
- **Scene 2**: Making the final decision to investigate Marcus's claim rather than perform a heist.

## Character Moments

### Best Moments
- Refusing magical healing to keep scars as remembrance (Ch. 2)
- Taking command during Dock Ward fire (Ch. 4)
- Finding purpose through helping others (Ch. 4)
- Creating the Last Light Company concept (Ch. 4)
- Genuine laughter during Thomas Blackwood misunderstanding (Ch. 10)

### Worst Moments
- Watching companions die in Undershade Canyon (Ch. 1)
- Three days alone with the dead (Ch. 1)
- Facing limitations during mine disaster (Ch. 7)

### Turning Points
- Decision to create a rescue company (Ch. 3)
- Accepting leadership role (Ch. 4)
- "Hope is a tool" philosophy shared with Vera (Ch. 10)

## Interaction Log

### With Thorne Brightward
- Chapter 1: Rescued by his patrol
- Chapter 2: His vigil during her recovery
- Chapter 3: Planning the Company's future
- Chapter 4: Tension over her participation in the fire
- Chapter 10: Professional partnership during winter missions

### With Aldwin Gentleheart
- Chapter 6: Recruiting him after witnessing his gentle passage
- Chapter 10: Trusting his medical expertise with Vera

### With Grimjaw Ironbeard
- Chapter 7: Recruiting him after the mine disaster
- Chapter 10: Including him in Vera's rescue mission for his expertise

### With Vera Moonwhisper
- Chapter 10: Rescued her from winter, recognized kindred spirit, recruited her

## Upcoming Scenes

### Planned Appearances
- Continuing to build the Last Light Company
- Leading further rescue missions
- Potential confrontation with the Scales of Pyre cult
- Investigation into the Silent Hand traffickers with Vera

### Required Interactions
- Continue developing command relationship with specialists
- Further exploration of "hope as a tool" philosophy
- Possible confrontation with officials over vigilante actions


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

