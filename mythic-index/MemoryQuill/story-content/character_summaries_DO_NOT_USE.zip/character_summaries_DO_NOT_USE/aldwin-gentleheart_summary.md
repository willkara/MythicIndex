# Brother Aldwin Gentleheart - Profile

## Basic Information
- **Full Name**: Aldwin Gentleheart
- **Aliases/Nicknames**: "Brother" (earned title from soldiers, not a religious designation)
- **Race**: Halfling
- **Class**: Cleric
- **Role in Story**: Medic for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Compact, sturdy build typical of halflings
- **Hair**: Curly brown hair, prematurely touched with silver at the temples
- **Eyes**: Kind hazel eyes that hold the weight of countless difficult decisions
- **Distinguishing Features**: 
  - Hands are his most notable feature - small but incredibly steady
  - Long, dexterous fingers of both a scholar and healer
  - Hands marked with faint scars from field surgery
  - Fingers permanently stained with herb oils
- **Typical Clothing**: Practical robes in earth tones - brown wool with leather reinforcement at the shoulders and sleeves
- **Body Language**: Carries himself with quiet dignity of someone who has seen the worst of life and chosen to respond with compassion
- **Physical Condition**: Healthy, with remarkable endurance and steady hands despite witnessing trauma

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Aldwin Gentleheart.

## Personality
- **Archetype**: The Healer/Caretaker
- **Temperament**: Calm, compassionate, philosophical
- **Positive Traits**: Dedicated, empathetic, pragmatic, knowledgeable
- **Negative Traits**: Possibly carries burden of difficult decisions, may struggle with rural/quiet settings after war experience
- **Moral Alignment**: Neutral Good (focuses on alleviating suffering regardless of other considerations)

## Skills & Abilities
- **Expertise**: Medicine, herbalism, theology, philosophy
- **Languages**: TBD
- **Education Level**: Highly educated at prestigious academy
- **Special Abilities**: 
  - Holistic healing approach (physical, spiritual, mental)
  - Tea preparation with both medicinal and spiritual properties
  - Ability to provide comfort in most desperate situations
  - Knowledge of gentle end-of-life care

## Personal Details
- **Habits**: Tea ritual
- **Hobbies**: Herbalism, philosophical contemplation
- **Personal Quarters**: A warm, circular room built into the quietest part of the Sanctuary terrace, with a low, timber-beamed ceiling. The air is thick with the comforting aroma of dried herbs, spices, and brewing tea. The curved walls are lined with floor-to-ceiling shelves, holding hundreds of meticulously labeled ceramic jars and wooden boxes. This is his personal laboratory and sanctuary. He finds peace in the quiet, methodical work of his craft. A large, comfortable armchair sits at the center of the room, facing a low table with a beautiful, well-used ceramic tea set. This is where he performs his personal tea ceremonies to center himself after a difficult healing session. He rarely sleeps in his bed, preferring to doze in the chair, surrounded by the tools of his trade, waking occasionally to check on a steeping tincture or to grind herbs with a heavy stone mortar and pestle.
- **Likes**: Providing comfort, meaningful conversation, tea ceremonies
- **Dislikes**: Unnecessary suffering, stagnation
- **Fears**: Helplessness in the face of suffering; being unable to provide comfort or dignity to someone in their final moments.

## Combat & Tactics
- **Primary Weapon**: Quarterstaff with healing crystals embedded in the head - "Mercy's Touch" - doubles as walking stick and medical tool
- **Secondary Tools**: Healer's kit repurposed as improvised weapons (scalpels for precision cuts, needles for pressure points)
- **Armor**: Reinforced robes with hidden leather padding - protection that doesn't impede healing work
- **Special Equipment**: Ornate tea service that unfolds into complete brewing station, various medicinal compounds
- **Fighting Style**: Defensive healer - fights only to protect patients, uses staff to create space and disable rather than harm
- **Signature Move**: "Sanctuary Circle" - creates healing zone in combat where allies gain strength
- **Combat Philosophy**: "First, do no harm. Unless they harm my patients - then all bets are off"
- **Tactical Role**: Combat medic who keeps team fighting while minimizing casualties

## Psychological Response Matrix
- **In Crisis**: Immediate triage mentality - categorizes by urgency, stays remarkably calm while prioritizing care
- **During Negotiation**: Finds common ground through shared humanity, reminds all parties of what truly matters
- **Moral Dilemma**: Always chooses life preservation, but understands sometimes mercy means letting go
- **Team Conflict**: Offers tea ceremony and neutral ground for discussion, mediates through compassion
- **Under Personal Attack**: Responds with unexpected kindness that often disarms aggressors
- **In Victory**: Immediately tends to enemy wounded - "The battle's over, now we're all just people in pain"

## Voice & Dialogue Patterns
- **Speech Style**: Gentle, measured tones with underlying steel when protecting patients
- **Signature Phrases**: 
  - "Let's not make this wound worse"
  - "Pain shared is pain halved"
  - "Tea first, then we talk" (his de-escalation technique)
  - "Even stones can be worn down by gentle rain"
- **Medical Metaphors**: Describes situations in healing terms - conflicts are "infections," solutions are "treatments"
- **Example Dialogue**: "The situation is infected, yes, but not terminal. We need to drain the abscess before it spreads. Sometimes that means cutting, but always with purpose."
- **Emotional Tells**: Hands become absolutely still when making hard decisions, voice drops to whisper when discussing death
- **Compassionate Authority**: Commands respect through kindness rather than force

## Notes
- Integrates physical treatment, spiritual comfort, and mental care in his healing approach.
- Tea ritual offers comfort to patients and companions.
- In cases where recovery is impossible and pain unbearable, his special blends offer gentle passage.
- His "gentle passage" teas are an open secret within the Company. While his compassion is never questioned, the practice is a source of quiet wariness for some.
- Joined the Company after witnessing Veyra's dedication during a plague outbreak.
- Recognizes a kindred spirit in Veyra - someone who understands that sometimes the greatest mercy is simply being present in someone's darkest moment.

### Public Perception
- Known for his profound kindness and holistic healing approach, often sitting with patients for hours and using special teas to provide comfort beyond just medicine.
- Respected for his calm demeanor even in the face of tragedy, treating both the living and the dead with equal respect.
- His special tea blends are rumored to offer not just physical relief, but also courage and peace.


---

# Brother Aldwin Gentleheart - Background

## Origin
- **Birthplace**: A halfling village in the Greenfields.
- **Birth Date**: TBD
- **Social Class**: Middle class, from a respected family of healers.
- **Cultural Background**: Halfling heritage with an emphasis on community care and traditional healing.

## Family
- **Parents**: Village healers (names TBD).
- **Siblings**: TBD
- **Extended Family**: Comes from a long lineage of healers.
- **Family Dynamics**: His family taught him the foundations of healing, but he diverged from their path, pursuing formal academic training. The respectful distance between them stems from a philosophical divide: they practice medicine with rigid, traditional precision, while Aldwin believes in a more holistic approach, treating the patient's spirit as much as their ailment.

## History
- **Childhood**: 
  - *Key Events*: Showed an early aptitude for healing and scholarly pursuits, often preferring books to the boisterous social life of his village.
  - *Formative Experiences*: Grew up learning the foundations of herbalism and patient care from his family.
  
- **Education/Training**: 
  - *Institutions*: Studied at a prestigious academy in Waterdeep, focusing on advanced medicine, philosophy, and theology.
  - *Mentors*: Various professors and healers (specific names TBD).
  - *Areas of Study*: His studies focused on the intersection of physical and spiritual well-being, laying the groundwork for his holistic approach.
  - *Notable Acquaintances*: During his studies, he occasionally attended cross-disciplinary lectures on arcane theory, where he was briefly acquainted with a brilliant, if eccentric, elven elementalist named Lyralei Stormcaller. He remembers being fascinated by her theories on how atmospheric pressure could affect somatic components, though he found her approach a bit too detached for his own tastes.
  
- **Adolescence/Young Adulthood**:
  - *Key Events*: Left his village to pursue higher education, a rare choice for a halfling of his community.
  - *Relationships*: Developed connections within the academic community of Waterdeep.
  - *Choices & Consequences*: His choice of a scholarly path over traditional healing created a respectful distance with his family, but provided him with the skills that would later save countless lives.
  
- **Major Life Events**:
  - *Event 1*: Outbreak of the Border Wars.
  - *Event 2*: Voluntarily enlisted as a field medic, motivated by a deep philosophical conviction to serve where the need was greatest.
  - *Event 3*: Earned the title "Brother" from the soldiers who, moved by his unwavering compassion, adopted him as their own family.
  - *Event 4*: Post-war return to village life, where he found himself dissatisfied with the quiet pace and lack of profound purpose.
  - *Event 5*: The Plague of the Gray Rot - A virulent plague swept through a remote, quarantined village that had been abandoned by official aid. Aldwin, feeling a pull of duty, traveled there to offer what help he could.
  - *Event 6*: The Joining - In the heart of the plague-stricken village, he met Veyra Thornwake and Thorne Brightward. He witnessed Veyra's unwavering dedication to not just healing the sick, but providing dignity to the dying and remembering the fallen. Recognizing a kindred spirit, he approached her and offered his skills, not as a hireling, but as a colleague, becoming the first crucial specialist to join the nascent Last Light Company.

## Backstory Elements
- **Defining Moments**: 
  - His service in the Border Wars, which forged his holistic healing philosophy through the cumulative weight of his experiences rather than a single event.
  - Witnessing Veyra's dedication during the plague outbreak, which gave his life a new, profound purpose.
  
- **Past Trauma**: 
  - The collective horrors of battlefield medicine and the countless difficult triage decisions he was forced to make.
  - The memories of administering "gentle passage" to those beyond saving.
  
- **Greatest Achievements**: 
  - His academic accomplishments.
  - The countless lives he saved during the war.
  - The development of his unique, compassionate approach to healing.
  
- **Biggest Failures**: 
  - The soldiers and patients he couldn't save, whose memories he carries with quiet dignity.
  
- **Secrets**: 
  - He carries a private grief for specific patients he lost during the war, whose faces he can still recall in perfect detail.

## How They Got Here
- **Reason for Current Situation**: After the intensity of the Border Wars, Aldwin found himself unable to readjust to the quiet life of a village healer. He felt a deep sense of stagnation, his profound skills and philosophical convictions going unused. The Plague of the Gray Rot was the catalyst he needed, a call to a higher purpose. Witnessing Veyra's mission in action, he saw the perfect synthesis of his wartime experience and his innate compassion. He joined the Last Light Company because it was the only place where his unique blend of healing, philosophy, and unwavering presence in the face of suffering would be truly valued.
- **Path to Current Location**: 
  - Village healer background -> Academic education -> War service -> Brief, dissatisfying return to village life -> The Plague of the Gray Rot -> Joining the Last Light Company.
  
- **Goals Prior to Story Start**: 
  - To find a meaningful application for his hard-won skills and philosophical outlook.
  - To continue providing compassionate care in the most challenging of circumstances.

## Historical Connections
- **Connection to Main Plot**: Medic for the Last Light Company.
- **Connection to Other Characters**: 
  - Respects Veyra as a kindred spirit.
  - Has a pre-existing, if distant, academic connection to Lyralei Stormcaller.
  
- **Connection to Story World**: 
  - Experienced the Border Wars.
  - Familiar with the academic institutions of Waterdeep.
  - Witnessed the Plague of the Gray Rot.

## Timeline
- Early life in a family of village healers in the Greenfields.
- Scholarly education at a prestigious academy in Waterdeep.
- Outbreak of the Border Wars.
- Voluntary service as a field medic, earning the title "Brother."
- Post-war return to village life and subsequent dissatisfaction.
- The Plague of the Gray Rot outbreak.
- Met Veyra Thornwake and Thorne Brightward in the plague-stricken village.
- Joined the nascent Last Light Company as its first specialist.

## Personal Details
- **How He Relaxes**: The meticulous, sensory process of preparing tea—selecting leaves, grinding herbs, heating water to a precise temperature—is a form of meditation for him. It is a quiet, grounding ritual that allows him to center himself and process the pain he witnesses daily.
- **Favorite Meal**: Honey-glazed river trout with a side of wild greens and toasted seeds. It's a dish that bridges the two halves of his life: the simple, wholesome ingredients are reminiscent of his halfling village, while the refined preparation speaks to the palate he developed during his academic years.
- **Family Connection**: He carries a small, worn, leather-bound book filled with pressed flowers and herbs from the fields around his home village, a gift from his mother. On difficult nights, he opens it, the faint scent of home a silent connection to the family and the simpler form of healing he evolved from.


---

# Brother Aldwin Gentleheart - Character Development

## Personality Core
- **Defining Traits**: Compassionate, philosophical, steady, pragmatic
- **Core Values**: Alleviating suffering, dignity in death, holistic healing
- **Motivations**: To provide care where most needed, to honor the cycle of life
- **Fears**: Possibly failure to provide comfort when needed most
- **Internal Conflicts**: Mercy vs. prolonging life, academic knowledge vs. practical reality
- **Contradictions**: Gentle healer who makes hard decisions about life and death

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Academic healer from traditional family
  - *World View*: Scholarly, theoretical approach to medicine
  - *Key Relationships*: Academic peers, family
  
- **Catalyst Events**:
  - *Event 1*: Border Wars outbreak - decision to volunteer as field medic
  - *Event 2*: Battlefield experiences and trauma
  - *Event 3*: Post-war return to village life
  - *Event 4*: Plague outbreak and witnessing Veyra's dedication
  
- **Current State**:
  - *Self-Perception*: "Brother" - adopted family member to those in need
  - *World View*: Holistic approach to healing (physical, spiritual, mental)
  - *Key Relationships*: Last Light Company, especially Veyra
  
- **Intended Destination**:
  - *Self-Perception*: TBD
  - *World View*: TBD
  - *Key Relationships*: TBD

## Growth Milestones
- **From Academic to Field Medic**: 
  - *Development Noted*: Theory confronted with brutal reality
  - *Catalyst*: Border Wars
  - *Impact*: Practical application of knowledge, development of improvisation skills
  
- **Development of Holistic Healing Philosophy**: 
  - *Development Noted*: Integration of physical, spiritual, and mental care
  - *Catalyst*: Witnessing battlefield trauma and psychological effects
  - *Impact*: Creation of tea ceremony and more comprehensive approach to healing

- **Finding Purpose in Last Light Company**:
  - *Development Noted*: From dissatisfaction to renewed meaning
  - *Catalyst*: Witnessing Veyra during plague outbreak
  - *Impact*: Joining a cause aligned with personal philosophy

## Character Flaws
- **Possible Savior Complex**: 
  - *Effects on Character*: May take on too much responsibility for others' well-being
  - *Effects on Others*: Could create dependency
  - *Development Plan*: Learning to balance care with self-preservation
  
- **Pragmatism That Borders on Coldness**: 
  - *Effects on Character*: Making difficult decisions about who can be saved
  - *Effects on Others*: May appear detached when making triage decisions
  - *Development Plan*: Finding balance between necessary pragmatism and empathy

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Specific formulations of his "gentle passage" teas
  - *Secret 2*: Possibly specific patients he couldn't save that haunt him
  
- **Unknown to Character**:
  - *Truth 1*: TBD - perhaps unexpected effects of his care
  - *Truth 2*: TBD - possibly misunderstandings about his intentions
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Volunteering as Field Medic**:
  - *Context*: Border Wars outbreak
  - *Options Considered*: Stay in academic setting vs. apply skills where needed
  - *Choice Made*: Entered battlefield medicine
  - *Consequences*: Practical experience, trauma, development of holistic philosophy
  
- **Developing Tea Ceremony**:
  - *Context*: Battlefield medicine limitations
  - *Options Considered*: Traditional medicine vs. holistic approach
  - *Choice Made*: Created ritual that addressed physical, spiritual, mental needs
  - *Consequences*: Signature approach to healing that extends beyond physical treatment

- **Leaving Village Life After War**:
  - *Context*: Dissatisfaction with routine healing
  - *Options Considered*: Remain in comfortable setting vs. seek meaningful work
  - *Choice Made*: Joined Last Light Company after plague encounter
  - *Consequences*: Found purpose aligned with personal philosophy

## Development Notes
- Character represents integration of scholarly knowledge with practical experience
- Tea ceremony serves as physical manifestation of his healing philosophy
- The "Brother" title symbolizes his transition from academic to adopted family member
- Development arc shows progression from theoretical to holistic healer
- His relationship with life and death is nuanced and pragmatic rather than idealistic
- Future development might explore tensions around "gentle passage" practices
- Could develop teaching role within Company, passing knowledge to others

## Psychological Profile
*   **Brother Aldwin Gentleheart (The Witness):** He is a soul who has seen the absolute worst of humanity on the battlefield and made a conscious choice to respond with compassion rather than cynicism. His healing is not just medicinal; it's philosophical. The tea ceremony is a ritual to impose calm and order on the chaos of suffering. He carries the weight of every difficult decision, every life he couldn't save, but he bears it with quiet dignity. He is the Company's moral and spiritual anchor.


---

# Brother Aldwin Gentleheart - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and medic, kindred spirits
  - *Hierarchy*: Respects her leadership
  - *Dynamics*: Mutual recognition of dedication to alleviating suffering
  - *History*: Witnessed her dedication during a plague outbreak, which inspired him to join
  - *Current Status*: Trusted company medic
  - *Professional Opinion of*: Sees her as someone who understands that sometimes the greatest mercy is simply being present in someone's darkest moment
  - *Memorable Interactions*: The plague outbreak that brought them together

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and medic
  - *Hierarchy*: Respects chain of command
  - *Dynamics*: Likely values Thorne's military background and discipline
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Probably appreciates his tactical expertise and leadership

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow company member
  - *Hierarchy*: Equals with different specialties
  - *Dynamics*: Might find common ground in their observant natures
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Likely respects her tracking abilities and connection to animals

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (medical vs. heavy rescue)
  - *Dynamics*: Would work closely in rescue operations - Grimjaw extracting victims, Aldwin treating them
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates his experience and protective instincts

- **Lyralei Stormcaller**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (medical vs. magical support)
  - *Dynamics*: Her magical abilities might complement his healing in certain situations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects her magical knowledge and research approach

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Confidants; "The Cynic and the Believer."
  - *Hierarchy*: Equals.
  - *Dynamics*: Marcus, a pragmatist who often has to do morally gray things for the greater good, seeks out Aldwin after particularly difficult missions, not to confess, but to recalibrate. He sits for a tea ceremony, and Aldwin's quiet, non-judgmental presence allows Marcus to reconnect with the "why" of their mission, cleansing his palate from the dirty work he has to do. Aldwin, in turn, sees the core of goodness in Marcus beneath the cynical exterior.
  - *History*: TBD
  - *Current Status*: A quiet, deeply important confidential relationship.
  - *Feelings Toward*: He sees Marcus as a man making difficult choices for the right reasons and offers him a space of quiet contemplation without judgment.

- **Nireya Voss**: 
  - *Nature of Relationship*: Professional partner; the other half of the healing process.
  - *Hierarchy*: Peers and colleagues who lead the Temple of Renewal together.
  - *Dynamics*: Theirs is a relationship of profound mutual respect and seamless cooperation. Aldwin is the master of the body, using his clerical magic and medical knowledge to mend flesh and bone. He is the first face most of the wounded see. However, he understands that some wounds are beyond his reach. He knows precisely when to step back and bring in Nireya to tend to a patient's fractured spirit, psychological trauma, or to provide peace for the dying. They are the complete package of healing.
  - *History*: They likely met and developed their working relationship within the Company, quickly realizing how their different approaches to healing complemented each other perfectly.
  - *Current Status*: The two pillars of the Sanctuary. They often have quiet, philosophical conversations over tea about the nature of life, death, and the soul, each valuing the other's unique perspective.
  - *Feelings Toward*: Deep professional and personal respect. He sees her as a vital and necessary counterpart to his own skills and is grateful for her ability to handle the spiritual burdens that he cannot.

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (medical vs. technical)
  - *Dynamics*: Her innovative devices might enhance his medical capabilities
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Appreciates her technical problem-solving and creative approach

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Fellow Company member
  - *Hierarchy*: Different specialties (medical vs. engineering)
  - *Dynamics*: His structural knowledge might help in safely extracting injured victims from dangerous locations
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Respects his methodical approach and engineering expertise

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (medical vs. infiltration)
  - *Dynamics*: His healing abilities support her potentially dangerous infiltration work
  - *History*: TBD
  - *Current Status*: Professional colleagues
  - *Professional Opinion of*: Values her professional competence while providing medical support for her high-risk operations

## Past Relationships
- **Border War Soldiers**: 
  - *Relationship Type*: Field medic to soldiers
  - *History*: Provided medical care during the war
  - *Current Status*: Most connections likely ended after war
  - *Feelings Toward*: Deep compassion, sense of duty
  - *Tensions/Issues*: Possibly haunted by those he couldn't save
  - *Shared Experiences*: Battlefield trauma and camaraderie
  - *Notable Individuals*: Those who first called him "Brother" and adopted him as family

- **Academic Mentors/Peers**: 
  - *Relationship Type*: Student to teachers/colleagues
  - *History*: Formal education at prestigious academy
  - *Current Status*: Likely limited contact since war
  - *Feelings Toward*: Respect for knowledge gained
  - *Tensions/Issues*: Possible philosophical differences after war experiences
  - *Shared Experiences*: Academic discussions, medical training

## Family Relationships
- **Parents (Halfling Healers)**:
  - *Relationship Type*: Son to village healer parents
  - *History*: Taught him initial healing skills before academia
  - *Current Status*: TBD
  - *Feelings Toward*: Respect for traditional knowledge
  - *Tensions/Issues*: Possible disappointment at his leaving village life
  - *Shared Experiences*: Early healing training, family traditions

- **Other Family Members**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Feelings Toward*: TBD

## Patients & Care Relationships
- **Last Light Company Members**:
  - *Relationship Type*: Healer to patients
  - *Dynamics*: Holistic care provider - addresses physical, spiritual, and mental needs
  - *Notable Interactions*: Tea ceremonies for comfort and healing
  - *Special Care*: Understanding individual needs of each company member

- **Terminal Patients**:
  - *Relationship Type*: Compassionate end-of-life care provider
  - *Dynamics*: Offers dignity and peace in final moments
  - *Notable Interactions*: Special tea blends for "gentle passage"
  - *Personal Impact*: Likely carries memories of those who passed under his care

## Interpersonal Patterns
- **Trust Building**:
  - Uses tea ceremony as a way to establish rapport and trust
  - Creates safe space for both physical and emotional healing
  - Demonstrates reliability through consistent care

- **Conflict Resolution**:
  - Likely approaches conflicts philosophically
  - May serve as mediator due to calm, steady presence
  - Focuses on underlying needs rather than surface disagreements

## Relationship Evolution Tracker
- **Pre-War**: Academic relationships, family connections
- **During War**: Formation of "Brother" identity, soldier bonds
- **Post-War Village Life**: Strained relationship with peaceful routine
- **Plague Outbreak**: Meeting Veyra, witnessing her dedication
- **Current**: Developing relationships with Last Light Company members

## Potential Relationship Development
- May deepen philosophical connection with Veyra
- Could develop teaching relationship with others interested in healing
- Might form special bonds with those he's healed from serious injuries
- Potential tension with anyone who questions his "gentle passage" practices


---

# Aldwin Gentleheart — Dialogue & Psyche

## Core temperament
Quietly compassionate, steady, and philosophical. Sees suffering and responds with presence and dignity rather than spectacle.

## Dialogue instincts
- Public: calm, measured, speaks slowly to create space. Uses simple metaphors drawn from domestic life and ritual.
- Teaching/comfort: ritualized phrasing (tea, passages), invites participation rather than giving orders.
- Under pressure: unflappable; keeps tone soft but firm, using short corrective or grounding statements.
- Humor: gentle, small levity that eases tension—never flippant about pain.

## Emotional anchors & physical tells
- Tea ritual: preparing or offering a cup = bringing calm and focus.
- Small, steady hands: smoothing a blanket, adjusting a bandage—actions speak with his words.
- Soft smile and steady eye contact signal acceptance and reassurance.
- Pauses long enough for another to exhale; silence is an active tool for him.

## Conflict & humor rules
- Does not debate the dignity of life in abstractions; reframes hard choices with compassion.
- Avoids dark jokes about death; uses warmth and a tiny wryness to lighten unbearable moments.
- Will calmly challenge black-and-white thinking about mercy vs. preservation.

## Writer cues (practical)
- Use Aldwin as the emotional anchor in scenes involving suffering or ethical tension.
- When inserting dialogue, give him short, clarifying lines that reframe a dilemma (e.g., "Suffering is the enemy, not death.").
- Pair his lines with a small ritual action (pouring tea, laying a hand) to emphasize embodiment of his philosophy.

## Drop-in sample lines (from Chapters 6-9)
- **On his philosophy:** "Suffering is the enemy, my friend, not death."
- **On his methods:** "I freed her... It's not medicine. It's compassion."
- **On his purpose:** "I don't save lives. I save souls."
- **On joining the company:** "Building a company for the lost? Then I'll gather my things."
- **On the company's nature:** "The lost leading the lost."
- **A simple kindness:** "A kindness is never a small thing."
- **Gentle levity:** "Don't worry. It's just mint."

## Voice evolution note (chapters 1–9)
- Introduction: appears as a quiet moral figure, steadying others.
- Middle: his presence reframes the Company's approach to risk and mercy.
- Later: becomes a core emotional center; his calm speech helps the Company accept hard choices and recover afterward.

## Usage examples (scenes)
- In a triage tent: short, guiding phrases combined with ritual actions to slow panicked breaths.
- After a rescue: one soft sentence that converts survivor panic into dignified care.
- When debating ethics: a simple, humane aphorism that reframes the argument.

## Notes for editors
- Avoid making Aldwin a polemicist; keep him concise and tactile.
- Let his teachings appear through small rituals and consistent, gentle language rather than long sermons.


---

# Brother Aldwin "Gentle Passage" Gentleheart - Scene Tracker

## Major Scenes

### Chapter 6 – The Healer's Calling <!-- slug: ch6-healers-calling -->
- **Scene 2**: Introduction at plague-stricken Oakhaven village
- **Scene 3**: "Gentle passage" ceremony for plague victims
- **Scene 4**: Decision to join the Last Light Company

### Chapter 7 – The Weight of the World <!-- slug: ch7-weight-world -->
- **Scene 3**: Tending to injured miners at Blackvein Lode
- **Scene 4**: Building rapport with Grimjaw during rescue operation

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 1**: Preparing medical supplies for winter rescue mission
- **Scene 2**: Gentle assessment of the Thornwood misunderstanding
- **Scene 4**: Immediate medical assessment of Vera in the snow
- **Scene 5**: Life-saving treatment of Vera's severe hypothermia
- **Scene 6**: Ongoing care and assessment of Vera's magical exhaustion
- **Scene 7**: Selected for tracking mission for medical expertise
- **Scene 9**: Tending to rescued children from the Silent Hand trafficker
- **Epilogue**: Offering herbal remedies for Vera's beast sense exhaustion
- **Epilogue**: Good-natured reaction to teasing about his "special teas"

## Character Moments

### Best Moments
- Gentle passage ceremony at Oakhaven (Ch. 6)
- Immediate assessment and treatment of Vera (Ch. 10)
- Calm presence during animal protection of Vera (Ch. 10)
- Offering herbs for Vera's beast sense exhaustion (Ch. 10)

### Worst Moments
- Confronting limitations of healing during plague (Ch. 6)
- Potentially not having appropriate treatments for magical exhaustion (Ch. 10)

### Turning Points
- Decision to join the Last Light Company (Ch. 6)
- Building rapport with Grimjaw (Ch. 7)
- Meeting Vera and recognizing her unique connection to animals (Ch. 10)

## Interaction Log

### With Veyra Thornwake
- Chapter 6: First meeting, philosophical alignment recognized
- Chapter 10: Supporting her decision regarding Vera and rescued children

### With Thorne Brightward
- Chapter 6: Being introduced to the Company concept
- Chapter 10: Coordination during Vera's rescue and recovery

### With Grimjaw Ironbeard
- Chapter 7: Beginning of working relationship during mine rescue
- Chapter 10: Gentle teasing during dinner about "special teas"

### With Vera Moonwhisper
- Chapter 10: Saving her life from hypothermia
- Chapter 10: Recognizing her druidic connection to animals
- Chapter 10: Offering herbal remedies for beast sense exhaustion

## Upcoming Scenes

### Planned Appearances
- Continued medical support during rescue missions
- Potential development of specialized treatments for magical exhaustion
- Further exploration of "gentle passage" philosophy

### Required Interactions
- Development of healing relationship with Vera
- Further integration of medical knowledge with other specialists' work
- Potential philosophical discussions about death and mercy with Company members


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

