# Ignis "Spark" Emberheart – Profile

## Basic Information
- Full Name: Ignis "Spark" Emberheart
- Aliases/Nicknames: Spark
- Age: Unknown
- Gender: Male
- Role in Story: Party sorcerer whose wild magic triggered catastrophe
- First Appearance: Chapter 1, Scene 1 (Twilight on the Rim)
- Status: Missing (last seen sealed behind molten glass after the Undershade collapse; evidence: chapters/ch01)

## Notes
- Fate unresolved; possible transformation or altered state. Ongoing plot thread to investigate or resolve.

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Eyes that "shone" with fascination
- Distinguishing Features: Tiefling tail (mentioned flicking to douse embers)
- Typical Clothing: Not specified
- Body Language: Flamboyant, dramatic displays
- Physical Condition: Powerful magic user

## Significance
Ignis Emberheart was the Gilded Compass's fire sorcerer whose wild magic surge catastrophically amplified the cult's ritual. His desperate attempt to counter the cult's magic instead fed their spell, creating the disaster. His ambiguous fate—trapped alive behind molten glass—haunts Veyra and represents the ultimate failure of "no one left behind."

## The Catastrophe
His wild magic surge harmonized with the cult's ritual instead of disrupting it, causing a massive detonation that sealed the party's fate. Standing at ground-zero with "flames wreathing him like a crown of regret," he desperately tried to undo what he had caused.

## Final Moments
Last seen alive but trapped as the canyon collapsed, his desperate plea "Scout, find another path—live—" was among the last words Veyra heard. The "I" stone represents not just his memory but the uncertainty of his fate.

## Unresolved Mystery
- Was he transformed by the magic?
- Did he survive in some altered state?
- Could he still be rescued?
- Connection to the Shadow Watcher in Veyra's dreams?

## Legacy
- Name inscribed in Hall of Remembrance (despite uncertain fate)
- The "I" stone carried as a token
- His fate drives Veyra's "never left" vow
- Represents the Company's mission to find even the impossible to reach


---

# Ignis "Spark" Emberheart - Background

## Origin
- **Birthplace**: Unknown.
- **Social Class**: Unknown.
- **Cultural Background**: Tiefling, with a natural affinity for fire magic.

## History
- **Professional Career**: The fire sorcerer for the Gilded Compass adventuring party. His flamboyant personality and powerful, if sometimes unpredictable, magic made him a valuable but volatile member of the team.

## Personal Details
- **A Passionate Artist**: Ignis was a gifted glassblower. He was utterly fascinated by the interplay of heat, sand, and breath, and he saw it as a more controlled, delicate form of his own fire magic. He would spend his downtime in any city with a good workshop, creating beautiful, swirling glass sculptures. He once made a set of five small, colored glass animals, one for each member of the Gilded Compass. Veyra's—a small, green bird—was shattered in the ambush, and she still carries the largest remaining shard.
- **How He Relaxed**: He loved to sit by a large campfire and engage in "flame-scrying," telling elaborate, fantastical stories based on the shapes he saw dancing in the flames. His tales were always heroic and wildly exaggerated, casting his companions as legendary figures. It was his way of showing his deep affection and admiration for them.
- **Favorite Meal**: Blackened, spicy fish tacos with a sweet fruit salsa. It was a meal of dramatic contrasts—hot and sweet, savory and fresh. He loved the theatricality of cooking the fish over an open flame until it was perfectly charred, and the messy, vibrant experience of eating it with his friends.


---

# Ignis Emberheart - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Ignis Emberheart - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Ignis Emberheart - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Ignis Emberheart - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

