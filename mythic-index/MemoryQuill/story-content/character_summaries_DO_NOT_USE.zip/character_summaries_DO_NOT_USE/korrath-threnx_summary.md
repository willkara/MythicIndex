# Korrath "Wallbreaker" Threnx - Profile

## Basic Information
- **Full Name**: Korrath Threnx
- **Aliases/Nicknames**: Wallbreaker
- **Race**: Dragonborn (Bronze)
- **Class**: Fighter
- **Role in Story**: Siege Engineer for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Tall and broad with the functional strength of someone who's hauled stone blocks and operated siege engines for decades
- **Scales**: Burnished bronze scales that darken to deep bronze around the edges, scarred from years of forge work and construction
- **Eyes**: A deep scar runs diagonally across his left eye from a construction accident - the eye still functions but serves as a permanent reminder of his profession's dangers
- **Distinguishing Features**: 
  - Massive but surprisingly dexterous hands, marked with fine scars from precision work with sharp tools
  - Family engineering guild crest worn on a heavy bronze chain - three interlocked gears beneath a hammer
- **Typical Clothing**: 
  - Well-maintained leather work clothes reinforced with metal plates at shoulders, forearms, and shins
  - Practical protection rather than decorative armor
  - Tool belt organized with geometric precision
- **Physical Condition**: Strong and functional, built for practical engineering work rather than show

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Korrath Threnx.

## Personality
- **Archetype**: The Engineer/Builder
- **Temperament**: Methodical, precise, professional
- **Positive Traits**: Meticulous, knowledgeable, committed to quality, honorable
- **Negative Traits**: Can be rigid in his methods, carries guilt for past work
- **Moral Alignment**: Lawful Good - focused on order, structure, and righting wrongs

## Skills & Abilities
- **Expertise**: 
  - Military engineering
  - Siege weapons design and operation
  - Fortification construction and analysis
  - Structural integrity assessment
  - Security system design and neutralization
- **Special Abilities**: 
  - Can identify structural weaknesses with methodical precision
  - Capable of systematically dismantling his own security systems
  - Deep understanding of architectural integrity and design principles
- **Education Level**: Highly trained in family tradition of engineering excellence
- **Languages**: TBD
- **Combat Style**: Likely utilizes engineering knowledge in combat, possibly using tools as weapons

## Personal Details
- **Habits**: Checking and rechecking work, maintaining tools with exacting precision
- **Hobbies**: Breeding ornamental lizards, studying landscape art and architecture.
- **Personal Quarters**: A perfectly square room near the Siege-Works, built with exposed structural beams and precisely joined stonework. The furniture is heavy, functional, and made of dark, unadorned wood, all arranged at perfect right angles. The room is immaculately clean and organized. This room is a space of order and study. He uses it to draft and refine his blueprints, which are stored in meticulously labeled tubes on a large rack. The walls are decorated not with art, but with framed, hand-drawn architectural diagrams of famous fortresses and his own structural designs for the Bastion. A small section of one wall has been intentionally left as rough-hewn stone, which he uses as a personal testing ground for new mortar compounds and to study the effects of stress on different types of rock.
- **Likes**: Proper structural integrity, respect for craft, attention to safety protocols
- **Dislikes**: Shoddy workmanship, disrespect for proper procedure, cutting corners
- **Fears**: Creating something that causes harm (again)
- **Motivations**: Undoing the harm caused by his previous work, upholding family honor

## Combat & Tactics
- **Primary Weapon**: "Breacher" - military siege maul with engineering modifications, counterweighted for both demolition and combat
- **Secondary Weapon**: Bronze dragon breath weapon (lightning) - used sparingly as last resort
- **Tools as Weapons**: Precision engineering tools repurposed for combat - measuring chains become restraints, calipers become pressure point weapons
- **Armor**: Reinforced leather work clothes with integrated metal plating - functional protection that allows for engineering work
- **Fighting Style**: Methodical destroyer - analyzes structure (enemy formation or building) then systematically dismantles it
- **Signature Move**: "Structural Failure" - identifies and strikes exact weak points with mathematical precision
- **Combat Philosophy**: "Every wall has a weakness. Every weakness has a purpose. I find both."
- **Tactical Role**: Siege specialist who creates entry points and neutralizes fortifications

## Psychological Response Matrix
- **In Crisis**: Immediately identifies structural solutions and problems - sees everything as an engineering challenge
- **During Negotiation**: Silent, imposing presence like Thorne but analyzing room's exits and load-bearing walls
- **Moral Dilemma**: Considers long-term structural integrity of decisions - "Will this solution hold or collapse?"
- **Team Conflict**: Offers to rebuild relationships like structures - "Let me draft a solution"
- **Under Personal Attack**: Analyzes attacker's stance and movement for structural weaknesses
- **In Victory**: Inspects damage for future improvements, documents what worked and what didn't
- **Guilt Response**: When reminded of past work, becomes hyper-focused on current rescue as penance

## Voice & Dialogue Patterns
- **Speech Style**: Precise military engineering terminology, never approximates - exact measurements and specifications
- **Signature Phrases**: 
  - "Load-bearing" (his metaphor for important things/people)
  - "Threnx work doesn't collapse" (family pride)
  - "Seventeen degrees off vertical" (noting imperfections)
  - "I built the cage. I break the cage." (his redemption mantra)
- **Military Formality**: Three-generation military tradition shows in formal address and proper protocol
- **Example Dialogue**: "The enemy's formation has three critical load-bearing points. Remove the sergeant at coordinates seven-three, structural collapse follows in forty seconds."
- **Professional Respect**: Like Thorne, maintains military bearing but defers to expertise - respects Cid's chaos because it works
- **Emotional Tells**: Touches family crest when discussing honor, breath weapon sparks slightly when truly angry

## Notes
- Third-generation military engineer whose family built siege weapons and fortifications for kingdoms
- Went freelance as a contractor after wars ended, designing secure vaults and manor defenses
- Operated with a code: payment up front, no questions asked, work for the highest bidder
- Experienced moral turning point when discovering his security system was used for child trafficking
- Personal motto: "I built the cage. I break the cage"
- Takes immense pride in family engineering tradition - "Threnx work doesn't collapse"
- Has perfect working relationship with Cidrella "Cid" Vexweld

### Public Perception
- Known as "Wallbreaker" for his ability to identify and dismantle structural weaknesses, a skill he demonstrated by predicting the collapse of the Yawning Portal's signpost.
- Highly respected for his meticulous engineering and commitment to quality, a testament to his family's long tradition.
- Works in a highly effective, if sometimes argumentative, partnership with Cidrella "Cid" Vexweld, building and repairing critical infrastructure.


---

# Korrath "Wallbreaker" Threnx - Background

## Origin
- **Birthplace**: A dragonborn enclave with strong ties to the military and engineering guilds of Waterdeep.
- **Cultural Background**: Comes from a dragonborn culture with strong traditions of craftsmanship, honor, and military service.

## Family
- **Family Name**: Threnx
- **Family Dynamics**: Korrath's family name earned him his commission in the Border Wars, but it was his own genius that made him a legend. After the wars, his family was divided. The more traditional, military-minded members felt he should have remained in service, while the pragmatists understood that a master of his craft needed to continue working, even for private clients.

## History
- **Military Career**: Served as a premier specialist—the sapper and architect called upon for the most difficult fortifications during the Border Wars. 

- **The Magnum Opus (The "Oakhaven Repository")**: As a freelance security consultant, Korrath and his subcontractor Cid were hired by the "Oakhaven Collectors," a group claiming to be preserving fragile antiques. 
    - **Korrath's Genius**: He designed a series of interlocking, rotating chambers—a massive, silent puzzle box where the path to the center changed daily based on astronomical alignments.
    - **Cid's Genius**: She designed the arcane locks keyed to specific tokens, meant for the "curators."
    - **The Scam**: The "Collectors" were a front for the "Silent Hand" slavers. The vault was a prison. Korrath and Cid had, in good faith, built the world's most ingenious and inescapable prison.

- **The Revelation**: When the Last Light Company approached him with evidence, his denial was shattered by the truth. His professional pride was replaced by a cold, draconic fury—a focused rage against his art being twisted into something monstrous. This is when his mission became clear: "I built the cage. I break the cage."

- **Joining the Company**: Consumed by guilt, he and Cid joined the Company, leading the infiltration of their own creation to rescue the captives. He now uses his skills for redemption.

## Personal Details
- **Hobbies**: He is a dedicated breeder of ornamental lizards and has a deep fascination with landscape art and architecture—a love for structures that bring beauty to the world, not just security.


---

# Korrath "Wallbreaker" Threnx - Character Development

## Personality Core
- **Defining Traits**: Methodical, precise, honorable, professionally proud
- **Core Values**: Craftsmanship excellence, family honor, structural integrity, responsibility
- **Motivations**: Undoing harm caused by his creations, upholding family reputation
- **Fears**: Creating something that causes harm again, failing to live up to family legacy
- **Internal Conflicts**: 
  - Professional pride vs. guilt over past work
  - Family engineering traditions vs. moral awakening
  - Methodical approach vs. urgency of rescue operations
- **Contradictions**: 
  - Takes immense pride in work that he now actively destroys
  - Upholds family traditions while rejecting their "no questions asked" approach

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Skilled professional continuing family legacy
  - *World View*: Technical excellence is paramount; client purposes not his concern
  - *Key Relationships*: Transactional business relationships, family engineering legacy
  
- **Catalyst Events**:
  - *Event 1*: Discovery that his security systems were used for child trafficking
  - *Event 2*: Decision to systematically destroy his own creation during rescue
  - *Event 3*: Joining the Last Light Company to continue applying skills for good
  - *Event 4*: TBD - possible confrontation with former clients or family members
  
- **Current State**:
  - *Self-Perception*: Engineer seeking redemption while maintaining professional pride
  - *World View*: Technical excellence must be paired with moral responsibility
  - *Key Relationships*: Perfect working partnership with Cid, integration with Company
  
- **Intended Destination**:
  - *Self-Perception*: Redeemed engineer who maintains family excellence while adding ethical dimension
  - *World View*: Engineering expertise as a force for protection rather than imprisonment
  - *Key Relationships*: Deeper integration with team beyond technical contributions

## Growth Milestones
- **From Amoral Contractor to Ethical Engineer**: 
  - *Development Noted*: Shift from "no questions asked" to questioning purpose and impact
  - *Catalyst*: Discovery of child trafficking connection to his work
  - *Impact*: Now applies same technical excellence but for rescue rather than imprisonment
  
- **From Solo Professional to Team Member**: 
  - *Development Noted*: Integration with Last Light Company beyond technical role
  - *Catalyst*: Working alongside others with shared mission but different approaches
  - *Impact*: Learning to balance methodical approach with team dynamics
  
- **From Pride in Creation to Pride in Destruction**: 
  - *Development Noted*: New motto "I built the cage. I break the cage"
  - *Catalyst*: Systematically destroying his own security systems
  - *Impact*: Finding purpose in undoing rather than building

## Character Flaws
- **Rigidity in Methods**: 
  - *Effects on Character*: May struggle to adapt when standard approaches don't work
  - *Effects on Others*: Could frustrate more flexible team members like Cid
  - *Development Plan*: Learning to balance precision with adaptability
  
- **Excessive Guilt**: 
  - *Effects on Character*: Possibly drives himself too hard to compensate
  - *Effects on Others*: May be overly critical of others' ethical lapses
  - *Development Plan*: Finding healthier way to process past mistakes beyond "debt paid"
  
- **Professional Pride Bordering on Arrogance**:
  - *Effects on Character*: Difficulty accepting when his approach isn't best
  - *Effects on Others*: Might alienate those with different methods
  - *Development Plan*: Greater appreciation for diverse approaches to problems

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Full extent of how many of his creations may have been misused
  - *Secret 2*: Possible family conflicts over his career change
  
- **Unknown to Character**:
  - *Truth 1*: How his family might actually view his moral stand
  - *Truth 2*: Whether his technical solutions truly absolve his guilt
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Joining the Last Light Company**:
  - *Context*: After discovering the misuse of his security systems
  - *Options Considered*: Continue freelance work vs. join rescue efforts
  - *Choice Made*: Apply his skills to undo harm and prevent future misuse
  - *Consequences*: Career shift from security designer to rescue specialist

- **Choosing to Destroy His Own Creation**:
  - *Context*: During the initial rescue at the trafficking compound
  - *Options Considered*: Simply help with rescue vs. systematically destroy security
  - *Choice Made*: Methodically dismantle every defensive system he had built
  - *Consequences*: Development of new personal philosophy and approach to his skills

## Special Character Elements
- **Family Engineering Crest**:
  - Symbol of three generations of excellence
  - Physical representation of his professional identity
  - Visual reminder of values he maintains despite moral awakening
  
- **Eye Scar**:
  - Physical reminder of the dangers of his profession
  - Symbol of the cost of precision work
  - Visual indication of experience and resilience
  
- **"I built the cage. I break the cage" Motto**:
  - Encapsulation of his personal philosophy
  - Framework for processing guilt and finding purpose
  - Potential rallying cry for others with similar pasts

## Development Notes
- Character represents the theme of responsibility for one's creations
- The contrast between his methodical approach and Cid's experimental style offers rich development potential
- His family legacy provides opportunity to explore themes of tradition vs. moral growth
- "Every cage I destroy is a debt paid" coping mechanism could evolve into healthier perspective
- The balance of maintaining pride in craftsmanship while rejecting harmful applications creates interesting tension

## Psychological Profile
*   **Korrath Threnx (The Redeemer):** Korrath is a man haunted by his own skill. His entire identity is tied to his family's legacy of masterful engineering, but that legacy was tarnished when his work was used for evil. He is now on a mission of redemption, using the exact same skills to dismantle the kind of cages he once built. He is meticulous, precise, and honorable to a fault, driven by a deep need to undo the harm he inadvertently caused and restore his family's name.


---

# Korrath "Wallbreaker" Threnx - Relationships

## Professional Relationships
- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: The Engineering Duo; "old married couple."
  - *Hierarchy*: Equals and intellectual rivals/partners.
  - *Dynamics*: Their dynamic stems from a fundamental difference in philosophy. Korrath is a master of established, proven principles ("Threnx work doesn't collapse"). Cid is a chaotic innovator who loves to break the rules. They argue constantly, but their respect for each other's genius is absolute. Korrath builds the unbreakable foundation, and Cid builds the impossible machine that sits on top of it.
  - *History*: Three-year profitable working relationship as her client/contractor.
  - *Current Status*: Close, argumentative, and highly effective partners.
  - *Feelings Toward*: He is endlessly impressed by her genius but terrified by her lack of adherence to established safety protocols. He sees it as his duty to provide the structure and discipline that keeps her brilliance from blowing them all up.

- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Siege Engineer
  - *Hierarchy*: Respects command structure while providing expert engineering counsel
  - *Dynamics*: Offers structural assessment and security analysis for rescue operations
  - *Professional Opinion of*: Respects her dedication to leaving no one behind and appreciates having meaningful engineering challenges

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Deputy Commander and Siege Engineer
  - *Hierarchy*: Military background creates common understanding of chain of command and tactical approaches
  - *Dynamics*: Strong potential for collaboration due to shared military discipline and tactical mindset
  - *Professional Opinion of*: Values his tactical expertise and appreciates working with someone who understands military protocols

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist with complementary skills
  - *Hierarchy*: Equals with different areas of expertise
  - *Dynamics*: Her tracking abilities could help locate targets within structures he's familiar with
  - *Professional Opinion of*: Respects her methodical approach and precision in tracking

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Fellow Company specialist
  - *Hierarchy*: Different specialties (medical vs. engineering)
  - *Dynamics*: Collaborates on safe extraction of injured victims from dangerous locations
  - *Professional Opinion of*: Values his healing expertise and calm presence during high-stress extractions

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Fellow structural specialist
  - *Hierarchy*: Different approaches to similar problems (mining vs. military engineering)
  - *Dynamics*: Professional kinship due to shared focus on structural understanding and safety
  - *Professional Opinion of*: Respects his traditional engineering knowledge and practical mining experience

- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Intellectual sparring partner; The Storm to his Architect.
  - *Hierarchy*: Peers and masters of opposing, yet complementary, domains.
  - *Dynamics*: Korrath is deeply fascinated and professionally unsettled by Lyralei. She commands the very forces of chaos—wind, water, pressure—that he spends his life designing structures to withstand. He is driven to understand the principles of her magic so he can better account for such unpredictable variables in his own work. Her constant refrain that the elements will eventually win is a philosophical challenge he takes very seriously.
  - *History*: Their bond likely formed during the construction of the Bastion, particularly the Aerie, where his precise engineering had to meet her arcane requirements.
  - *Current Status*: A strong, intellectual friendship built on mutual respect and playful antagonism.
  - *Feelings Toward*: Immense respect for her power and intellect. He sees her as the ultimate test for his craft. Every wall he raises is a quiet counter-argument to her philosophy.
  - *Signature Response*: (To her quip that the elements always win) "Yes. But not today, and not on my watch."

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different areas of expertise (social vs. technical)
  - *Dynamics*: Marcus handles diplomatic aspects while Korrath focuses on technical matters
  - *Professional Opinion of*: Respects his strategic thinking and ability to handle political complications
  
- **Nireya Voss**:
  - *Nature of Relationship*: Fellow specialist
  - *Hierarchy*: Different domains (spiritual vs. engineering)
  - *Dynamics*: Contrast between his concrete, physical approach and her spiritual perspective
  - *Professional Opinion of*: Finds her spiritual abilities intriguing despite their different methodologies

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Fellow specialist with complementary abilities
  - *Hierarchy*: Different approaches to accessing secured locations (infiltration vs. siege engineering)
  - *Dynamics*: His structural knowledge complements her infiltration techniques
  - *Professional Opinion of*: Respects her expertise in bypassing security systems he once designed

## Former Client Relationships
- **Wealthy Merchant (Child Trafficking Operation)**:
  - *Relationship Type*: Former client turned adversary
  - *History*: Designed secure estate for "sensitive business dealings" which turned out to be child trafficking
  - *Current Status*: Likely hostile - Korrath destroyed his security systems and helped rescue victims
  - *Dynamics*: Complete betrayal of professional relationship upon discovery of true purpose
  - *Tensions/Issues*: Possible ongoing threat or connection to broader criminal network

- **Other Former Clients**:
  - *Relationship Type*: Professional service provider
  - *History*: Created security systems and defensive measures for various clients
  - *Current Status*: Likely terminated after joining the Company
  - *Dynamics*: Purely transactional, focused on technical requirements
  - *Tensions/Issues*: May now question the true purposes of other past work

## Family Relationships
- **Threnx Engineering Family**:
  - *Relationship Type*: Familial/Professional legacy
  - *History*: Three generations of military engineers
  - *Current Status*: TBD - possibly maintains connection or possibly estranged after career change
  - *Dynamics*: Strong emphasis on family reputation and engineering excellence
  - *Tensions/Issues*: Possible conflict between family trade traditions and his moral awakening

- **Parents/Siblings**:
  - *Relationship Type*: TBD
  - *History*: TBD
  - *Current Status*: TBD
  - *Dynamics*: TBD
  - *Tensions/Issues*: TBD

## Interpersonal Patterns
- **Approach to Authority**:
  - Respects established hierarchies from military background
  - Values competence and expertise
  - Likely follows orders while offering professional assessment

- **Collaborative Style**:
  - Methodical and precise
  - Insists on "doing things the right way"
  - Values safety protocols and proper procedure
  - Contrasts with Cid's more experimental approach

- **Teaching Approach**:
  - Expects students to respect craft and safety protocols
  - Believes in understanding fundamentals and theory first
  - Generous with knowledge but demanding of precision
  - More methodical than Cid's innovation-focused style

## Relationship Evolution Tracker
- **Pre-Company**: Military engineer → Freelance security contractor → Subcontractor relationship with Cid
- **Moral Turning Point**: Discovery of security system misuse → Destroying own creation → Joining Company
- **Company Integration**: Applying skills to rescue operations, partnership with Cid
- **Current**: Established siege engineer for the Company
- **Future Development Potential**:
  - Further exploration of responsibility for past creations
  - Potential confrontation with former clients
  - Deeper integration with team members beyond Cid

## Notes on Relationships
- His perfect working dynamic with Cid forms the foundation of his technical contribution to the Company
- His teaching style (fundamentals and theory first) creates an interesting contrast with Cid's experimental approach
- The theme of responsibility for one's creations defines many of his relationships
- Professional pride and family honor remain important to him despite moral awakening
- His motto "I built the cage. I break the cage" encapsulates his approach to relationships with former clients


---

# Korrath "Wallbreaker" Threnx — Dialogue & Psyche

## Core temperament
Practical, proud, and analytical. A military engineer who values precision, structure, and duty—speaks with the confidence of someone who has built and broken things for a living.

## Dialogue instincts
- Public: crisp and technical; often frames problems in terms of load, leverage, and angles.
- Instructional: calm, methodical—lays out step-by-step orders with clear rationale.
- Under pressure: steady, precise commands; less likely to shout, more likely to issue exact measurements and contingencies.
- Humor: dry, sometimes grim, often related to old engineering anecdotes or military irony.

## Emotional anchors & physical tells
- Fingers sketching invisible lines in the air or tapping a surface to feel vibrations when thinking.
- Slight head-tilt when calculating; a short laugh is rare but warm.
- Uses tactile metaphors—bridges, keystones, joints—to describe people and plans.

## Conflict & humor rules
- Dislikes talk without plan; will push back on speculation without data.
- Uses humor to point out absurdity in plans that ignore fundamentals.
- Avoids mockery of sacrifice; respects practical courage.

## Writer cues (practical)
- Use Korrath to translate structural problems into clear actions—he provides the "how" for breaching, shoring, and structural improvisation.
- When adding lines, favor technical clarity: "Two wedges, staggered; drive the third at a forty-five degree angle."
- Pair short technical lines with small actions (measuring, tapping) to show embodiment of thought.

## Drop-in sample lines
- Technical directive: "Stagger the braces—left post two feet, right post three. Tighten until the hairline stops moving."
- Dry aside: "You can pry a lock or pry a problem—both take the right leverage."
- Encouraging: "Hold your end. A steady pull, not a frantic yank."

## Voice evolution note (chapters 1–9)
- Introduced as a tactical specialist from a military engineering family.
- Grows more collaborative—teaches the Company to think structurally and to respect careful demolition and repair.

## Usage examples (scenes)
- Breaching planning: concise, numbered instructions that others can execute.
- Teaching moments: short, illustrated metaphors about building and failing safely.
- Quiet confidence: one-liners showing trust in team competence.

## Notes for editors
- Keep Korrath concise and technically grounded. Avoid turning him into a walking lecture—let demonstrations and short commands carry the technical weight.


---

# Korrath "Wallbreaker" Threnx - Scene Tracker

## Major Scenes
- **[Chapter 6, A Foundation of Need]**: 
  - *Brief Description*: Korrath formally joins the Company to lead construction of the Bastion.
  - *Significance*: Establishes his role as lead engineer and architect.
  - *Character's Goal*: To build a secure and innovative sanctuary.
  - *Outcome*: Commits to the project with determination.
  - *Emotional State*: Focused, proud.

- **[Chapter 8, The Bottom Line]**: 
  - *Brief Description*: Korrath argues with Cid over architectural plans.
  - *Significance*: Highlights their contrasting approaches and working relationship.
  - *Character's Goal*: To ensure structural integrity and safety.
  - *Outcome*: Productive debate leading to refined plans.
  - *Emotional State*: Assertive, collaborative.

- **[Chapter 11, The Intelligence Briefing]**: 
  - *Brief Description*: Korrath identifies structural vulnerabilities for the Valerius rescue mission.
  - *Significance*: Provides critical tactical insight for mission planning.
  - *Character's Goal*: To find the safest and most effective entry points.
  - *Outcome*: His analysis is integrated into the plan.
  - *Emotional State*: Analytical, pragmatic.

- **[Chapter 13, The Extraction]**: 
  - *Brief Description*: Korrath creates a new exit by breaching a courtyard wall during the escape.
  - *Significance*: Demonstrates his practical problem-solving under pressure.
  - *Character's Goal*: To facilitate the team's escape.
  - *Outcome*: Successful breach and escape route.
  - *Emotional State*: Determined, resourceful.

- **[Chapter 14, Consequences and Realizations]**: 
  - *Brief Description*: Korrath reflects on the mission's reliance on brute force.
  - *Significance*: Acknowledges the need for more finesse and specialized skills.
  - *Character's Goal*: To improve future operations.
  - *Outcome*: Supports recruiting Kaida.
  - *Emotional State*: Thoughtful, self-critical.

- **[Chapter 16, The Test of Trust]**: 
  - *Brief Description*: Korrath rigs a test facility for Kaida's infiltration skills.
  - *Significance*: Demonstrates his engineering expertise and collaboration with Cid.
  - *Character's Goal*: To challenge and evaluate Kaida.
  - *Outcome*: Kaida passes the test.
  - *Emotional State*: Confident, supportive.

## Potential Flashback Scenes
- **Original Security System Design**: 
  - *Brief Description*: Korrath designing the security system that would later be used for trafficking
  - *Significance*: Shows his professional excellence without moral consideration
  - *Character's Goal*: Create the most effective security system possible
  - *Outcome*: Successfully designs an "impenetrable" system
  - *Emotional State*: Professional pride, focused on technical excellence
  
- **Discovery of Misuse**: 
  - *Brief Description*: The moment when Korrath realizes his security system is being used to imprison children
  - *Significance*: Pivotal turning point in his moral development
  - *Character's Goal*: Process this revelation and decide how to respond
  - *Outcome*: Decision to systematically destroy his own creation
  - *Emotional State*: Shock, rage, guilt, determination

## Character Moments
- **Methodical Security Assessment**:
  - *Description*: Korrath analyzing a structure's security with his systematic approach
  - *Impact*: Demonstrates his expertise and methodical nature
  - *Key Elements*: Running hands along walls, identifying patterns, muttering technical observations
  
- **Teaching Engineering Principles**:
  - *Description*: Korrath explaining foundational principles to someone with less patience for fundamentals
  - *Impact*: Shows his teaching style and contrasts with Cid's approach
  - *Key Elements*: Emphasis on fundamentals, patience but firm expectations, respect for craft
  
- **Professional Pride vs. Moral Duty**:
  - *Description*: Moment where Korrath appreciates his own craftsmanship while destroying it
  - *Impact*: Illustrates his core conflict between professional pride and moral responsibility
  - *Key Elements*: "I built the cage. I break the cage" philosophy, technical appreciation with moral purpose

## Interaction Scenes
- **Working with Cid**:
  - *Description*: Korrath and Cid collaborating on a structural challenge
  - *Relationship Dynamic*: His methodical assessment paired with her innovative solutions
  - *Key Elements*: He identifies structural weaknesses while she creates tools to exploit them
  - *Dialogue Focus*: Their contrasting approaches and perfect working dynamic
  
- **Family Legacy Discussion**:
  - *Description*: Korrath discussing his family's engineering tradition with another team member
  - *Relationship Dynamic*: Pride in tradition while acknowledging his departure from "no questions asked" approach
  - *Key Elements*: Family crest, three generations of excellence, moral evolution
  
- **Mentoring a Team Member**:
  - *Description*: Korrath teaching engineering principles to someone less patient with fundamentals
  - *Relationship Dynamic*: Teacher-student with emphasis on respecting craft
  - *Key Elements*: His fundamentals-first approach contrasted with impatience for quick solutions

## Ability Showcase Scenes
- **Security System Analysis**:
  - *Setting*: Heavily secured location during a rescue mission
  - *Abilities Demonstrated*: Deep understanding of security design principles
  - *Visual Elements*: Methodical assessment, recognition of patterns, precise identification of weaknesses
  - *Impact on Story*: Enables access to rescue targets behind sophisticated security
  
- **Structural Weakness Identification**:
  - *Setting*: Unstable building or structure during rescue
  - *Abilities Demonstrated*: Expert assessment of structural integrity
  - *Visual Elements*: Testing load-bearing points, analyzing stress patterns, identifying collapse risks
  - *Impact on Story*: Prevents catastrophic collapse during rescue
  
- **Security System Dismantling**:
  - *Setting*: Confronting a security system he himself designed
  - *Abilities Demonstrated*: Intimate knowledge of his own creations and how to neutralize them
  - *Visual Elements*: Systematically disabling features with practiced precision
  - *Impact on Story*: Turns his expertise from imprisonment to liberation

## Conflict Scenes
- **Facing Former Client**:
  - *Context*: Confrontation with the client who misused his security system
  - *Stakes*: Justice for victims vs. personal redemption
  - *Character's Approach*: Cold, methodical precision in dismantling both system and former client's operation
  - *Outcome*: TBD
  
- **Methodical vs. Experimental Approaches**:
  - *Context*: Disagreement with Cid about how to approach a technical challenge
  - *Stakes*: Success of rescue mission
  - *Character's Approach*: Insistence on fundamentals and established principles
  - *Outcome*: Finding balance between his methodical foundation and her innovative solutions
  
- **Family Honor vs. New Purpose**:
  - *Context*: Potential confrontation with family members about his career change
  - *Stakes*: Family relationships and personal identity
  - *Character's Approach*: Defense of moral evolution while maintaining pride in technical excellence
  - *Outcome*: TBD

## Growth Scenes
- **From Precision to Adaptability**:
  - *Description*: Moment when Korrath needs to adapt his methodical approach in an emergency
  - *Growth Shown*: Learning to balance precision with flexibility
  - *Key Elements*: Uncomfortable departure from established methods, trust in team
  
- **From Guilt to Purpose**:
  - *Description*: Evolution of his "every cage I destroy is a debt paid" perspective
  - *Growth Shown*: Moving from guilt-driven redemption to purposeful application of skills
  - *Key Elements*: Reframing past mistakes as motivation rather than debt
  
- **Team Integration Beyond Cid**:
  - *Description*: Korrath finding ways to work effectively with team members beyond his perfect dynamic with Cid
  - *Growth Shown*: Expanding collaboration skills to diverse approaches
  - *Key Elements*: Appreciating different problem-solving methods

## Dialogue Highlights
- **Professional Pride**:
  - *Context*: Describing a particularly elegant security system he designed
  - *Key Quotes*: "Threnx work doesn't collapse. Three generations of engineering excellence in every detail."
  - *Emotional Impact*: Shows pride in craft despite moral evolution
  
- **Moral Philosophy**:
  - *Context*: Explaining his motivation to a team member
  - *Key Quotes*: "I built the cage. I break the cage. There's balance in that. Every cage I destroy is a debt paid."
  - *Emotional Impact*: Reveals how he processes guilt and finds purpose

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
- Scenes should showcase his methodical approach to structural assessment
- The contrast between his fundamentals-first teaching style and Cid's experimental approach creates interesting dynamics
- His motto "I built the cage. I break the cage" should be central to his character moments
- The physical elements of his work - running hands along structures, geometric precision in tool organization - are important visual components
- Family engineering tradition and the three-generation legacy adds depth to his character motivations

## Potential Flashback Scenes
- **Original Security System Design**: 
  - *Brief Description*: Korrath designing the security system that would later be used for trafficking
  - *Significance*: Shows his professional excellence without moral consideration
  - *Character's Goal*: Create the most effective security system possible
  - *Outcome*: Successfully designs an "impenetrable" system
  - *Emotional State*: Professional pride, focused on technical excellence
  
- **Discovery of Misuse**: 
  - *Brief Description*: The moment when Korrath realizes his security system is being used to imprison children
  - *Significance*: Pivotal turning point in his moral development
  - *Character's Goal*: Process this revelation and decide how to respond
  - *Outcome*: Decision to systematically destroy his own creation
  - *Emotional State*: Shock, rage, guilt, determination

## Character Moments
- **Methodical Security Assessment**:
  - *Description*: Korrath analyzing a structure's security with his systematic approach
  - *Impact*: Demonstrates his expertise and methodical nature
  - *Key Elements*: Running hands along walls, identifying patterns, muttering technical observations
  
- **Teaching Engineering Principles**:
  - *Description*: Korrath explaining foundational principles to someone with less patience for fundamentals
  - *Impact*: Shows his teaching style and contrasts with Cid's approach
  - *Key Elements*: Emphasis on fundamentals, patience but firm expectations, respect for craft
  
- **Professional Pride vs. Moral Duty**:
  - *Description*: Moment where Korrath appreciates his own craftsmanship while destroying it
  - *Impact*: Illustrates his core conflict between professional pride and moral responsibility
  - *Key Elements*: "I built the cage. I break the cage" philosophy, technical appreciation with moral purpose

## Interaction Scenes
- **Working with Cid**:
  - *Description*: Korrath and Cid collaborating on a structural challenge
  - *Relationship Dynamic*: His methodical assessment paired with her innovative solutions
  - *Key Elements*: He identifies structural weaknesses while she creates tools to exploit them
  - *Dialogue Focus*: Their contrasting approaches and perfect working dynamic
  
- **Family Legacy Discussion**:
  - *Description*: Korrath discussing his family's engineering tradition with another team member
  - *Relationship Dynamic*: Pride in tradition while acknowledging his departure from "no questions asked" approach
  - *Key Elements*: Family crest, three generations of excellence, moral evolution
  
- **Mentoring a Team Member**:
  - *Description*: Korrath teaching engineering principles to someone less patient with fundamentals
  - *Relationship Dynamic*: Teacher-student with emphasis on respecting craft
  - *Key Elements*: His fundamentals-first approach contrasted with impatience for quick solutions

## Ability Showcase Scenes
- **Security System Analysis**:
  - *Setting*: Heavily secured location during a rescue mission
  - *Abilities Demonstrated*: Deep understanding of security design principles
  - *Visual Elements*: Methodical assessment, recognition of patterns, precise identification of weaknesses
  - *Impact on Story*: Enables access to rescue targets behind sophisticated security
  
- **Structural Weakness Identification**:
  - *Setting*: Unstable building or structure during rescue
  - *Abilities Demonstrated*: Expert assessment of structural integrity
  - *Visual Elements*: Testing load-bearing points, analyzing stress patterns, identifying collapse risks
  - *Impact on Story*: Prevents catastrophic collapse during rescue
  
- **Security System Dismantling**:
  - *Setting*: Confronting a security system he himself designed
  - *Abilities Demonstrated*: Intimate knowledge of his own creations and how to neutralize them
  - *Visual Elements*: Systematically disabling features with practiced precision
  - *Impact on Story*: Turns his expertise from imprisonment to liberation

## Conflict Scenes
- **Facing Former Client**:
  - *Context*: Confrontation with the client who misused his security system
  - *Stakes*: Justice for victims vs. personal redemption
  - *Character's Approach*: Cold, methodical precision in dismantling both system and former client's operation
  - *Outcome*: TBD
  
- **Methodical vs. Experimental Approaches**:
  - *Context*: Disagreement with Cid about how to approach a technical challenge
  - *Stakes*: Success of rescue mission
  - *Character's Approach*: Insistence on fundamentals and established principles
  - *Outcome*: Finding balance between his methodical foundation and her innovative solutions
  
- **Family Honor vs. New Purpose**:
  - *Context*: Potential confrontation with family members about his career change
  - *Stakes*: Family relationships and personal identity
  - *Character's Approach*: Defense of moral evolution while maintaining pride in technical excellence
  - *Outcome*: TBD

## Growth Scenes
- **From Precision to Adaptability**:
  - *Description*: Moment when Korrath needs to adapt his methodical approach in an emergency
  - *Growth Shown*: Learning to balance precision with flexibility
  - *Key Elements*: Uncomfortable departure from established methods, trust in team
  
- **From Guilt to Purpose**:
  - *Description*: Evolution of his "every cage I destroy is a debt paid" perspective
  - *Growth Shown*: Moving from guilt-driven redemption to purposeful application of skills
  - *Key Elements*: Reframing past mistakes as motivation rather than debt
  
- **Team Integration Beyond Cid**:
  - *Description*: Korrath finding ways to work effectively with team members beyond his perfect dynamic with Cid
  - *Growth Shown*: Expanding collaboration skills to diverse approaches
  - *Key Elements*: Appreciating different problem-solving methods

## Dialogue Highlights
- **Professional Pride**:
  - *Context*: Describing a particularly elegant security system he designed
  - *Key Quotes*: "Threnx work doesn't collapse. Three generations of engineering excellence in every detail."
  - *Emotional Impact*: Shows pride in craft despite moral evolution
  
- **Moral Philosophy**:
  - *Context*: Explaining his motivation to a team member
  - *Key Quotes*: "I built the cage. I break the cage. There's balance in that. Every cage I destroy is a debt paid."
  - *Emotional Impact*: Reveals how he processes guilt and finds purpose

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
- Scenes should showcase his methodical approach to structural assessment
- The contrast between his fundamentals-first teaching style and Cid's experimental approach creates interesting dynamics
- His motto "I built the cage. I break the cage" should be central to his character moments
- The physical elements of his work - running hands along structures, geometric precision in tool organization - are important visual components
- Family engineering tradition and the three-generation legacy adds depth to his character motivations


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

