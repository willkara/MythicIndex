# Korrath Threnx: The Architect of Redemption

Korrath's relationship with the Bastion is one of redemption and mutual respect between two master builders. His anchor is the **Siege-Works** on the **Keep Terrace**, a space of heavy engineering where the Dragonborn architect and the living stone collaborate to forge the tools of salvation, not domination. Every structure he designs is an act of penance, a testament to his vow to build things that protect, not imprison.

## The Anchor: A Forge of Atonement

### Korrath's Quarters
Adjacent to his workshop, Korrath's quarters are a space of meticulous order and quiet contemplation. The Bastion has learned to accommodate his draconic nature while also providing a space for the man wrestling with his past.

*   **Draconic Proportions**: The ceilings are high and doorways wide, but the furniture is surprisingly human-scaled.
    *   **Contradiction**: He requires the high ceilings for his own comfort, but he keeps the furniture low to the ground, a subconscious act of humility and a constant reminder to consider the scale of those he now protects.
*   **The Schematic Wall**: One entire wall is a massive, smooth slate for drafting.
    *   **Unconscious Habit**: Korrath always begins his designs with the escape routes. Before he draws a single defensive wall or load-bearing column, he maps out how people will get out safely. It is a deeply ingrained reversal of his past work, where his first consideration was how to keep people in.
*   **The Personal Space**: His living area is spartan, dominated by a single, perfectly polished scale from his own hide, resting on a pedestal.
    *   **Unexpected Detail**: The Bastion has noticed that the temperature in the room fluctuates with Korrath's emotional state, a draconic trait he cannot suppress. When he is wrestling with guilt, the air grows noticeably warmer. In response, the Bastion has learned to subtly increase the cool air circulation, a quiet, supportive gesture he has never acknowledged.

### The Siege-Works
This heavy-duty workshop is where Korrath's vision takes form. The Bastion is an active partner here, a silent apprentice and collaborator.

*   **The Yielding Stone**: The consciousness has learned to yield to Korrath's tools, parting with an ease that feels like cooperation.
    *   **Practical Detail**: Korrath's tools are a mix of state-of-the-art engineering implements and ancient, hand-forged chisels. He uses the modern tools for precision, but for the final, finishing touches on any defensive structure, he always uses the old tools, as if seeking a more personal, tactile connection to the stone he is shaping.
*   **The Structural Feedback**: Korrath can "listen" to the Bastion by placing a hand on the raw stone of the workshop.
    *   **Intended vs. Actual Use**: He uses this to understand the stone's limits, but it has also become a form of confession. The Bastion feels the weight of his regrets through these vibrations, and in return, it communicates a sense of geological patience, a silent reassurance that even the greatest pressures can be borne over time.

## Life Within the Bastion: The Guardian of Integrity

Korrath is the guardian of the Bastion's physical integrity, a role that takes him everywhere and defines his relationships.

### The Intellectual Rivalry
His most dynamic relationship is with **Cid**. Their loud debates in her **Prototyping Workshop** are legendary. He argues for safety and stability, she for innovation and chaos. Yet, in his own workshop, he keeps a small, heavily modified prototype she gave him, a device that is dangerously unstable but brilliantly conceived—a private acknowledgment of her genius that he would never admit to publicly.

### The Commander's Architect
Korrath works closely with **Veyra** and **Thorne** in the **Strategic Operations Center**. He translates their tactical needs into physical reality, his massive frame a reassuring presence over the strategy table as he demonstrates how the Bastion itself can be their greatest tactical asset.
