# Korrath Threnx: The Architect and the Stone

Korrath's relationship with the Bastion is one of redemption and mutual respect between two master builders. His anchor is the **Siege-Works** on the **Keep Terrace**, the highest and most secure level of the sanctuary. Here, in a space of heavy engineering and precise creation, the Dragonborn architect and the living stone collaborate to forge the tools of salvation.

## The Anchor: A Forge of Redemption

### Korrath's Quarters
Adjacent to his workshop, Korrath's quarters are a testament to the Bastion's ability to accommodate non-human physiology. The consciousness, recognizing his draconic heritage from his physical form and needs, has shaped a space that is both functional and comfortable for him:

*   **Draconic Proportions**: The ceilings are higher than in human-centric areas, and doorways are wider, allowing him to move without stooping.
*   **Temperature Control**: The Bastion learned early that Korrath generates more body heat and maintains his rooms at a cooler temperature with better air circulation.
*   **Reinforced Structure**: The stone floor has gradually hardened in the pathways where his greater weight creates more pressure, preventing wear while maintaining comfort for human visitors.

### The Siege-Works
This heavy-duty workshop and forge, partially built into a natural cave for ventilation, is where Korrath's vision takes form. The Bastion is not a passive structure here but an active partner in his work, a fact made clear by their collaboration:

*   **The Yielding Stone**: The consciousness has learned to yield to Korrath's tools. When he carves stone for a new defensive structure, the rock parts with an ease that feels like cooperation, not excavation.
*   **The Perfect Forge**: The Bastion manages the forge's ventilation with masterful precision, drawing smoke away and pulling in air to achieve the exact temperatures Korrath requires for his metalwork.
*   **The Structural Feedback**: Korrath can "listen" to the Bastion by placing a hand on the raw stone of the workshop. The consciousness communicates structural stresses, weaknesses, and geological opportunities through subtle vibrations, giving him an unparalleled understanding of his building materials.

## Life Within the Bastion: Shared Spaces & Relationships

While his work anchors him to the Keep, Korrath's presence and influence are felt throughout the entire structure he designed. He is the guardian of its physical integrity, a role that takes him everywhere.

### The Intellectual Rivalry
Korrath's most dynamic relationship is with **Cidrella "Cid" Vexweld**. He is a constant, looming presence in her **Prototyping Workshop**, where they engage in loud, passionate debates about engineering philosophy—his methodical safety versus her chaotic innovation. The Bastion facilitates their collaboration, even creating the "Argument Wall" in Cid's workshop to display their competing designs. Their arguments are the creative engine of the Tower of Innovation.

### The Commander's Architect
Korrath works closely with **Veyra** and **Thorne** in the **Strategic Operations Center**. He is the one who translates their tactical needs into physical reality, designing defenses and engineering solutions. He can often be found leaning over the strategy table, his large frame a reassuring presence, showing the command team how the Bastion itself can be their greatest tactical asset.

### A Quiet Respect
Though they rarely speak at length, Korrath shares a deep, unspoken respect with **Grimjaw**. He often seeks out the old dwarf in the **Great Courtyard** to discuss the quality of the stone or the integrity of a new support structure. They are two masters of the earth, and the Bastion seems to hum with satisfaction when they are together, as if its oldest and newest stewards are in accord.
