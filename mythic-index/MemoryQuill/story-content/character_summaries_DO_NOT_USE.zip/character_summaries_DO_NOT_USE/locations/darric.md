# Corporal Darric: The Unyielding Anchor

Corporal Darric's relationship with the Bastion is one of straightforward, mutual respect. She is the Company's anchor, and her quarters are a reflection of that role: solid, dependable, and more complex than they appear on the surface. The Bastion, after a brief and amusing misunderstanding about dwarves wanting to live in caves, has learned to appreciate her unique blend of clan tradition and city pragmatism, creating a space that is both a military billet and a private sanctuary.

## The Anchor: The Balanced Quarters

Darric's room is a perfect synthesis of military efficiency and dwarven comfort, with hidden graces that speak to the woman behind the armor.

*   **The Inspection Wall**: An armor and weapon maintenance station that would make any quartermaster proud.
    *   **Practical Detail**: The wall isn't just for storage; it's a diagnostic tool. The Bastion has learned to create minute, almost imperceptible color shifts in the stone behind the gear. A slightly darker patch behind a leather strap indicates it needs oiling; a cooler spot on the wall reveals a hidden stress fracture in a piece of plate.
*   **The Correspondence Corner**: A solid stone desk positioned to catch the morning light.
    *   **Unconscious Habit**: Darric keeps two stacks of letters: official Company business and mail from her family. She unconsciously arranges them so that the family letters are always physically on top, a small, daily act of prioritizing what truly matters.
*   **The View Nook**: A defensive window placement that offers an optimal sunset view.
    *   **Contradiction**: She claims the nook is for "checking perimeters," a story no one believes. The Bastion maintains the illusion, but has subtly widened the ledge and angled it for perfect comfort, creating a space where the gruff corporal can indulge in a moment of quiet beauty.
*   **The Practice Space**: A section of floor that appears randomly stone-strewn but provides perfect angles for her secret stone-skipping hobby.
    *   **Unexpected Detail**: The Bastion has learned this is not just a hobby, but a form of divination for her. The way the stones bounce and settle helps her process complex tactical problems. The consciousness, in a gesture of quiet partnership, sometimes arranges the stones in patterns that subtly suggest solutions to the very problems she's pondering.
*   **The Family Wall**: A wall with subtle indentations for family mementos.
    *   **Intended vs. Actual Use**: She intended this as a small, private display. It has become an unofficial shrine for any dwarf who passes through the Bastion. Visitors and new recruits have taken to leaving their own small clan tokens on the wall, a practice Darric publicly grumbles about but privately cherishes. The Bastion ensures every new addition finds a perfect, secure spot.

## The Training Grounds: The Master's Domain

Darric's influence extends far beyond her quarters. The training grounds and armory are where her steadfast nature shapes the entire Company.

### The Formation Platform
The Bastion created a raised platform for Darric to drill defensive formations. It can simulate different terrains, but its most important feature is its memory. The stone retains faint, glowing outlines of the most effective shield wall formations, a ghostly tactical guide for new recruits that only appears when Darric is instructing.

### The Armory Annex
Her unofficial quartermaster's office is a model of efficiency. The Bastion has learned her exacting standards, but it has also learned her sentimentality. The proudly dented shin-guard she wore in her first real battle is displayed here. The Bastion could repair it, but instead, it has reinforced the metal around the dent, preserving the badge of honor while ensuring its integrity—a perfect metaphor for their relationship.

## The Unspoken Understanding

The relationship between Darric and the Bastion is built on mutual respect and practical cooperation. The sanctuary has learned that for someone who bridges the traditional and the modern, the military and the familial, the gruff and the graceful, stability is the greatest gift it can provide. Her room is a constant, a foundation as steady and reliable as the dwarf who inhabits it, a space that proves that the deepest care is sometimes shown not through grand gestures, but through a thousand small, unspoken perfections.
