# Archer Venn: The Exile in the Stone

Archer Venn's relationship with the Bastion is a long, patient siege. She wages a war of sarcastic deflection and self-imposed discomfort against a sanctuary that insists on offering a home to someone who believes she doesn't deserve one. Her quarters are not a living space but a fortress of emotional exile, a place where the Bastion has learned that the greatest care it can offer is to respect her defenses while gently probing for cracks.

## The Anchor: A Fortress of Controlled Chaos

When Venn arrived, she chose the smallest, most isolated room available—a storage closet she could barricade herself inside. The Bastion, recognizing her elven heritage, tried to offer light and air; Venn responded by hanging thick cloth over the windows. The sanctuary learned its first lesson: this elf was rejecting not comfort, but her own nature.

### Current State: A Negotiated Truce
Her quarters have evolved into a space of constant, low-level stimulation, a carefully managed chaos designed to keep memory at bay.

*   **The Arrow Wall**: A wall of seemingly random holes and protrusions for her gear.
    *   **Unconscious Habit**: Venn spends hours reorganizing the wall, not for efficiency, but as a form of meditation. She doesn't realize that her arrangements always create subtle spiral patterns, an echo of the forest she was exiled from, a home she recreates without conscious thought.
*   **The Gambling Corner**: A space with perfect acoustics for dice rolls.
    *   **Contradiction**: She calls it her "honest corner," a place of pure chance, yet she unconsciously presses her thumb against one specific die before a crucial roll—the same nervous habit she had when lying to her former mentor. It's a space of chance where she cannot escape her own history.
*   **The Shooting Gallery**: A narrow, impossible corridor for archery practice.
    *   **Intended vs. Actual Use**: She claims it's for practice, but it's truly for catharsis. The targets she visualizes are not enemies, but faces from her past. The Bastion, sensing this, ensures the far wall absorbs not just the arrows, but the sound of her pained whispers that follow each shot.
*   **The Non-Bed**: A deliberately uncomfortable sleeping mat on a stone slab.
    *   **Practical Detail**: The mat is frayed and worn, but the stone beneath it is perfectly smooth. Venn has, without noticing, polished the stone with her restless movements, creating a space of comfort in the heart of her self-imposed penance.
*   **The Tarnished Clasp**: A silver clasp, her only memento, hangs in a small depression in the wall.
    *   **Unexpected Detail**: The Bastion has learned the clasp is a focus for her shame. After nights when her guilt is heaviest, she will wake to find the clasp has been turned to face the wall, as if the Bastion itself is giving her a brief respite from its judgment.

## The Practice Grounds: A Claimed Territory

The outdoor archery range has become Venn's unofficial domain. Here, her relationship with the Bastion is less adversarial and more like that of a demanding student and a patient master.

*   **Wind Patterns**: The Bastion creates complex air currents to challenge her. She believes it's random; the Bastion is actually recreating the specific wind conditions of the forest where she failed her final trial, giving her a thousand chances to correct a single mistake.
*   **The Target Walls**: The walls regenerate overnight but maintain the scars of her best shots.
    *   **Rejected Comfort**: She scoffs at this as the Bastion being "lazy," but she has never chosen to practice on a perfectly pristine section of the wall. She is, without admitting it, proud of the record of her own improvement.

## The Unspoken Understanding

The Bastion is playing a very long game with Venn. It provides healing at a rate so slow she can't recognize it as care. The temperature variations in her room are less extreme now, the dice sometimes roll in ways that make her laugh, and the mat on her slab is a fraction of an inch thicker than it was a year ago. Each improvement is small enough to be deniable.

Venn, for her part, has stopped actively fighting. She still makes sarcastic comments to the walls, but now she sometimes pauses, as if waiting for the stone's silent, witty reply. She would never admit it, but in a fortress of stone that expects nothing from her, she has found a place where she can almost stand to be herself.
