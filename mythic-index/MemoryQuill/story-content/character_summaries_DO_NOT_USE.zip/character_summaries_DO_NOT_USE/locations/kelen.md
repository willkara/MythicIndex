# Sergeant Kelen: The Guardian of the Walls

Sergeant Kelen's relationship with the Bastion is one of mutual guardianship. He is the unwavering protector of its inhabitants, and it is the silent, steady witness to his unending watch. His quarters are not a home but a post, a space defined by military precision and tactical advantage. Yet, in the quiet moments between patrols and duty rosters, the space reveals a man processing profound loss by creating unshakable order.

## The Anchor: The Watch Post

Kelen chose his modest, ground-floor room for its strategic position, and the Bastion has learned to honor his purpose, enhancing its function as a watch post while subtly offering a comfort he would never ask for.

*   **The Ordered Space**: Everything has its place, maintained with absolute precision.
    *   **Unconscious Habit**: Kelen's gear is not merely stored; it is laid out in the exact same formation every single night, a ritual of readiness that is also a silent prayer for the safety of those he protects. The Bastion has learned this pattern and now the shelves themselves have faint, almost invisible grooves where each piece of equipment belongs.
*   **The Memory Corner**: A small shelf holding his few personal items.
    *   **Contradiction**: He keeps his late wife Elspeth's letters bundled with military precision, tied with a perfectly knotted cord. Yet, the ink on the top letter is slightly smeared, a testament to the single tear he allows himself to shed each time he reads them.
*   **The Carving Station**: A small workspace where he carves wooden figures.
    *   **Intended vs. Actual Use**: He tells people he carves soldiers to use on the strategy map. In reality, he carves figures of his daughter, Anya, at different ages, a silent way of watching her grow up from afar. The Bastion, sensing the preciousness of these carvings, ensures the wood it provides is always free of knots and imperfections.
*   **The Letters Desk**: A simple, functional desk where he writes to his daughter.
    *   **Practical Detail**: The desk has a single, deep drawer. Inside, hidden beneath official Company forms, is every letter Anya has ever sent him, arranged chronologically. He reads one every night before his final patrol, a private ritual of connection before he resumes his watch.

## The Perimeter Path: The Living Patrol Route

Kelen walks the Bastion's perimeter every morning and evening. This is not just a security check; it is his form of meditation, a way of reaffirming his purpose.

*   **The Circuit**: The path is worn with his footsteps, a physical manifestation of his dedication.
    *   **Unexpected Detail**: The Bastion has learned the rhythm of his grief. On the anniversary of his wife's passing, the stones along his patrol route will subtly warm to his touch, a silent gesture of companionship from one ancient guardian to another. He has never spoken of it, but he has come to expect the warmth, a quiet comfort on his hardest day.
*   **The Conversation Spots**: Places where Kelen speaks to the sanctuary, thinking he's alone. The Bastion has learned to respond with a gentle breeze or a beam of sunlight, a silent dialogue between two protectors.

## The Unspoken Understanding

The bond between Kelen and the Bastion is built on a mutual recognition of duty as a form of love. The sanctuary respects his need for emotional distance, showing its care not through overt gestures, but through the quiet, unwavering support of his watch. It ensures the walls are strong, the sightlines are clear, and the ground is steady beneath his feet, providing a foundation of reliability for the man who serves as the foundation for so many others.
