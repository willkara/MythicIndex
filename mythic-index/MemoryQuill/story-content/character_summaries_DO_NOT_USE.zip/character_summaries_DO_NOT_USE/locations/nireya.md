# Nireya Voss: The Oracle and the Stone

Nireya's relationship with the Bastion is its most profound and spiritually complex. She is not merely an inhabitant but a kindred spirit—a guardian of a sacred threshold, just as the Bastion is. Her anchor is the **Liminal Chamber** on the **Sanctuary Terrace**, the final and most sacred space in the integrated **Healing Suite**, a corner of the Bastion where the veil between worlds touches stone.

## The Anchor: A Threshold Made Manifest

### Nireya's Quarters - "The Living Threshold"
Nireya was not assigned her quarters; she was drawn to them. The Bastion, recognizing her as a living embodiment of the boundary between life and death, has learned to accommodate her dual nature. Her room is a space that exists in multiple states simultaneously.

*   **The Division Line**: A line of black sand, enhanced by the Bastion with microscopic crystals, divides the room's reality.
    *   **Practical Detail**: The sand isn't merely symbolic; it acts as a spiritual filter, absorbing stray emotional residue and preventing the energies of the two sides from bleeding into one another. Nireya meticulously smooths it every morning, a ritual of resetting the balance.
*   **The Day Side**: Her anchor to the living world.
    *   **Contradiction**: For a woman so intimate with death, this side of her room is fiercely alive. It is crowded with small, thriving succulents, and the walls are covered in charcoal sketches of the faces of people she has *saved*, not lost.
*   **The Night Side**: Where she communicates with the dead.
    *   **Intended vs. Actual Use**: While this space is for communing, she also uses its strange, phased reality for storage. Important or dangerous spiritual artifacts are left here, where they are "less real" and harder for those on either side of the veil to sense or steal.
*   **The Sleep Line**: Her sleeping mat rests directly on the sand line.
    *   **Unconscious Habit**: When troubled, Nireya traces complex, spiraling patterns in the sand with her foot as she sits on her mat. She doesn't realize these patterns are ancient runes of binding and protection, an instinctual warding against the things she fears.

### The Healing Suite: The Final Step
Nireya's Liminal Chamber is the culmination of the patient's journey in the Healing Suite, a space for wounds that medicine and counseling cannot reach.

*   **The Liminal Chamber**: A natural, sound-dampening cave.
    *   **Unexpected Detail**: The Bastion has learned to assist in her rituals. When Nireya successfully guides a particularly troubled spirit, a single, tiny quartz crystal, perfectly clear, will materialize on the chamber floor. Nireya has been collecting these "Tears of the Stone" in a small bowl, believing them to be gifts of gratitude from the Bastion itself.

## Life Within the Bastion: Guardian of the Veil

Nireya's presence brings a spiritual gravity to the entire sanctuary. She is a constant reminder of the unseen world and the responsibilities the living have to the dead.

### The Oracle of the Hall
Nireya is a key interpreter of the Bastion's cryptic warnings in the **Hall of Remembrance**. She works with Vera and Thorne to decipher the messages, providing the crucial context that turns the Bastion's symbolic art into actionable intelligence.

### The Integrated Healer
Nireya is the spiritual capstone of the Healing Triad. She provides the final, crucial step for patients whose trauma extends beyond the physical and mental realms. In the **Difficult News Alcove**, her presence offers a strange comfort, a promise that even in the worst outcomes, there is a path forward. In the **Quiet Room**, her collaboration with Aldwin and Halden is a seamless ritual of transition, ensuring that every soul, whether it remains or departs, is treated with profound honor and respect.
