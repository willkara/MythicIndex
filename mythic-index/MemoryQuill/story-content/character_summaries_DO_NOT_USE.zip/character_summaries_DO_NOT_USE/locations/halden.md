# Medic Halden: The Gardener of Atonement

Halden's relationship with the Bastion is a quiet, therapeutic one, built on the shared understanding of carrying a heavy burden. His anchor is not a single room but a small ecosystem of healing and penance on the **Sanctuary Terrace**, forming the entry point to the integrated **Healing Suite**. Here, his guilt-haunted service finds a purpose, and the Bastion provides a space for his slow, methodical journey toward self-forgiveness.

## The Anchor: A Botanical Sanctuary

### Halden's Quarters & Treatment Room
Halden's personal and professional spaces are almost indistinguishable, a blend of monastic cell, apothecary, and practical treatment center. He chose an isolated chamber with an exterior balcony, a space the Bastion has since helped him transform.

*   **The Living Apothecary**: Every surface is covered in plants, creating a space that feels more like a greenhouse than a medical facility.
    *   **Contradiction**: For a man obsessed with preventing mistakes, his workspace is a chaotic jungle. Yet he knows the precise location of every leaf and root. The Bastion has learned his "system," which is based not on order, but on the frequency of his whispered confessions to each plant.
*   **The Anatomical Gallery**: Medical charts line the walls, preserved by the Bastion.
    *   **Intended vs. Actual Use**: These are not just references. Halden uses them as a focus for his guilt, tracing the pathways of the circulatory system as if trying to pinpoint the exact moment his own path went wrong.
*   **The Guilt Shrine**: A corner dedicated to a single anatomical drawing of a heart, surrounded by beautiful but medicinally useless flowers.
    *   **Unexpected Detail**: The Bastion has learned the significance of this memorial. On the anniversary of his past failure, it coaxes a single, perfect, tear-like drop of dew to form on the drawing, a shared moment of remembrance that Halden has never acknowledged but has come to expect.
*   **The Minimal Living Space**: His actual living area is spartan.
    *   **Practical Detail**: The simple wooden bed is scarred with hundreds of tiny tally marks near the headboard, an unconscious, physical record of sleepless nights spent wrestling with his conscience.

### The Healing Suite: The First Step
Halden's treatment room is the first stage in the patient's journey through the Healing Suite. It is a space of stark, practical medicine.

*   **The Treatment Room**: Clean, simple, and efficient.
    *   **Unconscious Habit**: Halden arranges his surgical tools in a perfect, gleaming row before every procedure, but always places the scalpel a fraction of an inch out of alignment—a small, constant penance for a past mistake with a blade.
*   **The Recovery Garden**: A small courtyard that connects his space to Aldwin's.
    *   **The Bridge**: This garden is the crucial transition from physical to mental healing. Halden often brings patients here, speaking to them not as a medic, but as a fellow gardener, using the quiet language of plants to begin the process of emotional recovery before handing them off to Aldwin.

## Life Within the Bastion: A Quiet Service

Halden's life is one of self-imposed isolation, but the Bastion and his fellow healers ensure he remains connected.

### The Burden Bearers
Both Halden and the Bastion understand what it means to carry responsibility for harm. The sanctuary has witnessed centuries of violence; Halden carries the weight of one death that defines him. This shared understanding forms the foundation of their silent, therapeutic relationship.

### The Integrated Healer
Halden's pragmatism is the essential anchor for the Healing Triad. He handles the raw, physical reality of trauma, creating the stability necessary for Aldwin's gentle counseling and Nireya's spiritual work to be effective. He often defers to their expertise in the **Difficult News Alcove**, his silence a respectful acknowledgment of the wounds he cannot heal with herbs and sutures alone. The Bastion, recognizing his need for solitude but also his need for connection, often creates practical reasons for him to collaborate with his fellow healers, ensuring his atonement does not become complete isolation.
