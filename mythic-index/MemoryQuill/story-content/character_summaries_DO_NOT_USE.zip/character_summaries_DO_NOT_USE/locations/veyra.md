# Veyra Thornwake: The Commander and the Stone

Veyra's relationship with the Bastion is one of shared, sacred purpose. She is the will of the Company, and the Bastion is her fortress of hope. This duality is reflected in her two anchors: the **Command Stratum**, a subterranean office where she wages her war of logistics and remembrance, and the **Watcher's Perch**, a high corner room where she attempts to find a peace that her vigilance rarely allows.

## The Office: The Command Stratum

Located in a circular, windowless room at the base of the Keep, the Stratum is the physical embodiment of Veyra's eternal watch. Others saw it as a bunker; she recognized it as a sanctum for her burden. The Bastion, sensing a purpose that resonated with its own, has transformed it into a space of active, silent partnership.

*   **The Map Wall**: A massive, curved wall of interconnected maps that has become a living document. The Bastion preserves every mark and thread Veyra adds.
    *   **Unconscious Habit**: Veyra never sits at the large stone desk provided. A smooth, worn path circles the room's center, a testament to her constant pacing. The path is slightly deeper in front of the wall displaying failed missions, a place she unconsciously pauses longer during her circuits.
*   **The Thread System**: Red threads for active missions, black for failures, gold for successes. The Bastion has learned to make these threads resonate with faint vibrations—urgency for the red, a deep sorrow for the black, a quiet warmth for the gold—a tactile form of intelligence only Veyra can read.
*   **Practical Details**: The room is littered with half-drunk cups of tea, all abandoned at the same level of consumption. The Bastion keeps them from molding, a silent testament to a commander who intends to rest but is always pulled away by duty.

## Personal Quarters: The Watcher's Perch

For her personal space, Veyra chose a corner room higher in the Keep, a location selected for its tactical sightlines but which she has reluctantly begun to use for contemplation.

*   **The Dual View**: One window offers a commanding view of the Great Courtyard, allowing her to watch training drills. The other looks out onto the raw, unconquered face of the mountain.
    *   **Contradiction**: She tells herself the courtyard view is for tactical oversight, but she finds her gaze drawn more often to the mountain, seeking a stillness she can't find within herself. The sounds of drills from below have, without her notice, begun to regulate her breathing, calming her when she's agitated.
*   **The Sleepless Watch**: Her simple cot is positioned to face the mountain, an unconscious desire for peace. Yet every morning, she wakes having turned in her sleep to face the door, her body refusing to ever fully stand down from its watch.
*   **Unexpected Detail**: The Bastion, sensing her private grief, has begun a slow, meticulous work. On the mountain-facing wall, it has subtly carved the names of every Company member lost under her command. The carvings are almost invisible, appearing only for a few moments when the dawn light strikes the stone at a precise angle. Veyra has not consciously noticed this yet, but she has started waking earlier, drawn to the sunrise without knowing why.

## Life Within the Bastion: A Divided Existence

Veyra's life is a constant transit between her two anchors, between the burden of command and the search for solace.

### The Commander's Presence
Her most critical relationship is with her deputy, **Thorne**. She brings moral purpose to his tactical planning in the **Ops Center**, and he brings pragmatic reality to her idealistic vision. The Bastion facilitates their synergy, ensuring the path between her Stratum and his strategy table is always clear.

### The Weight of Remembrance
Veyra is a frequent visitor to the **Hall of Remembrance**. She stands before the Palimpsest Wall, not to interpret its warnings—she leaves that to her specialists—but to bear witness. The Bastion senses her grief and respect, and the Hall is always quiet and still for her, the humming crystals softening their tone.

### The Fireside Leader
Though her duties often keep her in the Keep, Veyra makes a point to join the gatherings in the **Great Courtyard**. When she sits by **Grimjaw's** fire, the Bastion seems to draw the community closer. The firelight softens the hard lines on her face, and the living stone creates a pocket of warmth and peace around their commander, offering a brief respite from her eternal watch.
