# Sarge: The Unyielding Foundation

Sarge's relationship with the Bastion is one of mutual, unspoken respect for order, discipline, and the unglamorous work of maintaining readiness. His anchor is the **Armoury & Ready Room**, a space he keeps with military precision, a reflection of his own steadfast nature.

## The Anchor: The Barracks Cell & The Armoury

### Sarge's Quarters - "The Barracks Cell"
A small, meticulously organized room on the `Establishment Terrace`, near the `Armoury & Ready Room`. It's spartan, functional, and smells faintly of gun oil and old leather. The Bastion, recognizing his long service and no-nonsense attitude, ensures his bed is always perfectly made (even if he just throws his blanket on it), and his few personal effects (a worn deck of cards, a faded photograph of his old unit) are always dust-free.
*   **The Inspection Light**: The light in his room is always crisp and bright, with no soft ambiance, suitable for inspection. The Bastion ensures no shadows obscure any corner, a subtle nod to his vigilance.
*   **The Silent Alarm**: The stone floor near his bed subtly vibrates with a specific pattern if there's an unscheduled movement in the Armoury, a silent alarm only he seems to notice.
*   **The Unseen Valet**: His uniform and gear are always laid out perfectly, and his boots are mysteriously polished overnight. Sarge pretends it's his own meticulousness, but the Company knows better.

### Sarge's Workshop/Area - The Armoury & Ready Room
This is Sarge's true domain, a place of constant activity and meticulous organization.
*   **The Self-Sharpening Rack**: The Bastion ensures all weapons on the racks are always perfectly sharp and oiled, subtly honing blades and maintaining mechanisms overnight. Sarge attributes it to "good maintenance," but the Company knows better.
*   **The Echoing Drill Ground**: The acoustics in the Ready Room are perfect for his booming commands during drills, with the Bastion subtly amplifying his voice to ensure every recruit hears him clearly.
*   **The Quartermaster's Nook**: A small, unofficial "office" carved out of a supply closet where he keeps track of requisitions and personnel records. The Bastion keeps this space perfectly temperature-controlled for preserving old paper and ensures a fresh quill and ink are always present.

## Life Within the Bastion: Shared Spaces & Relationships

Sarge's presence is a pillar of the Bastion's daily discipline, his influence felt most strongly in the more structured areas of the sanctuary.
*   **With Thorne**: They share a deep, professional respect. Sarge often consults Thorne on tactical deployments, and Thorne relies on Sarge for the readiness of the rank-and-file. The Bastion ensures their discussions in the Armoury are never overheard.
*   **With Darric**: Sarge and Darric often spar in the **Great Courtyard** training grounds. The Bastion subtly adjusts the terrain to challenge them, creating temporary obstacles or uneven ground, enjoying their disciplined combat.
*   **With New Recruits**: Sarge is the first point of contact for new Company members regarding equipment and discipline. The Bastion observes these interactions, learning the needs of newcomers through Sarge's exacting standards.
