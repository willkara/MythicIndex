# The Healing Triad: Body, Mind, and Spirit

The healing practices within the Bastion are not confined to a single room or practitioner. They are a holistic process guided by the complementary philosophies of Medic Halden, Brother Aldwin, and Nireya Voss. Their workspaces on the **Sanctuary Terrace** are interconnected, forming a **Healing Suite** that allows patients to move through a continuum of care, from the mending of flesh to the soothing of the soul. The Bastion has learned to facilitate this triage, subtly guiding patients and healers alike through a physical space that mirrors the journey from trauma to recovery.

## The Patient's Journey: A Continuum of Care

The suite is designed not as a series of separate offices, but as a flowing space where the boundaries between different modes of healing are permeable.

### 1. The Body: Halden's Practical Triage
Patients first enter **Halden's Treatment Room**, a space of clean surfaces, good light, and practical, non-magical medicine. It is here that the immediate physical trauma is addressed.
*   **Atmosphere**: The room is deliberately neutral, almost sterile. The Bastion maintains this by circulating clean, dry air and providing bright, steady light. This reflects Halden's focus on the tangible, mechanical aspects of healing.
*   **The Transition**: Once a patient is physically stabilized, the path of recovery leads them towards a small, shared courtyard garden.

### 2. The Mind: Aldwin's Tea Sanctuary & The Recovery Garden
The **Recovery Garden** serves as the bridge between Halden's and Aldwin's domains. Here, amidst medicinal plants, patients can begin to process their experiences. This space leads into **Aldwin's Tea Sanctuary**, a warm, circular room where mental and emotional healing begins.
*   **Atmosphere**: The Bastion fills this space with the gentle sound of trickling water and the scent of calming herbs. The light is warmer, the stone benches are smoother, and the air is slightly more humid.
*   **The Process**: Aldwin's tea ceremonies are a form of gentle counseling. He doesn't pry; he creates a space of peace where patients can talk if they choose. The Bastion has learned to assist, subtly warming a cup when a hand trembles, or deepening the shadows in a corner for privacy.

### 3. The Spirit: Nireya's Threshold
For those whose trauma is not merely physical or emotional, the path continues to **Nireya's Liminal Chamber**. This is not a standard part of every recovery, but a necessary final step for those touched by death, corruption, or profound loss.
*   **Atmosphere**: The transition is marked by a palpable drop in temperature and a deepening of silence. The Bastion actively thins the veil here, but also reinforces the spiritual integrity of the surrounding stone, creating a contained, safe space for Nireya's work.
*   **The Ritual**: Nireya's role is to guide the spirit back to a state of wholeness—severing unhealthy connections to the deceased, cleansing spiritual taints, or helping a soul complete its journey if recovery is not possible.

## The Overlap Zones: Collaborative Healing

The true strength of the triad lies in the spaces where their practices intersect.

*   **The Difficult News Alcove**: A small, acoustically isolated chamber off the main corridor. The Bastion has learned that this is where the three healers often meet with a patient or their family to deliver grave news. The stone here seems to absorb sound and sorrow, and a single, soft crystal provides a gentle, non-judgmental light. It is a space designed for shared burdens.
*   **The Consultation Garden**: While technically part of Aldwin's domain, all three healers use the garden for informal consultations. Halden finds patients open up more with their hands in the earth, Aldwin uses the plants as metaphors in his counseling, and Nireya can read the spiritual health of a person by the way the plants react to their presence.
*   **The Quiet Room**: Originally Aldwin's space for "gentle passage," this room has become a place of profound collaboration. When a soul is preparing to depart, Aldwin eases the body's pain, Halden provides practical comfort and ensures the process is without struggle, and Nireya stands ready to guide the spirit across the threshold. The Bastion facilitates this, blending the physical and spiritual into a single, peaceful act of transition.

Through this integrated approach, the Bastion has learned that true healing is a complex, multi-faceted process. It is not enough to set a bone or stitch a wound. The mind must be calmed, and the spirit must be settled. The Healing Suite is the architectural embodiment of this profound understanding, a physical journey that mirrors the path to becoming whole again.
