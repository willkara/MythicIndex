# Finn: The Fleet-Footed Whisper

Finn's relationship with the Bastion is one of playful exploration and quiet trust. He sees the sanctuary not just as a home, but as a vast, living playground of shortcuts and hidden paths. His anchor isn't a single room, but the entire network of passages that he traverses with boundless energy.

## The Anchor: The Waystation & The Bastion's Veins

### Finn's Quarters - "The Waystation"
A small, somewhat chaotic room on the `Establishment Terrace`, perhaps near Vera's Intelligence Center. It's filled with half-packed bags, maps with hastily scrawled notes, and a collection of small, found objects (a shiny pebble, a bird's feather, a strangely shaped piece of crystal).
*   **The Invisible Tidier**: The Bastion treats Finn with a gentle, almost parental patience, subtly tidying his space when he's gone, ensuring his bed is comfortable despite his tendency to sleep anywhere, and making sure his water skin is always full.
*   **The Scouting Window**: The window in his room offers a view of the main approach, a subtle encouragement for his scouting duties. The Bastion sometimes highlights distant movements with a flicker of light, alerting him to arrivals.
*   **The Map Wall**: One wall is covered in his own hastily drawn maps of the surrounding territory, which the Bastion subtly corrects or updates with new details (e.g., a new game trail, a recently collapsed rockslide) by making the stone shift or change color.

### Finn's Workshop/Area - The Bastion's Veins
Finn is constantly on the move, so his "workshop" is the entire network of passages and external routes. He's often found in `Vera's Intelligence Center` receiving assignments or in the `Great Courtyard` practicing his agility.
*   **The Guided Path**: The Bastion might subtly guide him to new, unexplored passages, or create small, temporary perches for him to rest on during his runs. It sometimes makes certain sections of floor slightly springier to aid his speed.
*   **The Whispering Walls**: When Finn is carrying an urgent message, the Bastion might subtly amplify the sound of his footsteps in empty corridors, creating a sense of urgency for anyone who hears him approaching.
*   **The Secret Stash Points**: Small, hidden nooks appear along his most frequented routes, containing emergency rations or a fresh water source, appearing just when he needs them most.

## Life Within the Bastion: Shared Spaces & Relationships

Finn's energy is a constant, positive presence throughout the Bastion, a reminder of the youthful vitality the sanctuary protects.
*   **With Vera**: Finn is Vera's primary human messenger. He often brings her reports from outside, and she trusts his instincts implicitly. The Bastion ensures their meetings in `Vera's Intelligence Center` are always private and efficient.
*   **With Kaida**: Kaida finds Finn's natural agility and intuitive understanding of the Bastion's hidden paths fascinating. She sometimes "tests" him by setting up small challenges, which he usually passes with a grin. The Bastion seems to enjoy these games, subtly assisting both of them.
*   **With Grimjaw**: Grimjaw often offers Finn a hearty meal and a place by the fire in the **Great Courtyard**, recognizing the young scout's tireless efforts. He'll often tell Finn, "You move like the wind, lad, but even the wind needs to rest."
