# Lyralei Stormcaller: The Weaver and the Stone

Lyralei's relationship with the Bastion is a unique academic and atmospheric partnership. Her anchor is the **Aerie** at the pinnacle of the **Tower of Innovation**, a space that is less a room and more a living weather station. Here, the ancient stone consciousness and the brilliant, storm-touched elf collaborate on a constant study of the chaotic forces that shape their world, and the chaotic forces within Lyralei herself.

## The Anchor: An Observatory of Storms

### Lyralei's Quarters - "The Atmospheric Laboratory"
Lyralei chose the highest, most exposed chamber in the Bastion, seeing its collapsed dome not as damage but as an opportunity for unfiltered data. The Bastion, after initial attempts to shield her, has learned to become her research partner.

*   **The Dome Observatory**: A masterwork of selective permeability, creating "atmospheric membranes" that admit specific weather phenomena.
    *   **Practical Detail**: The floor beneath the dome is a complex mosaic of inlaid silver runes, designed by Lyralei to channel and measure the arcane energy of the storms she invites inside. The Bastion keeps the silver perpetually clean and conductive.
*   **The Dimensional Stability Zone**: The center of her room maintains slightly different physical laws to accommodate her phoenix familiar, Quill.
    *   **Contradiction**: For a scientist obsessed with precise measurement, the epicenter of her own room is a place where the laws of physics are actively blurred. This doesn't bother her in the slightest, a testament to her ability to accept paradoxes that would frustrate more rigid minds.
*   **The Living Library**: Her chaotic towers of books are subtly organized by the Bastion.
    *   **Unconscious Habit**: Lyralei leaves books open to pages she finds particularly interesting. The Bastion has learned that this is not forgetfulness; it is her way of creating a three-dimensional mind map. It will subtly adjust the lighting on specific passages it senses are relevant to her current research, a silent collaboration of scholarship.

### The Aerie
Above her quarters lies the Aerie proper, an open observatory where her partnership with the Bastion is most profound.

*   **The Open Observatory**: Open to the sky but protected by the Bastion's atmospheric membranes.
    *   **Intended vs. Actual Use**: The Aerie is for research, but it has also become her place of emotional release. During intense storms, she will stand in the protected heart of the chaos, her hair whipping in the contained winds, shouting complex meteorological equations at the raging sky—the only way she knows how to express the turbulence within her own soul.
*   **The Phoenix Roost**: A specific perch for Quill.
    *   **Unexpected Detail**: The Bastion has learned that Quill's dimensional phasing is tied to Lyralei's emotional state. When she is calm, the perch is solid. When she is agitated, the stone of the perch becomes slightly translucent, shimmering with a faint, fiery light. It is a living barometer of her inner storm.

## Life Within the Bastion: The Grounded Academic

Lyralei's focus is often on the sky, but her work and her presence are deeply connected to the life of the Company.

### The Courtyard Forecaster
Lyralei is a frequent, if sometimes distracted, presence in the **Great Courtyard**, providing uncannily accurate weather forecasts. The Bastion often aids her, channeling unique air currents up to the courtyard to give her more data to analyze.

### A Calming Influence
Surprisingly, she often seeks out the quiet of the **Temple of Renewal**. The calm, stable environment, so different from her own chaotic laboratory, seems to help ground her. She and **Aldwin** share a quiet friendship, a silent acknowledgment between two people who understand that both the body and the sky have complex, often unpredictable systems that must be treated with patience and respect.
