# Marcus Heartbridge: The Diplomat and the Stone

Marcus's relationship with the Bastion is its most complex and theatrical. His anchor is a two-room suite on the **Establishment Terrace** that he has converted into a **Diplomatic Theater**. The Bastion, initially confused by his constantly shifting personas, has learned to become his silent stage manager, providing the perfect environment for the art of influence, while also safeguarding the small, private space where the actor can finally rest.

## The Anchor: A Stage for Secrets

### Marcus's Quarters - "The Salon"
Marcus chose his quarters not for comfort but for their potential as a performance space. The Bastion has learned to treat the suite as an instrument that Marcus plays with masterful precision.

*   **The Salon Performance Space**: The outer room is a masterwork of calculated hospitality, with infinitely adjustable ambiance.
    *   **Practical Detail**: The chairs in the salon are all of slightly different heights. Marcus knows the precise psychological effect of each one and directs guests to their seats with the care of a master strategist. The Bastion has learned to make the "disadvantageous" chairs infinitesimally less comfortable.
*   **The Private Sanctum**: The inner room is a space of absolute privacy where all masks can be laid aside.
    *   **Contradiction**: The public-facing salon is filled with priceless art, comfortable furniture, and expensive wine. The private sanctum is almost monastic: a simple bed, a single chair, and one small, heavily-worn book of children's stories. The performer is exhausted by performance.
*   **The Desk of Secrets**: His writing desk contains hidden compartments that the Bastion helps conceal.
    *   **Unconscious Habit**: When writing a particularly deceptive letter, Marcus uses a specific quill with a slightly frayed tip. He is unaware of this habit, but the Bastion has noticed, and will sometimes subtly move that quill to the back of the holder when a more honest approach is required.

### The Intelligence Vault
Located on the **Tower of Innovation Terrace**, this is Marcus's true domain. It is a secure, climate-controlled archive where the Company's collected knowledge is meticulously catalogued.

*   **Intended vs. Actual Use**: The Vault is for storing intelligence on external threats, but Marcus also uses it as a library of personal histories. He keeps detailed, non-judgmental records of every Company member's story, believing that understanding their pasts is the only way to protect their futures.
*   **Unexpected Detail**: The Bastion, as the ultimate security system, has learned to recognize the emotional "color" of the information Marcus is accessing. When he is reviewing something particularly dangerous or painful, the ambient temperature in the Vault will drop by a few degrees, a silent, shared shiver of concern.

## Life Within the Bastion: The Grand Performance

Marcus navigates the Bastion's social spaces with the grace of a master actor, using them as extensions of his salon to build rapport and gather information.

### The Courtyard Diplomat
Marcus frequently conducts informal meetings in the **Great Courtyard**, using the open environment to create a sense of transparency. The Bastion assists, guiding him to a bench where the sound of a fountain might obscure their conversation, or where the afternoon sun will fall perfectly to create a warm, agreeable atmosphere.

### The Professional Alliance
His most crucial working relationship is with **Kaida**. They meet in the Bastion's forgotten spaces. He provides the social openings; she slips through the physical ones. Theirs is a partnership of silent, professional understanding, a perfectly executed dance of shadows and whispers facilitated by the living stone they inhabit.
