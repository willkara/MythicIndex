# Cidrella "Cid" Vexweld: The Genius and the Stone

Cid's relationship with the Bastion is a dynamic, intellectual partnership bordering on a playful rivalry. Her anchor is the **Prototyping Workshop** and adjoining **Annex** on the **Tower of Innovation Terrace**. This space is not merely a laboratory; it's a three-dimensional, living schematic of her own brilliant, chaotic mind. Here, the Bastion has learned that supporting Cid's genius means embracing unpredictability and becoming an active, and often exasperated, participant in her endless experiments.

## The Anchor: A Laboratory of Living Chaos

### Cid's Quarters - "The Annex"
Cid rejected traditional quarters, instead claiming a defunct, two-story maintenance area. Her comfort comes from capability, not coziness, and the Annex is a testament to this philosophy.

*   **The Vertical Workshop**: The space is a web of moving platforms and gantries.
    *   **Unconscious Habit**: Cid never takes the same path through the workshop twice. Her movements are a form of three-dimensional brainstorming, and the Bastion has learned to anticipate her leaps of logic, moving platforms to intercept her swings before she seems to know where she's going next.
*   **The Living Power Grid**: Crystalline formations store and discharge energy on demand.
    *   **Practical Detail**: The crystals are covered in her unique shorthand, scrawled in grease pencil. These aren't scientific notes, but reminders to herself: "Don't lick this one," "Spicy!" or "Remember to ask Korrath about resonance dampening."
*   **The Failure Museum**: A rotating wall displays her failed prototypes.
    *   **Contradiction**: For a forward-looking innovator, she is obsessed with her past mistakes. She talks to the failed inventions like old friends, alternately scolding and encouraging them. The Bastion sometimes rotates a specific failure into view when she's about to repeat a mistake, a silent "Ahem" from the stone.
*   **The Emergency Bed**: A bed hidden in the wall, deployed by the Bastion when she is near collapse.
    *   **Intended vs. Actual Use**: Cid has never once slept in the bed. She uses it as a clean surface for laying out delicate components, forcing the Bastion to keep it deployed for days on end while she naps in a chair surrounded by active, humming machinery.

### The Prototyping Workshop
The main workshop is Cid's true domain, a space of glorious, productive chaos.

*   **The Component Swarm**: The walls are covered in tools and parts.
    *   **Unexpected Detail**: The Bastion's attempts to organize the swarm based on her subconscious patterns have had a strange side effect. Sometimes, components for an invention she hasn't thought of yet will begin to cluster together, a physical manifestation of her nascent ideas. She'll stare at a cluster for an hour before a eureka moment sends her scrambling for the very parts the Bastion has gathered.
*   **The Testing Void**: A quarantined section for dangerous experiments.
    *   **Practical Detail**: The entrance to the Void is littered with discarded, half-melted goggles and singed gloves, a testament to her "safety third" approach. The Bastion has taken to reinforcing the floor just outside the entrance, having learned that's where she's most likely to be thrown by an unexpected detonation.

## Life Within the Bastion: A System to be Improved

Cid sees the entire Bastion as a delightful system full of inefficiencies to be corrected and potentials to be unlocked.

### The Siege-Works Rivalry
Cid is a constant presence in **Korrath's Siege-Works**. Their loud, passionate arguments over engineering philosophy are the creative engine of the Bastion's defenses. The "Argument Wall" in her workshop displays their competing designs, but in a corner, almost hidden, is a perfectly rendered schematic of a collaborative project they both deny exists.

### The Kitchen Battlefield
Cid's attempts to "optimize" the kitchen in the **Common Hall** are a source of constant chaos. Her latest invention, a "flavor-enhancing sonic resonator," is currently sitting in a corner, covered in a dish towel by **Mistress Elba**. The Bastion, however, seems to enjoy the rivalry and has been observed subtly vibrating the device when Elba isn't looking.
