# Kaida Shadowstep: The Ghost in the Stone

Kaida's relationship with the Bastion is a constant, silent game of cat and mouse, built on mutual professional respect. Her anchor is **The Professional's Perch**, a strategically chosen chamber she treats not as a home, but as the most complex lock she's ever had to pick. The Bastion, in turn, treats her not as a resident, but as a resident security consultant, constantly testing and being tested in a silent, ongoing dialogue of paranoia and preparation.

## The Anchor: A Perch of Paranoia

Kaida chose her room for its tactical advantages: terrible official access, perfect unofficial access, and a commanding view of the **Great Courtyard**. The Bastion has learned to engage with her on her own terms, turning her quarters into a shared laboratory of security.

*   **The Observation Post**: The main window is enhanced by both parties.
    *   **Practical Detail**: Kaida has etched tiny, almost invisible markings onto the glass, allowing her to calculate distances and trajectories at a glance. The Bastion, recognizing their purpose, subtly shifts the light to make these markings gleam when she's tracking a target of interest.
*   **The Escape Architecture**: The Bastion reinforces her escape routes rather than sealing them.
    *   **Contradiction**: She has three perfectly maintained, instantly accessible escape routes in her room, yet she has never used them. Her paranoia requires their existence, but her professionalism (and perhaps a sliver of loyalty she'd never admit to) keeps her in place.
*   **The Practice Corner**: The Bastion manifests new and ancient lock mechanisms within the walls.
    *   **Unconscious Habit**: Kaida keeps a meticulous record of the time it takes her to pick each new lock the Bastion creates. She thinks it's for professional development, but the logbook is filled with personal, frustrated notes: "You cheeky bastard, that was a nice twist." It's the closest she comes to a personal journal.
*   **The Personal Space**: Her actual living area is sparse and impeccably clean.
    *   **Unexpected Detail**: The only personal item is a single, exquisitely crafted silver locket, kept polished but always empty. The Bastion, sensing its significance, has created a small, hidden compartment directly behind where the locket hangs, a space she has not yet discovered. It is the only secret in the room that is not her own.

## Life Within the Bastion: The Unseen Guardian

Kaida moves through the Bastion like a ghost, using its shared spaces not for community, but for reconnaissance and the subtle execution of her duties.

### The Ghost on the Rafters
The **Common Hall** is a source of constant intelligence. She is rarely seen on the main floor, having established a network of perches in the high rafters.
*   **Intended vs. Actual Use**: She uses the rafters for observation, but they have also become her dining hall. She will often lower a small, hooked line to snag a piece of bread or fruit from a communal bowl, a game she plays to keep her skills sharp. The Bastion, aware of this, sometimes ensures a particularly good piece of cheese is left in a convenient spot.

### The Professional Courtesy
Her most significant relationship is with **Marcus Heartbridge**. They meet in the forgotten corridors of the Bastion, spaces the consciousness has learned to keep acoustically isolated and unobserved. Theirs is a partnership of pure, efficient professionalism.

### The Watcher of the Courtyard
From her perch, Kaida has an unparalleled view of the **Great Courtyard**. She avoids the communal gatherings, but she is a constant, unseen observer. This is her form of connection, her way of guarding the family she keeps at arm's length. The Bastion has learned to tunnel sounds and sharpen sightlines, allowing her to hear Grimjaw's stories and Veyra's quiet commands, making her a silent, informed participant in the life of the Company.
