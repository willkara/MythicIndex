# Grimjaw Ironbeard: The Heart and the Stone

Grimjaw's relationship with the Bastion is one of profound, instinctual kinship. He is the heart of the Company, and his anchor is the **Great Courtyard**, the social and spiritual center of the sanctuary. More than any other, Grimjaw communicates with the Bastion not through words or intellect, but through the shared language of stone, patience, and memory.

## The Anchor: The Deep Delve & The Courtyard Hearth

### Grimjaw's Quarters
When Grimjaw arrived, he ignored the offered quarters and walked deep into the mountain's foundations, placing a hand on raw bedrock and declaring, "Here." His quarters are a collaboration between his own tools and the Bastion's willing consciousness.

*   **The Living Stone Chamber**: The room is largely natural rock, shaped by partnership.
    *   **Practical Detail**: The furniture, carved from the living stone, is all sized for him, but every piece has a smaller, gnome-or-halfling-sized step carved into its base—a practical accommodation for his smaller friends that speaks volumes about his gentle nature.
*   **The Spring Wall**: A natural spring trickles down the bedrock, a communication channel with the Bastion.
    *   **Unconscious Habit**: Grimjaw keeps a collection of small, smooth stones by the spring. When he's worried about a member of the Company, he'll unconsciously select a stone that reminds him of them and place it in the stream, as if asking the Bastion to watch over them.
*   **The Singing Chamber**: The room's acoustics resonate in harmony with his sagas.
    *   **Contradiction**: He only sings the loud, boisterous epics when others are present. When alone, the Bastion has heard him singing soft, dwarven lullabies—songs of loss and remembrance from his long life.

### The Great Courtyard
While his quarters are his private anchor, the **Main Level of the Great Courtyard** is his public domain. This is where he serves as the Company's social anchor, and the Bastion is his active partner.

*   **The Hearthstone**: The communal fire pits are the heart of the courtyard.
    *   **Intended vs. Actual Use**: The fire is for warmth and community, but Grimjaw uses it as a diagnostic tool. He reads the state of the Company's morale in the way people huddle near the flames, in the stories they share, and in the silences between them.
*   **The Storyteller's Amphitheater**: The acoustics around the fire pits carry his voice.
    *   **Unexpected Detail**: The Bastion has learned to participate in his stories. When he speaks of a cold mountain pass, the air around the fire will grow subtly cooler. When his tale turns to a dragon's fire, a sudden, warm gust of wind will sweep through the courtyard. The listeners think it's just his masterful storytelling; Grimjaw knows he has a co-conspirator.

## Life Within the Bastion: The Grounded Presence

Grimjaw's presence brings a sense of stability to every part of the Bastion he visits, his interactions revealing a wisdom that is both practical and profound.

### The Foundations of Command
Though not a strategist, Grimjaw is often sought out by **Veyra** and **Thorne** in the **Strategic Operations Center**. He will place a hand on the stone floor and give his assessment: "The stone is anxious today. Expect trouble from the north." The Bastion communicates its larger anxieties through him, and command has learned to listen.

### A Master's Respect
Grimjaw shares a deep, unspoken respect with **Korrath**. They can be found in the **Siege-Works**, not talking, but simply observing the stone together. Korrath brings the science, Grimjaw the soul, and the Bastion seems to hum with satisfaction when they are together.

### An Unlikely Student
He has a surprising friendship with **Cid**, who is fascinated by his intuitive understanding of physics. He answers her complex questions with simple, profound dwarven truths, often demonstrating with a handful of pebbles and a lifetime of experience.
