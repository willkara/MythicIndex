# Elara Whisperwind – Profile

## Basic Information
- Full Name: Elara Whisperwind
- Aliases/Nicknames: None mentioned
- Age: Unknown (at time of death)
- Gender: Female
- Role in Story: Party rogue and infiltrator
- First Appearance: Chapter 1, Scene 1 (Twilight on the Rim)
- Status: Deceased (Undershade Canyon)

## Physical Description
- Height/Build: Agile build suited for stealth
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: None specified
- Typical Clothing: Cloak (which ignited during escape attempt)
- Body Language: Moved "half-in shadow," natural stealth
- Physical Condition: Agile, quick reflexes

## Significance
Elara Whisperwind was the Gilded Compass's infiltrator and trap specialist. Her death represents the loss of finesse and subtlety that the party relied upon. Her inability to escape despite her skills underscores the overwhelming nature of the cult's trap.

## Death Scene
Became trapped when trying to squeeze through the closing escape gap, her cuirass catching on the fusing glass. Despite Borin's attempts to shield her, she died in the final collapse. Her hoarse cry was one of the last sounds Veyra heard.

## Legacy
- Body recovered and given proper burial rites by Veyra
- Name inscribed in the Hall of Remembrance
- The "E" stone carried by the patrol as a token
- Her loss highlights the Company's later need for skilled infiltrators (leading to Kaida's recruitment)


---

# Elara Whisperwind - Background

## Origin
- **Birthplace**: An elven community, likely one with a strong tradition of divination and mysticism.
- **Social Class**: Unknown.
- **Cultural Background**: Elven, with a personal inclination towards quiet observation and subtle arts.

## History
- **Professional Career**: The infiltrator and trap specialist for the Gilded Compass. Her skills in stealth and her keen senses made her an invaluable asset for navigating dangerous ruins and hostile territory.

## Personal Details
- **A Secret Talent**: Elara was a gifted tea-leaf reader. It was a skill she learned from her grandmother, and while she presented it as a bit of a party trick, she had a genuine, uncanny knack for seeing patterns and potential futures in the leaves. Her quiet pronouncements, often delivered with a wry smile, were a source of both comfort and gentle guidance for the party.
- **How She Relaxed**: She found peace in rooftop gardens and high, quiet places. She would often slip away from the noise of the city to sit on a high ledge or in a hidden garden, simply watching the world go by from a distance. It was in these moments of quiet observation that she felt most at ease.
- **Favorite Meal**: Spiced Lentil Soup with warm, crusty bread. It was a simple, quiet meal that she could eat slowly. She had incredibly sensitive hearing, and the loud, boisterous atmosphere of most taverns was often overwhelming for her. This was a meal she could enjoy in a quiet corner, a small island of peace in a noisy world.


---

# Elara Whisperwind - Character Development

## Personality Core
- **Defining Traits**: 
- **Core Values**: 
- **Motivations**: 
- **Fears**: 
- **Internal Conflicts**: 
- **Contradictions**: 

## Character Arc
- **Starting Point**: 
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Catalyst Events**:
  - *Event 1*:
  - *Event 2*:
  - *Event 3*:
  
- **Current State**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:
  
- **Intended Destination**:
  - *Self-Perception*:
  - *World View*:
  - *Key Relationships*:

## Growth Milestones
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:
  
- **[Chapter/Scene]**: 
  - *Development Noted*:
  - *Catalyst*:
  - *Impact*:

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:
  
- **Secondary Flaws**: 
  - *Effects on Character*:
  - *Effects on Others*:
  - *Development Plan*:

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*:
  - *Secret 2*:
  
- **Unknown to Character**:
  - *Truth 1*:
  - *Truth 2*:
  
- **Revelation Timeline**:
  - *Secret/Truth*:
  - *Planned Reveal*:
  - *Expected Impact*:

## Key Decisions & Turning Points
- **Decision 1**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:
  
- **Decision 2**:
  - *Context*:
  - *Options Considered*:
  - *Choice Made*:
  - *Consequences*:

## Development Notes
*[Additional notes on planned character development]*


---

# Elara Whisperwind - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Elara Whisperwind - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Elara Whisperwind - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

