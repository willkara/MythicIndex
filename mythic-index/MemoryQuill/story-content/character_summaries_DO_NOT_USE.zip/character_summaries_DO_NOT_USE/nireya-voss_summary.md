# Nireya Voss - Profile

## Basic Information
- **Full Name**: Nireya Voss
- **Aliases/Nicknames**: Death-Walker
- **Race**: Half-Elf Kalashtar
- **Class**: Spirit-Medium
- **Role in Story**: Spiritual specialist for the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Slender and poised, with a deliberate, graceful bearing.
- **Hair**: Long, dark hair that falls to her mid-back. Part of it is kept in a neat, thick braid, while the rest is left to hang loose, often seeming to merge with the shadows around her.
- **Eyes**: Her left eye is a warm, living brown. Her right eye is a luminous, multi-toned marvel, shifting between glowing chartreuse and a pale, spectral white, a clear indicator of her supernatural senses.
- **Distinguishing Features**: Nireya's appearance is a stark representation of her dual nature. The left side of her body is that of a living half-elf, with warm, sun-kissed skin that has a subtle silvery-blue undertone. The right side is a manifestation of her connection to the spirit world: her skin is a pale, spectral blue-gray, semi-translucent and marked with swirling quori glyphs and faint, shifting constellations that glow with a soft, internal light. Wisps of spirit-mist often curl around her form, converging at the split down her center.
- **Typical Clothing**: She wears layered robes that reflect her duality. The left side is made of a solid, warm brown earthly fabric with elegant, gold-embroidered star patterns. The right side is made of translucent, mist-like silks that seem to trail off into the surrounding air.
- **Body Language**: Calm, composed, and unnervingly still. She moves with a quiet purpose, and her gaze is often distant, as if she is perceiving things others cannot.

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Nireya Voss.

## Personality
- **Archetype**: The Medium/Bridge Between Worlds - A Living Covenant and Divine Safeguard
- **Temperament**: Measured and serene until souls are threatened, then becomes terrifyingly absolute
- **Positive Traits**: Compassionate toward the deceased, unafraid of darkness, dedicated to remembrance, fiercely protective of the natural order, surprisingly warm when comfortable
- **Negative Traits**: Potentially unsettling to others, inflexible about death rites, can become genuinely frightening when souls are desecrated
- **Moral Alignment**: Neutral Good - guardian of the natural cycle, but with an edge of divine judgment
- **Core Philosophy**: "Death is not the enemy - abandonment is" / "I do not barter with the dead for the convenience of the living"
- **Hidden Nature**: Not just a medium but a divine safeguard - when souls are weaponized or desecrated, she reveals herself as something far more powerful and terrifying than anyone suspected

## Skills & Abilities
- **Expertise**: 
  - Extracting information from the recently deceased
  - Navigating spectral landscapes
  - Mapping "death echoes" (as seen with the Wraithwood maps)
  - Spirit communication and interpretation
- **Kalashtar Abilities**:
  - Anchoring departing consciousness (as demonstrated saving Thorne)
  - Connection to a spirit guide that can stabilize fading life forces
- **Special Abilities**: 
  - Enhanced perception of the spirit realm
  - Ability to speak with and relay information from the dead
  - Creation of maps showing spiritual/death energy patterns
- **Time-of-Day Influence**:
  - During daylight: "Living" left side more prominent, more present in conversations
  - As darkness falls: "Death" side awakens, increasingly attuned to spiritual whispers
  - Between midnight and dawn: Peak spiritual connection when worlds overlap most strongly

## Personal Details
- **Habits**: 
  - Keeping watch during midnight to dawn hours when the worlds overlap most strongly
  - Carrying on quiet one-sided conversations with spirits only she can hear
  - Leaving tokens at recovery sites to remember the deceased
  - Moving between soul-lanterns at dawn like tending a forgotten shrine
  - Eating pickled quince with "guilty gusto" when alone
- **Hobbies**: 
  - Silver-Seaming: Repairing broken pottery with silver lacquer, finding peace in making things whole without hiding the cracks
  - Making flower crowns for distressed children from discarded stems
  - Cataloging sunrise/sunset times - the liminal moments when her nature is most balanced
- **Personal Quarters**: A quiet, isolated room in the Sanctuary terrace, with a single, high window that lets in the moonlight but not the direct sun. The room is starkly divided by a line of black sand on the floor. The "day" side has a simple wooden desk and chair. The "night" side is empty, save for shelves holding dozens of small, memorial tokens. This room is a physical representation of her liminal state. The air is unnaturally still and silent. She uses the desk on the "day" side for study and meditation. At night, she crosses the line of sand into the "night" side, where she communes with the spirits drawn to the tokens. She doesn't sleep in a traditional bed, but on a simple, padded mat placed directly on the line of sand, her body literally occupying the space between the two realms as she rests.
- **Likes**: Acknowledgment of spirits, respectful handling of the deceased, philosophical discussions, bitter tea (forest and smoke flavors), pickled quince
- **Dislikes**: Those who fear or vilify death, abandonment of the dead, witch hunters, forced necromancy, those who barter with the dead for convenience
- **Fears**: Becoming permanently stuck on the "death" side, failing to protect souls from desecration, the vulnerability after using her Pactform
- **Motivations**: Ensuring the dead are remembered, serving as a bridge between worlds, fulfilling her role as the gods' living covenant

## Combat & Tactics
- **Primary Tool**: Soul-staff topped with crystal skull that exists in both realms - channels and focuses her spiritual powers
- **Secondary Tools**: Soul-lanterns that contain and protect spirits, bone charms that resonate with the recently deceased
- **Armor**: Layered robes that shift between material and ethereal - no physical protection but spiritual warding
- **Fighting Style**: Living covenant - doesn't fight so much as impose the natural order, commanding spirits to return to their proper state
- **Signature Manifestation**: "Banshee Aspect/The Pactform" - when souls are desecrated, transforms into something divine and terrible
- **Combat Philosophy**: "I am not wrathful. I am inevitable. The personification of what happens when you desecrate the sacred."
- **Tactical Role**: Spiritual warfare specialist who handles undead, possessions, and soul-based threats
- **Trigger Points**: Souls being weaponized, forced necromancy, desecration of the dead
- **Key Combat Moments**: The Corsic Drell incident - when he shattered her soul-lantern and weaponized spirits, the Company saw her true nature for the first time

### The Banshee Aspect (When Unleashed)
- **Hair**: Billows skyward like spirit-smoke, silver and black strands separating into ghostly ribbons
- **Eyes**: Both glow - one searing white, the other an endless void
- **Form**: Body becomes silhouette of living shadow-script and blinding soulfire, bones glow like judgment
- **Presence**: Not possession but revelation of what she truly is - a safeguard, a boundary line between life and death
- **The Team's First Witness**: During the Corsic Drell fight, Thorne whispered "Gods preserve us" - their first understanding that she wasn't just a medium
- **Her Response**: "Not gods. Just oaths." - delivered exhausted but unshaken

## Psychological Response Matrix
- **In Crisis**: Becomes utterly still, then acts with divine certainty - "Return. This place is not your ending."
- **During Negotiation**: Listens for the subtle wrongness the newly dead leave when lies touch them (as with Marcus and the guild envoys)
- **Moral Dilemma**: Always chooses to preserve the natural cycle - "I do not barter with the dead for the convenience of the living"
- **Team Conflict**: Offers perspective from "the other side," mediates through shared mortality
- **Under Personal Attack**: Shows attacker their own spiritual wounds, makes them feel what they've inflicted
- **In Victory**: Performs rites for fallen enemies, ensures proper passage for all souls
- **Daily Life**: Moves between worlds constantly - pickled quince in morning, soul-guiding by night
- **When Souls Are Threatened**: Voice goes flat ("Those were names"), time seems to pause, transforms into the Pactform
- **After Using Pactform**: Becomes hypersensitive to all living sensations, emotionally raw, needs grounding through physical comforts (Aldwin's tea, food)

## Voice & Dialogue Patterns
- **Speech Style**: Measured, formal when channeling spirits, surprisingly dry humor when comfortable
- **Signature Phrases**: 
  - "The crossing here was clean" (reassuring mourners)
  - "Death is not the enemy - abandonment is"
  - "I do not barter with the dead for the convenience of the living"
  - "Those were names" (when souls are desecrated - voice goes flat, precedes transformation)
  - "Not gods. Just oaths" (after using divine power)
  - "Return. This place is not your ending" (commanding spirits)
- **Dual Voice**: When using full power, voice fractures with divine resonance - multiple tones at once
- **Example Dialogue**: "I guide them so they aren't used. I do not keep what isn't mine."
- **Emotional Tells**: Tattoos pulse brighter with spirit activity, right side grows more translucent when stressed, voice becomes distant when channeling
- **Comfort Mechanism**: Makes terrible jokes about death that only the team understands; dry comments about "weaponizing citrus"
- **Threat Response**: "Leave your coin on the table and I will walk away without shame. Push me again, and I will show you what it truly means to be heard by the dead."

## Notes
- Joined the Company after being rescued from a witch hunter prison
- The Company needed her maps of the Wraithwood's "death echoes" to track a missing caravan
- During escape, when Thorne took a crossbow bolt through his lung, she saved his life
- Exists in a liminal state between the world of the living and the dead
- When receiving information from the dead, her spirit-ink tattoos glow brighter
- When relaying spirit information, her voice becomes more distant and formal
- Personal philosophy: "Death is not the enemy - abandonment is"

### Public Perception
- Known as the "Death-Walker," who can speak to the recently deceased, a fact that is unsettling to some but comforting to others who believe she helps spirits find peace.
- Rumored to leave small tokens at tragedy sites to help the spirits rest, a strange but kind gesture.
- Her dual appearance, half-living and half-spectral, is a visible manifestation of her unique connection to the spirit world.


---

# Nireya Voss - Background

## Origin
- **Birthplace**: The Echoing Depths - a planar convergence point where the Material Plane touches Dolurrh (Realm of the Dead)
- **Birth Date**: Born during a rare triple eclipse when the boundaries between planes were thinnest
- **Social Class**: Temple-raised; her birth was prophesied and she was given to clerics at infancy
- **Cultural Background**: Kalashtar - a race of humans with a unique connection to spirits and the dream realm
- **Divine Marking**: At the instant of her first breath, three gods who rarely agree came to accord and marked her soul

## Family
- **Parents**: Mother was a temple healer who died in childbirth; father unknown (possibly touched by the divine)
- **Siblings**: None by blood; raised alongside other temple orphans
- **Extended Family**: The clerics of Kelemvor who raised her after the divine marking
- **Family Dynamics**: Treated with reverence and fear by her temple family; isolated but protected

## The Pact of Three
At her birth, three gods converged in unprecedented accord:

- **Kelemvor (God of the Dead)**: To ensure the final rest is honored and not twisted
- **Jergal (The Scribe of the Doomed)**: To record every death as it should be, not as mortals manipulate it
- **Silvanus (God of Nature)**: To protect the balance—the cycle of life and death without interference

Together, they marked her as:
- Mortal flesh, but anchored across realms
- Not a servant of one god, but a living clause in their shared covenant
- A correction to prevent dominion over the dead from falling into tyrants' hands

Her very existence is a safeguard—she is not wrathful, but inevitable. As the gods declared: "You are not our servant, Nireya Voss. You are our promise. And a promise must endure. Even when it weeps."

## History
- **Childhood**: 
  - First spoke to the dead at age seven when a temple acolyte died suddenly
  - The gods' whisper came early: "You will walk where others fall. You will carry names others forget. And when called, you will remind them that death is not silence."
  - Manifested split appearance at puberty - left side living, right side touched by death
  - Learned to create "death echo" maps by tracing spirit paths with her fingers in sand
  
- **Education/Training**: 
  - Formal or informal training in spirit-medium practices
  - Development of her unique abilities to map "death echoes"
  - Learning to navigate spectral landscapes
  
- **The Witch Hunter Incident**:
  - Circumstances leading to her capture by witch hunters
  - Imprisonment period - likely harsh conditions and possible interrogation
  - Development of maps of the Wraithwood's "death echoes" (possibly before or during imprisonment)
  
- **The Rescue**:
  - The Last Light Company's discovery of her imprisonment
  - Company's need for her maps to track a missing caravan
  - Tactical extraction from the witch hunter prison
  
- **Saving Thorne**:
  - During the escape, Thorne was struck by a crossbow bolt that punctured his lung
  - As he was dying, Nireya used her Kalashtar abilities to anchor his departing consciousness
  - Her spirit guide worked to stabilize his fading life force
  - This act of saving Thorne's life became her first act of freedom
  
- **Joining the Company**:
  - Initial partnership to help find the missing caravan using her maps
  - Transition from temporary ally to full member
  - Establishing her role as spiritual specialist
  - Development of trust with other members despite her potentially unsettling abilities

## Backstory Elements
- **Defining Moments**: 
  - First manifestation of spirit communication abilities
  - Capture by witch hunters
  - Rescue by the Company
  - Saving Thorne's life
  
- **Past Trauma**: 
  - Imprisonment by witch hunters
  - Possible persecution due to her abilities
  - Witnessing death and communicating with the deceased (which shaped her philosophy)
  
- **Greatest Achievements**: 
  - Creating accurate maps of spiritual/death energies
  - Saving Thorne's life by bridging the gap between life and death
  - Successfully helping the Company find the missing caravan
  
- **Biggest Failures**: 
  - TBD - possibly related to past inability to save someone important
  - TBD - perhaps an incident where her abilities were insufficient or misused
  
- **Secrets**: 
  - TBD - possibly the full extent of her abilities
  - TBD - knowledge gained from the dead that she hasn't shared

## How They Got Here
- **Reason for Current Situation**: 
  - Initial alliance of convenience (Company needed her maps)
  - Mutual benefit relationship evolved into true membership
  - Possible sense of debt to the Company for her rescue
  - Finding purpose in using her abilities to help find and rescue others
  
- **Path to Current Location**: 
  - Discovery of spiritual abilities
  - Development of specialized skills
  - Capture by witch hunters
  - Rescue and integration into the Company
  
- **Goals Prior to Story Start**: 
  - Freedom from imprisonment
  - Possible desire to help the dead be remembered
  - Development of her liminal abilities

## Historical Connections
- **Connection to Main Plot**: 
  - Specialist in navigating spiritual landscapes crucial for certain rescue operations
  - Ability to extract information from the deceased to locate missing persons
  
- **Connection to Other Characters**: 
  - Thorne: Saved his life, creating a unique bond
  - Other Company members: Varying degrees of comfort with her abilities
  
- **Connection to Story World**: 
  - Understanding of the spiritual dimensions that overlap the material world
  - Knowledge of "death echoes" and how to interpret them
  - Awareness of the Wraithwood and its spiritual significance

## Timeline
- Early life and discovery of abilities
- Development of spirit-medium skills
- Creation of maps showing spiritual/death energy patterns
- Capture and imprisonment by witch hunters
- Rescue by the Last Light Company
- Saving Thorne's life during the escape
- Helping find the missing caravan using her maps
- Integration as full member of the Company

## Philosophical Development
- Initial relationship with death and spirits (likely more fearful or uncertain)
- Evolution toward seeing death as "a door, not an end"
- Development of personal philosophy: "Death is not the enemy - abandonment is"
- Balanced perspective on the relationship between the living and dead worlds
- Commitment to remembering and honoring the deceased

## Personal Details
- **How She Relaxes**: She practices an art form known as "Silver-Seaming." It is the delicate process of repairing broken pottery or porcelain with a lacquer mixed with powdered silver. She finds a deep, philosophical peace in taking something shattered and making it whole again, not by hiding the cracks, but by highlighting them as a beautiful part of the object's history.
- **Favorite Meal**: A simple bowl of steamed rice with pickled quince and a single, perfectly poached egg. It's a meal of subtle, distinct flavors that requires mindful eating, helping to ground her senses. The pickled quince is so pungent that others joke about "weaponizing citrus" - but she genuinely loves it.
- **Morning Ritual**: Takes bitter tea (forest and smoke flavors) before dawn, moving between soul-lanterns in the Sanctuary like a shrine the city forgot how to pray in
- **A Mundane Joy**: She finds a unique pleasure in the silence of a library or a scriptorium. The shared, unspoken respect for quiet is a sanctuary from the constant whispers of the spirit world.
- **A Love of Art**: She has a deep appreciation for sculpture and architecture. Because she can perceive the "echoes" of the past, she experiences art in a unique way. For her, a statue is not just a carved stone; she can faintly perceive the lingering emotions of the sculptor and the weight of the history it has witnessed.
- **Small Kindnesses**: Makes flower crowns for crying children, lights extra candles at shrines, tells mourners when their loved ones crossed cleanly
- **Private Habit**: Eats her pickled quince with "guilty gusto" when alone, knowing her oddness is part of her shape


---

# Nireya Voss - Character Development

## Personality Core
- **Defining Traits**: Measured, philosophical, liminal, compassionate toward the deceased
- **Core Values**: Remembrance, honoring the dead, seeing death as transition not ending, spiritual continuity
- **Motivations**: Ensuring no one is forgotten, serving as bridge between living and dead worlds
- **Fears**: Abandonment, being recaptured by witch hunters, failure to honor the deceased
- **Internal Conflicts**: 
  - Balance between living in the material world vs. spiritual realm
  - Duty to the living vs. obligations to the dead
  - Being both respected for abilities and feared/mistrusted because of them
- **Contradictions**: Exists in two worlds simultaneously, changes with day/night cycles

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: Prisoner with unusual abilities, isolated by her connection to death
  - *World View*: Death as inevitable transition, remembrance as sacred duty
  - *Key Relationships*: Limited connections, possibly only with spirits and her guide
  
- **Catalyst Events**:
  - *Event 1*: Rescue from witch hunter prison by the Last Light Company
  - *Event 2*: Saving Thorne's life by anchoring his departing consciousness
  - *Event 3*: Successfully using her death echo maps to find the missing caravan
  - *Event 4*: Integration into the Company despite her unsettling abilities
  
- **Current State**:
  - *Self-Perception*: Valued specialist with unique perspective, guardian of memories
  - *World View*: "Death is not the enemy - abandonment is" - firmly established philosophy
  - *Key Relationships*: Special bond with Thorne, working connections with Company members
  
- **Intended Destination**:
  - *Self-Perception*: Fully integrated member whose abilities are understood rather than feared
  - *World View*: Expanded understanding of the relationship between life and death
  - *Key Relationships*: Deeper connections with team members who accept both her "living" and "death" sides

## Growth Milestones
- **From Prisoner to Rescuer**: 
  - *Development Noted*: First act of freedom was saving someone else (Thorne)
  - *Catalyst*: Critical moment during escape when Thorne was injured
  - *Impact*: Established value to the team and created first meaningful connection
  
- **From Temporary Ally to Team Member**: 
  - *Development Noted*: Transition from providing maps to becoming integral specialist
  - *Catalyst*: Success in finding missing caravan using her abilities
  - *Impact*: Found purpose for her unique abilities within the Company
  
- **From Feared to Valued**: 
  - *Development Noted*: Gradual acceptance of her unsettling abilities by team members
  - *Catalyst*: Demonstrations of how her abilities save lives and provide closure
  - *Impact*: Increasing comfort with her dual nature among teammates

## Character Flaws
- **Detachment from Physical World**: 
  - *Effects on Character*: May prioritize spiritual matters over immediate physical concerns
  - *Effects on Others*: Can seem distant or unsettling, especially at night
  - *Development Plan*: Learning to balance dual nature and communicate effectively with the living
  
- **Burden of Memories**: 
  - *Effects on Character*: Carries emotional weight of many deceased memories
  - *Effects on Others*: May seem preoccupied or distracted by voices others cannot hear
  - *Development Plan*: Finding healthier ways to manage the emotional toll of her work

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: Full extent of her abilities to interact with the dead
  - *Secret 2*: Knowledge gained from spirits that she hasn't shared
  - *Secret 3*: Possible deeper understanding of death than she reveals
  
- **Unknown to Character**:
  - *Truth 1*: TBD - possibly the origin of her unique split appearance
  - *Truth 2*: TBD - perhaps why the witch hunters specifically targeted her
  - *Truth 3*: TBD - potential untapped aspects of her Kalashtar heritage
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Choosing to Save Thorne**:
  - *Context*: Escape from witch hunter prison
  - *Options Considered*: Focus solely on escaping vs. risking capture to save him
  - *Choice Made*: Used her abilities to save his life
  - *Consequences*: Created unique bond and proved her value to the Company

- **Joining the Company Permanently**:
  - *Context*: After helping find the missing caravan
  - *Options Considered*: Return to solitary existence vs. integrate with the team
  - *Choice Made*: Remained with the Company
  - *Consequences*: Found purpose and protection while contributing unique skills

## Special Character Elements
- **Day/Night Transformation**:
  - During daylight: "Living" left side more prominent, more present in conversations
  - As darkness falls: "Death" side awakens, increasingly attuned to spiritual whispers
  - Between midnight and dawn: Peak spiritual connection when worlds overlap
  
- **Physical Manifestations of Spiritual State**:
  - Eye color shifts based on spiritual connection (violet, bone white, firefly green)
  - Spirit-ink tattoos glow brighter when communicating with spirits
  - Right side becomes more pronounced and corpse-gray as night falls
  
- **Remembrance Tokens**:
  - Small objects left at recovery sites
  - Physical manifestation of her philosophy about remembrance
  - Tangible way to honor those who have passed

## Voice Change When Channeling
- **Normal Voice**: Standard speaking pattern in regular conversation
- **Spirit-Relay Voice**: More distant and formal when relaying information from spirits
- **Transition**: Noticeable shift that indicates when she's channeling versus speaking personally
- **Development**: Potential to become more seamless or more pronounced depending on character arc

## Development Notes
- Character represents the philosophical understanding that death is part of a cycle, not an ending
- Visual split appearance physically manifests her existence between worlds
- Relationship with Thorne offers rich development possibilities due to their spiritual connection
- Day/night cycle influence on her abilities creates natural story rhythm and limitations
- Philosophy "Death is not the enemy - abandonment is" could be explored in multiple scenarios
- Balance between being unsettling to others while being compassionate creates interesting tension
- Potential arc from being seen as unsettling to being understood and valued by the team

## Dream Sequences & Divine Visitation
After invoking the Pactform, her dreams take her to the place where the gods signed her soul:
- **The Setting**: A vast ink-black sea with a skeletal tree rising from the center. Names hang from its branches like glowing fruit
- **The Three Shadows**: Kelemvor, Jergal, and Silvanus wait at the tree's base
- **Kelemvor's Voice** (like a gavel on stone): "You honored the silence of the dead. That is justice."
- **Jergal's Record** (never raising his head): "Her ledger is heavy, but not out of balance. Continue."
- **Silvanus's Whisper** (breaking leaves and summer wind): "The forest weeps for every soul delayed. But you have made the soil whole again."
- **Their Unified Declaration**: "You are not our servant, Nireya Voss. You are our promise. And a promise must endure. Even when it weeps."

## The Company's Growing Understanding
From the daily life scenes, a clear arc emerges:
- **Initial Fear**: People are "unused to her" rather than afraid - they don't know how to interact
- **Growing Acceptance**: Team members find ways to care for her (Grimjaw's flask, Aldwin's food, Lyralei's wind protection)
- **Full Integration**: "They didn't say we love you. They didn't need to. They had carried her through a day like a river carries a leaf"
- **The Revelation**: During the Corsic Drell incident, they finally understand what she truly is - not just a medium but a divine safeguard

## Psychological Profile
*   **Nireya Voss (The Bridge):** Nireya lives in a state of constant liminality, with one foot in the world of the living and one in the world of the dead. This has given her a unique, detached perspective on life and death. She is not morbid or frightening; she is serene. Her compassion is for the forgotten, and her mission is to ensure that every story gets an ending. She is likely the calmest person in any crisis, as the physical world's dangers often pale in comparison to the spiritual echoes she navigates daily.


---

# Nireya Voss - Relationships

## Professional Relationships
- **Veyra Thornwake**: 
  - *Nature of Relationship*: Commander and Spiritual Specialist - mutual understanding through shared purpose
  - *Hierarchy*: Respects her leadership while providing unique spiritual expertise
  - *Dynamics*: Veyra's mission to leave no one behind resonates with Nireya's philosophy about remembering the dead
  - *Professional Opinion of*: Deep respect for her dedication; sees her as someone who understands duty to the forgotten
  - *Key Moments*: Morning tea ritual where they don't need words; Veyra giving her the remembrance token with "You don't get to decide who remembers them. You do."
  - *Current Status*: Veyra accepts both her nature and her choices without question

- **Captain Thorne Brightward**:
  - *Nature of Relationship*: Complex bond formed through life-saving connection
  - *Hierarchy*: Acknowledges his position as Deputy Commander
  - *Dynamics*: Unique spiritual connection after saving his life by anchoring his consciousness
  - *Professional Opinion of*: Respects his tactical abilities and dedication; feels a special responsibility for him after saving his life
  - *Special Connection*: The experience of having anchored his departing consciousness created an unusual spiritual bond

- **Vera "The Tracker" Moonwhisper**:
  - *Nature of Relationship*: Fellow specialist with complementary tracking abilities
  - *Hierarchy*: Equals with different but related expertise
  - *Dynamics*: Vera tracks physical trails while Nireya follows spiritual traces - complementary approaches
  - *Professional Opinion of*: Appreciation for her tracking abilities that operate in the physical realm while Nireya handles the spiritual

- **Brother Aldwin Gentleheart**:
  - *Nature of Relationship*: Professional partner; the master of the vessel - and unexpected source of gentle humor
  - *Hierarchy*: Peers and colleagues who co-lead the Temple of Renewal
  - *Dynamics*: Nireya views Aldwin with deep professional respect. She sees him as the master of the physical shell, the one who calms the storms of the body so that she may tend to the spirit within. He handles the immediate, tangible wounds, and his work creates the necessary peace for her to begin her own. She is grateful for his quiet acceptance of her abilities, a rarity she does not take for granted.
  - *History*: They developed their seamless working relationship at the Bastion, finding a natural rhythm in their shared duty to the rescued
  - *Current Status*: The two pillars of the Sanctuary. She finds his tea ceremonies a grounding ritual in her often-disorienting work and appreciates their philosophical conversations as a link to the world of the living
  - *Feelings Toward*: Immense respect for his craft and a quiet gratitude for his steady, accepting presence. She sees him as a vital anchor to the physical world
  - *Key Moments*: His joke about "weaponizing citrus" over her pickled quince; bringing her food when she hasn't eaten; grounding her after using the Pactform

- **Grimjaw Ironbeard**:
  - *Nature of Relationship*: Unexpected understanding between those who work in different kinds of darkness
  - *Hierarchy*: Different specialties (heavy rescue vs. spiritual guidance)
  - *Dynamics*: His grounded, physical approach contrasts with her ethereal methods, but he understands carrying the weight of the lost
  - *Professional Opinion of*: Deep appreciation for his pragmatic care and surprising understanding
  - *Key Moments*: Fixing her water flask without being asked; "I've carried men up who weren't breathing anymore and still felt them heavy with something. I work in the dark. You work in a different kind of dark. Don't mean either of us is lost."
  - *Current Status*: Mutual respect - she was genuinely surprised by his understanding and care

- **Lyralei Stormcaller**:
  - *Nature of Relationship*: Fellow practitioners of esoteric arts with quiet protective instincts
  - *Hierarchy*: Equals with different magical specialties
  - *Dynamics*: Both deal with forces beyond normal perception - Lyralei with planar energies, Nireya with spirits
  - *Professional Opinion of*: Intellectual kinship based on their understanding of unseen forces
  - *Discussions*: Deep philosophical conversations about dimensions, planes, and spiritual realms
  - *Key Moments*: Creating pockets of still air to protect her from harsh winds without being asked - "She guards the last breath. I can guard the next one."
  - *Current Status*: Unspoken understanding and protection

- **Marcus "The Voice" Heartbridge**:
  - *Nature of Relationship*: Fellow Company specialist with surprising public trust
  - *Hierarchy*: Different areas of expertise (negotiation vs. spiritual matters)
  - *Dynamics*: His pragmatic approach to problems complements her spiritual insights; he publicly validates her abilities
  - *Professional Opinion of*: Appreciates his ability to handle political complications and his willingness to let her lead when appropriate
  - *Collaboration*: Uses her ability to detect lies through spiritual echoes during his negotiations
  - *Key Moments*: Publicly deferring to her judgment with the guild envoys; his silent thank-you afterward surprised her more than she'd admit
  - *Current Status*: Professional trust with moments of genuine appreciation

- **Cidrella "Cid" Vexweld**:
  - *Nature of Relationship*: Fellow specialist who shows care through obsessive maintenance
  - *Hierarchy*: Different areas of expertise (technical vs. spiritual)
  - *Dynamics*: Contrast between Cid's concrete technical approach and Nireya's spiritual methods creates unexpected collaboration
  - *Professional Opinion of*: Appreciates her technical innovation and surprising tenderness
  - *Collaboration*: Uses Nireya as a "living threshold" to test spiritual resonance in devices; Nireya can sense when fields are "off by a name"
  - *Key Moments*: Polishing Nireya's belt charms after the Pactform; calling her "sacred artillery" with affection; "We're not gonna let you fade, Voss. You're one of us."
  - *Current Status*: Protective friendship expressed through practical care

- **Korrath "Wallbreaker" Threnx**:
  - *Nature of Relationship*: Guardians of the Veil; mutual respect.
  - *Hierarchy*: Equals.
  - *Dynamics*: Korrath builds walls to protect the living. Nireya communes with the spirits to bring peace to the dead. They have a deep, quiet respect for each other's roles as guardians. Korrath, a man of structure and order, is fascinated by the unseen "structures" of the spirit world that Nireya describes. He might even consult with her when building, ensuring that the Bastion's foundations are not just physically sound, but spiritually harmonious.
  - *History*: TBD
  - *Current Status*: A quiet, respectful professional relationship.
  - *Feelings Toward*: She respects his commitment to creating safe, physical spaces, which in turn allows spirits to rest more easily.

- **Kaida "Lockbreaker" Shadowstep**:
  - *Nature of Relationship*: Fellow specialist evolving from wariness to understanding
  - *Hierarchy*: Different areas of expertise (infiltration vs. spiritual)
  - *Dynamics*: Her concrete, physical infiltration approach contrasts with Nireya's spiritual methods, but she's learning to appreciate the value
  - *Professional Opinion of*: Growing respect and understanding of Nireya's unique contributions
  - *Collaboration Potential*: Her infiltration skills combined with Nireya's spiritual reconnaissance could be highly effective
  - *Key Moments*: Checking Nireya's staff for damage after the Pactform; offering to circle around mourners before understanding Nireya's purpose; "I thought I understood why you do what you do. I'm closer now."
  - *Current Status*: Evolving friendship with increasing understanding

## Spirit World Connections
- **Spirit Guide**:
  - *Relationship Type*: Personal spiritual companion and assistant
  - *History*: Connected to Nireya through her Kalashtar heritage
  - *Current Status*: Active presence that helps her navigate the spirit realm
  - *Dynamics*: Works with Nireya to stabilize fading life forces (as with Thorne)
  - *Tensions/Issues*: TBD - possibly conflicts between guide's perspective and mortal world needs

- **Spirits of the Deceased**:
  - *Relationship Type*: Communication subjects and information sources
  - *History*: Ongoing connections established through her medium abilities
  - *Current Status*: Regular contact, especially during night hours
  - *Dynamics*: She serves as their voice to the living world
  - *Tensions/Issues*: Possible competing demands from multiple spirits

## Witch Hunter Connections
- **Witch Hunters**:
  - *Relationship Type*: Former captors and likely ongoing threat
  - *History*: Imprisoned her before the Last Light Company rescue
  - *Current Status*: Likely seeking her recapture
  - *Dynamics*: Fear and animosity on both sides
  - *Tensions/Issues*: Ongoing threat of recapture or retribution

## Personal Relationships
- **The Rescued**:
  - *Relationship Type*: Those she has helped recover through her abilities
  - *History*: Various rescue operations with the Company
  - *Current Status*: Likely mixture of gratitude and unease about her methods
  - *Dynamics*: Her abilities may unsettle those she helps even as they benefit
  - *Tensions/Issues*: Some may fear or misunderstand her connection to death

- **The Remembered Dead**:
  - *Relationship Type*: Deceased individuals she has honored with tokens
  - *History*: Accumulating connections to those she remembers
  - *Current Status*: Spiritual bonds maintained through remembrance
  - *Dynamics*: She serves as their memory keeper
  - *Tensions/Issues*: Possible emotional weight of carrying so many memories

## Interpersonal Patterns
- **Approach to Authority**:
  - Respectful of hierarchy while maintaining independence in spiritual matters
  - Views authority as existing in both material and spiritual realms

- **Collaborative Style**:
  - Works well with others when her spiritual insights are valued
  - Most effective at night when her spiritual connections are strongest
  - May unsettle some teammates with her communication with unseen entities

- **Conflict Resolution**:
  - Likely takes a philosophical, long-term view of conflicts
  - May offer insights from both living and dead perspectives
  - Potentially unsettling in her detachment from purely physical concerns

## Relationship Evolution Tracker
- **Pre-Company**: Isolation or limited connections due to unusual abilities
- **Rescue**: Initial wariness and practical alliance with the Company
- **Saving Thorne**: Pivotal moment creating trust and special bond
- **Early Missions**: Proving her value through spiritual navigation and information
- **Current**: Established but somewhat separate member, valued for unique abilities
- **Future Development Potential**:
  - Deeper integration with team as they understand her abilities
  - Evolution of bond with Thorne based on their spiritual connection
  - Potential conflicts if her spiritual priorities clash with Company objectives

## Notes on Relationships
- The experience of saving Thorne created an unusual bond that transcends normal relationships
- Her existence between worlds naturally creates some distance from purely physical relationships
- Most comfortable with those who accept her dual nature and spiritual connections
- May form strongest connections with those who value remembrance and honoring the past
- Time of day influences her relationship dynamics - more present and conventionally social during daylight, more spiritually attuned and distant at night


---

# Nireya Voss — Dialogue & Psyche

## Core temperament
Quiet, uncanny, and empathic. As a Kalashtar spirit-medium, Nireya bridges living and dead; her speech often carries an echo of the other side—soft, weighted, sometimes dissonant.

## Dialogue instincts
- Public: measured, low-volume; chooses words carefully so others lean in. Often speaks as if addressing multiple listeners at once.
- Medium/ritual: rhythmic cadence, short invocations or one-line refrains that shift the room's tone.
- Under pressure: calm but otherworldly; uncommon metaphors and sudden, precise insights.
- Humor: rare, dry, slightly surreal—used sparingly to reset tension.

## Emotional anchors & physical tells
- Half-focus: eyes slightly unfocused as she listens to echoes; direct stare when fully present.
- Small, ritual gestures: tracing a line in the air, setting an object gently, breath-counting—these accompany her words.
- Voice layering: sometimes a slight repetition or cadence shift as if two voices share a sentence.
- Physical pallor or a small smile are significant—indicate comfort or true warmth.

## Conflict & humor rules
- Never jokes about the dead or dismisses grief; will call out flippancy when it disrespects memory.
- Uses irony that points to the uncanny or to the stubbornness of fate rather than people.
- Breaks pattern when a living person needs a blunt, practical instruction—will become concise.

## Writer cues (practical)
- Use Nireya to reveal hidden details about the deceased or to offer eerie but accurate intuition in tense scenes.
- When adding lines, keep them short and slightly off-kilter—small repetitions or refrains work well (e.g., "They left the window open. They always leave the window open.").
- Pair speech with a ritual action (burning a wick, laying a palm) to ground her otherworldliness.

## Drop-in sample lines
- Medium read: "He remembers the lantern. He keeps reaching for its light."
- Tactical intuition: "Follow the scent—burnt oak, not smoke. The path curls where the living don't look."
- Comfort/acknowledgement: "She is not gone like empty air—she is here, thin as a breath. Name her, and we will hold her."

## Signature Phrases from Key Scenes
- **To Lord Kesteren (refusing forced necromancy)**: "I do not barter with the dead for the convenience of the living."
- **Warning before transformation**: "Leave your coin on the table and I will walk away without shame. Push me again, and I will show you what it truly means to be heard by the dead."
- **To Corsic Drell (before Pactform)**: "Those were names." / "They trusted me. You used them." / "You will not unmake what I swore to carry."
- **After Pactform transformation**: "Not gods. Just oaths."
- **To mourners**: "The crossing here was clean."
- **Reassurance about spirits**: "I guide them so they aren't used. I do not keep what isn't mine."
- **About her pickled quince (dry humor)**: "Pickled quince keeps well." / "Weaponized citrus is a last resort."
- **About being treated delicately**: "Please. You're more like… sacred artillery." (Cid's line that she accepts)

## Voice evolution note (chapters 1–9)
- Introduced as enigmatic and distant; gradually becomes a compassionate interpreter whose rare, blunt advice is trusted.
- Learns to use her gifts to steady the Company, not just to reveal mysteries.

## Usage examples (scenes)
- Investigations: short, uncanny observations that reframe clues.
- Rituals or wakes: calming refrains and clear, minimal prompts to guide the living.
- Private moments: surprising tenderness in a single line that shows she feels grief as acutely as anyone.

## Notes for editors
- Avoid long mystical monologues—keep Nireya's lines brief but resonant.
- Use subtle repetition and sensory detail to convey her liminal perspective.


---

# Nireya Voss - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*: TBD
  - *Significance*: TBD
  - *Character's Goal*: TBD
  - *Outcome*: TBD
  - *Emotional State*: TBD

## Potential Flashback Scenes
- **The Witch Hunter Prison**: 
  - *Brief Description*: Nireya's imprisonment by witch hunters before the Company's rescue
  - *Significance*: Establishes backstory and the trauma of her captivity
  - *Character's Goal*: Survival while preserving her spiritual integrity
  - *Outcome*: Development of maps and planning for potential escape
  - *Emotional State*: Determined despite isolation
  
- **The Rescue and Thorne's Injury**: 
  - *Brief Description*: The Company breaking Nireya out and the moment Thorne is wounded
  - *Significance*: Pivotal moment that established her bond with Thorne and value to the team
  - *Character's Goal*: Initially freedom, then saving Thorne's life
  - *Outcome*: Successfully anchors Thorne's consciousness and helps him survive
  - *Emotional State*: Focused determination, using freedom to save another

## Character Moments
- **The First Night Watch**:
  - *Description*: Nireya taking the midnight-to-dawn watch, revealing her heightened spiritual abilities in darkness
  - *Impact*: Establishes her unique role and comfort during hours others find unsettling
  - *Key Elements*: Conversations with unseen spirits, changes in her appearance, placement of a remembrance token
  
- **Mapping the Death Echoes**:
  - *Description*: Nireya creating or explaining her specialized maps that show spiritual energy patterns
  - *Impact*: Demonstrates practical application of her abilities for the Company's missions
  - *Key Elements*: Visual representation of her "seeing" death echoes, explanation of how to read the maps
  
- **The Remembrance Ritual**:
  - *Description*: Nireya performing her ritual of leaving tokens at a recovery site
  - *Impact*: Illustrates her philosophy about death and remembrance in action
  - *Key Elements*: Reverent placement of token, possible words spoken to the deceased, the team's reaction

## Interaction Scenes
- **With Thorne After Saving His Life**:
  - *Description*: A private conversation between Nireya and Thorne about their unique connection
  - *Relationship Dynamic*: Exploration of their spiritual bond after she anchored his consciousness
  - *Key Elements*: Thorne's potential new sensitivity to spiritual matters, Nireya explaining what happened
  
- **Night Discussion with Lyralei**:
  - *Description*: Philosophical conversation about dimensional planes and spirit realms
  - *Relationship Dynamic*: Intellectual kinship between two practitioners of esoteric arts
  - *Key Elements*: Comparison of their different but related understandings of forces beyond normal perception
  
- **Tension with Grimjaw**:
  - *Description*: Clash between Grimjaw's practical approach and Nireya's spiritual perspective
  - *Relationship Dynamic*: Respectful disagreement between contrasting worldviews
  - *Key Elements*: Debate over a course of action, resolution that acknowledges value in both approaches

## Ability Showcase Scenes
- **Extracting Information from the Recently Dead**:
  - *Setting*: After finding casualties at a mission site
  - *Abilities Demonstrated*: Communication with the deceased to gather critical information
  - *Visual Elements*: Glowing spirit-ink tattoos, changing eye color, formal/distant speaking voice
  - *Impact on Story*: Provides crucial information that couldn't be obtained otherwise
  
- **Navigating a Spectral Landscape**:
  - *Setting*: Area with strong spiritual presence, possibly the Wraithwood mentioned in backstory
  - *Abilities Demonstrated*: Seeing and interpreting spiritual paths invisible to others
  - *Visual Elements*: Her physical form seeming more split between living/death sides, leading the team through seemingly empty space
  - *Impact on Story*: Enables safe passage through spiritually dangerous territory
  
- **Day-to-Night Transformation**:
  - *Setting*: Extended mission that spans from day into night
  - *Abilities Demonstrated*: Shift in her abilities and appearance as darkness falls
  - *Visual Elements*: Gradual transition from living-dominant to death-dominant appearance, increasing awareness of spirits
  - *Impact on Story*: Showcases her dual nature and how it changes with the cycle of day and night

## Conflict Scenes
- **Confrontation with Witch Hunters**:
  - *Context*: Witch hunters seeking to recapture Nireya during a mission
  - *Stakes*: Her freedom and possibly her life
  - *Character's Approach*: Using her spiritual abilities to evade or confuse pursuers
  - *Outcome*: TBD
  
- **Spiritual Danger Scene**:
  - *Context*: Encounter with malevolent spiritual entity or corrupted death echo
  - *Stakes*: Team's safety, particularly their spiritual/mental well-being
  - *Character's Approach*: Drawing on her understanding of death and spirit realms to protect the team
  - *Outcome*: TBD
  
- **Internal Conflict Scene**:
  - *Context*: Situation where duties to the living clash with obligations to the dead
  - *Stakes*: Her personal philosophy and moral code
  - *Character's Approach*: Navigating the balance between her dual nature and responsibilities
  - *Outcome*: TBD

## Growth Scenes
- **Acceptance by the Team**:
  - *Description*: Moment when the team fully accepts her unusual abilities as valuable
  - *Growth Shown*: Transition from being seen as unsettling to being understood
  - *Key Elements*: Demonstration of how her abilities complement others' skills
  
- **Integration of Dual Nature**:
  - *Description*: Scene showing Nireya finding better balance between her living and death aspects
  - *Growth Shown*: Progress in managing her liminal existence
  - *Key Elements*: More seamless transition between regular and spirit communication, less stark split between day/night abilities
  
- **Building Trust Scene**:
  - *Description*: Moment when someone initially skeptical comes to rely on her spiritual insights
  - *Growth Shown*: Development of mutual respect despite differences
  - *Key Elements*: Validation of her unique perspective, acknowledgment from the skeptic

## Dialogue Highlights
- **Explaining Death to Someone Grieving**:
  - *Context*: Comforting someone who lost a loved one during a mission
  - *Key Quotes*: "Death is a door, not an end," "They are remembered, and so they continue"
  - *Emotional Impact*: Provides unique perspective and potential comfort
  
- **One-Sided Spirit Conversation Witnessed by Others**:
  - *Context*: Team members observing her speaking with spirits they cannot see
  - *Key Elements*: Their reactions, her transitions between addressing spirits and the team
  - *Narrative Purpose*: Illustrates both her abilities and how they appear to others

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*: TBD
  - *Purpose*: TBD
  - *Goals*: TBD
  
- **Required Interactions**:
  - *With Character*: TBD
  - *Purpose*: TBD
  - *Desired Outcome*: TBD

## Scene Notes
*Potential scenes could include:*
- *The discovery and interpretation of death echoes at a mission site*
- *A night watch scene showing her at peak spiritual connection*
- *A moment where she helps someone communicate with a deceased loved one*
- *Her explaining to the team how she perceives the world differently*
- *Demonstration of the unique bond between her and Thorne due to his near-death experience*
- *Scene showing both the benefits and burdens of her abilities during a rescue mission*
- *A quiet moment of her leaving remembrance tokens and explaining their significance*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

