# Archer Venn – Profile

## Basic Information
- Full Name: Venn (surname not mentioned)
- Aliases/Nicknames: None
- Race: Elf (Wood Elf)
- Race: Elf (Wood Elf)
- Age: Not specified
- Gender: Female
- Role in Story: City Guard archer, proto-Company member
- First Appearance: Chapter 1, Scene 6 (The Vigil)
- Status: Active

## Physical Description
- Height/Build: Not specified
- Hair: Not specified
- Eyes: Not specified
- Distinguishing Features: A perpetually smug grin that doesn't reach her eyes, and a single, intricately braided strand of hair with a tarnished silver clasp. The clasp was a gift from a young hunter who died as a result of her battlefield recklessness; she keeps it as a constant, shameful reminder.
- Typical Clothing: City Guard armor
- Body Language: Alert, watchful
- Physical Condition: Combat-ready archer

## Significance
Archer Venn provides both marksmanship and morale to Thorne's patrol. Her wise-cracking nature and ability to lighten tense moments make her valuable for team cohesion. She represents the balance between professionalism and humanity needed in rescue work.

## Key Actions
- Kept overwatch during the initial vigil at Undershade
- Brought specially tuned arrows to Veyra during recovery
- Spun theories about the lantern's phoenix feather wick
- Made jokes to lighten mood ("Hospital gruel still winning the taste-test?")
- Founding Patrol: Member of Captain Thorne Brightward's original patrol that discovered Veyra at Undershade Canyon; counted among the Last Light Company's founding patrol (evidence: ch01, core/02-storyJournal.md).

## Personality Traits
- Wise-cracking sense of humor
- Professional when needed
- Skilled craftsman (tunes her own arrows)
- Loyal to her unit
- "Ever the arrow seeking release"

## Future Role
Expected to become the Company's marksman and morale booster, providing both covering fire and emotional relief during tense operations.


---

# Archer Venn – Background

## Origin
- **Birthplace**: A reclusive Wood Elf community in the High Forest.
- **Social Class**: Formerly a respected hunter and scout.
- **Cultural Background**: Elven; shaped by the long, slow rhythms of the forest and a society where actions have centuries-long consequences.

## Family
- **Family Dynamics**: Venn has not spoken to her family since her exile. She carries a deep sense of shame and loss regarding them, though she masks it with indifference.

## History
- **Childhood**: Trained from a young age in archery and woodland survival, showing immense talent. She was a respected hunter with a focus on the excellence of the bow rather than a deep connection to nature itself.
- **Formative Events**: 
  - **The Transgression (The Echoing Cave):** Venn was exiled after a disastrous mission to clear a nest of Phase Spiders. Believing the elders' slow, methodical plan was inefficient, she took a reckless "hero shot" to collapse a rock shelf onto the Broodmother. Her aim was perfect, but her prideful miscalculation of the cavern's integrity caused a much larger collapse. The falling rock killed a young hunter she had mentored and trapped several others. She was exiled because her impulsive pride proved to be a danger to the community.
- **Life in Waterdeep**: She fled to Waterdeep, a city whose frantic pace and the short memories of its inhabitants were a welcome antidote to her past. The constant, immediate problems of the city are a distraction from the timeless pain of her exile.
- **Hobbies**: She is a gambler and a flirt, deliberately seeking out fleeting, meaningless connections. This chaotic lifestyle is a way to drown out the past and live entirely in the present moment, avoiding any new bonds that could lead to the kind of loss she has already experienced.
- **Motivation for Joining the Watch**: The Watch offered a perfect meritocracy where her skill with a bow was all that mattered. It provided structure, distraction, and a way to use her deadly talents without having to form deep personal attachments.

---

# Archer Venn – Character Development

## Personality Core
- **Defining Traits**: Witty, observant, reckless, proud, deeply guarded. Her humor is a well-honed defense mechanism.
- **Core Values**: Competence, self-reliance, a buried desire for redemption.
- **Motivations**: To escape her past and find a new purpose that can overshadow her old mistakes.
- **Fears**: Being truly known, repeating the mistakes that led to her exile, forming bonds only to lose them again.
- **Internal Conflicts**: The elven desire for a meaningful, long-term purpose versus her self-destructive need for immediate, fleeting distractions.

## Character Arc
- **Starting Point**: A cynical, detached City Watch archer using her job and her vices to run from her past.
- **Catalyst Events**: Seeing her own past trauma and exile reflected in Veyra's eyes, and later witnessing Veyra's undeniable competence during the Dock Ward fire.
- **Current State**: A committed member of the Company who has found a cause worthy of her skills, though she still struggles with vulnerability and forming genuine bonds.
- **Intended Destination**: To become a key tactical asset and a trusted, if still sarcastic, friend within the Company, finally coming to terms with her past and finding a new family.

## Key Relationships
- **Relationship to Thorne**: Thorne is the stable, authoritative figure she both needs and resents. Her constant testing of his patience with her wisecracks is a subconscious way of seeking boundaries and affirmation that she belongs, even as an outsider.
- **Reaction to Veyra**:
    - **First Thought**: "That look in her eyes... I've seen it before. In a mirror." Her first thought isn't an abstract observation, but a moment of sharp, uncomfortable self-recognition. She sees a reflection of her own past pain and exile in Veyra's eyes, which is both deeply unsettling and compelling.
    - **Why She Followed**: Veyra's mission offered something she thought she'd lost forever: a purpose with long-term meaning. Patrolling the city was a distraction; this was a cause. In Veyra's unwavering focus, she saw a path to redeeming her own past. Her dedication to "no one left behind" resonated with the guilt from her exile. Following Veyra is her penance and her hope for a new legacy.


---

# Archer Venn - Relationships

## Family Bonds
- **[Family Member]**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

- **[Family Member]**:
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Romantic Relationships
- **[Character]**: 
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

- **[Character]**:
  - *Relationship Type*: [Past/Current/Potential]
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Important Moments*:

## Friendships
- **[Character]**: 
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

- **[Character]**:
  - *How Met*: 
  - *Bond Strength*: 
  - *Current Status*: 
  - *Dynamics*: 
  - *Trust Level*: 
  - *Shared Activities/Interests*:

## Professional Relationships
- **[Character]**: 
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

- **[Character]**:
  - *Nature of Relationship*: 
  - *Hierarchy*: 
  - *Dynamics*: 
  - *History*: 
  - *Current Status*: 
  - *Professional Opinion of*:

## Adversaries
- **[Character]**: 
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

- **[Character]**:
  - *Source of Conflict*: 
  - *Conflict Intensity*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Potential Resolution*:

## Relationship Evolution Tracker
- **[Date/Chapter]**: [What changed and why]
- **[Date/Chapter]**: [What changed and why]


---

# Archer Venn - Dialogue & Mannerisms

## Speech Patterns
- **Vocabulary Level**: 
- **Accent/Dialect**: 
- **Formal/Informal**: 
- **Sentence Structure**: 
- **Rhythm/Cadence**: 
- **Unique Phrases**: 
- **Verbal Tics**:

## Common Expressions
- **Greetings**: 
- **Farewells**: 
- **Exclamations**: 
- **Curses/Oaths**: 
- **When Surprised**: 
- **When Angry**: 
- **When Happy**:

## Physical Mannerisms
- **Nervous Habits**: 
- **Happy Gestures**: 
- **Angry Reactions**: 
- **Thinking Poses**: 
- **Listening Behavior**: 
- **Social Behaviors**: 
- **Personal Space Preferences**:

## Emotional Responses
- **Under Stress**: 
- **When Lying**: 
- **When Comfortable**: 
- **In Conflict**: 
- **When Vulnerable**: 
- **When Confident**: 
- **When Attracted to Someone**:

## Communication Style
- **Direct/Indirect**: 
- **Assertive/Passive**: 
- **Verbose/Taciturn**: 
- **Emotional/Reserved**: 
- **Humor Style**: 
- **Argument Approach**: 
- **Persuasion Techniques**:

## Voice Qualities
- **Pitch**: 
- **Volume**: 
- **Timbre**: 
- **Speed**: 
- **Distinctiveness**: 
- **Vocal Range**: 
- **Emotional Tells in Voice**:

## Dialogue Examples
### Casual Conversation
*[Example dialogue]*

### Under Pressure
*[Example dialogue]*

### Emotional Moment
*[Example dialogue]*

## Evolution of Speech
*[Notes on how the character's speech patterns may evolve through the story]*


---

# Archer Venn - Scene Tracker

## Major Scenes
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:
  
- **[Chapter X, Scene Y]**: 
  - *Brief Description*:
  - *Significance*:
  - *Character's Goal*:
  - *Outcome*:
  - *Emotional State*:

## Character Moments
- **Best Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Worst Moments**:
  - *Scene Reference*:
  - *Description*:
  - *Impact*:
  
- **Turning Points**:
  - *Scene Reference*:
  - *Description*:
  - *Before/After Effect*:
  
- **Revelations**:
  - *Scene Reference*:
  - *What Was Revealed*:
  - *Impact*:

## Interaction Log
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:
  
- **With [Character]**: 
  - *Chapter/Scene*:
  - *Nature of Interaction*:
  - *Outcome*:
  - *Relationship Effect*:

## Action Sequences
- **[Scene Description]**:
  - *Actions Taken*:
  - *Skills Demonstrated*:
  - *Outcome*:
  - *Character Growth*:

## Dialogue Highlights
- **[Scene Reference]**:
  - *Conversation With*:
  - *Key Quotes*:
  - *Subtext*:
  - *Impact*:

## Emotional Journey
- **[Scene Reference]**:
  - *Starting Emotion*:
  - *Ending Emotion*:
  - *Catalyst for Change*:
  - *Visible Signs*:

## Upcoming Scenes
- **Planned Appearances**:
  - *Scene/Chapter*:
  - *Purpose*:
  - *Goals*:
  
- **Required Interactions**:
  - *With Character*:
  - *Purpose*:
  - *Desired Outcome*:

## Scene Notes
*[Additional notes or scene ideas for this character]*


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

