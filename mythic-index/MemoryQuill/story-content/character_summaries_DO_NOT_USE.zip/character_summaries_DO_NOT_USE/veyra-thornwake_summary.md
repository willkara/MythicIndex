# Veyra Thornwake - Profile

## Basic Information
- **Full Name**: Veyra Thornwake
- **Aliases/Nicknames**: Commander
- **Race**: Half-Elf
- **Class**: Ranger/Cleric
- **Role in Story**: Commander of the Last Light Company
- **First Appearance**: TBD
- **Status**: Active

## Physical Description
- **Height/Build**: Wiry and strong, though thinner than expected for her role
- **Hair**: Long, ash-black hair with streaks of silver and gray despite her age, worn in tight braids on one side, the other half wild and partly shaved. Feathers, broken rings, and colored threads tied into the strands—trophies from those she's saved or buried.
- **Eyes**: One hazel eye, the other clouded from damage but still twitching with focus
- **Distinguishing Features**: The left side of her face is marred by an old, deep burn—mottled skin climbing from her jaw up past the temple, curling just under her eye, cutting through a faded tattoo that was once a swirling geometric sigil, now warped like melted glass.
- **Typical Clothing**: Weatherworn leather coat reinforced with old, mismatched armor plates—each a remnant of someone else's gear, polished and patched.
- **Body Language**: Calm, deliberate movements even in chaos
- **Physical Condition**: Scarred but resilient, battle-hardened

## Visual References
- **Associated Images**: See [Image Descriptions](images/image_descriptions.md) for detailed visual descriptions of Veyra Thornwake.

## Personality
- **Archetype**: Steadfast Leader/Survivor
- **Temperament**: Calm, collected, grave
- **Positive Traits**: Determined, loyal, protective of those in her charge
- **Negative Traits**: Possibly haunted by past trauma, burden of leadership
- **Moral Alignment**: Neutral Good (puts protection of others above all)

## Skills & Abilities
- **Expertise**: Combat medicine, survival, tracking, leadership
- **Languages**: TBD
- **Education Level**: Field-trained medic
- **Special Abilities**: Combination of ranger tracking/survival skills and cleric healing abilities

## Personal Details
- **Habits**: Collecting tokens from those she's saved or buried
- **Hobbies**: Maintaining her "record of weight" tattoo
- **Personal Quarters**: A circular room with a high, vaulted ceiling at the base of the Keep. The walls are bare, honey-colored stone, cool to the touch. The only furniture is a narrow cot with a single grey wool blanket, a heavy wooden chest, and a tall, imposing armor stand. There are no windows, only the steady, unwavering light of a single magical lantern that casts long shadows. This room is less a bedroom and more a monk's cell dedicated to a single purpose. It is silent, save for the faint, distant hum of the Bastion. The dominant feature is a massive wall covered in maps, not just of the Sword Coast, but of specific, dangerous regions: the Spine of the World, the Underdark, the Shadowfell. Red threads connect active missions, while black threads trace the paths of failures. She uses this space not just for rest, but for a nightly vigil, mentally walking the paths of her people, anticipating dangers, and mourning the lost. The small, worn wooden box on the chest contains dozens of tokens—a splinter of a shield, a single steel feather, a dried flower—each a tangible memory of a life she touched.
- **Likes**: TBD
- **Dislikes**: Abandoning the fallen
- **Fears**: Failing those who depend on her

## Combat & Tactics
- **Primary Weapons**: Dual scimitars named "Mercy" (silver-edged) and "Judgment" (cold iron-forged) - representing her dual nature as ranger and cleric
- **Secondary Weapon**: Composite longbow with salvaged strings from fallen comrades' instruments
- **Armor**: Weatherworn leather coat reinforced with old, mismatched armor plates—each a remnant of someone else's gear
- **Special Items**: Battered metal lantern that glows with soft gold light, said to reveal itself only to the lost

### Fighting Style Evolution
- **Past Style (Pre-Incident)**: Whirlwind fighter - constant movement, aggressive dual-blade dancing, relying on speed and momentum
- **Current Style (Post-Trauma)**: Tactical defender - precise, calculated strikes from defensive positions. Each movement deliberate and meaningful, no wasted motion.
- **Philosophy Shift**: From "strike fast, strike often" to "every cut must count"
- **Signature Move**: "Guardian's Stand" - defensive position that protects rescue targets while delivering precise counterstrikes
- **Combat Role**: Battlefield controller who positions herself for maximum situational awareness, prioritizing protection over aggression

## Psychological Response Matrix
- **In Crisis**: Becomes hypervigilant, compartmentalizes emotion, speaks in clipped commands. Counts everything—people, exits, threats, time.
- **During Negotiation**: Lets others talk while she reads body language for threats. Rarely speaks but when she does, it's definitive.
- **Moral Dilemma**: Weighs lives mathematically - will sacrifice principle for people. "The math is simple—more alive is better."
- **Team Conflict**: Mediates through action rather than words. "We move forward" ends most arguments.
- **Under Personal Attack**: Deflects to mission focus - personal pain is irrelevant to the objective.
- **In Victory**: Immediately shifts to casualty assessment. No celebration until all are safe and accounted for.

## Voice & Dialogue Patterns
- **Speech Style**: Short, declarative sentences. Rarely uses "I think" or "maybe" - speaks in certainties
- **Signature Phrases**: 
  - "Clock's running" (her urgency phrase)
  - "Hope is a tool. Use it."
  - Never says "leave them" - will find alternatives
- **Vocabulary**: Military efficiency mixed with medical precision. Counts constantly in speech.
- **Example Dialogue**: "Three exits. Two guards. Sixty seconds. Vera, take high. Thorne, with me."
- **Emotional Tells**: Voice gets quieter when more dangerous, never louder
- **Combat Commands**: Brief and clear - "Mercy for the fallen, Judgment for the standing"

## Notes
- A trail of ink winds up her left side, starting at her hand and vanishing beneath her armor—names written in old dialects of fallen friends, rescuees, even enemies. She calls it her "record of weight."
- Philosophy: "Hope is a tool. Use it."
- Speaks in low, deliberate tones and leads with calm gravity even in chaos
- Demonstrated her pragmatic leadership during the Stonebridge investigation by navigating the team's moral conflict, allowing them to bend the law but not break their principles. She is adept at adapting plans when new intelligence comes to light (Chapter 13).

### Public Perception
- Widely known for her "record of weight" tattoo, a rumor that is true and reinforces her personal commitment to every life.
- Rumored to have survived a dragon's fire, which explains the prominent burn scar on her face and adds to her legendary toughness.
- Respected in political circles for her direct, no-nonsense approach, which is seen as both refreshing and unnerving.


---

# Veyra Thornwake - Background

## Origin
- **Birthplace**: TBD
- **Birth Date**: TBD
- **Social Class**: TBD
- **Cultural Background**: Half-Elven heritage

## Family
- **Parents**: TBD
- **Siblings**: TBD
- **Extended Family**: TBD
- **Family Dynamics**: TBD

## History
- **Childhood**: TBD
  - *Key Events*: TBD
  - *Formative Experiences*: TBD
  
- **Education/Training**: 
  - *Institutions*: TBD
  - *Mentors*: TBD
  - *Areas of Study*: Medicine, combat tactics, survival
  
- **Adolescence/Young Adulthood**:
  - *Key Events*: Joined or was assigned to a noble adventuring party as a medic
  - *Relationships*: Formed bonds with her adventuring party
  - *Choices & Consequences*: Decision to become a field medic led to both her greatest trauma and her current purpose
  
- **Major Life Events**:
  - *Event 1*: The Undershade Canyon Ambush - The traumatic event where her original party, "The Gilded Compass," was destroyed, and she was forced to leave a comrade behind, his fate unknown.
  - *Event 2*: The Silent Oath - Her discovery by Captain Thorne Brightward and his decision to stand vigil with her, forming the foundational bond of the Last Light Company.
  - *Event 3*: Formation of the Last Light Company - The formal establishment of the Company with the iron vow that no soul would be left behind.

## Backstory Elements
- **Defining Moments**: The Undershade Canyon Ambush fundamentally changed her from a "starry-eyed medic" to the hardened commander she is today. The moment she was forced to abandon Ignis is the core of her trauma and the fuel for her mission.
- **Past Trauma**: Losing her comrades, suffering severe burns and injuries, and the unbearable guilt of being unable to save Ignis.
- **Greatest Achievements**: Founding the Last Light Company, surviving impossible odds.
- **Biggest Failures**: Being forced to leave Ignis behind in the fire, a failure that haunts her daily.
- **Secrets**: The full extent of her guilt and the possibility that she believes Ignis could still be alive somewhere.

## How They Got Here
- **Reason for Current Situation**: The traumatic experience of the Undershade Canyon Ambush, and specifically the forced abandonment of a living comrade, led to the formation of a company dedicated to ensuring no one is ever left behind again.
- **Path to Current Location**: TBD
- **Goals Prior to Story Start**: Established the Last Light Company with the mission that no one would be left behind.

## Historical Connections
- **Connection to Main Plot**: The "Scales of Pyre" cult and the fate of Ignis Emberheart are potential ongoing plot threads.
- **Connection to Other Characters**: Her bond with Thorne was forged in the immediate aftermath of the ambush.
- **Connection to Story World**: The Undershade Canyon is a place of immense personal trauma for her.

## Timeline
- Served as a medic in "The Gilded Compass," a noble adventuring party.
- The party was ambushed in Undershade Canyon by the "Scales of Pyre" cult.
- Survived the "Dragon's Breath" fire, sustaining significant injuries.
- Witnessed the deaths of three comrades and was forced to abandon a fourth, Ignis Emberheart, who was trapped but still alive.
- Was discovered by Captain Thorne Brightward while recovering the bodies of her fallen comrades.
- Established the Last Light Company with Thorne, founded on the vow that no one would be left behind.
- Currently serves as Commander of the Last Light Company.

## Personal Details
- **How She Relaxes**: She finds peace in the solitary, meticulous ritual of maintaining the mementos in her hair. It is a quiet way to honor the saved and the lost, processing her burdens through focused action rather than words.
- **Favorite Meal**: A simple, hearty bowl of mushroom and barley stew. It's the kind of practical, long-lasting trail food her first party, the Gilded Compass, used to make. The earthy taste reminds her of them, but it also carries a deeper memory: her mother used to add a pinch of savory blackroot to the stew when she was a child, a taste that is now an almost-forgotten echo of warmth and safety.
- **A Secret Skill**: She is an exceptional whistler, able to perfectly mimic birdsong. It's a skill she rarely uses now, a bittersweet echo of the person she was before the fire, sometimes emerging only when she believes she is truly alone.


---

# Veyra Thornwake - Character Development

## Personality Core
- **Defining Traits**: Determined, resilient, protective, purposeful
- **Core Values**: No one left behind, loyalty to those in her care, hope as a practical tool rather than blind optimism
- **Motivations**: Preventing others from suffering the same fate as her former comrades, honoring the memory of the fallen
- **Fears**: Failing those who depend on her, being unable to recover the fallen
- **Internal Conflicts**: Survivor's guilt vs. purpose, burden of leadership vs. personal healing
- **Contradictions**: Appears hardened but preserves hope, collects mementos of both grief and triumph

## Character Arc
- **Starting Point**: 
  - *Self-Perception*: "Starry-eyed medic" - likely optimistic, possibly naive
  - *World View*: Probably saw adventure as noble, world as fundamentally good or fair
  - *Key Relationships*: Member of a noble adventuring party, likely valued for healing skills
  
- **Catalyst Events**:
  - *Event 1*: Ambush in Undershade canyon
  - *Event 2*: Survival and recovery mission for fallen comrades
  - *Event 3*: Founding of the Last Light Company
  
- **Current State**:
  - *Self-Perception*: Battle-hardened commander with a purpose
  - *World View*: Sees world as harsh but values recovery, rescue, and remembrance
  - *Key Relationships*: Leader of the Last Light Company, carries memories of fallen comrades
  
- **Intended Destination**:
  - *Self-Perception*: TBD
  - *World View*: TBD
  - *Key Relationships*: TBD

## Growth Milestones
- **Surviving the Ambush**: 
  - *Development Noted*: Transitioning from team member to sole survivor
  - *Catalyst*: Attack in Undershade canyon
  - *Impact*: Fundamental shift in identity and purpose
  
- **Recovering the Bodies**: 
  - *Development Noted*: Determination and physical endurance beyond normal limits
  - *Catalyst*: Refusal to leave comrades behind
  - *Impact*: Formation of core value and future mission

- **Establishing the Last Light Company**:
  - *Development Noted*: Transition from survivor to leader
  - *Catalyst*: Decision to prevent others from suffering similar abandonment
  - *Impact*: Creation of new purpose and identity as Commander

## Character Flaws
- **Primary Flaws**: 
  - *Effects on Character*: Possible obsession with recovery mission, may prioritize the fallen over the living at times
  - *Effects on Others*: Could lead to risky missions for her company members
  - *Development Plan*: TBD
  
- **Secondary Flaws**: 
  - *Effects on Character*: Potential emotional distance as coping mechanism
  - *Effects on Others*: Might make personal connections difficult
  - *Development Plan*: TBD

## Secrets & Hidden Depths
- **Known to Character**:
  - *Secret 1*: TBD
  - *Secret 2*: TBD
  
- **Unknown to Character**:
  - *Truth 1*: TBD
  - *Truth 2*: TBD
  
- **Revelation Timeline**:
  - *Secret/Truth*: TBD
  - *Planned Reveal*: TBD
  - *Expected Impact*: TBD

## Key Decisions & Turning Points
- **Decision to Recover the Bodies**:
  - *Context*: Left for dead with fallen comrades
  - *Options Considered*: Save herself or recover the fallen
  - *Choice Made*: Spent days recovering each body
  - *Consequences*: Physical scarring, emotional trauma, but birth of her mission
  
- **Founding the Last Light Company**:
  - *Context*: Post-trauma recovery
  - *Options Considered*: Retire from adventuring vs. create purpose from trauma
  - *Choice Made*: Established company with mission that no one would be left behind
  - *Consequences*: Became Commander, created legacy for fallen comrades

## Development Notes
- Character represents transformation of trauma into purpose
- Her physical scars mirror emotional journey
- The "record of weight" tattoo symbolizes both burden and honor
- Collects tokens from saved and lost as physical manifestation of her mission
- Philosophy "Hope is a tool. Use it." suggests practical approach to optimism

## Psychological Profile
*   **Veyra Thornwake (The Survivor):** Her psychology is defined by trauma and purpose. The "record of weight" tattoo is a literal manifestation of her survivor's guilt; she carries the names of the lost so she doesn't have to carry their ghosts. Her calm, grave demeanor is a carefully constructed shield against the chaos she's witnessed. She leads not through charisma, but through an unshakeable, almost grim, determination. Her greatest fear is not her own death, but failing those who depend on her, which would be a repeat of her past trauma.


---

# Veyra Thornwake - Relationships

## Family Bonds
- **TBD**: 
  - *Relationship Type*: 
  - *History*: 
  - *Current Status*: 
  - *Feelings Toward*: 
  - *Tensions/Issues*: 
  - *Shared Experiences*:

## Past Relationships
- **Former Noble Adventuring Party Members**: 
  - *Relationship Type*: Comrades-in-arms, possibly friends
  - *History*: Served together until the ambush in Undershade canyon
  - *Current Status*: Deceased
  - *Feelings Toward*: Loyalty, grief, possibly survivor's guilt
  - *Tensions/Issues*: Their deaths formed the foundation of her current mission
  - *Shared Experiences*: Adventures, battles, the final ambush

## Professional Relationships
- **Captain Thorne Brightward**: 
  - *Nature of Relationship*: Comrades-in-arms; the "band of brothers" epitomized.
  - *Hierarchy*: Veyra is his Commander, and he is her unwavering Deputy. The trust is absolute.
  - *Dynamics*: Their bond is the foundational pillar of the Company, forged in tragedy and cemented by unspoken, mutual respect. They are two sides of the same coin. Veyra is the hardened idealist, fully aware she can't save everyone but honor-bound to try. Thorne is the pragmatist who makes her attempts possible. Their disagreements are purely tactical and always respectful, the debates of two commanders seeking the best path to an agreed-upon goal.
  - *History*: Thorne, then a city guard, was part of the patrol that discovered the aftermath of the Undershade canyon ambush. He found Veyra, the sole survivor, refusing to leave her fallen comrades. He stood vigil with her for two days as she buried them, and in that shared silence, he swore to follow her and help build her vision.
  - *Current Status*: Unshakably loyal. He is her most trusted confidant and tactical sounding board.
  - *Feelings Toward*: The loyalty of a soldier for a true commander and the love of a brother for his sister. He trusts her judgment completely, even when he questions the odds.

- **Vera "The Tracker" Moonwhisper**: 
  - *Nature of Relationship*: Commander and Scout
  - *Hierarchy*: Commander to specialist, with mentoring elements
  - *Dynamics*: Veyra rescued Vera and provided philosophical guidance
  - *History*: Found Vera half-dead in a blizzard, still hunting for her brother
  - *Current Status*: Trusted scout and someone Veyra personally guided
  - *Professional Opinion of*: Values her tracking skills and sees potential for healing
  - *Memorable Quote*: "Hope is a tool. Learn to use it better."

- **Brother Aldwin Gentleheart**: 
  - *Nature of Relationship*: Commander and Medic; Confidant
  - *Hierarchy*: Commander to specialist, but with a deep, almost spiritual, equality.
  - *Dynamics*: Aldwin is the only one who truly understands the immense weight Veyra carries. He acts as her unofficial confessor and quiet counsel. His tea ceremonies are a private ritual for them, a way for him to "heal the healer" and provide her with moments of peace she would never ask for herself. Their bond is one of shared witness to suffering and a mutual, unspoken understanding of the cost of their work.
  - *History*: Witnessed Veyra's dedication during a plague outbreak, which inspired him to join.
  - *Current Status*: Trusted medic and her most private confidant.
  - *Feelings Toward*: Deep respect and a quiet, protective affection. She sees him as the soul of the Company.

- **Grimjaw Ironbeard**: 
  - *Nature of Relationship*: Commander and Heavy Rescue specialist
  - *Hierarchy*: Leader to experienced team member, values his counsel
  - *Dynamics*: Respects his experience and "never loses anyone" reputation
  - *History*: TBD when they first met
  - *Current Status*: Trusted heavy rescue specialist
  - *Professional Opinion of*: Values his commitment to ensuring no one is left behind

- **Lyralei Stormcaller**: 
  - *Nature of Relationship*: Commander and Magical Support
  - *Hierarchy*: Leader to specialist
  - *Dynamics*: Values her unique magical capabilities for rescue operations
  - *History*: TBD
  - *Current Status*: Trusted magical support specialist
  - *Professional Opinion of*: Appreciates her weather magic and planar expertise

- **Marcus "The Voice" Heartbridge**: 
  - *Nature of Relationship*: Commander and Chief Negotiator.
  - *Hierarchy*: Veyra is the final authority, but she delegates all political and financial matters to him.
  - *Dynamics*: Veyra trusts Marcus's loyalty to the Company's mission, second only to Thorne's. She understands the necessity of his diplomatic maneuvering but is often impatient with its inherent subtlety and moral compromises. She wishes he could be more direct, but respects that his methods are effective in a world she has little taste for.
  - *History*: Marcus was a disillusioned diplomat who sought out Veyra, seeing in her a cause worthy of his talents. He was instrumental in the political negotiations that secured the land for the Bastion.
  - *Current Status*: A trusted and essential member of her command team, though their approaches often differ.
  - *Feelings Toward*: She trusts his results and his dedication to the Company's survival. However, she is sometimes frustrated by the necessary machinations of his job, creating a respectful but less intimate bond than the one she shares with Thorne.

- **Nireya Voss**: 
  - *Nature of Relationship*: Commander and Death-Walker
  - *Hierarchy*: Leader to specialist
  - *Dynamics*: Values her unique spiritual abilities for information gathering
  - *History*: TBD
  - *Current Status*: Trusted death-walker and spiritual specialist
  - *Professional Opinion of*: Appreciates her ability to communicate with the recently dead

- **Cidrella "Cid" Vexweld**: 
  - *Nature of Relationship*: Commander and Arcano-Engineer
  - *Hierarchy*: Leader to technical specialist
  - *Dynamics*: Values her ability to solve "impossible problems" with innovative solutions
  - *History*: TBD
  - *Current Status*: Trusted technical problem-solver
  - *Professional Opinion of*: Appreciates her specialized equipment and creative engineering

- **Korrath "Wallbreaker" Threnx**: 
  - *Nature of Relationship*: Commander and Siege Engineer
  - *Hierarchy*: Leader to engineering specialist
  - *Dynamics*: Values his structural expertise and methodical approach
  - *History*: TBD
  - *Current Status*: Trusted siege engineer
  - *Professional Opinion of*: Respects his engineering knowledge and systematic methods

- **Kaida "Lockbreaker" Shadowstep**: 
  - *Nature of Relationship*: Commander and Infiltration Specialist
  - *Hierarchy*: Leader to specialist serving community service
  - *Dynamics*: Values her infiltration expertise despite criminal background
  - *History*: TBD
  - *Current Status*: Trusted infiltration specialist
  - *Professional Opinion of*: Respects her professional competence and "redirected" purpose

## Mentors/Students
- **TBD Mentor**: 
  - *Relationship Type*: 
  - *Lessons Learned*: 
  - *Impact on Character*: 
  - *Current Status*:

- **Possible Students/Protégés in Last Light Company**: 
  - *Relationship Type*: Commander/mentor
  - *Teaching Style*: Likely practical, emphasizing survival and rescue
  - *Expectations*: High standards, adherence to the company's vow
  - *Current Status*: TBD

## Adversaries
- **Those Who Ambushed Her Party**: 
  - *Source of Conflict*: Caused the deaths of her comrades
  - *Conflict Intensity*: Severe
  - *History*: Ambushed and left her party for dead in Undershade canyon
  - *Current Status*: Unknown
  - *Feelings Toward*: Likely complex - may be seeking justice/vengeance or may have moved beyond it
  - *Potential Resolution*: TBD
- **Scales of Pyre (cult)**: The organization responsible for the ritual ambush in Undershade Canyon that triggered the catastrophe; active threat and ongoing plot antagonist (evidence: chapters/ch01, chapters/ch03).

## Relationship Evolution Tracker
- **Pre-Ambush**: Part of a noble adventuring party, likely close bonds with teammates
- **Ambush Event**: Traumatic severing of relationships through death
- **Post-Ambush**: Formation of new relationships through the Last Light Company
- **Present Day**: Commander with responsibility for her company members


---

# Veyra Thornwake — Dialogue & Psyche

## Core temperament
Deliberate, stoic, mission-first. Trauma and grief have honed her words into economy; every sentence carries purpose or promise.

## Dialogue instincts
- Public / command: short, declarative, precise. Uses concrete verbs and measured cadence; rarely wastes words.
- Private / confession: single-line metaphors or compact aphorisms—slightly lyrical but still restrained.
- Under pressure: voice drops to a low, controlled register; calm replaces panic.
- With close companions: allows very rare dry humor or softened cadence, but keeps emotional displays minimal.

## Emotional anchors & physical tells
- Lantern-hand: touching, adjusting, or resting fingers on her lantern = gathering resolve.
- Scar-hand: touching the burned cheek or forearm = memory surfacing; momentary withdrawal.
- Inhale-before-order: a slow, deep breath before issuing commands signals focus.
- Micro-smile: an almost invisible upturn that indicates genuine warmth; rare and significant.
- Abrupt silence: when she goes quiet, something internal is happening—use action to show consequence.

## Conflict & humor rules
- Avoids joking about loss, sacrifice, or survivors' guilt; intervenes to cut off such levity.
- Uses self-directed, dry deflection when praised (minimizes attention).
- Breaks pattern only with extreme fatigue or intense intimacy—these breaks should feel like a crack letting light through.

## Writer cues (practical)
- Commands: use short imperative sentences with clear targets. Structure: action → direct order → brief expected consequence.
- Explanations: keep them short; split across turns or have Thorne paraphrase longer points.
- Comforting lines: one compact image or aphorism, followed by silence or a physical gesture (e.g., sets lantern between hands).
- Vulnerability: deliver a single, unadorned confession line and let surrounding action show emotional fallout.
- When adding dialogue between characters, let Veyra's lines steer the scene. Her minimalism creates space for others to speak.

## Drop-in sample lines (from Chapters 1-3)
- **On duty vs. hope:** "Drink's on you if you keep both hands on the map."
- **On her scars:** "I was never beautiful. I was useful. The scars keep me useful."
- **On remembrance:** "Then I'll be ugly enough to never forget."
- **On pain:** "Good. Pain means I'm still here."
- **On leadership:** "Legends are for the dead."
- **On her new purpose:** "To make sure no one else burns alone."
- **On promises:** "Promises burn."
- **Private vow:** "Not left. Never left."

## Voice evolution note (chapters 1–9)
- Chapter 1: raw, jagged; language shows shock and sharp fragments.
- Chapters 2–5: resolves into terse leadership—decisive, directive.
- Chapters 6–9: remains concise but softens in private scenes; short aphorisms and one-line confessions appear as signs of emerging acceptance and steady leadership.

## Usage examples (scenes)
- Leading a rescue: minimal words, clear orders; pair each line with a visible action (points, breath, set of the lantern).
- Consoling survivors: a single sentence that reframes duty as promise, then silence.
- Tension with authorities: measured, precise rebuttals that avoid moralizing—focus on facts and outcomes.

## Notes for editors
- Preserve the economy of her speech. Lengthy monologues feel out of character.
- When expanding scenes, use Veyra's restraint to create tension—other characters can fill the silence.
- Keep metaphors sparse and concrete (wind, stone, lantern, fire).


---

# Veyra "The Lanternlight" Thornwake - Scene Tracker

## Major Scenes

### Chapter 1 – Ash and Compass <!-- slug: ch1-ash-compass -->
- **Scene 1**: Leading the Gilded Compass into Undershade Canyon
- **Scene 2**: Battle with the Scales of Pyre cultists
- **Scene 3**: Catastrophic ritual, watching companions die
- **Scenes 4-5**: Three days collecting bodies, discovery by Thorne's patrol

### Chapter 2 – The Lantern Ward <!-- slug: ch2-lantern-ward -->
- **Scene 1**: Recovery in Brightstone Healers' Hall, refusing magical healing
- **Scene 2**: Interaction with Dokra, discussion of scars and remembrance
- **Scene 3**: Receiving patrol's gifts and tokens of fallen companions

### Chapter 3 – Echoes in the City <!-- slug: ch3-echoes-city -->
- **Vignette 5**: Balcony conversation with Thorne, planning the future

### Chapter 4 – The First Spark <!-- slug: ch4-first-spark -->
- **Scene 1**: Dock Ward fire, defying Thorne to join the response
- **Scene 2**: Taking strategic command, using canyon experience
- **Scene 3**: Recognizing the need for specialists

### Chapter 6 – The Healer's Calling <!-- slug: ch6-healers-calling -->
- **Scene 3**: Witnessing Aldwin's work, forming bond with him
- **Scene 4**: Officially recruiting Aldwin as first specialist

### Chapter 7 – The Weight of the World <!-- slug: ch7-weight-world -->
- **Scene 1**: Facing the mine disaster, recognizing limitations
- **Scene 3**: Deciding to seek Grimjaw's expertise
- **Scene 4**: Witnessing Grimjaw's mastery, offering him a place

### Chapter 10 – The Tracker in the Snow <!-- slug: ch10-tracker-snow -->
- **Scene 1**: Receiving mission to find missing boy in winter ruins
- **Scene 2**: Experiencing rare moment of laughter at misunderstanding
- **Scene 4**: Discovering Vera Moonwhisper, witnessing animal protection
- **Scene 6**: Bonding with Vera over shared trauma of lost companions
- **Scene 7**: Trusting Vera to help with missing children despite recent recovery
- **Scene 9**: Accepting Vera's lethal justice against trafficker
- **Scene 9**: Officially recruiting Vera into the Last Light Company
- **Epilogue**: Welcoming Vera to her new quarters, leading found-family dinner

### Chapter 12 – The Wayward Compass <!-- slug: ch12-wayward-compass -->
- **Scene 1**: Leading a supply run, rescuing civilians on the Trade Way.
- **Scene 2**: Standoff with Black Hawk bandits at the Wayward Compass inn.
- **Scene 2**: Witnessing Marcus Heartbridge defuse the situation with information, not violence.

### Chapter 13 – An Honest Coin <!-- slug: ch13-honest-coin -->
- **Scene 1**: Debriefing the encounter with Marcus.
- **Scene 1**: Personal moment recalling her mother's cooking.
- **Scene 2**: Making the final decision to investigate Marcus's claim rather than perform a heist.

## Character Moments

### Best Moments
- Refusing magical healing to keep scars as remembrance (Ch. 2)
- Taking command during Dock Ward fire (Ch. 4)
- Finding purpose through helping others (Ch. 4)
- Creating the Last Light Company concept (Ch. 4)
- Genuine laughter during Thomas Blackwood misunderstanding (Ch. 10)

### Worst Moments
- Watching companions die in Undershade Canyon (Ch. 1)
- Three days alone with the dead (Ch. 1)
- Facing limitations during mine disaster (Ch. 7)

### Turning Points
- Decision to create a rescue company (Ch. 3)
- Accepting leadership role (Ch. 4)
- "Hope is a tool" philosophy shared with Vera (Ch. 10)

## Interaction Log

### With Thorne Brightward
- Chapter 1: Rescued by his patrol
- Chapter 2: His vigil during her recovery
- Chapter 3: Planning the Company's future
- Chapter 4: Tension over her participation in the fire
- Chapter 10: Professional partnership during winter missions

### With Aldwin Gentleheart
- Chapter 6: Recruiting him after witnessing his gentle passage
- Chapter 10: Trusting his medical expertise with Vera

### With Grimjaw Ironbeard
- Chapter 7: Recruiting him after the mine disaster
- Chapter 10: Including him in Vera's rescue mission for his expertise

### With Vera Moonwhisper
- Chapter 10: Rescued her from winter, recognized kindred spirit, recruited her

## Upcoming Scenes

### Planned Appearances
- Continuing to build the Last Light Company
- Leading further rescue missions
- Potential confrontation with the Scales of Pyre cult
- Investigation into the Silent Hand traffickers with Vera

### Required Interactions
- Continue developing command relationship with specialists
- Further exploration of "hope as a tool" philosophy
- Possible confrontation with officials over vigilante actions


---

Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.


---

