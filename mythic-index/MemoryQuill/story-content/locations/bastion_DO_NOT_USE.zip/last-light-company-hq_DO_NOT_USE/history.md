# The Bastion of Last Light - History

## Origins
The land upon which the Bastion sits was, for decades, an undeveloped and overlooked hillside on the outskirts of Waterdeep. Its strategic location overlooking the Trade Way and its network of natural caves made it a temporary haven for smugglers and other transients, giving the area a poor reputation. The land was technically owned by the city but was largely ignored by the authorities.

## Acquisition
Following the formal establishment of the Last Light Company, Commander Veyra Thornwake identified the hillside as the ideal location for a permanent headquarters. It offered defensibility, space for expansion, and proximity to the city without being entangled in its daily politics.

**Marcus Heartbridge** spearheaded the negotiations with the Lords of Waterdeep. He framed the project as a significant public good: the Company would not only fund the entire construction but would also take responsibility for securing a historically lawless area, improving the safety of the nearby trade routes. After a lengthy process and a few key demonstrations of the Company's value, the city granted them a perpetual lease on the land.

## Construction
The construction of the Bastion was a monumental undertaking and the first great project of the newly-formed Company. The vision was not to impose a fortress upon the land, but to build one in harmony with it.

- **Lead Architect & Engineer**: **Korrath "Wallbreaker" Threnx** was the undisputed master of the project. Drawing on his extensive knowledge of siege-craft and structural engineering, he designed the iconic terraced layout, integrating the buildings directly into the hillside's natural contours. His work is a "redemption project" on a grand scale—building a place of sanctuary using the same skills he once used for destruction.

- **Systems & Arcane Engineering**: **Cidrella "Vexxy" Vexweld** was the genius behind the Bastion's integrated systems. She designed the mechanical lifts of the Open Path, the complex arcane machinery of Lyralei's Aerie, the secure Undercroft passages, and the subtle, non-lethal magical defenses that protect the compound.

- **A Company Effort**: Every member of the Last Light Company contributed. Grimjaw helped quarry the stone, Aldwin planned the gardens, and the others provided the labor and specialized skills needed to raise the walls, furnish the halls, and turn a barren hillside into a home. This shared effort forged the Company's early bonds and solidified their identity.

## Current State
Completed and fully operational, the Bastion of Last Light stands as a testament to the Company's vision, resources, and collective will. It is a symbol of hope, built from the ground up by the very people who now call it home and use it as a base to extend that hope to others.
