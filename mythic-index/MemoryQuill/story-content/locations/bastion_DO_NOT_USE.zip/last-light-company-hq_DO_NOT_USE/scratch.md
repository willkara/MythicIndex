Unstructured notes, maps, ambiance ideas, etc.
