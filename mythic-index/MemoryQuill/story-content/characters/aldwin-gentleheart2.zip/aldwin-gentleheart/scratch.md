Unstructured bullets, half-ideas, snippets, TODOs – promoted or purged via Scratch Workflow.
